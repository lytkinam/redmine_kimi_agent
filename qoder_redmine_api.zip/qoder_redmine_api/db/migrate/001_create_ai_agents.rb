class CreateAiAgents < ActiveRecord::Migration[7.0]
  def change
    create_table :ai_agents do |t|
      t.string  :name,         null: false
      t.string  :agent_type,   null: false, default: 'custom'
      t.string  :endpoint_url, null: false
      t.string  :protocol,     null: false, default: 'chat_completions'
      t.string  :api_key
      t.string  :model_name
      t.text    :system_prompt
      t.boolean :active,       null: false, default: true
      t.timestamps null: false
    end

    add_index :ai_agents, :agent_type
    add_index :ai_agents, :active
  end
end
