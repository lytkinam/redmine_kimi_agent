class CreateAiAgentDispatches < ActiveRecord::Migration[7.0]
  def change
    create_table :ai_agent_dispatches do |t|
      t.integer  :issue_id,         null: false
      t.integer  :ai_agent_id,      null: false
      t.integer  :triggered_by,     null: false
      t.string   :status,           null: false, default: 'pending'
      t.text     :request_payload
      t.text     :response_payload
      t.integer  :journal_id
      t.datetime :dispatched_at
      t.datetime :completed_at
      t.timestamps null: false
    end

    add_index :ai_agent_dispatches, :issue_id
    add_index :ai_agent_dispatches, :ai_agent_id
    add_index :ai_agent_dispatches, :status
    add_index :ai_agent_dispatches, :triggered_by
    add_foreign_key :ai_agent_dispatches, :issues,    column: :issue_id
    add_foreign_key :ai_agent_dispatches, :ai_agents, column: :ai_agent_id
  end
end
