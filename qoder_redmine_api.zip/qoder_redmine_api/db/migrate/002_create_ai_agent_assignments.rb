class CreateAiAgentAssignments < ActiveRecord::Migration[7.0]
  def change
    create_table :ai_agent_assignments do |t|
      t.integer :user_id,       null: false
      t.integer :ai_agent_id,   null: false
      t.boolean :auto_dispatch, null: false, default: false
      t.timestamps null: false
    end

    add_index :ai_agent_assignments, :user_id, unique: true
    add_index :ai_agent_assignments, :ai_agent_id
    add_foreign_key :ai_agent_assignments, :users,     column: :user_id
    add_foreign_key :ai_agent_assignments, :ai_agents, column: :ai_agent_id
  end
end
