# Extends ai_agents to support Kimi Code CLI Web Interface:
# - Adds kimi_web_ws as a valid protocol value
# - Adds kimi_web_session_id for optional persistent session reuse
# - Adds kimi_web_work_dir for setting the work directory of the Kimi session
class AddKimiWebToAiAgents < ActiveRecord::Migration[7.0]
  def change
    add_column :ai_agents, :kimi_web_session_id, :string, comment: 'Kimi session UUID (reused across dispatches)'
    add_column :ai_agents, :kimi_web_work_dir,   :string, comment: 'Work directory for new Kimi sessions'
    add_column :ai_agents, :kimi_web_timeout,    :integer, default: 120, comment: 'WebSocket wait timeout in seconds'
  end
end
