# Agent Types and Configurations

<cite>
**Referenced Files in This Document**
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [init.rb](file://init.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the AI agent system for Redmine, focusing on the five supported agent types and their configurations. It covers endpoint URLs, API keys, model names, and protocol specifications, and clarifies the differences between chat_completions, responses, and kimi_web_ws protocols. Practical setup examples and step-by-step instructions are provided for each agent type, along with validation rules and behavioral effects of different configurations.

## Project Structure
The agent system spans models, controllers, clients, migrations, plugin settings, and Kimi Web reference materials. The following diagram shows how the major components relate to each other.

```mermaid
graph TB
subgraph "Models"
A["AiAgent<br/>validations, templates, helpers"]
B["AiAgentAssignment<br/>user ↔ agent mapping"]
C["AiAgentDispatch<br/>dispatch log"]
end
subgraph "Controllers"
D["AiAgentsController<br/>CRUD + test_connection"]
E["AiAgentAssignmentsController<br/>assign agents to users"]
F["AiAgentDispatchesController<br/>manual dispatch from issue"]
end
subgraph "Clients"
G["AgentClient<br/>OpenAI-compatible APIs"]
H["KimiWebClient<br/>WebSocket + REST for Kimi"]
end
subgraph "Settings"
S["Plugin Settings Partial<br/>base URL, timeouts"]
end
subgraph "Kimi Web"
R["API Reference<br/>REST + WS schema"]
W["WS Script<br/>CLI client"]
end
A --> D
B --> E
C --> F
D --> G
D --> H
G --> R
H --> R
S --> G
S --> H
W --> H
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [ai_agents_controller.rb:1-109](file://app/controllers/ai_agents_controller.rb#L1-L109)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [api-reference.md:1-776](file://kimi-web/reference/api-reference.md#L1-L776)
- [kimi-web-ws.py:1-363](file://kimi-web/scripts/kimi-web-ws.py#L1-L363)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [ai_agents_controller.rb:1-109](file://app/controllers/ai_agents_controller.rb#L1-L109)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [api-reference.md:1-776](file://kimi-web/reference/api-reference.md#L1-L776)

## Core Components
- AiAgent: Defines agent types, protocols, validations, system prompt templates, and helper predicates. It also resolves system prompts using Redmine settings and issue context.
- AgentClient: Implements OpenAI-compatible chat_completions and responses protocols, builds payloads, posts to endpoints, parses responses, and handles errors.
- KimiWebClient: Implements a dedicated client for Kimi Code CLI Web Interface using REST to manage sessions and WebSocket JSON-RPC for streaming conversations.
- Controllers: Provide CRUD for agents, connection testing, assignment management, and manual dispatch from issues.
- Migrations: Define the schema for agents, assignments, dispatch logs, and Kimi-specific fields.
- Plugin Settings: Configure base Redmine API URL and default timeout used by clients.

Key highlights:
- Supported agent types: hermes, pi, qoder, kimi_web, custom.
- Supported protocols: chat_completions, responses, kimi_web_ws.
- Model name is required for non-Kimi Web agents.
- System prompt templates are provided per agent type and can be overridden.

**Section sources**
- [ai_agent.rb:2-15](file://app/models/ai_agent.rb#L2-L15)
- [ai_agent.rb:53-140](file://app/models/ai_agent.rb#L53-L140)
- [agent_client.rb:22-42](file://lib/redmine_ai_agent/agent_client.rb#L22-L42)
- [kimi_web_client.rb:21-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L58)
- [001_create_ai_agents.rb:3-12](file://db/migrate/001_create_ai_agents.rb#L3-L12)
- [004_add_kimi_web_to_ai_agents.rb:7-9](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L7-L9)
- [_ai_agent_settings.html.erb:12-30](file://app/views/settings/_ai_agent_settings.html.erb#L12-L30)

## Architecture Overview
The agent architecture integrates three distinct pathways:
- OpenAI-compatible agents (chat_completions and responses): Use a unified HTTP client to send structured payloads and parse standardized response formats.
- Kimi Web agents (kimi_web_ws): Use a specialized client that manages REST sessions and a WebSocket JSON-RPC loop.
- Redmine integration: System prompts and issue context are injected into agent requests, enabling autonomous actions against the Redmine REST API.

```mermaid
sequenceDiagram
participant U as "User"
participant C as "AiAgentsController"
participant AC as "AgentClient"
participant KC as "KimiWebClient"
participant EP as "External Agent Endpoint"
U->>C : "Test connection"
alt "kimi_web_ws"
C->>KC : "Call health check"
KC-->>C : "{ ok, status, body }"
else "OpenAI-compatible"
C->>AC : "Build payload (chat_completions/responses)"
AC->>EP : "POST /v1/... (Authorization : Bearer)"
EP-->>AC : "JSON response"
AC-->>C : "{ ok, status, body }"
end
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)

## Detailed Component Analysis

### Agent Types and Templates
- hermes: Designed for autonomous Redmine issue resolution with tool-calling capabilities.
- pi: Coding-focused agent with concise Redmine API usage.
- qoder: Step-by-step coding assistant aligned with project conventions.
- kimi_web: Native integration with Kimi Code CLI Web Interface via WebSocket.
- custom: Generic OpenAI-compatible agent with customizable system prompt.

Behavioral differences:
- Tool-calling is enabled for hermes/pi but disabled for qoder and kimi_web.
- System prompts are resolved per agent type unless overridden.

Validation rules:
- agent_type must be one of the supported types.
- protocol must be one of the supported protocols.
- endpoint_url must be a valid http/https URL.
- model_name is required for non-Kimi Web agents.

**Section sources**
- [ai_agent.rb:2-3](file://app/models/ai_agent.rb#L2-L3)
- [ai_agent.rb:10-13](file://app/models/ai_agent.rb#L10-L13)
- [ai_agent.rb:53-140](file://app/models/ai_agent.rb#L53-L140)

### Protocols: chat_completions vs responses vs kimi_web_ws
- chat_completions:
  - Endpoint: /v1/chat/completions
  - Payload: model, messages, tools (when applicable)
  - Response parsing: choices[0].message.content
- responses:
  - Endpoint: /v1/responses
  - Payload: model, input, instructions
  - Response parsing: output array or output_text field
- kimi_web_ws:
  - Uses REST to create/manage sessions
  - Uses WebSocket JSON-RPC for streaming conversation
  - Delegates entirely to KimiWebClient

```mermaid
flowchart TD
Start(["Select Protocol"]) --> CC{"chat_completions?"}
CC --> |Yes| BuildCC["Build chat_completions payload"]
CC --> |No| Resp{"responses?"}
Resp --> |Yes| BuildResp["Build responses payload"]
Resp --> |No| KW["Use KimiWebClient"]
BuildCC --> Post["POST /v1/chat/completions"]
BuildResp --> PostResp["POST /v1/responses"]
KW --> WS["WebSocket JSON-RPC loop"]
Post --> ParseCC["Extract text from choices[0].message.content"]
PostResp --> ParseResp["Extract text from output/output_text"]
WS --> Done(["Return text + raw"])
ParseCC --> Done
ParseResp --> Done
```

**Diagram sources**
- [agent_client.rb:231-258](file://lib/redmine_ai_agent/agent_client.rb#L231-L258)
- [agent_client.rb:58-77](file://lib/redmine_ai_agent/agent_client.rb#L58-L77)
- [kimi_web_client.rb:142-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L282)

**Section sources**
- [agent_client.rb:231-258](file://lib/redmine_ai_agent/agent_client.rb#L231-L258)
- [agent_client.rb:58-77](file://lib/redmine_ai_agent/agent_client.rb#L58-L77)
- [kimi_web_client.rb:142-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L282)

### Configuration Parameters by Agent Type
- Common parameters:
  - name: Unique agent name
  - agent_type: hermes, pi, qoder, kimi_web, custom
  - endpoint_url: Base URL for the agent API (http/https)
  - protocol: chat_completions, responses, kimi_web_ws
  - api_key: Authorization token (Bearer)
  - model_name: Model identifier (required for non-Kimi Web)
  - system_prompt: Optional override of default template
  - active: Enable/disable agent
- Kimi Web-specific parameters (added via migration):
  - kimi_web_session_id: Reuse an existing session
  - kimi_web_work_dir: Set working directory for new sessions
  - kimi_web_timeout: WebSocket timeout in seconds

Validation and defaults:
- Defaults: agent_type='custom', protocol='chat_completions'
- Required fields: name, agent_type, endpoint_url, protocol, model_name (unless kimi_web_ws)

**Section sources**
- [001_create_ai_agents.rb:4-11](file://db/migrate/001_create_ai_agents.rb#L4-L11)
- [004_add_kimi_web_to_ai_agents.rb:7-9](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L7-L9)
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)

### Practical Setup Examples

#### Example A: Hermes (OpenAI-compatible, chat_completions)
- Purpose: Autonomous Redmine issue resolution with tool-calling.
- Configuration:
  - agent_type: hermes
  - protocol: chat_completions
  - endpoint_url: https://api.openai.com
  - api_key: your-openai-api-key
  - model_name: gpt-4o
- Behavior:
  - System prompt includes Redmine API access and tool definitions.
  - Tools are attached automatically for hermes/pi.

**Section sources**
- [ai_agent.rb:53-74](file://app/models/ai_agent.rb#L53-L74)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

#### Example B: Pi (OpenAI-compatible, responses)
- Purpose: Coding tasks with concise API usage.
- Configuration:
  - agent_type: pi
  - protocol: responses
  - endpoint_url: https://api.openai.com
  - api_key: your-openai-api-key
  - model_name: o1-preview
- Behavior:
  - Uses responses API payload and parses output_text or output array.

**Section sources**
- [ai_agent.rb:76-89](file://app/models/ai_agent.rb#L76-L89)
- [agent_client.rb:71-77](file://lib/redmine_ai_agent/agent_client.rb#L71-L77)
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

#### Example C: Qoder (OpenAI-compatible, chat_completions)
- Purpose: Step-by-step coding aligned with project conventions.
- Configuration:
  - agent_type: qoder
  - protocol: chat_completions
  - endpoint_url: https://api.openai.com
  - api_key: your-openai-api-key
  - model_name: gpt-4o
- Behavior:
  - System prompt tailored for Qoder; tool-calling disabled.

**Section sources**
- [ai_agent.rb:91-105](file://app/models/ai_agent.rb#L91-L105)
- [agent_client.rb:119-124](file://lib/redmine_ai_agent/agent_client.rb#L119-L124)

#### Example D: Kimi Web (kimi_web_ws)
- Purpose: Native integration with Kimi Code CLI Web Interface.
- Configuration:
  - agent_type: kimi_web
  - protocol: kimi_web_ws
  - endpoint_url: http://127.0.0.1:5494
  - api_key: optional token
  - kimi_web_session_id: optional pinned session
  - kimi_web_work_dir: optional work directory for new sessions
  - kimi_web_timeout: 120
- Behavior:
  - Creates/restores sessions via REST.
  - Streams conversation via WebSocket JSON-RPC.

**Section sources**
- [ai_agent.rb:107-125](file://app/models/ai_agent.rb#L107-L125)
- [kimi_web_client.rb:66-100](file://lib/redmine_ai_agent/kimi_web_client.rb#L66-L100)
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [api-reference.md:341-420](file://kimi-web/reference/api-reference.md#L341-L420)

#### Example E: Custom OpenAI-Compatible (generic)
- Purpose: Generic OpenAI-compatible provider.
- Configuration:
  - agent_type: custom
  - protocol: chat_completions or responses
  - endpoint_url: https://api.provider.com
  - api_key: your-provider-api-key
  - model_name: model-id
  - system_prompt: optional custom prompt
- Behavior:
  - Uses provided system prompt; tools depend on protocol.

**Section sources**
- [ai_agent.rb:127-139](file://app/models/ai_agent.rb#L127-L139)
- [agent_client.rb:58-77](file://lib/redmine_ai_agent/agent_client.rb#L58-L77)

### Step-by-Step Setup Instructions

#### Setup for OpenAI-compatible Agents (Hermes/Pi/Qoder/Custom)
1. Configure plugin settings:
   - Set redmine_api_base_url to your Redmine instance URL.
   - Adjust default_timeout if needed.
2. Create an agent:
   - Choose agent_type and protocol.
   - Fill endpoint_url and api_key.
   - Provide model_name (required for non-Kimi Web).
   - Optionally override system_prompt.
3. Test connection:
   - Use the test_connection endpoint to validate connectivity and credentials.
4. Assign agent to a user:
   - Link a user to the agent via AiAgentAssignments.
5. Dispatch:
   - Trigger dispatch from an issue or via the dispatch controller.

**Section sources**
- [_ai_agent_settings.html.erb:12-30](file://app/views/settings/_ai_agent_settings.html.erb#L12-L30)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_assignments_controller.rb:10-26](file://app/controllers/ai_agent_assignments_controller.rb#L10-L26)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)

#### Setup for Kimi Web
1. Install and run Kimi Code CLI Web Interface locally or remotely.
2. Configure agent:
   - agent_type: kimi_web
   - protocol: kimi_web_ws
   - endpoint_url: Base URL of the Kimi web interface (e.g., http://127.0.0.1:5494)
   - api_key: optional token (passed as Authorization or query param)
   - kimi_web_session_id: optional pinned session
   - kimi_web_work_dir: optional work directory for new sessions
   - kimi_web_timeout: adjust as needed
3. Test connection:
   - Use test_connection to hit /healthz for Kimi Web.
4. Verify WebSocket:
   - Use the provided Python script to connect and stream messages.

**Section sources**
- [kimi_web_client.rb:66-100](file://lib/redmine_ai_agent/kimi_web_client.rb#L66-L100)
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [ai_agents_controller.rb:49-62](file://app/controllers/ai_agents_controller.rb#L49-L62)
- [api-reference.md:341-420](file://kimi-web/reference/api-reference.md#L341-L420)

## Dependency Analysis
The following diagram shows how models, controllers, and clients depend on each other and on external systems.

```mermaid
classDiagram
class AiAgent {
+name
+agent_type
+endpoint_url
+protocol
+api_key
+model_name
+system_prompt
+active
+kimi_web_session_id
+kimi_web_work_dir
+kimi_web_timeout
+resolved_system_prompt(issue)
}
class AgentClient {
+call(issue, triggered_by)
-build_payload(issue)
-post_to_agent(payload)
-extract_text(raw)
}
class KimiWebClient {
+call(issue)
-ensure_session!
-websocket_prompt(session_id, prompt_text)
}
class AiAgentsController {
+test_connection()
}
AiAgent <.. AiAgentsController : "used by"
AiAgentsController --> AgentClient : "delegates for CC/Responses"
AiAgentsController --> KimiWebClient : "delegates for Kimi Web"
AgentClient --> AiAgent : "reads config"
KimiWebClient --> AiAgent : "reads config"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:22-42](file://lib/redmine_ai_agent/agent_client.rb#L22-L42)
- [kimi_web_client.rb:31-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L58)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:22-42](file://lib/redmine_ai_agent/agent_client.rb#L22-L42)
- [kimi_web_client.rb:31-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L58)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

## Performance Considerations
- Timeout tuning:
  - Default timeout is used by the HTTP client; plugin settings allow adjustment.
  - Kimi Web uses a configurable timeout for WebSocket waits.
- Payload size:
  - Issue context is appended to prompts; very large descriptions/journals increase latency.
- Concurrency:
  - Kimi Web restricts one prompt per session at a time; avoid overlapping prompts.
- Network reliability:
  - Use HTTPS endpoints and monitor for timeouts or invalid JSON responses.

**Section sources**
- [agent_client.rb:202-209](file://lib/redmine_ai_agent/agent_client.rb#L202-L209)
- [kimi_web_client.rb:35-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L35-L36)
- [api-reference.md:733-734](file://kimi-web/reference/api-reference.md#L733-L734)

## Troubleshooting Guide
Common issues and resolutions:
- Invalid endpoint URL:
  - Ensure endpoint_url uses http or https scheme.
- Authentication failures:
  - Verify api_key and bearer token format.
- Protocol mismatch:
  - Confirm protocol matches the agent’s intended API (/v1/chat/completions vs /v1/responses).
- Kimi Web connection problems:
  - Check /healthz availability and token/query param handling.
  - Validate WebSocket handshake and session state transitions.
- Timeout errors:
  - Increase default_timeout or kimi_web_timeout depending on workload.
- Invalid JSON or non-2xx responses:
  - Inspect raw response bodies and status codes.

**Section sources**
- [ai_agent.rb:11-13](file://app/models/ai_agent.rb#L11-L13)
- [agent_client.rb:223-229](file://lib/redmine_ai_agent/agent_client.rb#L223-L229)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [kimi_web_client.rb:208-209](file://lib/redmine_ai_agent/kimi_web_client.rb#L208-L209)

## Conclusion
The agent system supports diverse providers and protocols, enabling flexible automation of Redmine workflows. By selecting the appropriate agent type and protocol, configuring endpoints and credentials, and leveraging system prompts, teams can achieve autonomous issue handling. Kimi Web offers a native integration path with advanced streaming and session management, while OpenAI-compatible agents provide broad compatibility with standardized APIs.

## Appendices

### Agent Type Validation Rules
- agent_type must be one of: hermes, pi, qoder, kimi_web, custom.
- protocol must be one of: chat_completions, responses, kimi_web_ws.
- endpoint_url must be a valid http/https URL.
- model_name is required unless protocol is kimi_web_ws.

**Section sources**
- [ai_agent.rb:2-13](file://app/models/ai_agent.rb#L2-L13)

### Database Schema Summary
- ai_agents: Stores agent definitions and Kimi-specific fields.
- ai_agent_assignments: Links users to agents.
- ai_agent_dispatches: Logs dispatch attempts and outcomes.

**Section sources**
- [001_create_ai_agents.rb:3-12](file://db/migrate/001_create_ai_agents.rb#L3-L12)
- [004_add_kimi_web_to_ai_agents.rb:7-9](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L7-L9)
- [ai_agent_assignments_controller.rb:3-13](file://app/controllers/ai_agent_assignments_controller.rb#L3-L13)
- [ai_agent_dispatches_controller.rb:3-21](file://app/controllers/ai_agent_dispatches_controller.rb#L3-L21)