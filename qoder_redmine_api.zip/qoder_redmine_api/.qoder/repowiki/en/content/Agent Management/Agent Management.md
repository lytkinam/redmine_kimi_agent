# Agent Management

<cite>
**Referenced Files in This Document**
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent.rb (view)](file://app/views/ai_agents/_form.html.erb)
- [ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [init.rb](file://init.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the AI Agent Management functionality for integrating autonomous AI agents with Redmine. It covers how agents are created and configured (including agent types, protocols, endpoints, and system prompts), how they are managed through the admin interface, and how they operate during issue lifecycles. It also documents the internal clients that communicate with AI providers (OpenAI-compatible APIs and Kimi Web), and provides best practices for performance and reliability.

## Project Structure
The plugin extends Redmine with models, controllers, views, migrations, and client libraries to manage AI agents and dispatch them to work on issues.

```mermaid
graph TB
subgraph "Admin UI"
VForm["Views: ai_agents/_form.html.erb"]
VIndex["Views: ai_agents/index.html.erb"]
VEdit["Views: ai_agents/edit.html.erb"]
VSettings["Views: settings/_ai_agent_settings.html.erb"]
end
subgraph "Controllers"
CAgents["AiAgentsController"]
CAsgn["AiAgentAssignmentsController"]
CDisp["AiAgentDispatchesController"]
end
subgraph "Models"
MAgent["AiAgent"]
MAsign["AiAgentAssignment"]
MDisp["AiAgentDispatch"]
end
subgraph "Lib Clients"
LAgent["RedmineAiAgent::AgentClient"]
LKimi["RedmineAiAgent::KimiWebClient"]
LTool["RedmineAiAgent::RedmineApiSkill"]
end
subgraph "Routing & Plugin"
Routes["config/routes.rb"]
Init["init.rb"]
end
subgraph "Database"
Mig1["001_create_ai_agents.rb"]
Mig2["002_create_ai_agent_assignments.rb"]
Mig3["003_create_ai_agent_dispatches.rb"]
Mig4["004_add_kimi_web_to_ai_agents.rb"]
end
VForm --> CAgents
VIndex --> CAgents
VEdit --> CAgents
VSettings --> Init
CAgents --> MAgent
CAsgn --> MAsign
CDisp --> MDisp
MAgent --> LAgent
MAgent --> LKimi
LAgent --> LTool
Init --> Routes
Init --> MAgent
Init --> MAsign
Init --> MDisp
MAgent --> Mig1
MAsign --> Mig2
MDisp --> Mig3
MAgent --> Mig4
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [init.rb:1-31](file://init.rb#L1-L31)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

## Core Components
- AiAgent: Defines agent types, protocols, validations, system prompt templates, and helpers to resolve prompts with Redmine context.
- AiAgentAssignment: Links users to active agents and supports auto-dispatch configuration.
- AiAgentDispatch: Tracks dispatch events, status, and timing for agent actions against issues.
- Controllers: Admin CRUD for agents, plus connection testing; assignments and dispatches controllers for management.
- Views: Form for agent configuration, including dynamic field visibility for Kimi Web protocol.
- Clients: AgentClient for OpenAI-compatible chat_completions and responses APIs; KimiWebClient for WebSocket-driven sessions; RedmineApiSkill for executing tool calls server-side.
- Settings: Plugin-wide settings for enabling the plugin, Redmine base URL, and default timeouts.

Key responsibilities:
- Validation ensures required fields and correct values for agent_type, protocol, endpoint_url, and model_name (unless using Kimi Web WebSocket).
- System prompts are templated per agent type and resolved with issue and user context.
- Admin UI exposes creation, editing, listing, and deletion of agents, with a “Test Connection” action.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent.rb (view):1-111](file://app/views/ai_agents/_form.html.erb#L1-L111)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Architecture Overview
The system integrates three communication pathways:
- OpenAI-compatible APIs: Chat Completions and Responses API.
- Kimi Web WebSocket: JSON-RPC 2.0 over WebSocket with session management.
- Redmine API skills: Tool execution for agents that support function-calling.

```mermaid
sequenceDiagram
participant Admin as "Admin UI"
participant Ctrl as "AiAgentsController"
participant Model as "AiAgent"
participant Client as "AgentClient/KimiWebClient"
participant Skill as "RedmineApiSkill"
participant Redmine as "Redmine REST API"
Admin->>Ctrl : "Create/Edit/Delete Agent"
Ctrl->>Model : "Persist validated attributes"
Admin->>Ctrl : "Test Connection"
Ctrl->>Client : "POST /v1/chat/completions or /v1/responses<br/>or WebSocket connect for Kimi"
Client-->>Ctrl : "HTTP success/failure or WebSocket result"
Note over Client,Model : "System prompts resolved with issue/user context"
Client->>Skill : "Execute tool calls (optional)"
Skill->>Redmine : "GET/PUT /issues/.json, /projects/.json, /issue_statuses.json"
Redmine-->>Skill : "JSON response"
Skill-->>Client : "Execution result"
Client-->>Admin : "Agent response text"
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)

## Detailed Component Analysis

### AiAgent Model
Responsibilities:
- Enumerations for agent types and protocols.
- Validations for name uniqueness and presence, agent_type inclusion, endpoint_url format, protocol inclusion, and model_name presence (except Kimi Web WebSocket).
- Helper predicates for agent_type and protocol checks.
- Built-in system prompt templates per agent type, with placeholders resolved at runtime using plugin settings and issue/user context.
- Safe API key masking for logging.

```mermaid
classDiagram
class AiAgent {
+string name
+string agent_type
+string endpoint_url
+string protocol
+string api_key
+string model_name
+text system_prompt
+boolean active
+safe_api_key()
+chat_completions?()
+responses_api?()
+hermes?()
+pi?()
+qoder?()
+kimi_web?()
+kimi_web_ws?()
+resolved_system_prompt(issue)
}
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

### Agent Configuration Options
- Agent Types: hermes, pi, qoder, kimi_web, custom.
- Protocols: chat_completions, responses, kimi_web_ws.
- Endpoint URL: must be a valid http/https URL.
- API Key: optional for providers; masked in logs.
- Model Name: required for non-Kimi Web WebSocket protocols.
- System Prompt: optional; defaults are provided per agent type.
- Active: toggles whether the agent participates in auto-dispatch.
- Kimi Web fields (when protocol is kimi_web_ws): session_id, work_dir, timeout.

Dynamic UI behavior:
- Selecting agent type “kimi_web” forces protocol to “kimi_web_ws” and hides standard fields.
- Protocol selection toggles visibility of Kimi Web-specific fields.

**Section sources**
- [ai_agent.rb:2-3](file://app/models/ai_agent.rb#L2-L3)
- [ai_agent.rb:9-15](file://app/models/ai_agent.rb#L9-L15)
- [ai_agent.rb:52-140](file://app/models/ai_agent.rb#L52-L140)
- [ai_agent.rb (view):1-111](file://app/views/ai_agents/_form.html.erb#L1-L111)

### Agent Lifecycle (Admin Interface)
- Listing: sorted by name.
- Creation: pre-populates defaults for agent_type, protocol, active, and model_name.
- Editing: allows updating all configuration fields.
- Deletion: removes agent and nullifies associations.
- Test Connection: performs a lightweight connectivity check:
  - For Kimi Web WebSocket: GET /healthz with Authorization header if API key is set.
  - For OpenAI-compatible: minimal chat completion or response request depending on protocol.

```mermaid
flowchart TD
Start(["Admin Action"]) --> List["List Agents"]
Start --> New["New Agent Form"]
Start --> Edit["Edit Agent Form"]
Start --> Delete["Delete Agent"]
Start --> Test["Test Connection"]
New --> SaveNew["Save New Agent"]
Edit --> SaveEdit["Save Updated Agent"]
Delete --> Destroy["Destroy Agent Record"]
Test --> CheckKimi{"Protocol is Kimi Web WS?"}
CheckKimi --> |Yes| Health["HTTP GET /healthz"]
CheckKimi --> |No| OpenAI["POST /v1/chat_completions or /v1/responses"]
SaveNew --> Done(["Success"])
SaveEdit --> Done
Destroy --> Done
Health --> Done
OpenAI --> Done
```

**Diagram sources**
- [ai_agents_controller.rb:5-47](file://app/controllers/ai_agents_controller.rb#L5-L47)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)

### Agent Communication Clients

#### OpenAI-Compatible Client (AgentClient)
- Builds payloads for chat_completions or responses API based on protocol.
- Resolves system prompt and issue context message.
- Supports tool definitions for Hermes/Pi (Redmine API functions) unless agent is Kimi Web or Qoder.
- Sends HTTP requests with Authorization header and parses responses.
- Applies plugin default timeout or falls back to internal default.

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant AC as "AgentClient"
participant Provider as "Provider API"
Caller->>AC : "call(issue, triggered_by)"
AC->>AC : "build_payload(issue)"
AC->>Provider : "POST /v1/chat/completions or /v1/responses"
Provider-->>AC : "JSON response"
AC->>AC : "extract_text(raw)"
AC-->>Caller : "{ text, raw_response, request }"
```

**Diagram sources**
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

**Section sources**
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)

#### Kimi Web Client (KimiWebClient)
- Manages session creation/reuse via REST.
- Establishes WebSocket connection and drives JSON-RPC 2.0 session.
- Auto-approves agent requests to allow unattended operation.
- Collects agent text output and returns structured result.

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant KC as "KimiWebClient"
participant KWS as "Kimi WebSocket"
Caller->>KC : "call(issue)"
KC->>KC : "ensure_session!"
KC->>KWS : "WebSocket upgrade"
KWS-->>KC : "history_complete"
KC->>KWS : "jsonrpc initialize"
KWS-->>KC : "session_status idle"
KC-->>Caller : "{ text, raw_response, request }"
```

**Diagram sources**
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [kimi_web_client.rb:142-154](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L154)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)

**Section sources**
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)

#### Redmine API Skill (RedmineApiSkill)
- Executes tool calls server-side when agents return function-calls.
- Supports get_issue, update_issue, list_statuses, get_project.
- Uses X-Redmine-API-Key header and respects configured base URL and timeout.

```mermaid
flowchart TD
Start(["Tool Call Received"]) --> Parse["Parse function name and arguments"]
Parse --> Route{"Function Type"}
Route --> |redmine_get_issue| GetIssue["GET /issues/:id.json"]
Route --> |redmine_update_issue| UpdateIssue["PUT /issues/:id.json"]
Route --> |redmine_list_statuses| ListStatuses["GET /issue_statuses.json"]
Route --> |redmine_get_project| GetProject["GET /projects/:id.json"]
GetIssue --> Done(["Return JSON"])
UpdateIssue --> Done
ListStatuses --> Done
GetProject --> Done
```

**Diagram sources**
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)
- [redmine_api_skill.rb:67-86](file://lib/redmine_ai_agent/redmine_api_skill.rb#L67-L86)

**Section sources**
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

### Assignment and Dispatch
- AiAgentAssignment links a user to an active agent and supports auto-dispatch.
- AiAgentDispatch tracks per-issue dispatch attempts with status transitions and timing.
- Hooks automatically dispatch agents when issues are created or edited and the assignee changes, if enabled and configured.

```mermaid
classDiagram
class AiAgentAssignment {
+user_id
+ai_agent_id
+auto_dispatch
+for_user(user)
+agent_for(user)
}
class AiAgentDispatch {
+issue_id
+ai_agent_id
+triggered_by
+status
+duration()
+request_data()
+response_data()
}
class AiAgent {
+has_many ai_agent_assignments
+has_many users
+has_many ai_agent_dispatches
}
AiAgentAssignment --> AiAgent : "belongs_to"
AiAgentDispatch --> AiAgent : "belongs_to"
AiAgentDispatch --> AiAgentAssignment : "belongs_to"
```

**Diagram sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:5-7](file://app/models/ai_agent.rb#L5-L7)

**Section sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

## Dependency Analysis
- Controllers depend on models for persistence and on clients for provider communication.
- Views depend on model enumerations and helpers to render dynamic forms.
- Clients depend on plugin settings for base URLs and timeouts.
- Hooks coordinate auto-dispatch based on plugin enablement and assignment configuration.

```mermaid
graph LR
CAgents["AiAgentsController"] --> MAgent["AiAgent"]
CAgents --> Client["AgentClient/KimiWebClient"]
MAgent --> Settings["Plugin Settings"]
Hooks["Hooks"] --> MAsign["AiAgentAssignment"]
Hooks --> MDisp["AiAgentDispatch"]
Client --> Skill["RedmineApiSkill"]
Skill --> Redmine["Redmine REST API"]
```

**Diagram sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [agent_client.rb:202-208](file://lib/redmine_ai_agent/agent_client.rb#L202-L208)
- [kimi_web_client.rb:412-418](file://lib/redmine_ai_agent/kimi_web_client.rb#L412-L418)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [hooks.rb:51-71](file://lib/redmine_ai_agent/hooks.rb#L51-L71)

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Performance Considerations
- Timeout configuration:
  - AgentClient applies plugin default_timeout or a built-in default for HTTP reads.
  - KimiWebClient applies a configurable timeout for session idle waits.
- Payload minimization:
  - Use concise system prompts and limit tool definitions to necessary functions.
- Network efficiency:
  - Prefer HTTPS endpoints to avoid unnecessary redirects.
  - Reuse Kimi Web sessions when possible to reduce overhead.
- Throughput:
  - Batch or queue dispatches using the provided job infrastructure to prevent blocking UI operations.
- Monitoring:
  - Inspect logs for HTTP status codes and timeouts during agent calls and dispatches.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and remedies:
- Invalid endpoint URL:
  - Ensure scheme is http or https and reachable.
- Authentication failures:
  - Verify API key correctness and provider permissions.
- Timeout errors:
  - Increase plugin default_timeout or agent-specific timeouts.
- Kimi Web WebSocket errors:
  - Confirm WebSocket endpoint availability and token if required.
  - Check session health and retry with a new session if the pinned session is stale.
- Tool-call execution errors:
  - Validate Redmine base URL and API key used by the skill executor.
- Auto-dispatch not triggering:
  - Confirm plugin is enabled and assignment has auto_dispatch checked.

Operational checks:
- Use the “Test Connection” action to validate provider connectivity.
- Review AiAgentDispatch records for status and timing metrics.

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [kimi_web_client.rb:208-209](file://lib/redmine_ai_agent/kimi_web_client.rb#L208-L209)
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)

## Conclusion
The AI Agent Management plugin provides a robust framework for integrating diverse AI providers with Redmine. Administrators can configure agents with flexible protocols, secure credentials, and tailored system prompts, while the system automates dispatching and execution through dedicated clients and skills. Proper configuration of timeouts, endpoints, and permissions ensures reliable operation across different use cases.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Practical Configuration Examples
- OpenAI-compatible agent (Chat Completions):
  - agent_type: custom
  - protocol: chat_completions
  - endpoint_url: provider base URL
  - api_key: provider API key
  - model_name: target model
  - system_prompt: optional override
- OpenAI-compatible agent (Responses API):
  - agent_type: custom
  - protocol: responses
  - endpoint_url: provider base URL
  - api_key: provider API key
  - model_name: target model
- Kimi Web WebSocket:
  - agent_type: kimi_web
  - protocol: kimi_web_ws
  - endpoint_url: Kimi web UI base URL
  - api_key: optional token
  - kimi_web_session_id: optional pinned session
  - kimi_web_work_dir: working directory for session
  - kimi_web_timeout: idle wait timeout
- System prompt customization:
  - Provide a custom system_prompt or rely on built-in templates per agent type.

[No sources needed since this section provides general guidance]