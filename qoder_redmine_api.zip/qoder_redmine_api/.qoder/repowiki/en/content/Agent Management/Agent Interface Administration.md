# Agent Interface Administration

<cite>
**Referenced Files in This Document**
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [index.html.erb](file://app/views/ai_agents/index.html.erb)
- [_form.html.erb](file://app/views/ai_agents/_form.html.erb)
- [new.html.erb](file://app/views/ai_agents/new.html.erb)
- [edit.html.erb](file://app/views/ai_agents/edit.html.erb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [index.html.erb](file://app/views/ai_agent_assignments/index.html.erb)
- [_form.html.erb](file://app/views/ai_agent_assignments/_form.html.erb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the agent administration interface for managing AI agents within the Redmine plugin. It covers the admin interface functionality including:
- Listing agents with sortable columns and inline actions
- Form-based creation and editing of agents with dynamic field visibility
- Inline connection testing per agent
- Route structure and controller actions supporting the interface
- User interface elements, validation feedback, and error display
- Accessibility, keyboard navigation, and responsive design considerations

The interface is localized and integrates with plugin settings for Redmine base URL and timeouts.

## Project Structure
The agent administration feature spans controllers, models, views, routes, migrations, and localization files. The routes define resourceful endpoints for agents and assignments, while the controllers coordinate data flow and enforce authorization.

```mermaid
graph TB
subgraph "Routes"
R1["config/routes.rb"]
end
subgraph "Controllers"
C1["AiAgentsController"]
C2["AiAgentAssignmentsController"]
end
subgraph "Models"
M1["AiAgent"]
M2["AiAgentAssignment"]
end
subgraph "Views"
V1["ai_agents/index.html.erb"]
V2["_form.html.erb"]
V3["new.html.erb"]
V4["edit.html.erb"]
VA["ai_agent_assignments/index.html.erb"]
VF["_form.html.erb"]
end
subgraph "Localization"
L1["config/locales/en.yml"]
end
R1 --> C1
R1 --> C2
C1 --> M1
C2 --> M2
C1 --> V1
C1 --> V2
C1 --> V3
C1 --> V4
C2 --> VA
C2 --> VF
M1 --> V1
M2 --> VA
L1 --> V1
L1 --> V2
L1 --> V3
L1 --> V4
L1 --> VA
L1 --> VF
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-83)
- [_form.html.erb:1-111](file://app/views/ai_agents/_form.html.erb#L1-111)
- [new.html.erb:1-8](file://app/views/ai_agents/new.html.erb#L1-8)
- [edit.html.erb:1-8](file://app/views/ai_agents/edit.html.erb#L1-8)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-39)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-22)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-83)
- [_form.html.erb:1-111](file://app/views/ai_agents/_form.html.erb#L1-111)
- [new.html.erb:1-8](file://app/views/ai_agents/new.html.erb#L1-8)
- [edit.html.erb:1-8](file://app/views/ai_agents/edit.html.erb#L1-8)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-39)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-22)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Core Components
- Routes: Define resource endpoints for agents (including a member action for connection testing) and assignments, plus nested dispatch routes under issues.
- Controllers: Enforce admin-only access, handle CRUD for agents and assignments, and provide connection testing logic.
- Models: Define agent types, protocols, validations, and system prompt templates; define assignment relationships and validations.
- Views: Render agent listing with inline actions, dynamic agent creation/edit forms, and assignment management.
- Localization: Provide labels, hints, notices, and confirmations for the interface.

Key responsibilities:
- Agent listing and inline actions (edit, test, delete)
- Dynamic form rendering based on agent type and protocol
- Validation feedback and error display
- Connection testing via AJAX
- Assignment management between users and agents

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-83)
- [_form.html.erb:1-111](file://app/views/ai_agents/_form.html.erb#L1-111)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-39)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-22)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Architecture Overview
The admin interface follows Rails conventions:
- Routes map to controllers
- Controllers fetch or mutate models
- Views render forms and lists, including dynamic behavior
- Localization keys drive labels and hints

```mermaid
sequenceDiagram
participant U as "Admin User"
participant R as "Rails Router"
participant AC as "AiAgentsController"
participant AM as "AiAgent Model"
participant V as "ERB Views"
U->>R : GET /ai_agents
R->>AC : index
AC->>AM : order( : name)
AM-->>AC : collection
AC->>V : render index.html.erb
U->>R : POST /ai_agents/ : id/test_connection
R->>AC : test_connection
AC->>AM : agent lookup
AC->>AM : protocol-specific test
AM-->>AC : result
AC-->>U : JSON {ok,status,body/error}
U->>R : GET /ai_agents/new
R->>AC : new
AC->>AM : new record defaults
AC->>V : render new.html.erb
U->>R : POST /ai_agents
R->>AC : create
AC->>AM : save
AM-->>AC : success/failure
AC-->>U : redirect or render new
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-83)
- [new.html.erb:1-8](file://app/views/ai_agents/new.html.erb#L1-8)

## Detailed Component Analysis

### Agent Management Routes and Controller Actions
- Routes define:
  - Resources for agents with a member action for testing connections
  - Resources for agent assignments
  - Nested resources for issue dispatches
- Controller actions:
  - Index: lists agents ordered by name
  - New/Edit/Create/Update/Delete: standard CRUD with strong parameters
  - Test connection: protocol-aware connectivity checks with JSON responses

```mermaid
flowchart TD
Start(["Admin navigates to /ai_agents"]) --> List["Render index<br/>List agents with actions"]
List --> NewAgent["Click 'New Agent'"]
NewAgent --> CreateForm["Render new form<br/>Dynamic fields"]
CreateForm --> Submit["Submit form"]
Submit --> Valid{"Valid?"}
Valid --> |Yes| Success["Redirect to index with notice"]
Valid --> |No| RenderNew["Render new with errors"]
Success --> List
RenderNew --> CreateForm
List --> EditAgent["Click 'Edit'"]
EditAgent --> EditForm["Render edit form<br/>Dynamic fields"]
EditForm --> Update["Submit update"]
Update --> ValidUpd{"Valid?"}
ValidUpd --> |Yes| SuccessUpd["Redirect to index with notice"]
ValidUpd --> |No| RenderEdit["Render edit with errors"]
SuccessUpd --> List
RenderEdit --> EditForm
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-83)
- [new.html.erb:1-8](file://app/views/ai_agents/new.html.erb#L1-8)
- [edit.html.erb:1-8](file://app/views/ai_agents/edit.html.erb#L1-8)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-83)
- [new.html.erb:1-8](file://app/views/ai_agents/new.html.erb#L1-8)
- [edit.html.erb:1-8](file://app/views/ai_agents/edit.html.erb#L1-8)

### Agent Listing and Inline Actions
- The listing displays agent attributes and inline buttons for edit, test, and delete.
- The test button triggers an AJAX call to the agent’s test_connection endpoint and shows a result message.
- Users can navigate to the assignment management page from the agents index.

UI elements:
- Action links with icons
- Confirmation dialogs for destructive actions
- Endpoint truncation for readability
- Badge and code-like formatting for type and protocol

Accessibility and UX:
- Buttons use semantic icons and localized labels
- Confirm dialog for deletion improves safety
- Truncated endpoint URLs prevent layout overflow

**Section sources**
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-L83)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [en.yml:42-51](file://config/locales/en.yml#L42-L51)

### Dynamic Agent Creation and Editing Forms
The form supports:
- Agent type selection affecting protocol choices
- Protocol selection toggling standard vs. Kimi Web fields
- Conditional visibility of model_name vs. Kimi Web fields
- Password field for API key with placeholder indicating unchanged behavior
- System prompt area with placeholder and hint
- Active checkbox and submit/cancel actions

JavaScript behavior:
- On protocol change, standard or Kimi Web field groups are shown/hidden
- Selecting “Kimi Web” agent type forces the Kimi Web WebSocket protocol

Validation feedback:
- Error messages are rendered at the top of the form
- Field-level hints guide input

**Section sources**
- [_form.html.erb:1-111](file://app/views/ai_agents/_form.html.erb#L1-L111)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [en.yml:52-67](file://config/locales/en.yml#L52-L67)

### Agent Model and Validations
- Agent types and protocols are constrained via constants and validations
- Endpoint URL must be a proper HTTP/HTTPS URL
- Model name is required except for Kimi Web WebSocket protocol
- Safe API key masking prevents plaintext exposure
- Built-in system prompt templates per agent type, with placeholders resolved at runtime

```mermaid
classDiagram
class AiAgent {
+string name
+string agent_type
+string endpoint_url
+string protocol
+string api_key
+string model_name
+text system_prompt
+boolean active
+has_many ai_agent_assignments
+has_many users
+has_many ai_agent_dispatches
+validates name, agent_type, endpoint_url, protocol, model_name
+safe_api_key()
+chat_completions?()
+responses_api?()
+kimi_web_ws?()
+resolved_system_prompt(issue)
}
class AiAgentAssignment {
+belongs_to user
+belongs_to ai_agent
+validates user_id, ai_agent_id
+for_user(user)
+agent_for(user)
}
AiAgent "1" --> "many" AiAgentAssignment : "has_many"
AiAgentAssignment "many" --> "1" AiAgent : "belongs_to"
AiAgentAssignment "many" --> "1" User : "belongs_to"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

### Assignment Management
- Index lists active user-agent assignments with auto-dispatch flag and protocol
- New/Edit forms allow selecting users and agents, with auto-dispatch option
- Uniqueness constraint ensures one agent per user

```mermaid
sequenceDiagram
participant U as "Admin User"
participant AC as "AiAgentAssignmentsController"
participant AA as "AiAgentAssignment"
participant AU as "User"
participant AG as "AiAgent"
participant V as "Views"
U->>AC : GET /ai_agent_assignments
AC->>AA : includes( : user, : ai_agent).order(...)
AA-->>AC : assignments
AC->>V : render index
U->>AC : GET /ai_agent_assignments/new
AC->>AU : active users (unused in query)
AC->>AG : active agents
AC->>V : render new form
U->>AC : POST /ai_agent_assignments
AC->>AA : create with params
AA-->>AC : success/failure
AC-->>U : redirect or render new
```

**Diagram sources**
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-39)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-22)

**Section sources**
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-39)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-22)

### Settings Integration
Plugin settings include enabling the feature, setting the Redmine base URL for agent API access, and configuring default timeout. These settings influence how system prompts are constructed and how long HTTP requests wait.

**Section sources**
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)

## Dependency Analysis
- Controllers depend on models for persistence and validations
- Views depend on controllers for instance variables and on localization for labels/hints
- Routes connect endpoints to controller actions
- Migrations define the underlying database schema for agents and assignments

```mermaid
graph LR
R["routes.rb"] --> AC["AiAgentsController"]
R --> AAC["AiAgentAssignmentsController"]
AC --> AM["AiAgent"]
AAC --> AAM["AiAgentAssignment"]
V1["ai_agents/index.html.erb"] --> AC
V2["_form.html.erb"] --> AC
V3["new.html.erb"] --> AC
V4["edit.html.erb"] --> AC
VA["ai_agent_assignments/index.html.erb"] --> AAC
VF["_form.html.erb"] --> AAC
L["en.yml"] --> V1
L --> V2
L --> V3
L --> V4
L --> VA
L --> VF
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-83)
- [_form.html.erb:1-111](file://app/views/ai_agents/_form.html.erb#L1-111)
- [new.html.erb:1-8](file://app/views/ai_agents/new.html.erb#L1-8)
- [edit.html.erb:1-8](file://app/views/ai_agents/edit.html.erb#L1-8)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-39)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-22)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-83)
- [_form.html.erb:1-111](file://app/views/ai_agents/_form.html.erb#L1-111)
- [new.html.erb:1-8](file://app/views/ai_agents/new.html.erb#L1-8)
- [edit.html.erb:1-8](file://app/views/ai_agents/edit.html.erb#L1-8)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-39)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-22)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Performance Considerations
- Index queries: Agents are fetched with ordering; consider adding database indexes on frequently filtered/sorted columns if needed.
- Assignment listing: Uses includes to avoid N+1 queries when rendering user and agent associations.
- Connection testing: Uses short timeouts for HTTP requests to prevent blocking the UI.
- Rendering: Large system prompts are truncated in listings; full prompts are used in dispatch contexts.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Validation failures during create/update:
  - Ensure required fields are present and formatted correctly (URL, model name for non-Kimi Web protocols).
  - Check that agent type and protocol combinations are valid.
- Connection test failures:
  - Verify endpoint URL and protocol match the target service.
  - Confirm API key correctness and network accessibility.
  - Review returned status/body/error in the test result area.
- Deletion confirmation:
  - Use the confirmation dialog to avoid accidental deletions.
- Assignment conflicts:
  - The uniqueness constraint on user_id prevents duplicate assignments; remove existing assignment before creating a new one.

**Section sources**
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)
- [ai_agent_assignment.rb:5](file://app/models/ai_agent_assignment.rb#L5)
- [index.html.erb:36-39](file://app/views/ai_agents/index.html.erb#L36-L39)
- [index.html.erb:27-30](file://app/views/ai_agent_assignments/index.html.erb#L27-L30)

## Conclusion
The agent administration interface provides a robust, localized, and accessible way to manage AI agents and their assignments. It emphasizes clear validation feedback, dynamic forms, and inline testing capabilities. The modular structure supports future enhancements such as bulk operations, advanced filtering, and expanded protocol support.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Screenshots and Examples
Note: The repository does not include screenshots. The following examples describe typical UI states and interactions.

- Agent listing page:
  - Displays columns for name, type, protocol, model, endpoint, active status, assigned users, and action buttons.
  - Example interaction: Click “Test Connection” to validate endpoint accessibility; observe the result message area.
- New agent form:
  - Select agent type; protocol selection toggles standard fields versus Kimi Web fields.
  - Example interaction: Choose “Kimi Web” agent type to force the Kimi Web WebSocket protocol and reveal Kimi-specific fields.
- Edit agent form:
  - Same dynamic behavior as new form; password field indicates unchanged behavior when editing existing records.
- Assignment management:
  - Lists active users and agents; allows assigning one agent per user with auto-dispatch option.

[No sources needed since this section doesn't analyze specific files]

### Accessibility and Responsive Design Notes
- Keyboard navigation:
  - Focusable elements include form controls, action links, and buttons; ensure tab order aligns with visual layout.
  - Provide visible focus indicators for interactive elements.
- Screen reader support:
  - Use semantic labels and aria-live regions for dynamic feedback (e.g., test result area).
- Responsive design:
  - Tables adapt to narrow screens; consider stacked presentation on very small devices.
  - Text areas and input widths accommodate content; ensure sufficient spacing for mobile touch targets.

[No sources needed since this section provides general guidance]