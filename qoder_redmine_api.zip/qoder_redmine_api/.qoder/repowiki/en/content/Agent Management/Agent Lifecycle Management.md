# Agent Lifecycle Management

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the AI agent lifecycle management system integrated into the Redmine application. It covers the complete lifecycle from creation to deletion, including validation rules, dependency checks, state management, and the admin interface operations. It also documents how agent activation/deactivation affects automatic dispatch, validation rules for agent parameters, error handling and retries, and practical scenarios and best practices for production deployments.

## Project Structure
The plugin integrates with Redmine’s routing and controllers, persists agent definitions and assignments in the database, and orchestrates asynchronous dispatches via a job. Permissions and settings are registered at the plugin level.

```mermaid
graph TB
subgraph "Admin UI"
R["Routes<br/>config/routes.rb"]
C1["AiAgentsController<br/>app/controllers/ai_agents_controller.rb"]
C2["AiAgentAssignmentsController<br/>app/controllers/ai_agent_assignments_controller.rb"]
C3["AiAgentDispatchesController<br/>app/controllers/ai_agent_dispatches_controller.rb"]
end
subgraph "Domain Models"
M1["AiAgent<br/>app/models/ai_agent.rb"]
M2["AiAgentAssignment<br/>app/models/ai_agent_assignment.rb"]
M3["AiAgentDispatch<br/>app/models/ai_agent_dispatch.rb"]
end
subgraph "Background Job"
J1["AiAgentDispatchJob<br/>app/jobs/ai_agent_dispatch_job.rb"]
end
subgraph "Persistence"
D1["CreateAiAgents<br/>db/migrate/001_create_ai_agents.rb"]
D2["CreateAiAgentAssignments<br/>db/migrate/002_create_ai_agent_assignments.rb"]
D3["CreateAiAgentDispatches<br/>db/migrate/003_create_ai_agent_dispatches.rb"]
end
subgraph "Plugin Settings & Permissions"
P1["init.rb"]
V1["Settings Partial<br/>app/views/settings/_ai_agent_settings.html.erb"]
end
R --> C1
R --> C2
R --> C3
C1 --> M1
C2 --> M2
C3 --> M3
C3 --> J1
J1 --> M3
J1 --> M1
M1 --- D1
M2 --- D2
M3 --- D3
P1 --> R
P1 --> V1
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [init.rb:1-31](file://init.rb#L1-L31)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:1-31](file://init.rb#L1-L31)

## Core Components
- AiAgent: Defines agent metadata, validations, protocol/type flags, system prompt templates, and safe API key masking.
- AiAgentAssignment: Links users to agents and controls whether auto-dispatch is enabled for that assignment.
- AiAgentDispatch: Tracks dispatch requests per issue, their status, timing, and serialized request/response payloads.
- Controllers: Provide admin CRUD for agents and assignments, manual dispatch triggers, and connection testing.
- Job: Executes dispatches asynchronously, posts journal notes, runs tool-call loops, and handles retries and errors.
- Routes: Expose admin endpoints and per-issue dispatch actions.
- Settings: Enable/disable plugin and configure base URL and default timeout.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Architecture Overview
The system separates concerns across models, controllers, a background job, and persistence. Dispatches are queued from the UI and executed asynchronously. Automatic dispatch depends on active agents and assignment flags.

```mermaid
sequenceDiagram
participant Admin as "Admin UI"
participant Agents as "AiAgentsController"
participant Assign as "AiAgentAssignmentsController"
participant IssueUI as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Model as "AiAgent/AiAgentDispatch"
participant Skill as "RedmineApiSkill"
Admin->>Agents : "GET/POST/PUT/DELETE /ai_agents"
Admin->>Assign : "GET/POST/PUT/DELETE /ai_agent_assignments"
Admin->>IssueUI : "POST /issues/ : id/ai_agent_dispatches"
IssueUI->>Job : "perform_later(issue_id, agent_id, user_id)"
Job->>Model : "create dispatch (status=running)"
Job->>Skill : "execute tool calls (loop)"
Skill-->>Job : "results"
Job->>Model : "update dispatch (status=done/error)"
Job-->>IssueUI : "journal notes posted"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:14-24](file://app/models/ai_agent_dispatch.rb#L14-L24)
- [ai_agent_assignment.rb:22-24](file://app/models/ai_agent_assignment.rb#L22-L24)

## Detailed Component Analysis

### AiAgent: Lifecycle, Validation, and State
- Lifecycle stages: Created with initial attributes, activated/deactivated, tested for connectivity, and deleted.
- Validation rules:
  - Name: present and unique.
  - Agent type: present and included in supported types.
  - Endpoint URL: present and a valid http/https URI.
  - Protocol: present and included in supported protocols.
  - Model name: required unless using the Kimi WebSocket protocol.
- Flags and helpers:
  - Protocol flags: chat_completions, responses, kimi_web_ws.
  - Agent type flags: hermes, pi, qoder, kimi_web, custom.
  - Active scope filters active agents.
- Safety:
  - Safe API key display masks the key in serialization.
- System prompts:
  - Built-in templates per agent type, resolved with runtime values from settings and issue context.

```mermaid
classDiagram
class AiAgent {
+String name
+String agent_type
+String endpoint_url
+String protocol
+String api_key
+String model_name
+Text system_prompt
+Boolean active
+String kimi_web_session_id
+String kimi_web_work_dir
+Integer kimi_web_timeout
+Boolean chat_completions?()
+Boolean responses_api?()
+Boolean hermes?()
+Boolean pi?()
+Boolean qoder?()
+Boolean kimi_web?()
+Boolean kimi_web_ws?()
+String resolved_system_prompt(issue)
+String safe_api_key()
}
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [001_create_ai_agents.rb:3-12](file://db/migrate/001_create_ai_agents.rb#L3-L12)

**Section sources**
- [ai_agent.rb:9-155](file://app/models/ai_agent.rb#L9-L155)
- [001_create_ai_agents.rb:3-12](file://db/migrate/001_create_ai_agents.rb#L3-L12)

### AiAgentAssignment: Assignment and Auto-Dispatch
- Enforces uniqueness of user-to-agent assignment.
- Provides convenience methods to fetch the active agent for a user.
- Stores auto_dispatch flag controlling whether automatic dispatch is enabled for that assignment.

```mermaid
classDiagram
class AiAgentAssignment {
+Integer user_id
+Integer ai_agent_id
+Boolean auto_dispatch
+AiAgent agent_for(user)
+AiAgent for_user(user)
+Boolean auto_dispatch?()
}
AiAgentAssignment --> AiAgent : "belongs_to"
AiAgentAssignment --> User : "belongs_to"
```

**Diagram sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [002_create_ai_agent_assignments.rb:3-7](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L7)

**Section sources**
- [ai_agent_assignment.rb:5-25](file://app/models/ai_agent_assignment.rb#L5-L25)
- [002_create_ai_agent_assignments.rb:3-7](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L7)

### AiAgentDispatch: Dispatch State Machine and Payloads
- Status lifecycle: pending → running → done or error.
- Scopes: filter by status and issue.
- Helpers: status predicates, duration calculation, and JSON-safe parsing of request/response payloads.

```mermaid
stateDiagram-v2
[*] --> Pending
Pending --> Running : "job starts"
Running --> Done : "success"
Running --> Error : "exception"
Done --> [*]
Error --> [*]
```

**Diagram sources**
- [ai_agent_dispatch.rb:2-24](file://app/models/ai_agent_dispatch.rb#L2-L24)

**Section sources**
- [ai_agent_dispatch.rb:9-43](file://app/models/ai_agent_dispatch.rb#L9-L43)
- [003_create_ai_agent_dispatches.rb:3-13](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L13)

### Controllers: Admin CRUD and Dispatch Triggers
- AiAgentsController:
  - Index, show, new, create, edit, update, destroy.
  - Member action test_connection supports both standard and Kimi WebSocket endpoints.
- AiAgentAssignmentsController:
  - CRUD for user-agent assignments; ensures unique user assignment and filters active agents.
- AiAgentDispatchesController:
  - Manual dispatch from an issue page; enqueues AiAgentDispatchJob for the active agent assigned to the issue’s assignee.

```mermaid
sequenceDiagram
participant Admin as "Admin"
participant AC as "AiAgentsController"
participant AAC as "AiAgentAssignmentsController"
participant ADC as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
Admin->>AC : "Create/Edit/Delete agents"
Admin->>AAC : "Create/Edit/Delete assignments"
Admin->>ADC : "POST /issues/ : id/ai_agent_dispatches"
ADC->>Job : "perform_later(...)"
Job-->>ADC : "journal updates"
```

**Diagram sources**
- [ai_agents_controller.rb:21-47](file://app/controllers/ai_agents_controller.rb#L21-L47)
- [ai_agent_assignments_controller.rb:16-48](file://app/controllers/ai_agent_assignments_controller.rb#L16-L48)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

### Job: Dispatch Execution, Tool Loop, Retries, and Journaling
- Performs the dispatch, posts “task sent” journal note, executes agent call, and runs a tool-call loop up to a fixed number of iterations.
- Persists request/response payloads and final status.
- Posts “dispatch done” journal note upon completion.
- Handles AgentError via retry policy and logs unexpected errors.
- On error, sets status to error, posts “dispatch error” journal note.

```mermaid
flowchart TD
Start(["Job.start"]) --> Find["Load Issue/Agent/User"]
Find --> Valid{"Records found?"}
Valid --> |No| LogWarn["Log warning and exit"]
Valid --> |Yes| CreateDisp["Create dispatch (running)"]
CreateDisp --> JournalStart["Post 'dispatch started' journal"]
JournalStart --> CallAgent["Call AgentClient (tool loop)"]
CallAgent --> Persist["Persist request/response payloads"]
Persist --> JournalDone["Post 'dispatch done' journal"]
JournalDone --> End(["Exit"])
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### Routes and Permissions
- Routes define admin endpoints for agents and assignments, plus per-issue dispatch creation and viewing.
- Plugin registers permissions for dispatching and managing agents and assignments, and adds an admin menu entry.

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:18-30](file://init.rb#L18-L30)

### Settings and Environment
- Plugin settings include enabling/disabling the plugin, setting the Redmine API base URL, and default timeout.
- Settings are rendered in the admin settings panel.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Dependency Analysis
- Controllers depend on models for validation and persistence.
- Dispatch controller depends on assignment and agent models to select the active agent for an issue.
- Job depends on AgentClient and RedmineApiSkill to execute tool loops and interact with the Redmine API.
- Database migrations define foreign keys and indexes across AiAgent, AiAgentAssignment, and AiAgentDispatch.

```mermaid
graph LR
AC["AiAgentsController"] --> AM["AiAgent"]
AAC["AiAgentAssignmentsController"] --> AA["AiAgentAssignment"]
ADC["AiAgentDispatchesController"] --> AD["AiAgentDispatch"]
ADC --> AA
AJ["AiAgentDispatchJob"] --> AD
AJ --> AM
AJ --> Skill["RedmineApiSkill"]
AA --> AM
```

**Diagram sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)
- [003_create_ai_agent_dispatches.rb:16-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L16-L22)

## Performance Considerations
- Asynchronous dispatch: Long-running agent calls are offloaded to a background job to avoid blocking UI requests.
- Retries: Transient AgentErrors are retried with exponential backoff to improve resilience.
- Tool loop limits: The tool-call loop caps iterations to prevent runaway processing.
- Indexes: Database indexes on foreign keys and status facilitate fast filtering and reporting.
- Payload sizes: Request/response payloads are stored as text; consider compression or truncation in high-volume environments.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Connection tests:
  - Use the agent’s test_connection endpoint to validate endpoint reachability and credentials for both standard and Kimi WebSocket protocols.
- Dispatch failures:
  - Check AiAgentDispatch status and payloads for error details.
  - Review job logs for AgentError and unexpected exceptions.
- Missing active agent:
  - Manual dispatch requires an active agent assignment for the issue’s assignee; otherwise, a user-visible error is shown.
- Permissions:
  - Ensure the user has the required permission to dispatch agents on the target project.

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)

## Conclusion
The AI agent lifecycle management system provides a robust framework for defining, assigning, validating, and operating AI agents within Redmine. It supports admin CRUD, assignment-based auto-dispatch, manual dispatch triggers, and resilient asynchronous execution with tool-call loops. Proper validation, state management, and error handling ensure reliable operation in production environments.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Agent Lifecycle Scenarios and Best Practices
- Creating an agent:
  - Choose agent type and protocol; ensure endpoint URL is reachable and credentials are correct; set model name appropriately; activate the agent.
- Assigning agents to users:
  - Ensure unique user-to-agent assignments; enable auto_dispatch only when desired; keep assignments aligned with user roles and projects.
- Manual dispatch:
  - Trigger dispatch from the issue page; monitor dispatch status and journal notes; investigate errors via dispatch records.
- Activation/deactivation impact:
  - Deactivating an agent prevents automatic dispatch for its assignments; re-activate only after resolving configuration issues.
- Rollback procedures:
  - For failed dispatches, rely on the error status and payloads to diagnose; correct agent configuration and re-dispatch as needed.
- Production best practices:
  - Use HTTPS endpoints; mask API keys in logs; monitor job queues; enforce strict validation; regularly test connections; limit tool loop iterations; maintain clear system prompts per agent type.

[No sources needed since this section provides general guidance]