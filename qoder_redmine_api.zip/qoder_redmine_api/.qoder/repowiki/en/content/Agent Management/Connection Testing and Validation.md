# Connection Testing and Validation

<cite>
**Referenced Files in This Document**
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [index.html.erb](file://app/views/ai_agents/index.html.erb)
- [_form.html.erb](file://app/views/ai_agents/_form.html.erb)
- [init.rb](file://init.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the agent connection testing and validation procedures implemented in the plugin. It focuses on the test_connection endpoint that validates connectivity for:
- Standard OpenAI-compatible agents (Chat Completions and Responses APIs)
- Kimi Web agents using the WebSocket JSON-RPC protocol

It covers the ping mechanisms, timeout configurations, error handling, response interpretation, and practical troubleshooting guidance for common connection issues.

## Project Structure
The connection testing feature spans controllers, models, routing, clients, and UI views:
- Controller: handles the test_connection endpoint and delegates to clients
- Model: defines agent types, protocols, and helpers for protocol detection
- Clients: HTTP and WebSocket clients for OpenAI-compatible and Kimi Web agents
- Routing: exposes the test_connection route
- Views: provide the UI to trigger and interpret test results
- Migration: adds Kimi Web-specific fields to the agent model

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentsController<br/>test_connection"]
end
subgraph "Models"
M1["AiAgent<br/>protocol helpers"]
end
subgraph "Clients"
CL1["AgentClient<br/>OpenAI-compatible"]
CL2["KimiWebClient<br/>WebSocket JSON-RPC"]
end
subgraph "Routing"
R1["Routes<br/>test_connection"]
end
subgraph "Views"
V1["Index View<br/>Test Button + Result"]
V2["Form View<br/>Protocol Selection"]
end
subgraph "External"
E1["OpenAI-Compatible API"]
E2["Kimi Web REST + WS"]
end
R1 --> C1
C1 --> M1
C1 --> CL1
C1 --> CL2
CL1 --> E1
CL2 --> E2
V1 --> R1
V2 --> M1
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [agent_client.rb:8-42](file://lib/redmine_ai_agent/agent_client.rb#L8-L42)
- [kimi_web_client.rb:21-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L58)
- [routes.rb:3-6](file://config/routes.rb#L3-L6)
- [index.html.erb:33-82](file://app/views/ai_agents/index.html.erb#L33-L82)
- [_form.html.erb:19-26](file://app/views/ai_agents/_form.html.erb#L19-L26)

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [index.html.erb:1-83](file://app/views/ai_agents/index.html.erb#L1-L83)
- [_form.html.erb:1-111](file://app/views/ai_agents/_form.html.erb#L1-L111)

## Core Components
- Test endpoint: POST /ai_agents/:id/test_connection
- Protocol detection:
  - Kimi Web: protocol kimi_web_ws
  - Standard OpenAI-compatible: protocols chat_completions and responses
- Ping mechanisms:
  - Kimi Web: HTTP GET /healthz
  - Standard agents: minimal chat completion or response request
- Timeout configuration:
  - Kimi Web: HTTP timeouts 10s open/read
  - Standard agents: HTTP timeouts 10s open/15s read
- Error handling:
  - StandardError rescue returns JSON with ok=false and error message
  - HTTP success determined by Net::HTTPSuccess

Key implementation references:
- Controller action and protocol branching: [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- Protocol helpers: [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- Route definition: [routes.rb:3-6](file://config/routes.rb#L3-L6)
- UI trigger and result display: [index.html.erb:33-82](file://app/views/ai_agents/index.html.erb#L33-L82)

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [routes.rb:3-6](file://config/routes.rb#L3-L6)
- [index.html.erb:33-82](file://app/views/ai_agents/index.html.erb#L33-L82)

## Architecture Overview
The test_connection endpoint orchestrates two distinct validation flows depending on the agent’s protocol.

```mermaid
sequenceDiagram
participant U as "Admin User"
participant V as "Index View"
participant C as "AiAgentsController"
participant M as "AiAgent"
participant AC as "AgentClient"
participant KC as "KimiWebClient"
participant S1 as "OpenAI-Compatible API"
participant S2 as "Kimi Web REST/WS"
U->>V : Click "Test" button
V->>C : POST /ai_agents/ : id/test_connection
C->>M : Determine protocol (kimi_web_ws?)
alt Kimi Web
C->>S2 : GET /healthz (HTTP)
S2-->>C : HTTP 200 OK
C-->>V : {ok : true, status : "200", body : "..."}
else Standard OpenAI-compatible
C->>AC : Build payload (minimal ping)
AC->>S1 : POST /v1/chat/completions or /v1/responses
S1-->>AC : HTTP 200 OK
AC-->>C : Parsed JSON
C-->>V : {ok : true, status : "200", body : "..."}
end
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [api-reference.md:341-346](file://kimi-web/reference/api-reference.md#L341-L346)

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [api-reference.md:341-346](file://kimi-web/reference/api-reference.md#L341-L346)

## Detailed Component Analysis

### Controller: AiAgentsController.test_connection
Responsibilities:
- Detect agent protocol
- For Kimi Web: perform HTTP GET /healthz with Authorization header if api_key is present
- For standard agents: send a minimal request to either /v1/chat/completions or /v1/responses
- Apply protocol-specific timeouts
- Return standardized JSON { ok, status, body } or { ok: false, error }

Timeouts and payloads:
- Kimi Web: open/read 10s each; GET /healthz
- Standard agents: open 10s, read 15s; minimal payload with model and short input

Error handling:
- StandardError rescue returns { ok: false, error: message }

```mermaid
flowchart TD
Start(["POST /ai_agents/:id/test_connection"]) --> Detect["Detect protocol via AiAgent"]
Detect --> IsKimi{"kimi_web_ws?"}
IsKimi --> |Yes| Healthz["HTTP GET /healthz<br/>open/read 10s"]
Healthz --> OkCheck1{"HTTP 2xx?"}
OkCheck1 --> |Yes| ReturnOk1["Return {ok:true,status,body}"]
OkCheck1 --> |No| ReturnErr1["Return {ok:false,status,body}"]
IsKimi --> |No| IsChat{"chat_completions?"}
IsChat --> |Yes| CC["POST /v1/chat/completions<br/>open 10s, read 15s"]
IsChat --> |No| Resp["POST /v1/responses<br/>open 10s, read 15s"]
CC --> OkCheck2{"HTTP 2xx?"}
Resp --> OkCheck2
OkCheck2 --> |Yes| ReturnOk2["Return {ok:true,status,body}"]
OkCheck2 --> |No| ReturnErr2["Return {ok:false,status,body}"]
ReturnErr1 --> End(["End"])
ReturnOk1 --> End
ReturnOk2 --> End
ReturnErr2 --> End
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

### Model: AiAgent
Protocol detection helpers:
- chat_completions? and responses_api? for standard OpenAI-compatible agents
- kimi_web_ws? for Kimi Web WebSocket protocol

Validation ensures:
- endpoint_url is present and a valid http/https URI
- protocol is one of the supported values

These helpers are used by the controller to branch the test logic.

**Section sources**
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)

### Client: AgentClient (OpenAI-compatible)
While the test_connection endpoint performs a minimal request directly, the production client demonstrates the expected behavior:
- Resolves endpoint based on protocol
- Applies default timeout from plugin settings or falls back to 120s
- Sends Authorization header if api_key is present
- Parses JSON and raises AgentError on non-2xx or parse errors

This informs the expected behavior for standard agent tests.

**Section sources**
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [agent_client.rb:231-239](file://lib/redmine_ai_agent/agent_client.rb#L231-L239)
- [agent_client.rb:202-208](file://lib/redmine_ai_agent/agent_client.rb#L202-L208)

### Client: KimiWebClient
The test_connection endpoint does not use this client for validation, but the client’s behavior is relevant for understanding timeouts and protocol specifics:
- Uses a configurable kimi_web_timeout (default 120s)
- Manages WebSocket JSON-RPC session lifecycle
- Applies HTTP timeouts for REST operations

**Section sources**
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)
- [kimi_web_client.rb:412-418](file://lib/redmine_ai_agent/kimi_web_client.rb#L412-L418)

### Routing: Routes
Defines the test_connection member route under ai_agents.

**Section sources**
- [routes.rb:3-6](file://config/routes.rb#L3-L6)

### UI: Index View and Form
- Index view renders a "Test" button per agent that triggers the test_connection endpoint via JavaScript
- Results are displayed in a notice/error banner
- Form view controls visibility of Kimi Web fields and sets protocol selection

**Section sources**
- [index.html.erb:33-82](file://app/views/ai_agents/index.html.erb#L33-L82)
- [_form.html.erb:19-26](file://app/views/ai_agents/_form.html.erb#L19-L26)
- [_form.html.erb:87-110](file://app/views/ai_agents/_form.html.erb#L87-L110)

### Kimi Web API Reference
- Health probe endpoint: GET /healthz returning {"status":"ok"}

**Section sources**
- [api-reference.md:341-346](file://kimi-web/reference/api-reference.md#L341-L346)

## Dependency Analysis
- Controller depends on:
  - AiAgent model for protocol detection
  - Net::HTTP for direct HTTP requests
  - JSON for payload construction and response parsing
- Clients depend on:
  - Net::HTTP for REST calls
  - WebSocket libraries for Kimi Web
- UI depends on:
  - CSRF token and fetch API to call test_connection

```mermaid
graph LR
Controller["AiAgentsController"] --> Model["AiAgent"]
Controller --> NetHTTP["Net::HTTP"]
Controller --> JSON["JSON"]
Controller --> ClientA["AgentClient"]
Controller --> ClientK["KimiWebClient"]
ClientA --> NetHTTP
ClientK --> NetHTTP
ClientK --> WebSocket["WebSocket"]
UI["Index View"] --> Controller
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [index.html.erb:61-79](file://app/views/ai_agents/index.html.erb#L61-L79)

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [index.html.erb:61-79](file://app/views/ai_agents/index.html.erb#L61-L79)

## Performance Considerations
- Short timeouts for test_connection:
  - Kimi Web: 10s open/10s read
  - Standard agents: 10s open/15s read
- These are intentionally low to provide quick feedback during admin configuration
- Production clients use longer timeouts (default 120s) to accommodate larger responses and tool calls

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Interpreting Test Results
- Successful connection:
  - ok: true
  - status: HTTP 200
  - body: truncated response payload
- Failed connection:
  - ok: false
  - error: error message
  - status/body: HTTP error code and body (when applicable)

### Common Issues and Fixes

- Network connectivity failures
  - Symptoms: HTTP timeout or connection refused
  - Checks:
    - Verify endpoint_url is reachable from the server hosting the plugin
    - Confirm firewall rules allow outbound connections
  - Resolution: Fix network routing or proxy configuration

- Authentication problems
  - Symptoms: HTTP 401/403
  - Checks:
    - Ensure api_key is set and correct
    - For Kimi Web, verify Authorization header is sent when api_key is present
  - Resolution: Update credentials or adjust server-side auth

- Invalid endpoint URL
  - Symptoms: URI parsing errors or invalid scheme
  - Checks:
    - endpoint_url must be a valid http/https URL
  - Resolution: Correct the base URL

- Protocol mismatch
  - Symptoms: Unexpected response or unsupported operation
  - Checks:
    - For Kimi Web, ensure protocol is kimi_web_ws
    - For OpenAI-compatible, ensure protocol is chat_completions or responses
  - Resolution: Adjust protocol selection in agent configuration

- Timeout exceeded
  - Symptoms: Test reports timeout
  - Checks:
    - Standard agents: read timeout is 15s; increase plugin default_timeout if needed
    - Kimi Web: health check uses 10s open/read
  - Resolution: Improve server responsiveness or adjust timeouts

- Health check failures (Kimi Web)
  - Symptoms: Non-200 response from /healthz
  - Checks:
    - Confirm Kimi Web service is running and accessible
    - Verify Authorization token if required
  - Resolution: Start or restart Kimi Web service

**Section sources**
- [ai_agents_controller.rb:90-92](file://app/controllers/ai_agents_controller.rb#L90-L92)
- [agent_client.rb:223-229](file://lib/redmine_ai_agent/agent_client.rb#L223-L229)
- [kimi_web_client.rb:412-418](file://lib/redmine_ai_agent/kimi_web_client.rb#L412-L418)
- [api-reference.md:341-346](file://kimi-web/reference/api-reference.md#L341-L346)

## Conclusion
The test_connection endpoint provides a fast, protocol-aware validation for agent connectivity:
- For Kimi Web agents, it performs a health check against /healthz
- For standard OpenAI-compatible agents, it sends a minimal request to the appropriate API endpoint
- It applies conservative timeouts suitable for admin testing and returns clear JSON results for easy interpretation
- Together with the UI and model helpers, it enables administrators to quickly diagnose and resolve connectivity issues