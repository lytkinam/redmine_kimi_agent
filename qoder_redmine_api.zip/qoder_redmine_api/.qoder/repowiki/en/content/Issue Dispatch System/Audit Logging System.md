# Audit Logging System

<cite>
**Referenced Files in This Document**
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [en.yml](file://config/locales/en.yml)
- [_dispatch_panel.html.erb](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb)
- [show.html.erb](file://app/views/ai_agent_dispatches/show.html.erb)
- [init.rb](file://init.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the audit logging and activity tracking system for dispatch activities in the Redmine AI Agent plugin. It covers how dispatches are recorded, how Redmine’s journal system is integrated to produce an audit trail, and how users can inspect dispatch history and outcomes. It also documents logging granularity, privacy and access control considerations, and compliance-relevant aspects of dispatch tracking.

## Project Structure
The audit logging system spans models, controllers, jobs, views, migrations, and plugin configuration. Dispatch records persist in the database and are surfaced in the issue journal and dedicated dispatch history UI.

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentDispatchesController<br/>POST /issues/:issue_id/ai_agent_dispatches"]
end
subgraph "Jobs"
J1["AiAgentDispatchJob<br/>perform(issue_id, ai_agent_id, triggered_by_user_id)"]
end
subgraph "Models"
M1["AiAgentDispatch<br/>dispatch records"]
M2["AiAgent<br/>agent configuration"]
M3["AiAgentAssignment<br/>user-agent mapping"]
end
subgraph "Views"
V1["_dispatch_panel.html.erb<br/>dispatch history panel"]
V2["show.html.erb<br/>dispatch detail view"]
end
subgraph "Persistence"
D1["ai_agent_dispatches table<br/>migration 003"]
end
subgraph "Localization"
L1["en.yml<br/>journal and UI labels"]
end
subgraph "Plugin"
P1["init.rb<br/>permissions and settings"]
P2["redmine_ai_agent.rb<br/>module loader"]
end
C1 --> J1
J1 --> M1
J1 --> M2
M1 --> D1
V1 --> M1
V2 --> M1
C1 --> M3
P1 --> C1
P2 --> J1
L1 --> V1
L1 --> V2
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [show.html.erb:1-57](file://app/views/ai_agent_dispatches/show.html.erb#L1-L57)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

**Section sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [show.html.erb:1-57](file://app/views/ai_agent_dispatches/show.html.erb#L1-L57)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Core Components
- Dispatch model and persistence: Tracks dispatch lifecycle, user attribution, timestamps, and payload storage.
- Job orchestration: Creates dispatch records, posts journal notes, executes agent calls, and updates status and payloads.
- Controller and UI: Provides manual dispatch initiation, permission checks, and dispatch history display.
- Localization: Supplies journal note templates and UI labels for audit-friendly messaging.
- Plugin permissions and settings: Define who can trigger dispatches and configure operational parameters.

Key audit-relevant attributes and behaviors:
- Dispatch record captures issue, agent, triggering user, status, timestamps, and optional journal linkage.
- Journal entries are posted at dispatch start, completion, and error conditions.
- Dispatch detail view exposes request/response payloads for transparency.
- Permissions gate who can trigger dispatches.

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)
- [show.html.erb:38-46](file://app/views/ai_agent_dispatches/show.html.erb#L38-L46)
- [init.rb:24-29](file://init.rb#L24-L29)

## Architecture Overview
The audit trail is produced through a deterministic flow: a user triggers a dispatch, the job creates a record, posts a “started” journal note, performs agent processing, persists request/response payloads, posts a “completed” journal note, and updates the dispatch status. Errors are captured with a “failed” journal note.

```mermaid
sequenceDiagram
participant U as "User"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Model as "AiAgentDispatch"
participant Issue as "Issue (journal)"
participant DB as "Database"
U->>Ctrl : "POST /issues/ : issue_id/ai_agent_dispatches"
Ctrl->>Ctrl : "authorize_dispatch()"
Ctrl->>Job : "perform_later(issue_id, agent_id, triggered_by)"
Job->>Model : "create!(status='running', timestamps)"
Job->>Issue : "init_journal(user, 'dispatch_started')"
Issue-->>Job : "journal saved"
Job->>DB : "update(journal_id)"
Job->>Job : "call agent, tool loop"
Job->>Model : "update!(status='done', payloads, completed_at)"
Job->>Issue : "init_journal(user, 'dispatch_done')"
Job-->>U : "dispatch complete"
Note over Job,Model : "On error : update status='error', post 'dispatch_error'"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:17-24](file://app/models/ai_agent_dispatch.rb#L17-L24)

**Section sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:17-24](file://app/models/ai_agent_dispatch.rb#L17-L24)

## Detailed Component Analysis

### Dispatch Model and Persistence
The dispatch model encapsulates the audit trail record and integrates with Redmine’s journal system via a foreign key to journal entries. It stores user attribution, timestamps, and request/response payloads for transparency.

```mermaid
classDiagram
class AiAgentDispatch {
+integer issue_id
+integer ai_agent_id
+integer triggered_by
+string status
+text request_payload
+text response_payload
+integer journal_id
+datetime dispatched_at
+datetime completed_at
+duration()
+request_data()
+response_data()
+pending?()
+running?()
+done?()
+error?()
+finished?()
}
class Issue {
+init_journal(user, notes)
+save()
}
class AiAgent {
+integer id
+string name
}
class User {
+integer id
+string name
}
AiAgentDispatch --> Issue : "belongs_to"
AiAgentDispatch --> AiAgent : "belongs_to"
AiAgentDispatch --> User : "triggered_by_user"
Issue --> AiAgentDispatch : "journal_id (optional)"
```

**Diagram sources**
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)
- [ai_agent_dispatch.rb:26-30](file://app/models/ai_agent_dispatch.rb#L26-L30)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent_dispatch_job.rb:71-78](file://app/jobs/ai_agent_dispatch_job.rb#L71-L78)

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)

### Journal Integration and Audit Trail
The job posts three types of journal notes:
- Started: Indicates dispatch initiation with agent name and timestamp.
- Completed: Records agent completion and response text.
- Error: Logs error conditions with error details.

These notes appear in the issue history and are attributed to the triggering user.

```mermaid
flowchart TD
Start(["Dispatch Job Start"]) --> CreateDispatch["Create AiAgentDispatch (status='running')"]
CreateDispatch --> PostStarted["Post 'dispatch_started' journal"]
PostStarted --> RunAgent["Call agent and tool loop"]
RunAgent --> Success{"Success?"}
Success --> |Yes| UpdateDone["Update dispatch status='done'<br/>persist payloads"]
UpdateDone --> PostDone["Post 'dispatch_done' journal"]
Success --> |No| UpdateError["Update dispatch status='error'<br/>persist error payload"]
UpdateError --> PostError["Post 'dispatch_error' journal"]
PostDone --> End(["Complete"])
PostError --> End
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:17-57](file://app/jobs/ai_agent_dispatch_job.rb#L17-L57)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)

**Section sources**
- [ai_agent_dispatch_job.rb:26-57](file://app/jobs/ai_agent_dispatch_job.rb#L26-L57)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)

### Manual Dispatch Trigger and Authorization
Manual dispatch is initiated from the issue page. The controller:
- Loads the issue
- Authorizes the current user against the project-level permission
- Enqueues the dispatch job with the current user as the trigger
- Redirects with a notice indicating the agent name

```mermaid
sequenceDiagram
participant U as "User"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant View as "_dispatch_panel.html.erb"
U->>View : "Click 'Send to AI Agent'"
View->>Ctrl : "POST /issues/ : issue_id/ai_agent_dispatches"
Ctrl->>Ctrl : "authorize_dispatch() -> allowed_to?( : dispatch_ai_agent, project)"
Ctrl->>Job : "perform_later(issue_id, agent_id, User.current.id)"
Ctrl-->>U : "flash notice : dispatch_enqueued"
Job-->>Ctrl : "job runs asynchronously"
```

**Diagram sources**
- [_dispatch_panel.html.erb:14-28](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L14-L28)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatches_controller.rb:27-31](file://app/controllers/ai_agent_dispatches_controller.rb#L27-L31)
- [en.yml:69-72](file://config/locales/en.yml#L69-L72)

**Section sources**
- [_dispatch_panel.html.erb:14-28](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L14-L28)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatches_controller.rb:27-31](file://app/controllers/ai_agent_dispatches_controller.rb#L27-L31)
- [en.yml:69-72](file://config/locales/en.yml#L69-L72)

### Dispatch History UI and Detail Views
The dispatch panel displays recent dispatches with status, trigger user, dispatch time, and duration. The detail view shows request/response payloads for transparency.

```mermaid
graph LR
Panel["_dispatch_panel.html.erb<br/>history table"] --> List["List AiAgentDispatch.for_issue(issue)"]
Detail["show.html.erb<br/>dispatch detail"] --> Fetch["Fetch AiAgentDispatch.find(id)"]
List --> Status["Status badges"]
List --> Trigger["Triggered by user"]
List --> Duration["Duration (seconds)"]
Detail --> Request["Request payload JSON"]
Detail --> Response["Response payload JSON"]
```

**Diagram sources**
- [_dispatch_panel.html.erb:31-67](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L31-L67)
- [show.html.erb:38-46](file://app/views/ai_agent_dispatches/show.html.erb#L38-L46)
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)

**Section sources**
- [_dispatch_panel.html.erb:31-67](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L31-L67)
- [show.html.erb:38-46](file://app/views/ai_agent_dispatches/show.html.erb#L38-L46)
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)

### Data Model and Indexing
The dispatch table includes indexes on foreign keys and status to support efficient queries by issue, agent, status, and trigger user. It also stores request/response payloads as text for auditability.

```mermaid
erDiagram
AI_AGENT_DISPATCHES {
integer id PK
integer issue_id FK
integer ai_agent_id FK
integer triggered_by
string status
text request_payload
text response_payload
integer journal_id
datetime dispatched_at
datetime completed_at
timestamps
}
ISSUES ||--o{ AI_AGENT_DISPATCHES : "has many"
AI_AGENTS ||--o{ AI_AGENT_DISPATCHES : "has many"
```

**Diagram sources**
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)

**Section sources**
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)

### Localization and Journal Messages
Localization keys define the exact wording of journal entries for started, completed, and error states. These keys are used by the job to post standardized audit notes.

**Section sources**
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)
- [ai_agent_dispatch_job.rb:30-56](file://app/jobs/ai_agent_dispatch_job.rb#L30-L56)
- [ai_agent_dispatch_job.rb:131-134](file://app/jobs/ai_agent_dispatch_job.rb#L131-L134)

## Dependency Analysis
The system exhibits clear separation of concerns:
- Controller depends on authorization and enqueues the job.
- Job depends on models, localization, and Redmine’s journal APIs.
- Views depend on models and localization for rendering.
- Plugin configuration defines permissions and settings.

```mermaid
graph TB
Ctrl["AiAgentDispatchesController"] --> Job["AiAgentDispatchJob"]
Job --> Model["AiAgentDispatch"]
Job --> Loc["en.yml (journal keys)"]
Job --> Issue["Issue (journal API)"]
ViewPanel["_dispatch_panel.html.erb"] --> Model
ViewDetail["show.html.erb"] --> Model
Init["init.rb (permissions/settings)"] --> Ctrl
Lib["redmine_ai_agent.rb"] --> Job
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [show.html.erb:1-57](file://app/views/ai_agent_dispatches/show.html.erb#L1-L57)
- [init.rb:24-29](file://init.rb#L24-L29)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

**Section sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [show.html.erb:1-57](file://app/views/ai_agent_dispatches/show.html.erb#L1-L57)
- [init.rb:24-29](file://init.rb#L24-L29)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Performance Considerations
- Asynchronous processing: Dispatches are queued via ActiveJob to avoid blocking the request thread.
- Retry strategy: Transient agent errors are retried to improve reliability.
- Minimal payload parsing: JSON parsing occurs only when needed; invalid payloads are handled gracefully.
- Indexing: Database indexes on issue_id, ai_agent_id, status, and triggered_by support fast queries for dispatch history.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common scenarios and diagnostics:
- Missing agent for assignee: The controller checks for an active agent assignment and returns an error message if none exists.
- Journal posting failures: The job logs errors when journal creation fails but continues processing.
- Dispatch errors: Errors are captured in the dispatch record and posted as a journal note with error details.
- Job retries: Transient agent errors are retried automatically; unexpected errors are logged with stack traces.

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [ai_agent_dispatch_job.rb:75-78](file://app/jobs/ai_agent_dispatch_job.rb#L75-L78)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

## Conclusion
The audit logging system integrates tightly with Redmine’s journal to provide a clear, user-attributed audit trail for dispatch activities. Dispatch records capture lifecycle events, payloads, and timing, while standardized journal messages ensure consistent visibility in issue history. Permissions and settings control who can trigger dispatches, and the UI surfaces historical dispatches for review.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Audit Trail Elements
- Who triggered: The dispatch record stores the triggering user ID; the UI shows the user’s name.
- When occurred: Dispatched and completed timestamps are recorded.
- What actions were taken: Journal notes indicate start, completion, and error states with agent name and contextual details.

**Section sources**
- [ai_agent_dispatch.rb:6-7](file://app/models/ai_agent_dispatch.rb#L6-L7)
- [ai_agent_dispatch.rb:26-30](file://app/models/ai_agent_dispatch.rb#L26-L30)
- [ai_agent_dispatch_job.rb:26-57](file://app/jobs/ai_agent_dispatch_job.rb#L26-L57)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

### Logging Granularity
- Dispatch lifecycle: Pending → Running → Done/Error.
- Payloads: Request and response payloads are persisted for inspection.
- Journal notes: Three distinct notes are posted during the lifecycle.

**Section sources**
- [ai_agent_dispatch.rb:2-3](file://app/models/ai_agent_dispatch.rb#L2-L3)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent_dispatch_job.rb:26-57](file://app/jobs/ai_agent_dispatch_job.rb#L26-L57)

### Privacy and Access Control
- Access control: Only users with the project-level permission can trigger dispatches.
- Payload masking: The agent model masks API keys in serialized contexts; however, payloads are stored as text and should be treated as sensitive.
- UI exposure: Dispatch detail pages show parsed JSON payloads; ensure appropriate viewer permissions.

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [show.html.erb:38-46](file://app/views/ai_agent_dispatches/show.html.erb#L38-L46)

### Compliance Considerations
- Retention: Dispatch records and associated journal notes remain in the database and issue history; retention policies should be aligned with organizational requirements.
- Integrity: Journal notes are created atomically with issue saves; errors are logged to aid forensic analysis.
- Auditing: Use the dispatch history UI and issue journal to generate reports of who triggered dispatches, when, and what outcomes occurred.

**Section sources**
- [ai_agent_dispatch_job.rb:71-78](file://app/jobs/ai_agent_dispatch_job.rb#L71-L78)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [_dispatch_panel.html.erb:31-67](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L31-L67)