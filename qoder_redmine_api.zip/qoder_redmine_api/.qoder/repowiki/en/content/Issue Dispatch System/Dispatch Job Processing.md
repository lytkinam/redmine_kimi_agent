# Dispatch Job Processing

<cite>
**Referenced Files in This Document**
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [routes.rb](file://config/routes.rb)
- [init.rb](file://init.rb)
- [_dispatch_panel.html.erb](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb)
- [show.html.erb](file://app/views/ai_agent_dispatches/show.html.erb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the dispatch job processing system that powers AI agent-driven automation for Redmine issues. It covers the job architecture using ActiveJob, including queuing, execution scheduling, and retry mechanisms. It documents the end-to-end workflow from dispatch creation to completion, including error handling and failure recovery. It also details integration with AI agent clients, including timeout handling and resource management, and explains job status tracking, progress monitoring, and lifecycle management. Finally, it provides performance considerations, queue management, and scaling strategies for high-volume dispatch scenarios.

## Project Structure
The dispatch system spans controllers, jobs, models, libraries, migrations, routes, and views. The key elements are:
- Controller triggers dispatch jobs and renders dispatch history.
- Job performs the AI agent call, manages tool-loop execution, and records outcomes.
- Models represent agents, assignments, and dispatch records with status tracking.
- Libraries encapsulate agent communication and Redmine API tool execution.
- Migrations define the persistence schema for dispatch records.
- Routes expose manual dispatch endpoints.
- Views present dispatch history and details to users.

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentDispatchesController<br/>POST /issues/:issue_id/ai_agent_dispatches"]
end
subgraph "Jobs"
J1["AiAgentDispatchJob<br/>perform_later(...)"]
end
subgraph "Models"
M1["AiAgentDispatch<br/>status, payloads, timestamps"]
M2["AiAgent<br/>agent_type, protocol, endpoint_url"]
end
subgraph "Libraries"
L1["AgentClient<br/>HTTP client, timeouts, parsing"]
L2["RedmineApiSkill<br/>tool execution"]
end
subgraph "Persistence"
D1["ai_agent_dispatches<br/>indexes, FKs"]
end
subgraph "Routing"
R1["Routes<br/>issues/:issue_id/ai_agent_dispatches"]
end
subgraph "Views"
V1["_dispatch_panel.html.erb<br/>history grid"]
V2["show.html.erb<br/>details + payloads"]
end
C1 --> J1
J1 --> M1
J1 --> L1
J1 --> L2
L1 --> M2
M1 --> D1
R1 --> C1
V1 --> C1
V2 --> M1
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)
- [routes.rb:13-14](file://config/routes.rb#L13-L14)
- [_dispatch_panel.html.erb:12-68](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L12-L68)
- [show.html.erb:6-36](file://app/views/ai_agent_dispatches/show.html.erb#L6-L36)

**Section sources**
- [routes.rb:13-14](file://config/routes.rb#L13-L14)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)
- [_dispatch_panel.html.erb:12-68](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L12-L68)
- [show.html.erb:6-36](file://app/views/ai_agent_dispatches/show.html.erb#L6-L36)

## Core Components
- AiAgentDispatchesController: Manages manual dispatch creation and dispatch listing/detail rendering for an issue.
- AiAgentDispatchJob: Orchestrates the end-to-end dispatch lifecycle, including dispatch record creation, agent invocation, tool-loop execution, payload persistence, journal notes, and error handling with ActiveJob retries.
- AiAgentDispatch: Domain model for dispatch records with status, payloads, timestamps, and helpers for duration and JSON parsing.
- AiAgent: Domain model for agent configuration, including type, protocol, endpoint, model name, and system prompt resolution.
- AgentClient: HTTP client that posts to agent endpoints, supports two protocols, extracts text, and raises structured errors with status/body.
- RedmineApiSkill: Executes Redmine API tool calls on behalf of the agent during tool-loop iterations.
- Database Schema: ai_agent_dispatches table persists dispatch records with indexes and foreign keys.
- Routing: Exposes manual dispatch endpoints under issues.
- Views: Present dispatch history and details to users.

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)
- [routes.rb:13-14](file://config/routes.rb#L13-L14)
- [_dispatch_panel.html.erb:12-68](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L12-L68)
- [show.html.erb:6-36](file://app/views/ai_agent_dispatches/show.html.erb#L6-L36)

## Architecture Overview
The system uses ActiveJob to enqueue dispatch tasks. The controller triggers a job with issue, agent, and triggering user identifiers. The job creates a dispatch record, posts a “task sent” journal note, invokes the agent client, optionally loops through tool calls via the Redmine API skill, persists request/response payloads, posts a completion journal note, and tracks duration. Errors are captured, recorded, and retried according to ActiveJob’s retry policy.

```mermaid
sequenceDiagram
participant U as "User"
participant C as "AiAgentDispatchesController"
participant Q as "ActiveJob Queue"
participant J as "AiAgentDispatchJob"
participant DB as "AiAgentDispatch"
participant AC as "AgentClient"
participant RS as "RedmineApiSkill"
U->>C : "POST /issues/ : issue_id/ai_agent_dispatches"
C->>Q : "perform_later(issue_id, ai_agent_id, user_id)"
Q-->>J : "Dequeue and run perform(...)"
J->>DB : "create!(status='running', dispatched_at)"
J->>U : "post_journal('dispatch started')"
J->>AC : "call(issue, triggered_by=user)"
alt "tool_calls present"
loop "up to 10 turns"
AC-->>J : "initial result"
J->>RS : "execute_tool_call(...) for each tool_call"
RS-->>J : "tool results"
J->>AC : "post_to_agent(messages with tool results)"
end
end
AC-->>J : "final result"
J->>DB : "update!(status='done', request/response payloads, completed_at)"
J->>U : "post_journal('dispatch done')"
J-->>Q : "success"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:27-31](file://app/controllers/ai_agent_dispatches_controller.rb#L27-L31)
- [ai_agent_dispatch_job.rb:18-57](file://app/jobs/ai_agent_dispatch_job.rb#L18-L57)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

## Detailed Component Analysis

### AiAgentDispatchJob
Responsibilities:
- Enqueue and execute dispatches.
- Create running dispatch records and post initial journal notes.
- Invoke AgentClient and run tool-loop with RedmineApiSkill.
- Persist request/response payloads and mark completion.
- Post final journal note and log metrics.
- Handle errors by updating status and posting error journal notes, then re-raising to leverage ActiveJob retries.

Key behaviors:
- Retry policy configured for transient AgentError with polynomial backoff and fixed number of attempts.
- Tool-loop executes up to a bounded number of turns, feeding tool results back to the agent.
- Safe journal posting with error logging.
- Robust error handling and logging.

```mermaid
flowchart TD
Start(["perform(issue_id, agent_id, user_id)"]) --> Load["Load Issue/AI Agent/User"]
Load --> Valid{"All records found?"}
Valid --> |No| LogWarn["Log warning and return"]
Valid --> |Yes| Create["Create AiAgentDispatch (status=running)"]
Create --> JournalStart["Post 'dispatch started' journal"]
JournalStart --> Call["AgentClient.call(issue)"]
Call --> ToolLoop{"Tool calls present?"}
ToolLoop --> |No| SaveDone["Persist request/response payloads<br/>Set status=done, completed_at"]
ToolLoop --> |Yes| Loop["Execute tools via RedmineApiSkill<br/>Append tool results<br/>Re-post to agent (up to N turns)"]
Loop --> SaveDone
SaveDone --> JournalDone["Post 'dispatch done' journal"]
JournalDone --> LogInfo["Log duration and completion"]
LogInfo --> End(["Exit"])
Call --> |AgentError| HandleErr["handle_error(status='error')<br/>Post error journal"]
HandleErr --> ReRaise["Re-raise to ActiveJob retry"]
LogWarn --> End
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### AgentClient
Responsibilities:
- Build protocol-specific payloads (chat completions vs responses).
- Resolve endpoint URLs based on agent configuration.
- Perform HTTP requests with timeouts and SSL handling.
- Parse responses and extract text content.
- Raise structured AgentError with status and body for non-2xx responses.

Key behaviors:
- Supports two protocols and delegates Kimi Web WebSocket to a dedicated client.
- Applies plugin-wide default timeout and explicit open/read timeouts.
- Extracts text from both protocol response shapes.
- Provides robust error handling for network, JSON, and URI issues.

```mermaid
classDiagram
class AgentClient {
+call(issue, triggered_by)
-build_payload(issue)
-build_chat_completions_payload(issue)
-build_responses_payload(issue)
-issue_context_message(issue)
-redmine_tools(issue)
-post_to_agent(payload)
-resolve_endpoint()
-extract_text(raw)
}
class AgentError {
+status
+body
}
AgentClient --> AgentError : "raises"
```

**Diagram sources**
- [agent_client.rb:8-261](file://lib/redmine_ai_agent/agent_client.rb#L8-L261)

**Section sources**
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

### RedmineApiSkill
Responsibilities:
- Execute tool calls returned by the agent.
- Implement Redmine REST API operations: get issue, update issue, list statuses, get project.
- Manage timeouts and parse responses safely.

Key behaviors:
- Accepts tool_call hashes and dispatches to appropriate methods.
- Wraps HTTP errors into structured exceptions with status codes.
- Returns serializable results or error payloads.

```mermaid
classDiagram
class RedmineApiSkill {
+execute_tool_call(tool_call)
-get(path)
-put(path, body)
-perform(uri, request)
+get_issue(issue_id)
+update_issue(issue_id, notes, status_id, done_ratio)
+list_statuses()
+get_project(project_id)
}
class RedmineApiError {
+status
}
RedmineApiSkill --> RedmineApiError : "raises"
```

**Diagram sources**
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)

**Section sources**
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [redmine_api_skill.rb:67-86](file://lib/redmine_ai_agent/redmine_api_skill.rb#L67-L86)
- [redmine_api_skill.rb:107-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L127)

### AiAgentDispatch Model
Responsibilities:
- Track dispatch lifecycle with statuses: pending, running, done, error.
- Store request/response payloads as JSON.
- Provide helpers for duration calculation and JSON parsing with safety.
- Scope queries for filtering by status and ordering by dispatch time.

Lifecycle and helpers:
- Status predicates for convenience.
- Duration computed from dispatched_at to completed_at.
- Safe JSON parsing with fallback to nil on parse errors.

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### AiAgent Model
Responsibilities:
- Define agent configuration: type, protocol, endpoint, model name, system prompt.
- Provide system prompt templates per agent type with Redmine context substitution.
- Offer helpers to detect protocol and agent type.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

### Controller and Routing
Responsibilities:
- Controller:
  - Authorize dispatch actions.
  - Find the target issue.
  - Locate an active agent assignment for the assignee.
  - Enqueue AiAgentDispatchJob with current user as the trigger.
  - Render dispatch history and detail pages.
- Routing:
  - Expose manual dispatch endpoints under issues.

Manual dispatch flow:
- Validates permissions and presence of an active agent assignment.
- Enqueues the job and redirects with a notice.

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [routes.rb:13-14](file://config/routes.rb#L13-L14)

### Views
Responsibilities:
- _dispatch_panel.html.erb:
  - Renders a panel with a manual dispatch button.
  - Lists recent dispatches with status badges, triggered by, dispatched time, duration, and links to details.
- show.html.erb:
  - Displays dispatch detail: agent, status, triggered by, timestamps, duration, and JSON payloads.

**Section sources**
- [_dispatch_panel.html.erb:12-68](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L12-L68)
- [show.html.erb:6-36](file://app/views/ai_agent_dispatches/show.html.erb#L6-L36)

## Dependency Analysis
High-level dependencies:
- Controller depends on models and ActiveJob to enqueue tasks.
- Job depends on models, AgentClient, and RedmineApiSkill.
- AgentClient depends on AiAgent configuration and plugin settings.
- RedmineApiSkill depends on plugin settings for base URL and API key.
- Views depend on models for rendering dispatch history and details.

```mermaid
graph LR
Controller["AiAgentDispatchesController"] --> Job["AiAgentDispatchJob"]
Job --> ModelDispatch["AiAgentDispatch"]
Job --> ModelAgent["AiAgent"]
Job --> Client["AgentClient"]
Job --> Skill["RedmineApiSkill"]
Client --> ModelAgent
Skill --> Settings["Plugin Settings"]
Views["Dispatch Views"] --> ModelDispatch
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:22-24](file://lib/redmine_ai_agent/agent_client.rb#L22-L24)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [_dispatch_panel.html.erb:12-68](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L12-L68)

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:22-24](file://lib/redmine_ai_agent/agent_client.rb#L22-L24)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [_dispatch_panel.html.erb:12-68](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L12-L68)

## Performance Considerations
- Queue isolation and concurrency:
  - Jobs are queued on the default queue. Consider dedicated queues per agent type or protocol to balance load and avoid contention.
- Backoff and retries:
  - Transient AgentError is retried with polynomial backoff and a fixed cap. Tune attempts and wait strategy based on observed SLAs.
- Timeouts:
  - AgentClient applies plugin-wide default timeout and explicit open/read timeouts. Ensure values accommodate agent latency and network conditions.
  - RedmineApiSkill applies its own read timeout; keep reasonable limits to prevent long-hanging requests.
- Tool-loop bounds:
  - The tool-loop caps iterations to a small fixed number to prevent runaway loops. Keep this bound conservative to avoid excessive latency.
- Payload sizes:
  - Request/response payloads are persisted as text. Large payloads increase storage and JSON parsing overhead. Consider trimming or offloading large artifacts externally.
- Indexes and queries:
  - ai_agent_dispatches table includes indexes on issue_id, ai_agent_id, status, and triggered_by. These support efficient listing and filtering.
- Scaling strategies:
  - Horizontal scaling: Run multiple workers behind the same queue backend to process jobs concurrently.
  - Vertical scaling: Increase worker count per environment and tune concurrency per process.
  - Queue prioritization: Use separate queues for auto-dispatches vs manual dispatches to manage urgency.
  - Circuit breakers: Optionally guard external agent endpoints with circuit breaker patterns to fail fast under sustained failures.
  - Monitoring: Track queue depth, job runtime percentiles, retry counts, and error rates.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and remedies:
- Missing records during job execution:
  - If any of issue, agent, or user is missing, the job logs a warning and exits early. Verify assignment integrity and cleanup orphaned records.
- Agent connectivity and timeouts:
  - AgentError indicates non-2xx responses or timeouts. Check endpoint URL, API key, and network reachability. Adjust plugin default timeout if needed.
- JSON parsing errors:
  - Invalid JSON from agent or Redmine API results in structured errors. Inspect payloads and normalize agent output.
- Tool-loop failures:
  - Tool execution errors are logged and the best-effort text is returned. Review tool arguments and Redmine API availability.
- Journal posting failures:
  - Failures to post journal notes are logged but do not abort the job. Investigate Redmine permissions and API key validity.
- Retry storms:
  - Frequent transient errors can overload the queue. Monitor retry counts and adjust backoff or add circuit breaking.

**Section sources**
- [ai_agent_dispatch_job.rb:12-15](file://app/jobs/ai_agent_dispatch_job.rb#L12-L15)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [redmine_api_skill.rb:57-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L57-L61)
- [ai_agent_dispatch_job.rb:75-78](file://app/jobs/ai_agent_dispatch_job.rb#L75-L78)

## Conclusion
The dispatch job processing system integrates ActiveJob with AI agent clients and Redmine’s API to automate issue handling. It provides robust queuing, retry, error handling, and visibility through dispatch records and journal notes. By tuning timeouts, retry policies, and queue topology, teams can achieve reliable, scalable automation for high-volume dispatch scenarios.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Database Schema: ai_agent_dispatches
- Columns: issue_id, ai_agent_id, triggered_by, status, request_payload, response_payload, journal_id, dispatched_at, completed_at, timestamps.
- Indexes: issue_id, ai_agent_id, status, triggered_by.
- Foreign keys: references to issues and ai_agents.

**Section sources**
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)

### Plugin Settings
- Enabled flag, base URL for Redmine API, default timeout for agent calls.
- Used by AgentClient and RedmineApiSkill to configure endpoints and timeouts.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [agent_client.rb:202-203](file://lib/redmine_ai_agent/agent_client.rb#L202-L203)
- [redmine_api_skill.rb:28-31](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L31)