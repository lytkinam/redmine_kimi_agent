# Automatic Dispatch Triggers

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the automatic dispatch trigger system that integrates with Redmine’s event system to automatically dispatch AI agents when issues are assigned to users. It covers how the plugin registers hooks, detects issue assignment events, evaluates trigger conditions, and executes the dispatch workflow end-to-end. It also documents permissions, agent assignment validation, practical activation scenarios, and common troubleshooting steps.

## Project Structure
The plugin is structured around Redmine’s plugin conventions:
- Plugin bootstrap and settings are defined in the plugin initializer.
- Hook listeners are registered via the plugin loader.
- Event hooks listen to issue lifecycle events and conditionally enqueue jobs.
- Jobs encapsulate the dispatch workflow, including agent invocation and optional tool loops.
- Models define the data schema for agents, assignments, and dispatch records.
- Routes expose manual dispatch endpoints under issues.

```mermaid
graph TB
subgraph "Plugin Bootstrap"
INIT["init.rb<br/>Registers plugin, settings, permissions, admin menu"]
LOADER["lib/redmine_ai_agent.rb<br/>Re-exports and registers hooks"]
end
subgraph "Event Hooks"
HOOKS["lib/redmine_ai_agent/hooks.rb<br/>Issue edit/new save hooks"]
end
subgraph "Jobs"
JOB["app/jobs/ai_agent_dispatch_job.rb<br/>Performs dispatch, posts journals, runs tool loop"]
end
subgraph "Models"
DISPATCH["app/models/ai_agent_dispatch.rb<br/>Dispatch record"]
ASSIGNMENT["app/models/ai_agent_assignment.rb<br/>User-agent assignment"]
AGENT["app/models/ai_agent.rb<br/>Agent definition and prompts"]
end
subgraph "Clients"
AC["lib/redmine_ai_agent/agent_client.rb<br/>Agent HTTP client"]
SKILL["lib/redmine_ai_agent/redmine_api_skill.rb<br/>Redmine API skill executor"]
end
ROUTES["config/routes.rb<br/>Manual dispatch routes"]
INIT --> LOADER
LOADER --> HOOKS
HOOKS --> JOB
JOB --> DISPATCH
JOB --> AC
JOB --> SKILL
HOOKS --> ASSIGNMENT
ASSIGNMENT --> AGENT
ROUTES --> JOB
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- Plugin initializer defines plugin metadata, settings, admin menu, and project-level permissions for dispatch and management.
- Hook listener subscribes to issue creation and update events and triggers dispatch when conditions are met.
- Dispatch job performs the AI agent call, posts journal notes, optionally executes tool calls against Redmine, and persists results.
- Models represent agents, assignments, and dispatch records with validations and scopes.
- Agent client abstracts agent-specific protocols and builds payloads for both Chat Completions and Responses APIs.
- Redmine API skill executes tool calls returned by the agent to read/update issues and projects.

**Section sources**
- [init.rb:12-29](file://init.rb#L12-L29)
- [hooks.rb:2-22](file://lib/redmine_ai_agent/hooks.rb#L2-L22)
- [ai_agent_dispatch_job.rb:1-67](file://app/jobs/ai_agent_dispatch_job.rb#L1-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)

## Architecture Overview
The automatic dispatch system listens to Redmine’s issue lifecycle hooks, validates eligibility, and enqueues a background job. The job creates a dispatch record, posts a “dispatch started” journal note, invokes the agent, optionally loops through tool calls, posts a “dispatch done” note, and persists results.

```mermaid
sequenceDiagram
participant Redmine as "Redmine Core"
participant Hooks as "Hooks Listener"
participant JobQ as "ActiveJob Queue"
participant Job as "AiAgentDispatchJob"
participant Model as "AiAgentDispatch"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
Redmine->>Hooks : "Issue created/updated"
Hooks->>Hooks : "check_and_auto_dispatch()"
Hooks->>JobQ : "perform_later(issue_id, agent_id, triggered_by)"
JobQ-->>Job : "Dequeue and run"
Job->>Model : "Create dispatch record"
Job->>Redmine : "Post 'dispatch started' journal"
Job->>Agent : "Call agent with issue context"
Agent-->>Job : "Initial result"
Job->>Skill : "Execute tool calls (loop)"
Skill-->>Job : "Tool results"
Job->>Agent : "Send updated messages"
Agent-->>Job : "Final text"
Job->>Model : "Update dispatch status and payloads"
Job->>Redmine : "Post 'dispatch done' journal"
```

**Diagram sources**
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

## Detailed Component Analysis

### Hook Registration and Event Detection
- The plugin registers a listener that responds to:
  - New issue creation after save.
  - Existing issue edits after save.
- The listener checks whether the plugin is enabled and whether the assignee changed (for edits) or the new issue is assigned (for creation).
- Eligibility is determined by finding an active agent assignment for the assignee with auto-dispatch enabled.

```mermaid
flowchart TD
Start(["Issue event"]) --> Enabled{"Plugin enabled?"}
Enabled --> |No| EndNo["Exit"]
Enabled --> |Yes| Extract["Extract issue and current user"]
Extract --> IsNew{"New issue?"}
IsNew --> |Yes| CheckAssigned{"Has assigned_to_id?"}
IsNew --> |No| AssigneeChanged{"Assignee changed?"}
CheckAssigned --> |No| EndNo
CheckAssigned --> |Yes| Proceed["Proceed"]
AssigneeChanged --> |No| EndNo
AssigneeChanged --> |Yes| Proceed
Proceed --> FindAssignment["Find active agent assignment for assignee"]
FindAssignment --> AutoDispatch{"auto_dispatch enabled?"}
AutoDispatch --> |No| EndNo
AutoDispatch --> |Yes| Enqueue["Enqueue AiAgentDispatchJob"]
Enqueue --> EndOk(["Done"])
```

**Diagram sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

**Section sources**
- [hooks.rb:2-22](file://lib/redmine_ai_agent/hooks.rb#L2-L22)
- [hooks.rb:51-71](file://lib/redmine_ai_agent/hooks.rb#L51-L71)

### Trigger Conditions and Validation
- Plugin enabled flag from settings.
- Assignee is a User.
- Active agent assignment exists for the assignee.
- Assignment has auto_dispatch enabled.
- Trigger user defaults to the current user or system if unavailable.

These conditions ensure that dispatches occur only when:
- The plugin is turned on.
- An assignee exists.
- An active agent is assigned to the user.
- Auto-dispatch is enabled for that assignment.

**Section sources**
- [hooks.rb:51-71](file://lib/redmine_ai_agent/hooks.rb#L51-L71)
- [ai_agent_assignment.rb:22-24](file://app/models/ai_agent_assignment.rb#L22-L24)

### Dispatch Workflow: From Trigger to Job Creation
- The job loads the issue, agent, and triggering user.
- Creates a dispatch record with status “running” and timestamps.
- Posts a “dispatch started” journal note.
- Invokes the agent client with the constructed payload.
- Executes a tool-call loop using the Redmine API skill when supported.
- Persists request/response payloads and final status.
- Posts a “dispatch done” journal note.
- Handles errors by marking the dispatch as “error” and logging.

```mermaid
sequenceDiagram
participant Job as "AiAgentDispatchJob"
participant DB as "AiAgentDispatch"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
Job->>DB : "Create running dispatch"
Job->>Job : "Post 'started' journal"
Job->>Agent : "call(issue, triggered_by)"
Agent-->>Job : "result"
loop "Up to 10 tool-call turns"
Job->>Skill : "execute_tool_call()"
Skill-->>Job : "result"
Job->>Agent : "send updated messages"
Agent-->>Job : "next result"
end
Job->>DB : "Update payloads and status 'done'"
Job->>Job : "Post 'done' journal"
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:17-67](file://app/jobs/ai_agent_dispatch_job.rb#L17-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### Permissions and Access Control
- Project-level permissions are defined for:
  - dispatch_ai_agent: allows creating and viewing issue dispatches.
  - manage_ai_agents: allows managing agents and assignments.
- These permissions gate who can trigger or manage dispatches and agent configurations.

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)

### Agent Integration Details
- Agent client supports two protocols:
  - Chat Completions: sends messages and optional tools.
  - Responses: sends input and instructions.
- Tool definitions are provided for agents that support function/tool calls (excluding Kimi Web and Qoder).
- Agent client resolves endpoint URLs and handles timeouts and errors.

**Section sources**
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)

### Redmine API Skill Execution
- Executes tool calls returned by the agent:
  - redmine_get_issue
  - redmine_update_issue
  - redmine_list_statuses
  - redmine_get_project
- Uses the assignee’s API key and configured base URL to call Redmine endpoints.

**Section sources**
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [redmine_api_skill.rb:67-86](file://lib/redmine_ai_agent/redmine_api_skill.rb#L67-L86)

### Manual Dispatch Endpoint
- Manual dispatch is exposed under issues for creating a dispatch and viewing details.
- Useful for testing and ad-hoc dispatches outside of automatic triggers.

**Section sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)

## Dependency Analysis
The following diagram shows how components depend on each other in the automatic dispatch pipeline.

```mermaid
graph LR
INIT["init.rb"] --> LOADER["lib/redmine_ai_agent.rb"]
LOADER --> HOOKS["hooks.rb"]
HOOKS --> ASSIGNMENT["ai_agent_assignment.rb"]
ASSIGNMENT --> AGENT["ai_agent.rb"]
HOOKS --> JOB["ai_agent_dispatch_job.rb"]
JOB --> DISPATCH["ai_agent_dispatch.rb"]
JOB --> AC["agent_client.rb"]
JOB --> SKILL["redmine_api_skill.rb"]
ROUTES["routes.rb"] -. manual dispatch .-> JOB
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [routes.rb:1-17](file://config/routes.rb#L1-17)

**Section sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

## Performance Considerations
- Background job queuing ensures automatic dispatch does not block the web request.
- Agent client applies configurable timeouts and retries for transient errors.
- Tool-loop iteration is capped to prevent long-running cycles.
- Journal posting occurs synchronously within the job to ensure visibility of dispatch events.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Plugin disabled: Verify the enabled setting is true; dispatches will not trigger otherwise.
- No active agent assignment: Ensure a user has an active agent assignment with auto_dispatch enabled.
- Assignee missing: Dispatches require a valid assignee; newly created issues must be assigned.
- Agent endpoint errors: Check endpoint URL, API key, and network connectivity; agent client raises explicit errors on non-2xx responses.
- Timeout errors: Increase default_timeout in plugin settings; agent and Redmine API skills enforce timeouts.
- Tool-call failures: Confirm the agent supports tools and that the assignee’s API key has sufficient permissions.
- Missing journal notes: Ensure the job runs successfully and that posting journals does not fail silently.

**Section sources**
- [hooks.rb:51-71](file://lib/redmine_ai_agent/hooks.rb#L51-L71)
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

## Conclusion
The automatic dispatch trigger system leverages Redmine’s hook infrastructure to detect issue assignment events, validate eligibility via agent assignments, and enqueue a robust dispatch job. The job orchestrates agent communication, optional tool loops, and journaling while persisting outcomes. Proper configuration of plugin settings, permissions, and agent assignments ensures reliable automation.