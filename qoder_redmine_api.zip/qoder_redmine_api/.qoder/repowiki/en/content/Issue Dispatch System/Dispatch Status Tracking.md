# Dispatch Status Tracking

<cite>
**Referenced Files in This Document**
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [show.html.erb](file://app/views/ai_agent_dispatches/show.html.erb)
- [_dispatch_panel.html.erb](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [init.rb](file://init.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the dispatch status tracking and monitoring system for AI agent-driven issue processing in Redmine. It explains how dispatch records are created, tracked, and viewed, including status indicators, timestamps, payload storage, and audit trail integration via issue journals. It also documents the dispatch history view, detail view, filtering and searching capabilities, and guidance for monitoring performance and identifying bottlenecks.

## Project Structure
The dispatch system spans models, controllers, jobs, views, migrations, routing, localization, hooks, and skills:
- Model: AiAgentDispatch defines dispatch records, statuses, and helpers.
- Controller: AiAgentDispatchesController exposes index, show, and manual creation endpoints.
- Job: AiAgentDispatchJob performs asynchronous dispatch processing, transitions statuses, and posts journal notes.
- Views: Dispatch panel and detail view present history and payload data.
- Migration: Creates the ai_agent_dispatches table with indexes and foreign keys.
- Routes: Defines per-issue dispatch endpoints.
- Locales: Provide labels, status translations, and journal messages.
- Hooks: Auto-dispatch on issue assignment and inject the dispatch panel into the issue page.
- Skills: RedmineApiSkill executes tool calls returned by the agent.

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentDispatchesController<br/>index/show/create"]
end
subgraph "Models"
M1["AiAgentDispatch<br/>STATUSES/scopes/status helpers"]
M2["AiAgent<br/>agent metadata"]
M3["AiAgentAssignment<br/>assignment lookup"]
end
subgraph "Jobs"
J1["AiAgentDispatchJob<br/>perform/loop/error handling"]
end
subgraph "Views"
V1["_dispatch_panel.html.erb<br/>history table"]
V2["show.html.erb<br/>detail view"]
end
subgraph "Infrastructure"
R1["routes.rb<br/>per-issue dispatch routes"]
L1["en.yml<br/>labels/statuses/journal"]
H1["hooks.rb<br/>auto-dispatch + panel injection"]
S1["redmine_api_skill.rb<br/>tool-call executor"]
D1["003_create_ai_agent_dispatches.rb<br/>schema/indexes"]
end
C1 --> M1
C1 --> M2
C1 --> M3
J1 --> M1
J1 --> M2
J1 --> S1
V1 --> M1
V2 --> M1
R1 --> C1
H1 --> V1
H1 --> J1
D1 --> M1
L1 --> V1
L1 --> V2
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [show.html.erb:1-57](file://app/views/ai_agent_dispatches/show.html.erb#L1-L57)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Core Components
- Dispatch record model
  - Statuses: pending, running, done, error.
  - Scopes: for_issue, pending, running, completed, errored.
  - Helpers: pending?, running?, done?, error?, finished?.
  - Timestamps: dispatched_at, completed_at; duration computed as completed_at - dispatched_at.
  - Payloads: request_payload and response_payload stored as text; parsed safely to JSON.
  - Associations: belongs_to issue, ai_agent, triggered_by_user; optional journal.
  - Validations: presence checks for issue_id, ai_agent_id, triggered_by; status inclusion in allowed set.

- Dispatch controller
  - Index: lists dispatches for an issue with included associations.
  - Show: renders a single dispatch; enforces that the dispatch belongs to the current issue.
  - Create: manual trigger; finds active agent assignment for the issue assignee; enqueues job; redirects with notice.

- Dispatch job
  - Performs the dispatch asynchronously; sets status to running and timestamps.
  - Posts a journal note indicating dispatch started.
  - Executes agent call and optional tool-call loop via RedmineApiSkill.
  - Persists request/response payloads and sets status to done with completion timestamp.
  - Posts a journal note summarizing completion.
  - On error, sets status to error, stores error payload, posts journal note, and retries per policy.

- Views
  - Dispatch panel: shows recent dispatch history with status badges, triggered_by, dispatched_at, duration, and links to detail.
  - Detail view: displays agent, status, triggered_by, timestamps, duration, request/response payloads.

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [show.html.erb:1-57](file://app/views/ai_agent_dispatches/show.html.erb#L1-L57)

## Architecture Overview
The dispatch lifecycle integrates user actions, automatic triggers, background processing, and UI feedback.

```mermaid
sequenceDiagram
participant U as "User"
participant R as "Routes"
participant C as "AiAgentDispatchesController"
participant J as "AiAgentDispatchJob"
participant M as "AiAgentDispatch"
participant A as "AiAgent"
participant S as "RedmineApiSkill"
participant I as "Issue Journal"
U->>R : "POST /issues/ : id/ai_agent_dispatches"
R->>C : "create"
C->>C : "authorize + find active agent assignment"
C->>J : "perform_later(issue_id, agent_id, user_id)"
J->>M : "create(status='running', timestamps)"
J->>I : "post journal 'dispatch started'"
J->>A : "client.call(issue)"
J->>S : "execute tool calls (loop)"
S-->>J : "results"
J->>M : "update(status='done', payloads, completed_at)"
J->>I : "post journal 'dispatch done'"
J-->>U : "job completes"
```

**Diagram sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:17-24](file://app/models/ai_agent_dispatch.rb#L17-L24)
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)

## Detailed Component Analysis

### Dispatch Record Management
- Status indicators and transitions
  - Allowed statuses: pending, running, done, error.
  - Transitions:
    - pending → running when the job starts.
    - running → done upon successful completion.
    - running → error on failure; error payloads persisted.
  - Helpers:
    - finished? indicates terminal states (done or error).
    - duration computes wall-clock time between dispatched_at and completed_at when available.

- Timestamps and metadata
  - dispatched_at: set when the job creates the record.
  - completed_at: set when the job finishes (success or error).
  - request_payload and response_payload: stored as text; parsed safely to JSON for display.

- Audit trail
  - Each dispatch associates with a journal record via journal_id.
  - Journal entries are posted for start, completion, and error events.

- Filtering and searching
  - Scopes enable filtering by status and issue.
  - UI supports viewing by status badges and sorting by dispatched_at.

**Section sources**
- [ai_agent_dispatch.rb:2-24](file://app/models/ai_agent_dispatch.rb#L2-L24)
- [ai_agent_dispatch.rb:26-42](file://app/models/ai_agent_dispatch.rb#L26-L42)
- [ai_agent_dispatch_job.rb:17-47](file://app/jobs/ai_agent_dispatch_job.rb#L17-L47)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

### Dispatch History View
- Purpose: Show recent dispatches for an issue with quick status and timing insights.
- Fields displayed:
  - ID, Status badge, Triggered by, Dispatched at (UTC), Duration, View link.
- Behavior:
  - Renders a table of up to 10 most recent dispatches for the issue.
  - Links to the detail view for each dispatch.

**Section sources**
- [_dispatch_panel.html.erb:31-67](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L31-L67)

### Dispatch Detail View
- Purpose: Present full processing details for a single dispatch.
- Content:
  - Agent name, type, and protocol.
  - Status, triggered_by, dispatched_at, completed_at, duration.
  - Request payload and response payload (pretty-printed JSON).
- UX:
  - Status badges with distinct styles per state.
  - Back link to the issue.

**Section sources**
- [show.html.erb:1-57](file://app/views/ai_agent_dispatches/show.html.erb#L1-L57)

### Manual Trigger and Auto-Dispatch
- Manual trigger
  - Button on the issue page invokes POST to create a new dispatch.
  - Requires project-level permission to dispatch AI agents.
  - Enqueues the job and shows a notice.

- Auto-dispatch
  - Hook listens to issue creation/edit save events.
  - If the assignee has an active agent assignment with auto-dispatch enabled, enqueues a dispatch.

**Section sources**
- [_dispatch_panel.html.erb:13-29](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L13-L29)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [hooks.rb:10-22](file://lib/redmine_ai_agent/hooks.rb#L10-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

### Tool-Call Loop and Payload Persistence
- The job executes an agentic loop when the agent responds with tool_calls.
- RedmineApiSkill executes tool calls against the Redmine API and feeds results back to the agent.
- After completion, the job persists request and raw response payloads and marks the dispatch as done.

**Section sources**
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)

### Status Field Meanings and Transition Rules
- pending: A dispatch record exists but processing has not started.
- running: Processing is in progress; dispatched_at is set.
- done: Processing completed successfully; completed_at is set and duration is available.
- error: Processing failed; completed_at is set and error payload is stored.

Transitions are driven by the job:
- pending → running when the job starts.
- running → done or error when the job finishes.

**Section sources**
- [ai_agent_dispatch.rb:1-12](file://app/models/ai_agent_dispatch.rb#L1-L12)
- [ai_agent_dispatch.rb:20-24](file://app/models/ai_agent_dispatch.rb#L20-L24)
- [ai_agent_dispatch_job.rb:17-47](file://app/jobs/ai_agent_dispatch_job.rb#L17-L47)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

### Filtering and Searching Capabilities
- By status
  - Scopes: pending, running, completed, errored.
- By issue
  - Scope: for_issue orders by dispatched_at descending.
- UI
  - Dispatch panel shows recent dispatches with status badges and durations.
  - Detail view shows request/response payloads for inspection.

Note: There are no explicit date-range filters in the provided code; the UI shows the 10 most recent dispatches per issue.

**Section sources**
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)
- [_dispatch_panel.html.erb:44-62](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L44-L62)

### Monitoring Dispatch Performance and Bottlenecks
- Metrics to track
  - Duration: inspect completed_at - dispatched_at for each dispatch.
  - Throughput: count of done/error per time window.
  - Error rate: ratio of errored to total dispatches.
- Where to observe
  - Dispatch panel: durations and status badges for quick triage.
  - Detail view: request/response payloads for deeper analysis.
  - Logs: job-level info and warnings for long-running or failing tasks.
- Recommendations
  - Use the duration metric to identify slow agents or tool-call loops.
  - Monitor error payloads to detect recurring failures (e.g., timeouts, invalid responses).
  - Investigate retry behavior for transient errors.

**Section sources**
- [ai_agent_dispatch.rb:26-30](file://app/models/ai_agent_dispatch.rb#L26-L30)
- [ai_agent_dispatch_job.rb:5-6](file://app/jobs/ai_agent_dispatch_job.rb#L5-L6)
- [ai_agent_dispatch_job.rb:59-67](file://app/jobs/ai_agent_dispatch_job.rb#L59-L67)

## Dependency Analysis
```mermaid
classDiagram
class AiAgentDispatch {
+STATUSES
+for_issue(issue)
+pending()
+running()
+completed()
+errored()
+pending?()
+running?()
+done?()
+error?()
+finished?()
+duration()
+request_data()
+response_data()
}
class AiAgentDispatchesController {
+index()
+show()
+create()
}
class AiAgentDispatchJob {
+perform(issue_id, ai_agent_id, triggered_by_user_id)
-run_tool_loop(client, agent, issue, result)
-handle_error(dispatch, issue, trigger, agent, error_message)
-post_journal(issue, user, message)
}
class RedmineApiSkill {
+execute_tool_call(tool_call)
+get_issue(issue_id)
+update_issue(issue_id, notes, status_id, done_ratio)
+list_statuses()
+get_project(project_id)
}
class AiAgent {
+ai_agent_assignments
+ai_agent_dispatches
}
class AiAgentAssignment {
+user
+ai_agent
+auto_dispatch?
}
AiAgentDispatchesController --> AiAgentDispatch : "queries"
AiAgentDispatchesController --> AiAgentAssignment : "lookup"
AiAgentDispatchJob --> AiAgentDispatch : "creates/updates"
AiAgentDispatchJob --> AiAgent : "client.call()"
AiAgentDispatchJob --> RedmineApiSkill : "executes tool calls"
AiAgentDispatch --> AiAgent : "belongs_to"
AiAgentDispatch --> AiAgentAssignment : "triggered_by_user"
AiAgent --> AiAgentDispatch : "has_many"
AiAgentAssignment --> AiAgent : "belongs_to"
```

**Diagram sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

## Performance Considerations
- Background processing
  - Dispatches are processed asynchronously via ActiveJob, preventing UI blocking.
- Retries
  - Transient agent errors are retried with exponential backoff to mitigate temporary failures.
- Payload parsing
  - Request/response payloads are parsed safely; malformed JSON is handled gracefully.
- Tool-call loop
  - Limits iterations to prevent runaway loops; captures final content when exhausted.
- Indexes
  - Database indexes on issue_id, ai_agent_id, status, and triggered_by improve query performance.

**Section sources**
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [003_create_ai_agent_dispatches.rb:16-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L16-L22)

## Troubleshooting Guide
- Dispatch shows as error
  - Inspect the error payload stored in response_payload.
  - Review journal entries for the error message posted during dispatch.
- No dispatches appear
  - Verify the issue has associated dispatches via the dispatch panel.
  - Confirm the user has the project-level permission to dispatch AI agents.
- Manual trigger fails
  - Ensure an active agent assignment exists for the assignee.
  - Check for authorization errors and missing permissions.
- Auto-dispatch not triggering
  - Confirm the assignment has auto_dispatch enabled and the agent is active.
  - Verify the plugin setting is enabled and the hook is registered.

**Section sources**
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [_dispatch_panel.html.erb:13-29](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L13-L29)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [en.yml:74-76](file://config/locales/en.yml#L74-L76)
- [init.rb:24-29](file://init.rb#L24-L29)

## Conclusion
The dispatch status tracking system provides a robust, observable pipeline for AI agent-driven issue processing. Dispatch records capture status, timestamps, and payloads; the UI surfaces history and detail views; and the job ensures reliable processing with retries and audit trails. With duration metrics and error payloads, teams can monitor performance and troubleshoot bottlenecks effectively.

## Appendices

### Status Definitions and Transitions
- pending: Initial state when a dispatch record is created.
- running: Processing started; dispatched_at set.
- done: Completed successfully; completed_at set; duration available.
- error: Failed; completed_at set; error payload stored.

**Section sources**
- [ai_agent_dispatch.rb:1-12](file://app/models/ai_agent_dispatch.rb#L1-L12)
- [ai_agent_dispatch.rb:20-24](file://app/models/ai_agent_dispatch.rb#L20-L24)
- [ai_agent_dispatch_job.rb:17-47](file://app/jobs/ai_agent_dispatch_job.rb#L17-L47)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

### Localization Keys Used
- Fields: status, triggered_by, dispatched_at, completed_at, duration.
- Headings: dispatch_detail, request_payload, response_payload.
- Statuses: pending, running, done, error.
- Journal: dispatch_started, dispatch_done, dispatch_error.
- Notices: dispatch_enqueued.
- Panel: title, dispatch_button, manual_only, no_dispatches.

**Section sources**
- [en.yml:3-50](file://config/locales/en.yml#L3-L50)
- [en.yml:88-98](file://config/locales/en.yml#L88-L98)
- [en.yml:69-76](file://config/locales/en.yml#L69-L76)
- [en.yml:82-87](file://config/locales/en.yml#L82-L87)