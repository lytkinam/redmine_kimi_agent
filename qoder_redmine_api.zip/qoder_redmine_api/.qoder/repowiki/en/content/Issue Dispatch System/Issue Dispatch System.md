# Issue Dispatch System

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
The Issue Dispatch System integrates AI agents into Redmine to automate issue processing. It supports:
- Automatic dispatch when issues are assigned to users (hook-based triggers)
- Manual dispatch initiation from the issue interface
- Background job processing with retries and error handling
- Dispatch status tracking and audit logging via Redmine’s journal system
- Dispatch record management for viewing history, monitoring ongoing processes, and troubleshooting failures

## Project Structure
The plugin is organized around models, controllers, jobs, hooks, and supporting clients. Routes define per-issue dispatch endpoints. Migrations establish dispatch records persistence.

```mermaid
graph TB
subgraph "Plugin Entry"
INIT["init.rb"]
REG["lib/redmine_ai_agent.rb"]
end
subgraph "Routing"
ROUTES["config/routes.rb"]
end
subgraph "Controllers"
CTRL["app/controllers/ai_agent_dispatches_controller.rb"]
end
subgraph "Jobs"
JOB["app/jobs/ai_agent_dispatch_job.rb"]
end
subgraph "Models"
MODEL_DISPATCH["app/models/ai_agent_dispatch.rb"]
MODEL_AGENT["app/models/ai_agent.rb"]
MODEL_ASSIGN["app/models/ai_agent_assignment.rb"]
end
subgraph "Hooks & Clients"
HOOKS["lib/redmine_ai_agent/hooks.rb"]
CLIENT["lib/redmine_ai_agent/agent_client.rb"]
SKILL["lib/redmine_ai_agent/redmine_api_skill.rb"]
end
INIT --> REG
REG --> HOOKS
ROUTES --> CTRL
CTRL --> JOB
JOB --> MODEL_DISPATCH
JOB --> MODEL_AGENT
JOB --> MODEL_ASSIGN
HOOKS --> JOB
JOB --> CLIENT
JOB --> SKILL
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- Plugin registration and permissions: Declares admin menu entries, plugin settings, and project-level permissions for dispatch and management.
- Hook listener: Integrates with Redmine’s event system to trigger automatic dispatch on issue creation and assignment changes.
- Dispatch controller: Handles manual dispatch initiation from the issue page and lists dispatch history.
- Dispatch job: Orchestrates agent communication, tool-loop execution, journal logging, and status transitions.
- Models: Define dispatch records, agent configurations, and user-to-agent assignments.
- Clients: Agent client encapsulates provider-specific API calls; Redmine API skill executes tool calls server-side.

**Section sources**
- [init.rb:18-30](file://init.rb#L18-L30)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

## Architecture Overview
The system combines Redmine’s event hooks, a manual dispatch controller, and a background job to coordinate AI agent processing. The job creates a dispatch record, posts “task sent” and “agent response” journal notes, and optionally loops through tool calls to execute Redmine API operations.

```mermaid
sequenceDiagram
participant User as "User"
participant Hooks as "Hooks Listener"
participant Controller as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant ModelDisp as "AiAgentDispatch"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
participant Redmine as "Redmine API"
User->>Controller : "Manual dispatch from issue page"
Controller->>Job : "perform_later(issue_id, agent_id, user_id)"
Hooks-->>Job : "Auto-dispatch on issue assignment/creation"
Job->>ModelDisp : "Create dispatch (status=running)"
Job->>Redmine : "Post journal 'dispatch started'"
Job->>Agent : "call(issue, triggered_by)"
Agent-->>Job : "Initial result"
Job->>Skill : "Execute tool calls (loop)"
Skill->>Redmine : "GET/PUT /issues/.json, /issue_statuses.json"
Redmine-->>Skill : "Response"
Skill-->>Job : "Tool results"
Job->>Agent : "Send updated messages"
Agent-->>Job : "Final text"
Job->>ModelDisp : "Update status=done, payloads"
Job->>Redmine : "Post journal 'dispatch done'"
```

**Diagram sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

## Detailed Component Analysis

### Automatic Dispatch Triggers (Hook-based Integration)
Automatic dispatch activates when:
- An issue is newly created and has an assignee, or
- An existing issue is edited and the assignee changed.

The hook checks for an active agent assignment with auto-dispatch enabled and enqueues a background job.

```mermaid
flowchart TD
Start(["Issue save event"]) --> CheckEnabled["Plugin enabled?"]
CheckEnabled --> |No| End(["Exit"])
CheckEnabled --> |Yes| LoadIssue["Load issue and assignee"]
LoadIssue --> HasAssignee{"Has assignee?"}
HasAssignee --> |No| End
HasAssignee --> |Yes| FindAssignment["Find active agent assignment<br/>with auto_dispatch=true"]
FindAssignment --> Found{"Assignment found?"}
Found --> |No| End
Found --> |Yes| Enqueue["Enqueue AiAgentDispatchJob"]
Enqueue --> End
```

**Diagram sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

**Section sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

### Manual Dispatch Process (Issue Interface)
Manual dispatch is initiated from the issue page via a dedicated button. The controller:
- Validates permissions
- Finds the active agent assigned to the issue’s assignee
- Enqueues a background job
- Redirects with a notice

```mermaid
sequenceDiagram
participant User as "User"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
User->>Ctrl : "POST /issues/ : id/ai_agent_dispatches"
Ctrl->>Ctrl : "Authorize and find issue"
Ctrl->>Ctrl : "Lookup active agent for assignee"
Ctrl->>Job : "perform_later(issue_id, agent_id, current_user_id)"
Ctrl-->>User : "Redirect with notice"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)

### Dispatch Job Processing (Background Job)
The job performs the following:
- Loads related records (issue, agent, user)
- Creates a dispatch record with status running and timestamps
- Posts a “task sent” journal note and links it to the record
- Calls the agent client and optionally runs a tool-call loop
- Persists request/response payloads and marks the dispatch as done
- Posts a “dispatch done” journal note
- On errors, transitions to error status and logs the failure

```mermaid
flowchart TD
JStart(["Job.start"]) --> Load["Load issue/agent/user"]
Load --> Valid{"Records present?"}
Valid --> |No| LogWarn["Log warning and exit"]
Valid --> |Yes| CreateDisp["Create dispatch (running)"]
CreateDisp --> PostStart["Post 'dispatch started' journal"]
PostStart --> CallAgent["Call AgentClient.call()"]
CallAgent --> ToolLoop{"Tool calls?"}
ToolLoop --> |No| Done["Mark done, persist payloads"]
ToolLoop --> |Yes| ExecTools["Execute tools via RedmineApiSkill"]
ExecTools --> CallAgent
Done --> PostDone["Post 'dispatch done' journal"]
PostDone --> JEnd(["Job.end"])
subgraph "Error Handling"
CallAgent --> Err{"Exception?"}
Err --> |AgentError| HandleErr["handle_error()<br/>status=error, journal"]
Err --> |Other| HandleErr
HandleErr --> Raise["Re-raise for ActiveJob retry"]
end
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### Dispatch Status Tracking and Audit Logging
Dispatch records track:
- Status lifecycle: pending, running, done, error
- Request/response payloads
- Dispatch and completion timestamps
- Associated journal entry ID

The job posts two journal notes:
- “Task sent” at start
- “Agent response” upon completion or error

```mermaid
classDiagram
class AiAgentDispatch {
+integer issue_id
+integer ai_agent_id
+integer triggered_by
+string status
+text request_payload
+text response_payload
+integer journal_id
+datetime dispatched_at
+datetime completed_at
+pending?()
+running?()
+done?()
+error?()
+finished?()
+duration
+request_data()
+response_data()
}
class AiAgent {
+string name
+string agent_type
+string protocol
+string endpoint_url
+string model_name
+boolean active
+resolved_system_prompt(issue)
}
class AiAgentAssignment {
+integer user_id
+integer ai_agent_id
+boolean auto_dispatch
+self.for_user(user)
+self.agent_for(user)
}
AiAgentDispatch --> AiAgent : "belongs_to"
AiAgentDispatch --> Issue : "belongs_to"
AiAgentDispatch --> User : "triggered_by_user"
AiAgentAssignment --> AiAgent : "belongs_to"
AiAgentAssignment --> User : "belongs_to"
```

**Diagram sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:26-57](file://app/jobs/ai_agent_dispatch_job.rb#L26-L57)

### Dispatch Record Management
- Viewing dispatch history: The controller lists dispatches for an issue, including agent and triggering user.
- Monitoring ongoing processes: Dispatch scopes filter by status (pending, running, done, error).
- Troubleshooting failed dispatches: Inspect payloads, timestamps, and associated journal entries.

```mermaid
sequenceDiagram
participant User as "User"
participant Ctrl as "AiAgentDispatchesController"
participant ModelDisp as "AiAgentDispatch"
User->>Ctrl : "GET /issues/ : id/ai_agent_dispatches"
Ctrl->>ModelDisp : "for_issue(issue).includes( : ai_agent, : triggered_by_user)"
ModelDisp-->>Ctrl : "Collection ordered by dispatched_at desc"
Ctrl-->>User : "Render index with recent dispatches"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:5-12](file://app/controllers/ai_agent_dispatches_controller.rb#L5-L12)
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)

**Section sources**
- [ai_agent_dispatches_controller.rb:5-12](file://app/controllers/ai_agent_dispatches_controller.rb#L5-L12)
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)

### Agent Client and Tool Loop
The agent client:
- Builds provider-specific payloads (OpenAI chat completions or responses API)
- Sends requests to the configured endpoint
- Extracts text responses
- Supports tool definitions for Hermes/Pi (excluding Kimi Web and Qoder)

The job runs a tool-call loop:
- Executes tool calls via the Redmine API skill
- Feeds results back to the agent
- Limits iterations to prevent runaway loops

```mermaid
flowchart TD
Build["Build payload (system prompt + issue context)"] --> Post["POST to agent endpoint"]
Post --> Resp{"Tool calls present?"}
Resp --> |No| Text["Extract text response"]
Resp --> |Yes| Exec["Execute tool_call via RedmineApiSkill"]
Exec --> Append["Append tool result to messages"]
Append --> Post
Text --> Done["Return final text"]
```

**Diagram sources**
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

**Section sources**
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

### Redmine Integration and Journal System
- The job posts “dispatch started” and “dispatch done/error” notes to the issue journal.
- Journal entries are linked to dispatch records for traceability.
- The agent client includes recent journal notes in the issue context sent to the agent.

**Section sources**
- [ai_agent_dispatch_job.rb:26-57](file://app/jobs/ai_agent_dispatch_job.rb#L26-L57)
- [agent_client.rb:101-112](file://lib/redmine_ai_agent/agent_client.rb#L101-L112)

## Dependency Analysis
Key dependencies and relationships:
- Controllers depend on models and enqueue jobs.
- Jobs depend on models, agent client, and skill.
- Hooks integrate with Redmine’s event system and enqueue jobs.
- Routes connect issue pages to dispatch actions.

```mermaid
graph LR
Hooks["lib/redmine_ai_agent/hooks.rb"] --> Job["app/jobs/ai_agent_dispatch_job.rb"]
Ctrl["app/controllers/ai_agent_dispatches_controller.rb"] --> Job
Job --> ModelDisp["app/models/ai_agent_dispatch.rb"]
Job --> ModelAgent["app/models/ai_agent.rb"]
Job --> ModelAssign["app/models/ai_agent_assignment.rb"]
Job --> Client["lib/redmine_ai_agent/agent_client.rb"]
Job --> Skill["lib/redmine_ai_agent/redmine_api_skill.rb"]
Routes["config/routes.rb"] --> Ctrl
```

**Diagram sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

**Section sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

## Performance Considerations
- Timeout configuration: Agent client and Redmine API skill enforce timeouts to avoid hanging requests.
- Retry strategy: Transient errors trigger exponential backoff retries via ActiveJob.
- Payload sizes: Large request/response payloads are stored as text; consider compression or external storage for very large outputs.
- Indexes: Dispatch table indexes on issue_id, ai_agent_id, status, and triggered_by improve query performance.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and remedies:
- Missing agent for assignee: Manual dispatch fails if no active agent assignment exists for the assignee.
- Network/timeout errors: Retries are applied automatically; inspect job logs for transient failures.
- Invalid agent endpoint or JSON: Errors surfaced as AgentError; verify endpoint URL and credentials.
- Redmine API errors: Skill raises RedmineApiError; confirm base URL, API key, and endpoint availability.
- Dispatch stuck in running/pending: Check job queue health, worker logs, and database status filters.

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [ai_agent_dispatch_job.rb:5, 61-67](file://app/jobs/ai_agent_dispatch_job.rb#L5,L61-L67)
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)

## Conclusion
The Issue Dispatch System seamlessly integrates AI agents with Redmine through hook-based automation and manual triggers. It leverages background jobs for robust asynchronous processing, comprehensive status tracking, and detailed audit trails via the journal system. Administrators and users can monitor dispatch history, troubleshoot failures, and ensure reliable issue resolution workflows.

## Appendices

### Database Schema: Dispatch Records
```mermaid
erDiagram
AI_AGENT_DISPATCHES {
integer id PK
integer issue_id FK
integer ai_agent_id FK
integer triggered_by
string status
text request_payload
text response_payload
integer journal_id
datetime dispatched_at
datetime completed_at
datetime created_at
datetime updated_at
}
ISSUES {
integer id PK
}
AI_AGENTS {
integer id PK
}
USERS {
integer id PK
}
AI_AGENT_DISPATCHES }o--|| ISSUES : "belongs_to"
AI_AGENT_DISPATCHES }o--|| AI_AGENTS : "belongs_to"
AI_AGENT_DISPATCHES }o--|| USERS : "triggered_by_user"
```

**Diagram sources**
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)