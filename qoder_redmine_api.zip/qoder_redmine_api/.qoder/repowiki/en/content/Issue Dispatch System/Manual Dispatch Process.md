# Manual Dispatch Process

<cite>
**Referenced Files in This Document**
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [_dispatch_panel.html.erb](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb)
- [routes.rb](file://config/routes.rb)
- [init.rb](file://init.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [en.yml](file://config/locales/en.yml)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the manual dispatch process that enables users to initiate AI agent processing on-demand from the Redmine issue interface. It covers the manual dispatch button, user authorization, dispatch panel integration, controller logic for handling manual dispatch requests, agent assignment lookup and validation, UI elements, permission checks, flash message feedback, step-by-step user workflows, and troubleshooting guidance for common issues.

## Project Structure
The manual dispatch feature spans controllers, models, views, routing, permissions, jobs, and view hooks. The key files involved are listed in the “Referenced Files” section and organized by responsibility.

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentDispatchesController<br/>POST /issues/:issue_id/ai_agent_dispatches#create"]
end
subgraph "Models"
M1["AiAgentDispatch<br/>dispatch records"]
M2["AiAgentAssignment<br/>user-agent mapping"]
M3["AiAgent<br/>agent definition"]
end
subgraph "Jobs"
J1["AiAgentDispatchJob<br/>perform async dispatch"]
end
subgraph "Views"
V1["_dispatch_panel.html.erb<br/>manual dispatch UI"]
end
subgraph "Routing"
R1["routes.rb<br/>resources :issues<br/>resources :ai_agent_dispatches"]
end
subgraph "Permissions"
P1["init.rb<br/>permission :dispatch_ai_agent"]
end
subgraph "Hooks"
H1["hooks.rb<br/>inject panel into issue show"]
end
C1 --> M1
C1 --> M2
C1 --> J1
V1 --> C1
R1 --> C1
P1 --> C1
H1 --> V1
M2 --> M3
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:24-29](file://init.rb#L24-L29)
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)

**Section sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [init.rb:24-29](file://init.rb#L24-L29)

## Core Components
- Manual dispatch controller: Handles the creation of a dispatch event, authorization checks, and redirects with flash messages.
- Dispatch job: Performs asynchronous AI agent invocation, tool-loop execution, journal updates, and error handling.
- Dispatch model: Stores dispatch records, status tracking, and payload persistence.
- Assignment model: Links users to active AI agents and supports auto-dispatch logic.
- Agent model: Defines agent capabilities, protocols, and system prompts.
- Dispatch panel: Renders the manual dispatch UI, including the dispatch button and history table.
- Routes: Exposes manual dispatch endpoints under the Issues resource.
- Permissions: Grants project-level permission to trigger manual dispatch.
- View hooks: Injects the dispatch panel into the issue show page.

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [_dispatch_panel.html.erb:14-67](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L14-L67)
- [routes.rb:13-15](file://config/routes.rb#L13-L15)
- [init.rb:24-29](file://init.rb#L24-L29)
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)

## Architecture Overview
The manual dispatch flow integrates UI, authorization, controller actions, background job processing, and persistent state.

```mermaid
sequenceDiagram
participant U as "User"
participant UI as "Issue Page Panel"
participant C as "AiAgentDispatchesController"
participant A as "AiAgentAssignment"
participant J as "AiAgentDispatchJob"
participant D as "AiAgentDispatch"
participant G as "AiAgent"
U->>UI : Click "Send to AI Agent"
UI->>C : POST /issues/ : issue_id/ai_agent_dispatches
C->>A : Lookup active agent for assignee
A-->>C : Assignment (agent)
C->>J : Enqueue dispatch job (issue_id, agent_id, triggered_by)
J->>D : Create dispatch record (status=running)
J->>G : Call agent (with issue context)
G-->>J : Response (may include tool_calls)
J->>J : Run tool-loop via RedmineApiSkill
J->>D : Update dispatch (status=done/error, payloads)
C-->>U : Redirect with flash notice/error
```

**Diagram sources**
- [_dispatch_panel.html.erb:16-22](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L16-L22)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_assignment.rb:14-20](file://app/models/ai_agent_assignment.rb#L14-L20)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:17-24](file://app/models/ai_agent_dispatch.rb#L17-L24)

## Detailed Component Analysis

### Manual Dispatch Button and Panel Integration
- The panel is injected into the issue show page via a view hook and renders a collapsible fieldset titled with agent name and type/protocol.
- The manual dispatch button is visible only if the current user has the project-level permission to dispatch AI agents and if the issue has an assignee.
- The button posts to the manual dispatch endpoint and includes a confirmation prompt localized for the user’s language.
- The panel displays recent dispatch history with status badges and links to dispatch detail pages.

```mermaid
flowchart TD
Start(["Render Issue Details"]) --> Hook["View hook injects dispatch panel"]
Hook --> CheckPerm{"User allowed to dispatch?"}
CheckPerm --> |No| HideButton["Do not render dispatch button"]
CheckPerm --> |Yes| CheckAssignee{"Issue has assignee?"}
CheckAssignee --> |No| DisableButton["Button disabled"]
CheckAssignee --> |Yes| EnableButton["Button enabled"]
EnableButton --> Click["User clicks 'Send to AI Agent'"]
Click --> Confirm["Confirmation dialog shown"]
Confirm --> |Cancel| End(["No action"])
Confirm --> |OK| Submit["POST to manual dispatch endpoint"]
```

**Diagram sources**
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)
- [_dispatch_panel.html.erb:14-29](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L14-L29)
- [en.yml:77-86](file://config/locales/en.yml#L77-L86)

**Section sources**
- [_dispatch_panel.html.erb:14-29](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L14-L29)
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)
- [en.yml:82-86](file://config/locales/en.yml#L82-L86)

### Controller Logic for Manual Dispatch
- The controller finds the target issue and enforces authorization using a project-level permission.
- It looks up the active agent assigned to the issue’s assignee.
- If no active agent is found, it sets an error flash and redirects to the issue.
- Otherwise, it enqueues the dispatch job with the issue, agent, and triggering user IDs, then sets a success flash and redirects.

```mermaid
flowchart TD
Enter(["POST /issues/:issue_id/ai_agent_dispatches#create"]) --> FindIssue["Find issue by ID"]
FindIssue --> Authorize{"User allowed to dispatch?"}
Authorize --> |No| Render403["Render 403"]
Authorize --> |Yes| LookupAgent["Lookup active agent for assignee"]
LookupAgent --> Found{"Agent found?"}
Found --> |No| FlashError["Set error flash<br/>Redirect to issue"]
Found --> |Yes| Enqueue["Enqueue AiAgentDispatchJob"]
Enqueue --> FlashNotice["Set notice flash<br/>Redirect to issue"]
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_assignment.rb:14-20](file://app/models/ai_agent_assignment.rb#L14-L20)

**Section sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

### Background Job Processing
- The job loads the issue, agent, and triggering user, creates a running dispatch record, and posts a journal note indicating the dispatch started.
- It invokes the agent client, runs a tool-call loop using the Redmine API skill, persists request/response payloads, and posts a final journal note with the agent’s response.
- On errors, it marks the dispatch as error, persists the error payload, and posts a journal note with the error details.

```mermaid
sequenceDiagram
participant Job as "AiAgentDispatchJob"
participant Rec as "AiAgentDispatch"
participant Cli as "AgentClient"
participant Skill as "RedmineApiSkill"
participant Iss as "Issue"
participant Trg as "Triggering User"
Job->>Iss : Load issue
Job->>Cli : Initialize client with agent
Job->>Rec : Create dispatch (status=running)
Job->>Iss : Post "dispatch started" journal
Job->>Cli : Call agent with issue context
Cli-->>Job : Initial result
loop Tool loop (up to 10 turns)
Job->>Skill : Execute tool calls
Skill-->>Job : Tool results
Job->>Cli : Send updated messages
Cli-->>Job : Next result
end
Job->>Rec : Update dispatch (status=done/error)
Job->>Iss : Post "dispatch done/error" journal
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [ai_agent_dispatch.rb:17-24](file://app/models/ai_agent_dispatch.rb#L17-L24)

**Section sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

### Data Model and Status Tracking
- Dispatch records track issue, agent, who triggered the dispatch, status, timestamps, and serialized request/response payloads.
- Statuses include pending, running, done, and error. Helper predicates simplify status checks.
- Indexes on issue_id, ai_agent_id, status, and triggered_by support efficient queries.

```mermaid
classDiagram
class AiAgentDispatch {
+integer issue_id
+integer ai_agent_id
+integer triggered_by
+string status
+text request_payload
+text response_payload
+integer journal_id
+datetime dispatched_at
+datetime completed_at
+pending?()
+running?()
+done?()
+error?()
+finished?()
+duration()
+request_data()
+response_data()
}
class AiAgentAssignment {
+integer user_id
+integer ai_agent_id
+boolean auto_dispatch
+for_user(user)
+agent_for(user)
+auto_dispatch?()
}
class AiAgent {
+string name
+string agent_type
+string protocol
+string model_name
+boolean active
+chat_completions?()
+responses_api?()
+kimi_web_ws?()
+resolved_system_prompt(issue)
}
AiAgentDispatch --> AiAgent : "belongs to"
AiAgentDispatch --> AiAgentAssignment : "via user_id"
AiAgentAssignment --> AiAgent : "belongs to"
```

**Diagram sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)
- [002_create_ai_agent_assignments.rb:3-13](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L13)

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)
- [002_create_ai_agent_assignments.rb:3-13](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L13)

### User Interface Elements and Feedback
- The panel title includes agent name and type/protocol.
- The dispatch button is styled and conditionally enabled/disabled based on assignee presence.
- Confirmation dialog ensures intentional dispatch.
- Flash messages inform users of enqueue success or missing agent scenarios.
- Dispatch history table shows status badges, triggerer, timestamps, durations, and links to details.

```mermaid
flowchart TD
Panel["Panel Title: Agent Name + Type/Protocol"] --> Button["Send to AI Agent Button"]
Button --> Confirm["Confirm Dialog"]
Confirm --> |Cancel| Idle["No action"]
Confirm --> |OK| Flash["Flash Notice/Error"]
Flash --> History["Dispatch History Table"]
History --> Status["Status Badges"]
History --> Detail["Detail Link"]
```

**Diagram sources**
- [_dispatch_panel.html.erb:6-29](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L6-L29)
- [en.yml:77-86](file://config/locales/en.yml#L77-L86)
- [en.yml:69-76](file://config/locales/en.yml#L69-L76)

**Section sources**
- [_dispatch_panel.html.erb:6-29](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L6-L29)
- [en.yml:69-76](file://config/locales/en.yml#L69-L76)

### Step-by-Step User Workflow
1. Navigate to an issue assigned to a user with an active AI agent assignment.
2. Locate the “AI Agent” panel on the issue page; the panel title shows the agent’s name and type/protocol.
3. Verify the “Send to AI Agent” button is enabled (requires assignee and dispatch permission).
4. Click the button; a confirmation dialog appears.
5. Confirm to submit the manual dispatch request.
6. Observe the flash notice confirming the dispatch was enqueued.
7. Monitor the dispatch history table for status updates and click “View” for details.

**Section sources**
- [_dispatch_panel.html.erb:14-29](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L14-L29)
- [en.yml:77-86](file://config/locales/en.yml#L77-L86)
- [en.yml:69-76](file://config/locales/en.yml#L69-L76)

## Dependency Analysis
- Controller depends on:
  - Issue lookup and authorization
  - Assignment lookup for active agent
  - Job enqueue
  - Flash messages and redirects
- Job depends on:
  - Dispatch record creation/update
  - Agent client invocation
  - Tool-loop execution via Redmine API skill
  - Journal posting
- Models depend on:
  - Foreign keys and indexes for performance
  - Validations for data integrity
- Views depend on:
  - Localization keys for labels and prompts
  - Permission checks to render controls
- Routes define the manual dispatch endpoints under the Issues resource.
- Permissions grant project-level capability to trigger manual dispatch.

```mermaid
graph LR
UI["_dispatch_panel.html.erb"] --> Ctrl["AiAgentDispatchesController"]
Ctrl --> Job["AiAgentDispatchJob"]
Ctrl --> Assn["AiAgentAssignment"]
Job --> Disp["AiAgentDispatch"]
Job --> Agent["AiAgent"]
Assn --> Agent
Routes["routes.rb"] --> Ctrl
Perm["init.rb (permissions)"] --> Ctrl
Hook["hooks.rb"] --> UI
```

**Diagram sources**
- [_dispatch_panel.html.erb:14-29](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L14-L29)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_assignment.rb:14-20](file://app/models/ai_agent_assignment.rb#L14-L20)
- [ai_agent_dispatch.rb:17-24](file://app/models/ai_agent_dispatch.rb#L17-L24)
- [routes.rb:13-15](file://config/routes.rb#L13-L15)
- [init.rb:24-29](file://init.rb#L24-L29)
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)

**Section sources**
- [routes.rb:13-15](file://config/routes.rb#L13-L15)
- [init.rb:24-29](file://init.rb#L24-L29)

## Performance Considerations
- Asynchronous processing: Manual dispatch enqueues a background job to avoid blocking the request thread.
- Retries: The job retries transient agent errors with exponential backoff.
- Tool-loop limits: The tool-call loop caps iterations to prevent long-running cycles.
- Indexes: Database indexes on dispatches improve query performance for status filtering and history retrieval.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- No active agent assigned to assignee:
  - Symptom: Error flash indicates no active AI agent for the assignee; dispatch does not start.
  - Resolution: Ensure the assignee has an active agent assignment configured.
  - Reference: [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25), [en.yml:74-75](file://config/locales/en.yml#L74-L75)
- Missing assignee:
  - Symptom: Dispatch button disabled; cannot dispatch manually.
  - Resolution: Assign the issue to a user with an active agent assignment.
  - Reference: [_dispatch_panel.html.erb:21](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L21)
- Permission denied:
  - Symptom: 403 error when submitting manual dispatch.
  - Resolution: Grant the user the project-level permission to dispatch AI agents.
  - Reference: [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48), [init.rb:24-29](file://init.rb#L24-L29)
- Agent error during processing:
  - Symptom: Dispatch recorded as error with payload containing error details; journal note posted.
  - Resolution: Inspect agent configuration, endpoint URL, and credentials; review logs for specifics.
  - Reference: [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67), [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- Tool-loop failures:
  - Symptom: Partial processing or fallback text; errors logged.
  - Resolution: Verify Redmine API skill configuration and endpoint accessibility.
  - Reference: [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [_dispatch_panel.html.erb:21](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L21)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

## Conclusion
The manual dispatch process provides a secure, user-friendly way to trigger AI agent processing from the issue interface. It enforces authorization, validates agent assignments, and integrates a responsive UI with persistent dispatch records and journal updates. Background jobs handle agent communication and tool loops asynchronously, ensuring reliability and performance.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Screenshots of the Dispatch Panel
- Panel Title: Displays agent name and type/protocol.
- Manual Dispatch Button: Styled button with confirmation prompt; disabled if the issue has no assignee.
- Dispatch History Table: Lists recent dispatches with status, triggerer, timestamps, durations, and detail links.

[No sources needed since this section describes UI elements conceptually]