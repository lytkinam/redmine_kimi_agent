# Database Schema

<cite>
**Referenced Files in This Document**
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [routes.rb](file://config/routes.rb)
- [init.rb](file://init.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the database schema and data model for the Redmine AI Agent Plugin. It focuses on the entity relationships among AiAgent, AiAgentAssignment, and AiAgentDispatch, including foreign keys, indexes, validations, and constraints. It also documents the migration history, schema evolution (including Kimi Web support), and operational considerations such as data lifecycle and retention.

## Project Structure
The plugin organizes database concerns in migrations and models, with controllers and jobs orchestrating runtime behavior. Routes define the public API surface for dispatches, while permissions and settings are registered in the plugin initializer.

```mermaid
graph TB
subgraph "Migrations"
M1["001_create_ai_agents.rb"]
M2["002_create_ai_agent_assignments.rb"]
M3["003_create_ai_agent_dispatches.rb"]
M4["004_add_kimi_web_to_ai_agents.rb"]
end
subgraph "Models"
A1["AiAgent"]
A2["AiAgentAssignment"]
A3["AiAgentDispatch"]
end
subgraph "Runtime"
R1["Routes"]
R2["Controllers"]
J1["AiAgentDispatchJob"]
end
M1 --> A1
M2 --> A2
M3 --> A3
M4 --> A1
A2 --> A1
A3 --> A1
A3 --> A2
R1 --> R2
R2 --> J1
```

**Diagram sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:1-31](file://init.rb#L1-L31)

## Core Components
This section defines the three core entities and their relationships.

- AiAgent
  - Represents an AI provider configuration (name, endpoint, protocol, credentials, model, system prompt, activation flag).
  - Supports multiple agent types and protocols, including a specialized Kimi Web mode.
- AiAgentAssignment
  - Links a Redmine user to a specific AiAgent with an auto-dispatch flag.
  - Enforces a unique user-to-agent mapping.
- AiAgentDispatch
  - Records a single dispatch event for an issue, including status, timing, and serialized request/response payloads.
  - Tracks who triggered the dispatch and optionally links to a journal entry.

Key associations:
- AiAgent has many AiAgentAssignment and AiAgentDispatch.
- AiAgentAssignment belongs to AiAgent and User.
- AiAgentDispatch belongs to Issue, AiAgent, and optionally Journal; it references the triggering user via a foreign key.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

## Architecture Overview
The schema supports a unidirectional flow: assignments connect users to agents, and dispatches are created per issue. Jobs orchestrate the actual agent calls and persist outcomes.

```mermaid
erDiagram
AI_AGENTS {
integer id PK
string name UK
string agent_type
string endpoint_url
string protocol
string api_key
string model_name
text system_prompt
boolean active
string kimi_web_session_id
string kimi_web_work_dir
integer kimi_web_timeout
timestamps timestamps
}
AI_AGENT_ASSIGNMENTS {
integer id PK
integer user_id UK
integer ai_agent_id
boolean auto_dispatch
timestamps timestamps
}
AI_AGENT_DISPATCHES {
integer id PK
integer issue_id
integer ai_agent_id
integer triggered_by
string status
text request_payload
text response_payload
integer journal_id
datetime dispatched_at
datetime completed_at
timestamps timestamps
}
AI_AGENTS ||--o{ AI_AGENT_ASSIGNMENTS : "has many"
AI_AGENTS ||--o{ AI_AGENT_DISPATCHES : "has many"
AI_AGENT_ASSIGNMENTS }o--|| USERS : "belongs to"
AI_AGENT_DISPATCHES }o--|| ISSUES : "belongs to"
AI_AGENT_DISPATCHES }o--|| AI_AGENTS : "belongs to"
AI_AGENT_DISPATCHES }o--|| USERS : "triggered_by (user)"
AI_AGENT_DISPATCHES }o--|| JOURNALS : "journal_id"
```

**Diagram sources**
- [001_create_ai_agents.rb:3-13](file://db/migrate/001_create_ai_agents.rb#L3-L13)
- [002_create_ai_agent_assignments.rb:3-8](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L8)
- [003_create_ai_agent_dispatches.rb:3-14](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L14)
- [004_add_kimi_web_to_ai_agents.rb:7-9](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L7-L9)
- [ai_agent_assignment.rb:2-3](file://app/models/ai_agent_assignment.rb#L2-L3)
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)

## Detailed Component Analysis

### AiAgent Model and Schema
- Fields and types
  - name: string, unique, required
  - agent_type: string, required, constrained to known values
  - endpoint_url: string, required, validated as HTTP/HTTPS URI
  - protocol: string, required, constrained to known values
  - api_key: string
  - model_name: string
  - system_prompt: text
  - active: boolean, default true
  - timestamps: created_at, updated_at
  - kimi_web_session_id: string (added by migration)
  - kimi_web_work_dir: string (added by migration)
  - kimi_web_timeout: integer, default 120 (added by migration)
- Indexes
  - agent_type: non-unique
  - active: non-unique
- Constraints and validations
  - Presence and inclusion checks for agent_type and protocol
  - URI format validation for endpoint_url
  - model_name required unless protocol is kimi_web_ws
  - name uniqueness enforced at the database level (via uniqueness validator)
  - active scope filters to enabled agents
- Notes
  - Safe API key masking for logging
  - Protocol and agent type helpers for behavior selection
  - Built-in system prompt templates per agent type

**Section sources**
- [001_create_ai_agents.rb:3-13](file://db/migrate/001_create_ai_agents.rb#L3-L13)
- [004_add_kimi_web_to_ai_agents.rb:7-9](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L7-L9)
- [ai_agent.rb:9-15](file://app/models/ai_agent.rb#L9-L15)

### AiAgentAssignment Model and Schema
- Fields and types
  - user_id: integer, required, unique per assignment
  - ai_agent_id: integer, required
  - auto_dispatch: boolean, default false
  - timestamps: created_at, updated_at
- Indexes
  - user_id: unique
  - ai_agent_id: non-unique
- Foreign keys
  - user_id references users(id)
  - ai_agent_id references ai_agents(id)
- Constraints and validations
  - Presence and uniqueness of user_id
  - Presence of ai_agent_id
- Associations
  - belongs_to user
  - belongs_to ai_agent
- Helpers
  - Lookup by user and active agent selection

**Section sources**
- [002_create_ai_agent_assignments.rb:3-8](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L8)
- [002_create_ai_agent_assignments.rb:12-13](file://db/migrate/002_create_ai_agent_assignments.rb#L12-L13)
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)

### AiAgentDispatch Model and Schema
- Fields and types
  - issue_id: integer, required
  - ai_agent_id: integer, required
  - triggered_by: integer, required
  - status: string, required, default 'pending'
  - request_payload: text
  - response_payload: text
  - journal_id: integer
  - dispatched_at: datetime
  - completed_at: datetime
  - timestamps: created_at, updated_at
- Indexes
  - issue_id: non-unique
  - ai_agent_id: non-unique
  - status: non-unique
  - triggered_by: non-unique
- Foreign keys
  - issue_id references issues(id)
  - ai_agent_id references ai_agents(id)
- Constraints and validations
  - Presence of issue_id, ai_agent_id, triggered_by
  - Status inclusion in predefined set
- Associations
  - belongs_to issue
  - belongs_to ai_agent
  - belongs_to triggered_by_user (user)
  - belongs_to journal (optional)
- Scopes and helpers
  - Status-based scopes (pending, running, completed, errored)
  - Duration calculation
  - JSON parsing helpers for request/response payloads

**Section sources**
- [003_create_ai_agent_dispatches.rb:3-14](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L14)
- [003_create_ai_agent_dispatches.rb:16-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L16-L22)
- [ai_agent_dispatch.rb:9-12](file://app/models/ai_agent_dispatch.rb#L9-L12)

### Data Flow and Lifecycle
The dispatch lifecycle is orchestrated by a job that creates a dispatch record, posts a journal note, executes the agent call, persists payloads, and posts a completion note.

```mermaid
sequenceDiagram
participant U as "User"
participant C as "AiAgentDispatchesController"
participant J as "AiAgentDispatchJob"
participant D as "AiAgentDispatch"
participant A as "AiAgent"
participant I as "Issue"
participant S as "Journal"
U->>C : "POST /issues/ : issue_id/ai_agent_dispatches"
C->>J : "Enqueue dispatch job"
J->>D : "Create dispatch (status='running')"
J->>S : "Post 'dispatch started' note"
J->>A : "Initialize AgentClient"
J->>A : "Call agent with issue context"
A-->>J : "Response (with tool loop if applicable)"
J->>D : "Update status='done', write payloads"
J->>S : "Post 'dispatch completed' note"
J-->>U : "Dispatch complete"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

## Dependency Analysis
- Referential integrity
  - AiAgentAssignment.user_id references users(id)
  - AiAgentAssignment.ai_agent_id references ai_agents(id)
  - AiAgentDispatch.issue_id references issues(id)
  - AiAgentDispatch.ai_agent_id references ai_agents(id)
  - AiAgentDispatch.triggered_by references users(id)
  - AiAgentDispatch.journal_id references journals(id)
- Association patterns
  - AiAgent has many AiAgentAssignment and AiAgentDispatch
  - AiAgentAssignment belongs to AiAgent and User
  - AiAgentDispatch belongs to Issue, AiAgent, and optionally Journal; references User via triggered_by
- Coupling and cohesion
  - Models encapsulate validations and helpers; controllers coordinate actions; jobs encapsulate async processing
  - Routes define the public interface for dispatch creation and listing

```mermaid
graph LR
Users["users"] --> |user_id| AiAgentAssignments["ai_agent_assignments"]
AiAgents["ai_agents"] --> |ai_agent_id| AiAgentAssignments
Issues["issues"] --> |issue_id| AiAgentDispatches["ai_agent_dispatches"]
AiAgents --> |ai_agent_id| AiAgentDispatches
Users --> |triggered_by| AiAgentDispatches
Journals["journals"] --> |journal_id| AiAgentDispatches
```

**Diagram sources**
- [002_create_ai_agent_assignments.rb:12-13](file://db/migrate/002_create_ai_agent_assignments.rb#L12-L13)
- [003_create_ai_agent_dispatches.rb:20-21](file://db/migrate/003_create_ai_agent_dispatches.rb#L20-L21)

**Section sources**
- [002_create_ai_agent_assignments.rb:12-13](file://db/migrate/002_create_ai_agent_assignments.rb#L12-L13)
- [003_create_ai_agent_dispatches.rb:20-21](file://db/migrate/003_create_ai_agent_dispatches.rb#L20-L21)
- [ai_agent_assignment.rb:2-3](file://app/models/ai_agent_assignment.rb#L2-L3)
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)

## Performance Considerations
- Index coverage
  - AiAgent: agent_type, active
  - AiAgentAssignment: user_id (unique), ai_agent_id
  - AiAgentDispatch: issue_id, ai_agent_id, status, triggered_by
- Query patterns
  - Assignment lookup by user (unique index)
  - Dispatch listing by issue (ordered by dispatched_at desc)
  - Status filtering for monitoring and cleanup
- Recommendations
  - Consider composite indexes for frequent filters (e.g., issue_id + status, ai_agent_id + status)
  - Monitor long-running dispatches and implement periodic maintenance to cap backlog
  - Archive old completed/error records to separate storage if retention requires

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Common validation failures
  - Missing or invalid endpoint_url (URI format)
  - Invalid agent_type or protocol values
  - Missing model_name when protocol is not kimi_web_ws
  - Duplicate user_id in AiAgentAssignment
- Operational errors
  - Dispatch errors recorded in response_payload with status 'error'
  - Tool loop failures handled gracefully with fallback text
  - Job retries on transient agent errors
- Logging and diagnostics
  - Safe API key masking in logs
  - Detailed error messages posted to issue journal
  - Job logs include dispatch ID, duration, and outcome

**Section sources**
- [ai_agent.rb:9-15](file://app/models/ai_agent.rb#L9-L15)
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [ai_agent_dispatch.rb:9-12](file://app/models/ai_agent_dispatch.rb#L9-L12)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)

## Conclusion
The schema cleanly separates agent configuration, user-agent assignments, and dispatch events. It enforces referential integrity, supports efficient lookups, and accommodates evolving agent types (notably Kimi Web). The job-driven dispatch process ensures robustness and observability, with clear hooks for monitoring and maintenance.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Migration History and Schema Evolution
- 001_create_ai_agents.rb
  - Creates ai_agents with core fields and indexes on agent_type and active.
- 002_create_ai_agent_assignments.rb
  - Creates ai_agent_assignments with unique user_id, indexes, and foreign keys to users and ai_agents.
- 003_create_ai_agent_dispatches.rb
  - Creates ai_agent_dispatches with indexes on issue_id, ai_agent_id, status, triggered_by, and foreign keys to issues and ai_agents.
- 004_add_kimi_web_to_ai_agents.rb
  - Adds Kimi Web support fields: kimi_web_session_id, kimi_web_work_dir, kimi_web_timeout.

**Section sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

### Data Lifecycle Management and Retention
- Dispatch lifecycle
  - Pending → Running → Done/Error
  - Dispatch records capture request/response payloads and timing
- Retention and archival
  - Consider partitioning or archiving older records by status and date
  - Implement periodic cleanup jobs to remove stale pending entries
  - Export or archive completed/error records for compliance if required

[No sources needed since this section provides general guidance]