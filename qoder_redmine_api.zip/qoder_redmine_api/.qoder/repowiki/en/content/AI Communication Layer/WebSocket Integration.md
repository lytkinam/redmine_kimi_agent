# WebSocket Integration

<cite>
**Referenced Files in This Document**
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [kimi-web.sh](file://kimi-web/scripts/kimi-web.sh)
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [SKILL.md](file://kimi-web/SKILL.md)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the WebSocket integration used to communicate with the Kimi Code CLI Web Interface from the Redmine AI Agent plugin. It covers:
- The KimiWebClient implementation for establishing WebSocket connections, formatting JSON-RPC 2.0 messages, and managing real-time streams
- The WebSocket protocol specifics, message types, and event handling
- External integration via Python and shell scripts
- Connection management, timeouts, and automatic approvals
- Practical configuration, initialization, and bidirectional communication patterns
- Security considerations, authentication, and debugging techniques

## Project Structure
The WebSocket integration spans three primary areas:
- Ruby-based Redmine plugin internals that orchestrate AI agent dispatches and use a dedicated WebSocket client
- External CLI tools that wrap REST and WebSocket interactions for manual or scripted usage
- Comprehensive API reference and skill documentation for protocol behavior and examples

```mermaid
graph TB
subgraph "Redmine Plugin"
A["AiAgentDispatchJob<br/>Triggers agent calls"]
B["AgentClient<br/>Delegates to KimiWebClient for kimi_web_ws"]
C["KimiWebClient<br/>WebSocket JSON-RPC loop"]
end
subgraph "External Tools"
D["kimi-web.sh<br/>REST CLI"]
E["kimi-web-ws.py<br/>WebSocket CLI"]
end
subgraph "Kimi Web Interface"
F["REST API<br/>/api/sessions/*"]
G["WebSocket Stream<br/>/api/sessions/{session_id}/stream"]
end
A --> B --> C
D --> F
E --> G
C --> G
D --> F
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [kimi-web.sh:101-108](file://kimi-web/scripts/kimi-web.sh#L101-L108)
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [api-reference.md:349-467](file://kimi-web/reference/api-reference.md#L349-L467)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [kimi-web.sh:101-108](file://kimi-web/scripts/kimi-web.sh#L101-L108)
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [api-reference.md:349-467](file://kimi-web/reference/api-reference.md#L349-L467)

## Core Components
- KimiWebClient: Implements WebSocket JSON-RPC 2.0 messaging, session lifecycle, and event handling for the Kimi interface
- AgentClient: Orchestrates agent selection and delegates Kimi Web WebSocket calls
- AiAgent model: Defines agent types and protocols, including kimi_web_ws
- AiAgentDispatchJob: Triggers agent calls and posts journal notes
- External CLI tools: kimi-web.sh (REST) and kimi-web-ws.py (WebSocket)

Key responsibilities:
- Establish WebSocket connection and perform HTTP upgrade handshake
- Drive the JSON-RPC message loop: initialize → history_complete → prompt → session_status/idle
- Collect streamed text fragments and complete responses
- Auto-approve requests to keep agent running unattended
- Manage timeouts and error propagation

**Section sources**
- [kimi_web_client.rb:21-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L58)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [ai_agent.rb:1-16](file://app/models/ai_agent.rb#L1-L16)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

## Architecture Overview
The WebSocket integration follows a strict JSON-RPC 2.0 protocol over WebSocket with the following flow:
- REST session creation and health checks
- WebSocket connection to the session stream
- History replay followed by history_complete
- Initialization and prompt submission
- Streaming events and session status updates
- Automatic request approvals to maintain continuity

```mermaid
sequenceDiagram
participant Job as "AiAgentDispatchJob"
participant AC as "AgentClient"
participant KC as "KimiWebClient"
participant WS as "WebSocket Server"
Job->>AC : call(issue)
AC->>KC : delegate kimi_web_ws
KC->>WS : connect /api/sessions/{session_id}/stream
WS-->>KC : history replay
WS-->>KC : history_complete
KC->>WS : initialize
KC->>WS : prompt
WS-->>KC : session_status (busy)
WS-->>KC : event (agent_text)
WS-->>KC : event (agent_response)
WS-->>KC : session_status (idle)
KC-->>AC : collected text
AC-->>Job : result
```

**Diagram sources**
- [kimi_web_client.rb:142-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L282)
- [api-reference.md:470-571](file://kimi-web/reference/api-reference.md#L470-L571)

**Section sources**
- [kimi_web_client.rb:142-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L282)
- [api-reference.md:470-571](file://kimi-web/reference/api-reference.md#L470-L571)

## Detailed Component Analysis

### KimiWebClient Implementation
KimiWebClient encapsulates:
- Session management via REST: ensure_session!, session_alive?, create_session!
- Prompt construction from issue context
- WebSocket handshake and frame encoding/decoding
- Message loop for JSON-RPC 2.0 events and requests
- Timeout enforcement and error handling

```mermaid
classDiagram
class KimiWebClient {
+initialize(agent)
+call(issue) Hash
-ensure_session! String
-session_alive?(id) bool
-create_session! String
-build_prompt(issue) String
-websocket_prompt(id, text) String
-ws_uri(id) URI
-open_socket(uri) Socket
-do_handshake(socket, uri) void
-drive_session(socket, text) String
-handle_agent_request(socket, msg) void
-send_frame(socket, data) void
-read_frame(socket, timeout) String
-json_rpc(method, params) Hash
-http_get(uri) Net : : HTTPResponse
-http_post(uri, body) Net : : HTTPResponse
}
```

**Diagram sources**
- [kimi_web_client.rb:31-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L421)

Key behaviors:
- Connection establishment: performs HTTP upgrade with Sec-WebSocket-* headers and optional Authorization
- Frame handling: encodes/decodes RFC 6455 frames, masks client frames, responds to ping with pong
- Message loop: waits for history_complete, sends initialize, then prompt; collects agent_text and agent_response; reacts to session_status transitions
- Request handling: auto-approves ApprovalRequest and answers QuestionRequest to keep agent moving
- Timeouts: enforces per-session timeout derived from agent configuration

**Section sources**
- [kimi_web_client.rb:156-210](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L210)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)
- [kimi_web_client.rb:305-385](file://lib/redmine_ai_agent/kimi_web_client.rb#L305-L385)

### WebSocket Protocol and Message Types
Protocol specifics:
- Endpoint: ws://{host}:{port}/api/sessions/{session_id}/stream
- Optional query parameter: token={KIMI_WEB_TOKEN}
- JSON-RPC 2.0 over WebSocket frames

Server-to-client messages:
- history_complete: signals readiness after history replay
- session_status: state transitions (idle, busy, stopped, error, restarting)
- event: streaming text fragments, complete responses, tool calls, tool results, notices
- request: ApprovalRequest and QuestionRequest requiring client response

Client-to-server messages:
- initialize: capability negotiation
- prompt: submit user input
- steer: guide current turn
- set_plan_mode: toggle plan mode
- cancel: abort current prompt
- replay: request history replay

```mermaid
flowchart TD
Start(["WebSocket Connected"]) --> Hist["Receive history replay"]
Hist --> HC["Receive history_complete"]
HC --> Init["Send initialize"]
Init --> Prompt["Send prompt"]
Prompt --> Status["Receive session_status"]
Status --> |busy| Wait["Wait for idle"]
Status --> |error| Err["Raise error"]
Wait --> Text["Receive agent_text"]
Text --> Resp["Receive agent_response"]
Resp --> Idle["session_status idle"]
Idle --> End(["Return final text"])
Err --> End
```

**Diagram sources**
- [api-reference.md:360-571](file://kimi-web/reference/api-reference.md#L360-L571)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)

**Section sources**
- [api-reference.md:360-571](file://kimi-web/reference/api-reference.md#L360-L571)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)

### External Integration: Python WebSocket Client
The Python script kimi-web-ws.py provides:
- Command-line interface for prompt, cancel, plan-mode, and interactive stream
- WebSocket URL construction with optional token query parameter
- JSON-RPC 2.0 message sending and receiving
- Auto-approval of ApprovalRequest when running non-interactively
- State tracking and printing of session_status and event types

```mermaid
sequenceDiagram
participant CLI as "kimi-web-ws.py"
participant WS as "WebSocket Server"
CLI->>WS : connect ws : //host : port/api/sessions/{session_id}/stream?token=...
WS-->>CLI : history_complete
CLI->>WS : prompt
WS-->>CLI : session_status (busy)
WS-->>CLI : event (agent_text)
WS-->>CLI : event (agent_response)
WS-->>CLI : session_status (idle)
CLI-->>CLI : print final text
```

**Diagram sources**
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [kimi-web-ws.py:68-148](file://kimi-web/scripts/kimi-web-ws.py#L68-L148)
- [kimi-web-ws.py:157-175](file://kimi-web/scripts/kimi-web-ws.py#L157-L175)

**Section sources**
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [kimi-web-ws.py:68-148](file://kimi-web/scripts/kimi-web-ws.py#L68-L148)
- [kimi-web-ws.py:157-175](file://kimi-web/scripts/kimi-web-ws.py#L157-L175)

### External Integration: Shell Wrapper (REST)
The shell script kimi-web.sh wraps REST endpoints for:
- Listing, getting, creating, updating, deleting sessions
- Forking sessions and generating titles
- Uploading and retrieving files
- Getting and patching global configuration
- Health probes and work directories listing

It sets Authorization: Bearer headers when a token is configured and uses curl for HTTP operations.

**Section sources**
- [kimi-web.sh:31-41](file://kimi-web/scripts/kimi-web.sh#L31-L41)
- [kimi-web.sh:101-177](file://kimi-web/scripts/kimi-web.sh#L101-L177)
- [kimi-web.sh:187-215](file://kimi-web/scripts/kimi-web.sh#L187-L215)
- [kimi-web.sh:219-249](file://kimi-web/scripts/kimi-web.sh#L219-L249)
- [kimi-web.sh:253-259](file://kimi-web/scripts/kimi-web.sh#L253-L259)

### Redmine Integration and Dispatch Flow
The plugin integrates with Redmine via:
- AiAgent model defining agent types and protocols (including kimi_web_ws)
- AiAgentDispatchJob orchestrating agent calls and posting journal notes
- AgentClient delegating to KimiWebClient for kimi_web_ws protocol
- Migration adding kimi_web_* fields to ai_agents for session reuse and timeouts

```mermaid
sequenceDiagram
participant User as "User"
participant Hook as "Issue Hooks"
participant Job as "AiAgentDispatchJob"
participant AC as "AgentClient"
participant KC as "KimiWebClient"
User->>Hook : Edit/Create Issue
Hook->>Job : Auto-dispatch if configured
Job->>AC : call(issue)
AC->>KC : call(issue)
KC-->>AC : {text, raw_response, request}
AC-->>Job : result
Job->>Job : post journal notes
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)

**Section sources**
- [ai_agent.rb:1-16](file://app/models/ai_agent.rb#L1-L16)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

## Dependency Analysis
- AgentClient depends on AiAgent configuration to choose the protocol and delegates to KimiWebClient for kimi_web_ws
- KimiWebClient depends on:
  - Agent configuration for endpoint, token, session reuse, and timeout
  - Ruby standard library for sockets, TLS, URI, JSON, and randomness
  - External Kimi Web interface for REST and WebSocket endpoints
- External tools depend on environment variables for host, port, and token

```mermaid
graph LR
AC["AgentClient"] --> KC["KimiWebClient"]
KC --> HTTP["Net::HTTP (REST)"]
KC --> WS["Raw TCP/TLS (WebSocket)"]
KC --> URI["URI/JSON/Random"]
KC --> Model["AiAgent (config)"]
Py["kimi-web-ws.py"] --> WS
Sh["kimi-web.sh"] --> HTTP
```

**Diagram sources**
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [kimi-web-ws.py:25-29](file://kimi-web/scripts/kimi-web-ws.py#L25-L29)
- [kimi-web.sh:31-35](file://kimi-web/scripts/kimi-web.sh#L31-L35)

**Section sources**
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [kimi-web-ws.py:25-29](file://kimi-web/scripts/kimi-web-ws.py#L25-L29)
- [kimi-web.sh:31-35](file://kimi-web/scripts/kimi-web.sh#L31-L35)

## Performance Considerations
- Timeouts: The client enforces a per-session timeout derived from agent configuration; exceeding it raises a timeout error
- Concurrency: Only one prompt per session at a time; attempting another while busy yields an error
- History replay: New connections receive full conversation history; this can increase initial latency
- Auto-approval: Prevents blocking on ApprovalRequest, maintaining throughput in automated flows
- Network overhead: WebSocket ping/pong and JSON-RPC framing add small overhead; batching or reducing verbosity can help

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Authentication failures:
  - Ensure KIMI_WEB_TOKEN is set and matches server expectations
  - Verify Authorization header usage in REST calls and token query param in WebSocket URL
- Connection errors:
  - Confirm Kimi Web is reachable at KIMI_WEB_HOST:KIMI_WEB_PORT
  - Check firewall and CORS/Origin policies if applicable
- Timeouts:
  - Increase agent.kimi_web_timeout to allow more time for long-running prompts
  - Reduce prompt length or complexity to fit within timeout
- Busy state:
  - Wait for session_status idle before sending another prompt
  - Cancel ongoing prompts if stuck
- Encoding issues (non-ASCII characters):
  - Set UTF-8 environment variables before running Python scripts on Windows

**Section sources**
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [kimi-web.sh:31-41](file://kimi-web/scripts/kimi-web.sh#L31-L41)
- [kimi-web-ws.py:11-15](file://kimi-web/scripts/kimi-web-ws.py#L11-L15)
- [SKILL.md:368-376](file://kimi-web/SKILL.md#L368-L376)

## Conclusion
The WebSocket integration with the Kimi Code CLI Web Interface is implemented through a robust Ruby-based client that adheres to JSON-RPC 2.0 over WebSocket, complemented by external Python and shell tools for manual and scripted workflows. The system manages session lifecycle, streaming events, and request approvals, while providing clear error signaling and timeouts. Proper configuration of host, port, and tokens ensures secure and reliable operation.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Practical Configuration and Initialization
- Environment variables:
  - KIMI_WEB_HOST, KIMI_WEB_PORT, KIMI_WEB_TOKEN
- Ruby agent configuration:
  - endpoint_url: base URL for Kimi Web
  - api_key: optional token for Authorization
  - kimi_web_session_id: optional pinned session ID
  - kimi_web_work_dir: working directory for new sessions
  - kimi_web_timeout: session timeout in seconds

**Section sources**
- [kimi-web.sh:31-41](file://kimi-web/scripts/kimi-web.sh#L31-L41)
- [kimi-web-ws.py:11-15](file://kimi-web/scripts/kimi-web-ws.py#L11-L15)
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [004_add_kimi_web_to_ai_agents.rb:6-10](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L6-L10)

### Bidirectional Communication Patterns
- Client-to-server:
  - initialize, prompt, steer, set_plan_mode, cancel, replay
- Server-to-client:
  - history_complete, session_status, event (agent_text, agent_response, tool_call, tool_result, notice), request (ApprovalRequest, QuestionRequest)

**Section sources**
- [api-reference.md:470-571](file://kimi-web/reference/api-reference.md#L470-L571)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)

### Security Considerations
- Transport security:
  - Use wss:// when available; otherwise ensure traffic is protected by network controls
- Authentication:
  - Prefer Authorization: Bearer header for REST; use token query parameter for WebSocket
  - Keep tokens secret and rotate regularly
- Origin and access control:
  - Configure server-side origin checks and sensitive path protections
- Token scope:
  - Limit token privileges to the minimum required for the integration

**Section sources**
- [kimi-web.sh:37-40](file://kimi-web/scripts/kimi-web.sh#L37-L40)
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [api-reference.md:600-622](file://kimi-web/reference/api-reference.md#L600-L622)