# AI Communication Layer

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [kimi-web SKILL.md](file://kimi-web/SKILL.md)
- [kimi-web api-reference.md](file://kimi-web/reference/api-reference.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the AI Communication Layer responsible for integrating Redmine with external AI providers. It covers:
- HTTP client implementation for OpenAI-compatible APIs (Chat Completions and Responses)
- Authentication handling and request/response parsing
- WebSocket integration for Kimi Web (JSON-RPC 2.0)
- Tool calling mechanism enabling AI agents to execute Redmine API operations
- Payload building for different agent types and protocols
- Error handling, timeouts, and retry logic
- Practical configuration and integration patterns

## Project Structure
The AI Communication Layer is implemented as a Redmine plugin with Ruby modules and jobs. Key areas:
- Plugin registration and settings
- Agent model with agent types, protocols, and system prompts
- HTTP client for OpenAI-compatible APIs
- WebSocket client for Kimi Web
- Redmine API skill for tool execution
- Job orchestrating dispatches and tool loops
- Hooks to trigger automatic dispatches
- Migrations extending agent records for Kimi Web

```mermaid
graph TB
subgraph "Plugin"
INIT["init.rb"]
REG["lib/redmine_ai_agent.rb"]
end
subgraph "Models"
MODEL_AI["app/models/ai_agent.rb"]
end
subgraph "Clients"
HTTP["lib/redmine_ai_agent/agent_client.rb"]
KIMI["lib/redmine_ai_agent/kimi_web_client.rb"]
SKILL["lib/redmine_ai_agent/redmine_api_skill.rb"]
end
subgraph "Orchestration"
JOB["app/jobs/ai_agent_dispatch_job.rb"]
HOOKS["lib/redmine_ai_agent/hooks.rb"]
CTRL["app/controllers/ai_agent_dispatches_controller.rb"]
end
subgraph "Config"
MIG1["db/migrate/001_create_ai_agents.rb"]
MIG4["db/migrate/004_add_kimi_web_to_ai_agents.rb"]
end
INIT --> REG
REG --> HTTP
REG --> KIMI
REG --> SKILL
REG --> HOOKS
MODEL_AI --> HTTP
MODEL_AI --> KIMI
JOB --> HTTP
JOB --> SKILL
CTRL --> JOB
HOOKS --> JOB
MIG1 --> MODEL_AI
MIG4 --> MODEL_AI
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

## Core Components
- AgentClient: HTTP client for OpenAI-compatible APIs (Chat Completions and Responses). Handles authentication, payload construction, request sending, and response parsing.
- KimiWebClient: WebSocket client for Kimi Code CLI Web Interface. Manages session creation, JSON-RPC 2.0 messaging, and real-time streaming.
- RedmineApiSkill: Executes Redmine REST API operations on behalf of the agent when tool_calls are returned.
- AiAgent model: Defines agent types, protocols, and system prompts; resolves dynamic placeholders for Redmine base URL and API key.
- AiAgentDispatchJob: Orchestrates dispatches, manages retries, runs tool loops, and posts journal notes.
- Hooks: Triggers automatic dispatches on issue creation/edit and injects UI panels.

**Section sources**
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Architecture Overview
The AI Communication Layer integrates three primary flows:
- HTTP-based agents (OpenAI-compatible): Chat Completions and Responses APIs
- WebSocket-based Kimi Web: JSON-RPC 2.0 over WebSocket
- Tool calling: Agent returns tool_calls; RedmineApiSkill executes them and feeds results back

```mermaid
sequenceDiagram
participant Hook as "Hooks"
participant Job as "AiAgentDispatchJob"
participant Client as "AgentClient"
participant Skill as "RedmineApiSkill"
participant Redmine as "Redmine REST API"
Hook->>Job : "Trigger dispatch"
Job->>Client : "call(issue, triggered_by)"
alt "Kimi Web WebSocket"
Client->>Client : "delegate to KimiWebClient"
else "OpenAI-compatible"
Client->>Client : "build_payload(issue)"
Client->>Client : "post_to_agent(payload)"
Client-->>Job : "{text, raw_response, request}"
end
opt "Tool loop"
Job->>Skill : "execute_tool_call(tool_call)"
Skill->>Redmine : "GET/PUT /issues/.json"
Redmine-->>Skill : "Response"
Skill-->>Job : "Result"
Job->>Client : "post_to_agent(messages with tool results)"
Client-->>Job : "Next text"
end
Job->>Job : "Persist dispatch and post journal"
```

**Diagram sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

## Detailed Component Analysis

### HTTP Client for OpenAI-Compatible APIs
Responsibilities:
- Build payloads for Chat Completions and Responses APIs
- Authenticate via Authorization header
- Parse responses and extract text content
- Manage timeouts and error handling

Key behaviors:
- Endpoint resolution: appends /v1/chat/completions or /v1/responses to agent.endpoint_url
- Authentication: adds Authorization: Bearer <api_key> when present
- Payloads:
  - Chat Completions: includes system prompt, user context, and optional tools for Hermes/Pi
  - Responses: includes input and instructions
- Response extraction:
  - Chat Completions: reads choices[0].message.content
  - Responses: aggregates array content or falls back to output_text

```mermaid
flowchart TD
Start(["call(issue)"]) --> CheckKimi{"Kimi Web WebSocket?"}
CheckKimi --> |Yes| Delegate["Delegate to KimiWebClient"]
CheckKimi --> |No| Build["build_payload(issue)"]
Build --> Post["post_to_agent(payload)"]
Post --> Success{"HTTP 2xx?"}
Success --> |No| RaiseErr["Raise AgentError"]
Success --> |Yes| Parse["extract_text(raw)"]
Parse --> Return["Return {text, raw_response, request}"]
```

**Diagram sources**
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

**Section sources**
- [agent_client.rb:22-42](file://lib/redmine_ai_agent/agent_client.rb#L22-L42)
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

### WebSocket Integration for Kimi Web
Responsibilities:
- Manage session lifecycle via REST
- Establish WebSocket connection and perform handshake
- Drive JSON-RPC 2.0 message loop
- Auto-approve requests to keep agent running
- Collect final text from streaming fragments

Protocol highlights:
- Session create/health via REST endpoints
- WebSocket upgrade with Sec-WebSocket headers
- JSON-RPC 2.0 methods: initialize, prompt, event, request, session_status
- Auto-approval for ApprovalRequest and QuestionRequest

```mermaid
sequenceDiagram
participant Job as "AiAgentDispatchJob"
participant KWC as "KimiWebClient"
participant REST as "Kimi REST API"
participant WS as "Kimi WebSocket"
Job->>KWC : "call(issue)"
KWC->>REST : "ensure_session!"
REST-->>KWC : "session_id"
KWC->>WS : "open_socket + do_handshake"
WS-->>KWC : "history_complete"
KWC->>WS : "json_rpc('initialize')"
WS-->>KWC : "session_status=idle"
KWC->>WS : "json_rpc('prompt', prompt_text)"
loop "Read frames"
WS-->>KWC : "event(agent_text/response)"
KWC->>WS : "Auto-approve requests"
end
WS-->>KWC : "session_status=idle"
KWC-->>Job : "{text, raw_response, request}"
```

**Diagram sources**
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [kimi_web_client.rb:66-100](file://lib/redmine_ai_agent/kimi_web_client.rb#L66-L100)
- [kimi_web_client.rb:142-180](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L180)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)
- [kimi-web SKILL.md](file://kimi-web/SKILL.md)

**Section sources**
- [kimi_web_client.rb:21-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L58)
- [kimi_web_client.rb:66-100](file://lib/redmine_ai_agent/kimi_web_client.rb#L66-L100)
- [kimi_web_client.rb:142-180](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L180)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)
- [kimi-web SKILL.md](file://kimi-web/SKILL.md)

### Tool Calling Mechanism
Mechanism:
- AgentClient builds tool definitions for Hermes/Pi (when not Kimi Web or Qoder)
- AiAgentDispatchJob detects tool_calls and executes them via RedmineApiSkill
- Results are fed back to the agent in a loop (up to 10 iterations)
- Final text is posted as a journal note

```mermaid
flowchart TD
Start(["Agent response"]) --> HasCalls{"tool_calls present?"}
HasCalls --> |No| Done["Return text"]
HasCalls --> |Yes| BuildMsgs["Append assistant + tool_calls"]
BuildMsgs --> Loop["For each tool_call"]
Loop --> Exec["RedmineApiSkill.execute_tool_call()"]
Exec --> Append["Append {role: 'tool', content: result}"]
Append --> Next["post_to_agent(messages)"]
Next --> HasCalls
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

**Section sources**
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [redmine_api_skill.rb:19-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L61)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

### Payload Building and Request Construction
Payloads differ by protocol:
- Chat Completions:
  - model, messages (system + user), tools (optional), tool_choice
- Responses:
  - model, input, instructions

Issue context message includes:
- Issue metadata and URL
- Description
- Recent journal notes

System prompts are templated per agent type and resolved with Redmine base URL, API key, issue/project IDs.

```mermaid
classDiagram
class AiAgent {
+agent_type
+protocol
+endpoint_url
+model_name
+api_key
+resolved_system_prompt(issue)
}
class AgentClient {
+call(issue, triggered_by)
-build_payload(issue)
-build_chat_completions_payload(issue)
-build_responses_payload(issue)
-issue_context_message(issue)
-redmine_tools(issue)
-post_to_agent(payload)
-extract_text(raw)
}
AiAgent --> AgentClient : "provides config and prompts"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:26-77](file://lib/redmine_ai_agent/agent_client.rb#L26-L77)
- [agent_client.rb:83-112](file://lib/redmine_ai_agent/agent_client.rb#L83-L112)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

**Section sources**
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:83-112](file://lib/redmine_ai_agent/agent_client.rb#L83-L112)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [ai_agent.rb:52-153](file://app/models/ai_agent.rb#L52-L153)

### Error Handling, Timeouts, and Retries
- AgentClient:
  - Raises AgentError on non-2xx HTTP responses
  - Catches timeouts, JSON parse errors, and invalid URIs
- KimiWebClient:
  - Raises KimiError/KimiTimeoutError for handshake failures, read/write errors, and session timeouts
- AiAgentDispatchJob:
  - Retries on AgentError with polynomial backoff (up to 3 attempts)
  - Records error state and posts journal note on failure
- Global defaults:
  - HTTP read timeout from plugin settings; fallback to 120s
  - HTTP open timeout set to 15s for AgentClient
  - Kimi REST open/read timeouts set to 10/30s

```mermaid
flowchart TD
A["HTTP Request"] --> B{"Success?"}
B --> |No| E["AgentError(status, body)"]
B --> |Yes| C["Parse JSON"]
C --> D{"Valid JSON?"}
D --> |No| F["AgentError(JSON parse error)"]
D --> |Yes| G["Return response"]
H["Kimi WS"] --> I{"Handshake OK?"}
I --> |No| J["KimiError(handshake)"]
I --> |Yes| K["Drive session loop"]
K --> L{"Timeout?"}
L --> |Yes| M["KimiTimeoutError"]
L --> |No| N["Collect text"]
```

**Diagram sources**
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [kimi_web_client.rb:208-209](file://lib/redmine_ai_agent/kimi_web_client.rb#L208-L209)
- [kimi_web_client.rb:229](file://lib/redmine_ai_agent/kimi_web_client.rb#L229)
- [ai_agent_dispatch_job.rb:4-5](file://app/jobs/ai_agent_dispatch_job.rb#L4-L5)

**Section sources**
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [kimi_web_client.rb:208-209](file://lib/redmine_ai_agent/kimi_web_client.rb#L208-L209)
- [kimi_web_client.rb:229](file://lib/redmine_ai_agent/kimi_web_client.rb#L229)
- [ai_agent_dispatch_job.rb:4-5](file://app/jobs/ai_agent_dispatch_job.rb#L4-L5)

### Practical Configuration and Integration Patterns
- Plugin settings:
  - enabled: toggles the plugin
  - redmine_api_base_url: Redmine instance URL used in prompts and links
  - default_timeout: HTTP read timeout for agent calls
- Agent configuration:
  - agent_type: hermes, pi, qoder, kimi_web, custom
  - protocol: chat_completions, responses, kimi_web_ws
  - endpoint_url: provider base URL
  - api_key: optional for HTTP auth or Kimi token
  - model_name: model identifier for the provider
  - system_prompt: optional override; otherwise resolved templates
  - For Kimi Web:
    - kimi_web_session_id: optional persistent session UUID
    - kimi_web_work_dir: working directory for new sessions
    - kimi_web_timeout: WebSocket timeout in seconds
- Integration patterns:
  - Automatic dispatch on issue creation/edit when assignee has an active agent assignment
  - Manual dispatch via UI panel and controller action
  - Tool calls executed server-side with RedmineApiSkill

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)

## Dependency Analysis
- Cohesion:
  - AgentClient encapsulates HTTP concerns
  - KimiWebClient encapsulates WebSocket concerns
  - RedmineApiSkill encapsulates Redmine API calls
- Coupling:
  - AiAgentDispatchJob depends on AgentClient and RedmineApiSkill
  - Hooks depend on AiAgentAssignment and trigger jobs
  - Models define agent capabilities and prompts
- External dependencies:
  - Net::HTTP for HTTP
  - WebSocket framing and TLS for Kimi
  - Redmine REST API for tool execution

```mermaid
graph LR
Hooks["Hooks"] --> Job["AiAgentDispatchJob"]
Job --> Client["AgentClient"]
Job --> Skill["RedmineApiSkill"]
Client --> Model["AiAgent"]
Skill --> Redmine["Redmine REST API"]
Kimi["KimiWebClient"] --> Model
```

**Diagram sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)

**Section sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)

## Performance Considerations
- Timeouts:
  - Use plugin default_timeout for HTTP read timeout
  - KimiWebClient applies its own timeout during session loop
- Backoff:
  - ActiveJob retry uses polynomial backoff to reduce load during transient failures
- Payload minimisation:
  - Limit recent journal notes included in user context
- Concurrency:
  - Jobs run asynchronously; ensure queue backend is tuned for workload

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- HTTP 401/403:
  - Verify api_key and endpoint_url correctness
- HTTP 5xx or timeouts:
  - Increase default_timeout or check provider availability
- Invalid JSON from agent:
  - Inspect raw response and payload structure
- Kimi handshake failures:
  - Confirm endpoint_url points to Kimi web UI and token if required
- Session errors or closures:
  - Check session alive status and recreate session
- Tool call failures:
  - Review RedmineApiSkill error messages and permissions

**Section sources**
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [kimi_web_client.rb:208-209](file://lib/redmine_ai_agent/kimi_web_client.rb#L208-L209)
- [kimi_web_client.rb:357-358](file://lib/redmine_ai_agent/kimi_web_client.rb#L357-L358)
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)

## Conclusion
The AI Communication Layer provides a robust, extensible foundation for integrating Redmine with diverse AI providers. It supports both HTTP and WebSocket protocols, implements a structured tool calling pattern, and includes comprehensive error handling and retry mechanisms. Proper configuration of agent types, protocols, and timeouts ensures reliable automation of Redmine workflows.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Appendix A: Agent Types and Protocols
- Agent types: hermes, pi, qoder, kimi_web, custom
- Protocols: chat_completions, responses, kimi_web_ws
- Tools available: redmine_get_issue, redmine_update_issue, redmine_list_statuses, redmine_get_project

**Section sources**
- [ai_agent.rb:2-3](file://app/models/ai_agent.rb#L2-L3)
- [ai_agent.rb:127-140](file://app/models/ai_agent.rb#L127-L140)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

### Appendix B: Database Schema Notes
- ai_agents table extended with Kimi-specific fields for session reuse and work directory
- Indexes on agent_type and active improve lookup performance

**Section sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)