# Payload Management

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains how payloads are constructed, transformed, filtered, and sanitized for AI agent communication with Redmine. It covers:
- Building payloads for chat_completions and responses APIs
- Formatting user context messages with project details, status, priority, and recent journal notes
- Dynamic payload construction based on agent type and protocol
- Tool/function definitions for agents that support function calling
- Response extraction and tool-loop execution
- Practical examples, protocol variations, and troubleshooting strategies

## Project Structure
The payload management logic spans several modules:
- Agent client for OpenAI-compatible endpoints
- Kimi Web client for a custom WebSocket protocol
- Redmine API skill for executing tool calls server-side
- Models and jobs orchestrating dispatch and persistence
- Settings and routing wiring the plugin into Redmine

```mermaid
graph TB
subgraph "Plugin Initialization"
INIT["init.rb"]
REG["lib/redmine_ai_agent.rb"]
end
subgraph "Agent Clients"
AC["AgentClient<br/>OpenAI-compatible"]
KWC["KimiWebClient<br/>WebSocket"]
end
subgraph "Skills"
RAS["RedmineApiSkill<br/>tool executor"]
end
subgraph "Models"
AA["AiAgent"]
AAD["AiAgentDispatch"]
end
subgraph "Controllers/Jobs"
CTRL["AiAgentDispatchesController"]
JOB["AiAgentDispatchJob"]
end
INIT --> REG
REG --> AC
REG --> KWC
REG --> RAS
CTRL --> JOB
JOB --> AC
JOB --> KWC
JOB --> RAS
AC --> AA
AC --> AAD
KWC --> AA
KWC --> AAD
RAS --> AA
RAS --> AAD
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Core Components
- AgentClient: Builds protocol-specific payloads, posts to the agent endpoint, parses responses, and manages tool loops for agents that support function calling.
- KimiWebClient: Manages session creation and WebSocket messaging for the Kimi web interface, composing a prompt string from issue context and system instructions.
- RedmineApiSkill: Executes tool calls server-side against the Redmine REST API using the assignee’s API key.
- AiAgent: Defines agent types, protocols, and system prompts; resolves placeholders for base URL and keys.
- AiAgentDispatch: Stores request/response payloads and dispatch metadata.
- AiAgentDispatchJob: Orchestrates dispatch, posts journal notes, persists payloads, and runs tool loops.

**Section sources**
- [agent_client.rb:8-261](file://lib/redmine_ai_agent/agent_client.rb#L8-L261)
- [kimi_web_client.rb:21-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L421)
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

## Architecture Overview
The payload lifecycle:
- Build payload based on agent protocol (chat_completions vs responses)
- For chat_completions, include system prompt and user context message; optionally include tool definitions
- Post payload to agent endpoint; parse response text
- For agents supporting function calling, execute tool calls via RedmineApiSkill and feed results back iteratively
- Persist request/response payloads and post agent text to Redmine journal

```mermaid
sequenceDiagram
participant C as "Controller"
participant J as "Job"
participant AC as "AgentClient"
participant EP as "Agent Endpoint"
participant S as "RedmineApiSkill"
C->>J : "Enqueue dispatch"
J->>AC : "call(issue, triggered_by)"
AC->>AC : "build_payload(issue)"
AC->>EP : "POST /v1/chat/completions or /v1/responses"
EP-->>AC : "raw response"
AC-->>J : "{text, raw_response, request}"
J->>J : "run_tool_loop(...)"
J->>S : "execute_tool_call(tool_call)"
S-->>J : "tool_result"
J->>AC : "post_to_agent(request with tool results)"
AC-->>J : "final text"
J->>J : "persist payloads, post journal"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)

## Detailed Component Analysis

### Payload Construction: Chat Completions vs Responses
- Protocol selection: AgentClient selects endpoint and payload shape based on agent.protocol.
- Chat Completions payload includes:
  - model
  - messages: system prompt + user context message
  - tools and tool_choice (only for compatible agents)
- Responses payload includes:
  - model
  - input: issue context message
  - instructions: system prompt

```mermaid
flowchart TD
Start(["Build Payload"]) --> CheckProto{"Protocol?"}
CheckProto --> |chat_completions| CC["Build Chat Completions Payload<br/>model + messages + tools"]
CheckProto --> |responses| RESP["Build Responses Payload<br/>model + input + instructions"]
CC --> Tools{"Tools available?"}
Tools --> |Yes| AddTools["Attach tool definitions"]
Tools --> |No| SkipTools["Skip tools"]
AddTools --> End(["Return Payload"])
SkipTools --> End
RESP --> End
```

**Diagram sources**
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

**Section sources**
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:231-239](file://lib/redmine_ai_agent/agent_client.rb#L231-L239)

### Message Formatting: Issue Context
The user context message aggregates:
- Issue metadata: project, status, priority, assignee, author, created/updated dates, URL
- Description with fallback when missing
- Recent journal notes (up to a fixed number), skipping blank notes

```mermaid
flowchart TD
A["Start"] --> B["Collect metadata"]
B --> C["Add description or fallback"]
C --> D{"Has journals?"}
D --> |Yes| E["Iterate last N journals<br/>filter blank notes"]
D --> |No| F["Skip journals"]
E --> G["Format notes with author/date"]
F --> H["Join lines"]
G --> H
H --> I["Return message text"]
```

**Diagram sources**
- [agent_client.rb:83-112](file://lib/redmine_ai_agent/agent_client.rb#L83-L112)

**Section sources**
- [agent_client.rb:83-112](file://lib/redmine_ai_agent/agent_client.rb#L83-L112)

### System Prompts and Dynamic Resolution
System prompts are selected by agent_type and can be overridden per agent. Placeholders are resolved using:
- Redmine base URL from settings
- Assignee’s API key
- Issue and project identifiers

```mermaid
classDiagram
class AiAgent {
+agent_type
+protocol
+endpoint_url
+model_name
+api_key
+resolved_system_prompt(issue) String
}
AiAgent : "SYSTEM_PROMPT_TEMPLATES"
AiAgent : "chat_completions?()/responses_api?()"
AiAgent : "hermes?()/pi?()/qoder?()/kimi_web?()"
AiAgent : "kimi_web_ws?"
```

**Diagram sources**
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [ai_agent.rb:52-50](file://app/models/ai_agent.rb#L52-L50)

**Section sources**
- [ai_agent.rb:52-153](file://app/models/ai_agent.rb#L52-L153)

### Tool Definitions and Function Calling
For agents that support function calling (e.g., Hermes/Pi), AgentClient builds tool definitions for:
- Fetching an issue
- Updating an issue (notes, status, completion)
- Listing statuses
- Getting project details

These are attached to the chat_completions payload when supported and not using Kimi Web or Qoder.

```mermaid
flowchart TD
TStart["Build Tools"] --> CheckAgent{"Kimi Web or Qoder?"}
CheckAgent --> |Yes| TEmpty["Return empty tools"]
CheckAgent --> |No| TBuild["Define functions:<br/>get_issue, update_issue,<br/>list_statuses, get_project"]
TBuild --> TEnd["Attach to payload"]
TEmpty --> TEnd
```

**Diagram sources**
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

**Section sources**
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

### Response Parsing and Text Extraction
- Chat Completions: Extracts assistant content from choices[0].message.content
- Responses: Handles both array and scalar output structures, concatenating text segments

```mermaid
flowchart TD
RS["Raw Response"] --> Proto{"Protocol?"}
Proto --> |chat_completions| CCX["Extract choices[0].message.content"]
Proto --> |responses| REX["If Array: join content[0].text;<br/>Else: use output_text"]
CCX --> RET["Return text"]
REX --> RET
```

**Diagram sources**
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

**Section sources**
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

### Tool Loop Execution
When function calls are detected, the job executes them via RedmineApiSkill and feeds results back to the agent up to a maximum number of iterations. The loop augments messages with tool_call_id and tool results.

```mermaid
sequenceDiagram
participant J as "Job"
participant AC as "AgentClient"
participant S as "RedmineApiSkill"
participant EP as "Agent Endpoint"
J->>AC : "Initial call"
AC-->>J : "raw_response"
loop Up to N iterations
J->>J : "Inspect raw_response.choices[0].message.tool_calls"
alt Has tool_calls
J->>S : "execute_tool_call(call)"
S-->>J : "tool_result"
J->>AC : "post_to_agent(messages + tool results)"
AC-->>J : "next raw_response"
else No tool_calls
J-->>J : "return final text"
end
end
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)

**Section sources**
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [redmine_api_skill.rb:34-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L61)

### Kimi Web Protocol: Session and Prompt
KimiWebClient:
- Creates or reuses a session via REST
- Establishes a WebSocket connection and runs a JSON-RPC loop
- Composes a prompt string combining issue context and system instructions
- Auto-approves requests to keep the agent running

```mermaid
sequenceDiagram
participant J as "Job"
participant K as "KimiWebClient"
participant REST as "Kimi REST API"
participant WS as "Kimi WebSocket"
J->>K : "call(issue)"
K->>REST : "ensure_session!"
REST-->>K : "session_id"
K->>K : "build_prompt(issue)"
K->>WS : "drive_session(session_id, prompt)"
WS-->>K : "final_text"
K-->>J : "{text, raw_response, request}"
```

**Diagram sources**
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)
- [kimi_web_client.rb:66-100](file://lib/redmine_ai_agent/kimi_web_client.rb#L66-L100)
- [kimi_web_client.rb:142-154](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L154)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)

**Section sources**
- [kimi_web_client.rb:38-136](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L136)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)

### Payload Persistence and Dispatch Lifecycle
- AiAgentDispatch stores request and response payloads as JSON
- Job posts “dispatch started” and “dispatch done/error” journal notes
- Dispatch status transitions from running to done/error with timestamps

```mermaid
stateDiagram-v2
[*] --> Pending
Pending --> Running : "job starts"
Running --> Done : "success"
Running --> Error : "failure"
Done --> [*]
Error --> [*]
```

**Diagram sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:17-57](file://app/jobs/ai_agent_dispatch_job.rb#L17-L57)

**Section sources**
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent_dispatch_job.rb:17-57](file://app/jobs/ai_agent_dispatch_job.rb#L17-L57)

## Dependency Analysis
- AgentClient depends on AiAgent for protocol and system prompt resolution, and on settings for base URL and timeouts.
- RedmineApiSkill depends on the Redmine base URL and assignee API key to call endpoints.
- AiAgentDispatchJob coordinates AgentClient/KimiWebClient and RedmineApiSkill, persisting payloads and journaling outcomes.
- Hooks enable auto-dispatch on issue updates and inject UI panels.

```mermaid
graph LR
AA["AiAgent"] --> AC["AgentClient"]
AA --> KWC["KimiWebClient"]
AAD["AiAgentDispatch"] --> AC
AAD --> KWC
AC --> RAS["RedmineApiSkill"]
JOB["AiAgentDispatchJob"] --> AC
JOB --> KWC
JOB --> RAS
CTRL["AiAgentDispatchesController"] --> JOB
HK["Hooks"] --> JOB
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:22-42](file://lib/redmine_ai_agent/agent_client.rb#L22-L42)
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

**Section sources**
- [agent_client.rb:22-42](file://lib/redmine_ai_agent/agent_client.rb#L22-L42)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

## Performance Considerations
- Payload size and encoding:
  - The user context message includes recent journal notes; limit the number of entries to control payload size.
  - Ensure UTF-8 encoding for prompt strings and JSON payloads.
- Timeout tuning:
  - AgentClient uses a configurable default timeout from settings; ensure it accommodates agent latency and tool execution.
  - KimiWebClient has a separate timeout for WebSocket operations.
- Tool loop limits:
  - The job enforces a maximum iteration count to prevent runaway loops.
- Network efficiency:
  - Reuse sessions for Kimi Web when possible to reduce overhead.
- Storage:
  - Request/response payloads are persisted as text; consider compression or pruning for very large responses.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common payload-related issues and resolutions:
- Invalid endpoint URL or HTTP failure:
  - AgentClient raises a structured error with status/body; inspect raw response and endpoint configuration.
- JSON parsing errors:
  - AgentClient and RedmineApiSkill catch parser errors; verify agent response format and Redmine API responses.
- Missing or empty tool results:
  - Ensure the assignee has a valid API key; confirm tool definitions are attached for compatible agents.
- Timeout errors:
  - Increase default_timeout or kimi_web_timeout depending on the agent type.
- Empty agent text:
  - The job falls back to a placeholder message when the agent returns empty text.

**Section sources**
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)
- [ai_agent_dispatch_job.rb:50-57](file://app/jobs/ai_agent_dispatch_job.rb#L50-L57)

## Conclusion
Payload management centers on dynamic, protocol-aware construction of user context and system prompts, with optional tool definitions for function-calling agents. The system supports both OpenAI-compatible endpoints and a custom WebSocket protocol, persists request/response payloads, and executes tool loops server-side to interact with Redmine. Proper configuration of endpoints, timeouts, and agent types ensures reliable and efficient operation.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Appendix A: Payload Examples by Scenario
- Chat Completions with tools:
  - Include model, messages (system + user), tools, and tool_choice.
  - Attach tools only when supported and not using Kimi Web or Qoder.
- Responses API:
  - Include model, input (issue context), and instructions (system prompt).
- Kimi Web:
  - Compose a prompt string with issue metadata, recent notes, and system instructions; manage session and WebSocket lifecycle.

**Section sources**
- [agent_client.rb:58-77](file://lib/redmine_ai_agent/agent_client.rb#L58-L77)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [kimi_web_client.rb:106-136](file://lib/redmine_ai_agent/kimi_web_client.rb#L106-L136)

### Appendix B: Data Model for Payload Storage
```mermaid
erDiagram
AI_AGENT {
int id PK
string name
string agent_type
string endpoint_url
string protocol
string api_key
string model_name
text system_prompt
boolean active
}
AI_AGENT_DISPATCH {
int id PK
int issue_id FK
int ai_agent_id FK
int triggered_by
string status
text request_payload
text response_payload
int journal_id
datetime dispatched_at
datetime completed_at
}
ISSUE ||--o{ AI_AGENT_DISPATCH : "has"
AI_AGENT ||--o{ AI_AGENT_DISPATCH : "has"
```

**Diagram sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)