# HTTP Client Implementation

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the HTTP client implementation used to communicate with OpenAI-compatible APIs for AI agents integrated into Redmine. It focuses on the AgentClient class, covering initialization, payload construction for both chat_completions and responses API protocols, authentication, endpoint resolution, HTTP transport configuration, timeouts, SSL handling, and error handling. It also documents the tool-call loop for agents that support function/tool calling, the differences between the two API protocols, and practical configuration and usage patterns.

## Project Structure
The HTTP client lives under lib/redmine_ai_agent and integrates with Redmine models and jobs. Key areas:
- HTTP clients: AgentClient (OpenAI-compatible), KimiWebClient (WebSocket-driven), RedmineApiSkill (server-side tool executor)
- Models: AiAgent, AiAgentAssignment, AiAgentDispatch
- Job: AiAgentDispatchJob orchestrates dispatch, HTTP calls, and tool-loop execution
- Plugin settings define defaults for timeouts and base URLs

```mermaid
graph TB
subgraph "Plugin"
INIT["init.rb<br/>Plugin settings"]
HOOKS["hooks.rb<br/>Issue hooks"]
end
subgraph "Models"
AGENT["ai_agent.rb<br/>Agent config + prompts"]
ASSIGN["ai_agent_assignment.rb<br/>User-to-agent mapping"]
DISPATCH["ai_agent_dispatch.rb<br/>Dispatch records"]
end
subgraph "Lib"
AC["agent_client.rb<br/>AgentClient (HTTP)"]
KWC["kimi_web_client.rb<br/>KimiWebClient (WS)"]
SKILL["redmine_api_skill.rb<br/>RedmineApiSkill"]
end
subgraph "Job"
JOB["ai_agent_dispatch_job.rb<br/>Dispatch runner"]
end
INIT --> AGENT
HOOKS --> JOB
JOB --> AC
JOB --> SKILL
AGENT --> AC
AGENT --> KWC
ASSIGN --> JOB
DISPATCH --> JOB
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Core Components
- AgentClient: Thin HTTP client that speaks both OpenAI Chat Completions and Responses API. Builds payloads, performs HTTP requests, parses responses, and raises AgentError on failures.
- KimiWebClient: Specialized client for Kimi Web interface using REST and WebSocket JSON-RPC.
- RedmineApiSkill: Executes Redmine REST API calls server-side on behalf of the agent when tool_calls are returned.
- AiAgent: Model storing agent configuration, protocol selection, endpoint URL, and system prompts.
- AiAgentDispatchJob: Orchestrates dispatch, HTTP calls, and the tool-call loop.
- AiAgentDispatch/AiAgentAssignment: Persistence and mapping for dispatch records and user-to-agent assignments.

Key behaviors:
- Endpoint resolution selects /v1/chat/completions or /v1/responses based on protocol.
- Authentication uses Authorization: Bearer header when api_key is configured.
- Timeout management uses a configurable default and per-client overrides.
- SSL is enabled automatically for HTTPS endpoints.
- Error handling centralizes failures into AgentError with status/body when available.

**Section sources**
- [agent_client.rb:8-261](file://lib/redmine_ai_agent/agent_client.rb#L8-L261)
- [kimi_web_client.rb:21-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L421)
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

## Architecture Overview
High-level flow:
- AiAgentDispatchJob triggers an agent dispatch for an issue.
- AgentClient builds the appropriate payload (chat_completions vs responses).
- HTTP request is sent to the resolved endpoint with Authorization header.
- Response is parsed and text is extracted.
- For agents that support tool_calls, a loop executes tool calls via RedmineApiSkill and resubmits the conversation.

```mermaid
sequenceDiagram
participant Hook as "Hooks"
participant Job as "AiAgentDispatchJob"
participant Client as "AgentClient"
participant Agent as "AiAgent"
participant Skill as "RedmineApiSkill"
participant HTTP as "Net : : HTTP"
Hook->>Job : "Issue created/updated"
Job->>Agent : "Load agent config"
Job->>Client : "Initialize with agent"
Job->>Client : "call(issue, triggered_by)"
Client->>Client : "build_payload(issue)"
Client->>HTTP : "POST /v1/chat/completions or /v1/responses"
HTTP-->>Client : "HTTP 200 + JSON"
Client->>Client : "extract_text(raw)"
alt "Agent supports tool_calls"
Client-->>Job : "Initial result"
Job->>Skill : "execute_tool_call(tool_call)"
Skill-->>Job : "Tool result"
Job->>Client : "post_to_agent(updated_messages)"
Client-->>Job : "Next result"
else "No tool_calls"
Client-->>Job : "Final result"
end
Job->>Job : "Persist request/response"
Job-->>Hook : "Post journal note"
```

**Diagram sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:22-261](file://lib/redmine_ai_agent/agent_client.rb#L22-L261)
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

## Detailed Component Analysis

### AgentClient Class
Responsibilities:
- Initialize with an AiAgent instance.
- Build payloads for chat_completions or responses API.
- Resolve endpoint URL and send HTTP POST.
- Parse response and extract text.
- Raise AgentError on HTTP/network errors.

Initialization and entry point:
- Initializes with an AiAgent and exposes call(issue, triggered_by:) returning { text, raw_response, request }.
- Delegates to KimiWebClient when protocol is kimi_web_ws.

Payload building:
- chat_completions: Uses model, messages array (system + user), and optional tools for supported agents.
- responses: Uses model, input, and instructions.

Endpoint resolution:
- Appends /v1/chat/completions for chat_completions.
- Appends /v1/responses for responses.

Authentication:
- Adds Authorization: Bearer <api_key> when present.

HTTP transport and timeouts:
- Creates Net::HTTP with host/port.
- Enables SSL for HTTPS.
- Sets read_timeout from plugin settings or default; open_timeout fixed at 15s.
- Logs the outgoing request.

Response parsing:
- For chat_completions: reads choices[0].message.content.
- For responses: concatenates output array items or falls back to output_text.

Error handling:
- Raises AgentError with HTTP status/body for non-success responses.
- Catches timeouts, JSON parse errors, and invalid URIs, wrapping them into AgentError.

```mermaid
classDiagram
class AgentClient {
+initialize(agent)
+call(issue, triggered_by) Hash
-build_payload(issue) Hash
-build_chat_completions_payload(issue) Hash
-build_responses_payload(issue) Hash
-resolve_endpoint() String
-post_to_agent(payload) Hash
-extract_text(raw) String
}
class AgentError {
+status Integer
+body String
+initialize(message, status : nil, body : nil)
}
AgentClient --> AgentError : "raises"
```

**Diagram sources**
- [agent_client.rb:8-261](file://lib/redmine_ai_agent/agent_client.rb#L8-L261)

**Section sources**
- [agent_client.rb:22-261](file://lib/redmine_ai_agent/agent_client.rb#L22-L261)

### KimiWebClient (Kimi Web Interface)
Purpose:
- Handles Kimi Web’s REST and WebSocket JSON-RPC protocol.
- Manages sessions, handshakes, and message loops.
- Returns a unified { text, raw_response, request } structure.

Key behaviors:
- Session management via REST: create or reuse a session.
- WebSocket upgrade with handshake verification.
- Message loop: initialize → history_complete → prompt → wait idle → collect text.
- Auto-approval of agent requests to keep the agent running unattended.
- Token handling via Authorization header or query parameter.

```mermaid
sequenceDiagram
participant Client as "KimiWebClient"
participant REST as "REST API"
participant WS as "WebSocket"
Client->>REST : "Ensure session"
REST-->>Client : "session_id"
Client->>WS : "Handshake"
WS-->>Client : "101 Switching Protocols"
Client->>WS : "JSON-RPC initialize"
WS-->>Client : "history_complete"
Client->>WS : "JSON-RPC prompt"
loop "Until idle"
WS-->>Client : "event/agent_text or agent_response"
end
WS-->>Client : "session_status=idle"
Client-->>Client : "Collect final text"
```

**Diagram sources**
- [kimi_web_client.rb:21-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L421)

**Section sources**
- [kimi_web_client.rb:21-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L421)

### RedmineApiSkill (Server-side Tool Execution)
Purpose:
- Execute Redmine REST API calls on behalf of the agent when tool_calls are returned.
- Supports redmine_get_issue, redmine_update_issue, redmine_list_statuses, redmine_get_project.

Behavior:
- Accepts base_url, api_key, and timeout.
- Parses tool_call.function.arguments and dispatches to appropriate method.
- Wraps errors into RedmineApiError with status when applicable.

```mermaid
flowchart TD
Start(["Receive tool_call"]) --> Parse["Parse function name and arguments"]
Parse --> Route{"Function name?"}
Route --> |redmine_get_issue| GetIssue["GET /issues/{id}.json"]
Route --> |redmine_update_issue| UpdateIssue["PUT /issues/{id}.json"]
Route --> |redmine_list_statuses| ListStatuses["GET /issue_statuses.json"]
Route --> |redmine_get_project| GetProject["GET /projects/{id}.json"]
GetIssue --> Return["Return parsed JSON"]
UpdateIssue --> Return
ListStatuses --> Return
GetProject --> Return
Route --> |Other| Unknown["Return error: unknown tool"]
```

**Diagram sources**
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)

**Section sources**
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)

### AiAgentDispatchJob (Orchestrator)
Responsibilities:
- Create dispatch record and post initial journal note.
- Call AgentClient and run tool-call loop if supported.
- Persist request/response payloads and post final journal note.
- Handle errors and mark dispatch as error.

Tool-call loop:
- Extracts tool_calls from choices[0].message.tool_calls.
- Executes each tool_call via RedmineApiSkill and appends results.
- Resubmits updated messages to the agent up to 10 iterations.

```mermaid
flowchart TD
Start(["Job.perform"]) --> CreateDispatch["Create dispatch record"]
CreateDispatch --> CallAgent["AgentClient.call(issue)"]
CallAgent --> ToolCalls{"tool_calls present?"}
ToolCalls --> |No| FinalText["Use agent text"]
ToolCalls --> |Yes| LoopStart["Loop 1..10"]
LoopStart --> ExecTools["Execute tool_calls via RedmineApiSkill"]
ExecTools --> AppendResults["Append tool results to messages"]
AppendResults --> Resubmit["Resubmit to agent"]
Resubmit --> ToolCalls
FinalText --> Persist["Persist request/response + journal"]
Persist --> End(["Done"])
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:22-261](file://lib/redmine_ai_agent/agent_client.rb#L22-L261)
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### AiAgent Model (Configuration and Prompts)
Highlights:
- Validates agent_type among hermes, pi, qoder, kimi_web, custom.
- Validates protocol among chat_completions, responses, kimi_web_ws.
- Provides resolved_system_prompt(issue) by substituting placeholders with runtime values.
- Safe API key masking for logging.

```mermaid
classDiagram
class AiAgent {
+agent_type String
+protocol String
+endpoint_url String
+api_key String
+model_name String
+chat_completions?() Boolean
+responses_api?() Boolean
+hermes?() Boolean
+pi?() Boolean
+qoder?() Boolean
+kimi_web?() Boolean
+kimi_web_ws?() Boolean
+resolved_system_prompt(issue) String
}
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

## Dependency Analysis
- AgentClient depends on AiAgent for endpoint, protocol, model, and API key.
- AiAgentDispatchJob composes AgentClient and RedmineApiSkill to execute tool loops.
- KimiWebClient is used exclusively when protocol is kimi_web_ws.
- Plugin settings provide redmine_api_base_url and default_timeout used across clients.

```mermaid
graph LR
AG["AiAgent"] --> AC["AgentClient"]
AG --> KWC["KimiWebClient"]
AC --> NET["Net::HTTP"]
AC --> AJOB["AiAgentDispatchJob"]
AJOB --> AC
AJOB --> SK["RedmineApiSkill"]
SK --> NET
INIT["Plugin Settings"] --> AC
INIT --> AJOB
```

**Diagram sources**
- [agent_client.rb:22-261](file://lib/redmine_ai_agent/agent_client.rb#L22-L261)
- [kimi_web_client.rb:21-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L421)
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [init.rb:12-16](file://init.rb#L12-L16)

**Section sources**
- [agent_client.rb:22-261](file://lib/redmine_ai_agent/agent_client.rb#L22-L261)
- [kimi_web_client.rb:21-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L421)
- [redmine_api_skill.rb:19-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L130)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [init.rb:12-16](file://init.rb#L12-L16)

## Performance Considerations
- Timeouts:
  - AgentClient read_timeout comes from plugin settings or defaults; open_timeout is fixed.
  - KimiWebClient uses its own timeout for WebSocket operations.
  - RedmineApiSkill sets a configurable timeout for Redmine API calls.
- SSL:
  - Automatic use_ssl based on endpoint scheme.
- Retries:
  - AiAgentDispatchJob retries on AgentError with polynomial backoff across up to 3 attempts.
- Payload minimization:
  - Tools are omitted when empty to reduce payload size for agents that do not support tool calling.
- Network efficiency:
  - Single-shot HTTP requests for chat_completions/responses.
  - WebSocket streaming for Kimi Web avoids repeated polling.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Invalid endpoint URL:
  - AgentError raised for invalid URI; verify endpoint_url format.
- Non-2xx HTTP response:
  - AgentError includes status and body; inspect remote service logs.
- Timeout errors:
  - Increase default_timeout in plugin settings or adjust agent-specific timeouts.
- Invalid JSON from agent:
  - AgentError wraps parser errors; validate agent response format.
- Agent returned empty text:
  - Check extract_text logic for protocol-specific fields.
- Tool-call failures:
  - Inspect RedmineApiSkill error propagation and Redmine API key permissions.

Operational tips:
- Enable logging around HTTP requests and responses.
- Verify Authorization header presence when api_key is configured.
- Confirm protocol matches agent API expectations (chat_completions vs responses).

**Section sources**
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)

## Conclusion
The HTTP client implementation provides a focused, extensible foundation for OpenAI-compatible API communication with Redmine. It cleanly separates concerns between payload construction, transport configuration, and response parsing, while offering robust error handling and retry strategies. Specialized clients address unique protocols (e.g., Kimi Web), and the tool-call loop enables autonomous agent actions against Redmine resources.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### API Protocol Differences: Chat Completions vs Responses
- Chat Completions:
  - Messages array with roles (system, user).
  - Optional tools and tool_choice for function/tool calling.
  - Response field: choices[0].message.content.
- Responses:
  - Fields: model, input, instructions.
  - Response field: output (array or object) or output_text.

**Section sources**
- [agent_client.rb:58-77](file://lib/redmine_ai_agent/agent_client.rb#L58-L77)
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

### Authentication and Endpoint Resolution
- Authentication:
  - Authorization: Bearer <api_key> when present.
- Endpoint resolution:
  - chat_completions → /v1/chat/completions
  - responses → /v1/responses
  - kimi_web_ws → delegated to KimiWebClient

**Section sources**
- [agent_client.rb:196-198](file://lib/redmine_ai_agent/agent_client.rb#L196-L198)
- [agent_client.rb:231-239](file://lib/redmine_ai_agent/agent_client.rb#L231-L239)
- [kimi_web_client.rb:156-161](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L161)

### Practical Configuration Examples
- Plugin settings:
  - enabled: true/false
  - redmine_api_base_url: base URL for Redmine REST API
  - default_timeout: seconds for HTTP read timeout
- Agent configuration:
  - agent_type: hermes, pi, qoder, kimi_web, custom
  - protocol: chat_completions, responses, kimi_web_ws
  - endpoint_url: base URL for agent API
  - api_key: optional bearer token
  - model_name: required for non-Kimi Web agents

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

### Request Building Patterns
- Chat Completions:
  - Build system prompt via AiAgent.resolved_system_prompt.
  - Construct user turn from issue context.
  - Attach tools for supported agents (filtered when empty).
- Responses:
  - Provide input and instructions derived from issue and system prompt.

**Section sources**
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:83-112](file://lib/redmine_ai_agent/agent_client.rb#L83-L112)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)

### Response Parsing Patterns
- Chat Completions:
  - choices[0].message.content
- Responses:
  - Concatenate output array items or fallback to output_text

**Section sources**
- [agent_client.rb:245-258](file://lib/redmine_ai_agent/agent_client.rb#L245-L258)

### Network Communication Patterns and Retry Logic
- AgentClient:
  - Net::HTTP with SSL, timeouts, and error mapping to AgentError.
- KimiWebClient:
  - REST session management plus WebSocket JSON-RPC loop with deadlines.
- RedmineApiSkill:
  - Net::HTTP with explicit X-Redmine-API-Key header and timeouts.
- Retry:
  - AiAgentDispatchJob retries on AgentError with exponential backoff across 3 attempts.

**Section sources**
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:142-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L282)
- [redmine_api_skill.rb:107-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L127)
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)

### Schema References
- AiAgent: name, agent_type, endpoint_url, protocol, api_key, model_name, system_prompt, active
- AiAgentAssignment: user_id, ai_agent_id, auto_dispatch
- AiAgentDispatch: issue_id, ai_agent_id, triggered_by, status, request_payload, response_payload, journal_id, dispatched_at, completed_at

**Section sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)