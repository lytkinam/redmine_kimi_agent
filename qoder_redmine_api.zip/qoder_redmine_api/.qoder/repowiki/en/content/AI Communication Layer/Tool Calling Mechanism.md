# Tool Calling Mechanism

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [SKILL.md](file://kimi-web/SKILL.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the tool calling mechanism that enables AI agents to execute Redmine API operations. It focuses on the RedmineApiSkill implementation, the OpenAI-style tool definitions for redmine_get_issue, redmine_update_issue, redmine_list_statuses, and redmine_get_project, and how these tools are integrated into agent payloads for Hermes and Pi agents. It also clarifies why tools are excluded for Kimi Web and Qoder, details dynamic tool loading based on agent type, parameter marshaling, response handling, practical invocation examples, error handling, security considerations, execution limits, permission checks, and audit logging for tool calls.

## Project Structure
The plugin integrates with Redmine through a plugin registration, a central module loader, and a set of Ruby classes implementing agent communication, tool definitions, and Redmine API skill execution. Jobs orchestrate agent calls and optional tool loops. Models define agent configurations and permissions. Routes and localization files support admin UI and internationalization.

```mermaid
graph TB
Plugin["Plugin Registration<br/>init.rb"] --> Loader["Module Loader<br/>lib/redmine_ai_agent.rb"]
Loader --> AgentClient["AgentClient<br/>lib/redmine_ai_agent/agent_client.rb"]
Loader --> RedmineSkill["RedmineApiSkill<br/>lib/redmine_ai_agent/redmine_api_skill.rb"]
Loader --> KimiClient["KimiWebClient<br/>lib/redmine_ai_agent/kimi_web_client.rb"]
Loader --> Hooks["Hooks Listener<br/>lib/redmine_ai_agent/hooks.rb"]
Job["AiAgentDispatchJob<br/>app/jobs/ai_agent_dispatch_job.rb"] --> AgentClient
Job --> RedmineSkill
Model["AiAgent Model<br/>app/models/ai_agent.rb"] --> AgentClient
Routes["Routes<br/>config/routes.rb"] --> Views["Admin UI"]
Locale["Locales<br/>config/locales/en.yml"] --> AdminUI["Admin UI"]
Migrations["Migrations<br/>db/migrate/*.rb"] --> DB["Database Schema"]
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

## Core Components
- RedmineApiSkill: Executes Redmine REST API calls on behalf of agents. It parses tool_call payloads, dispatches to specific methods, and returns serializable results. It encapsulates HTTP GET/PUT requests, authentication via X-Redmine-API-Key, and robust error handling.
- AgentClient: Builds agent payloads, conditionally includes tool definitions for compatible agents, posts to agent endpoints, and extracts textual responses. It supports both OpenAI Chat Completions and Responses APIs and delegates Kimi Web WebSocket flows to a dedicated client.
- AiAgentDispatchJob: Orchestrates agent dispatches, posts initial journal entries, executes the agent, optionally loops through tool_calls using RedmineApiSkill, persists request/response payloads, and posts final journal notes. It enforces a maximum loop limit and handles errors.
- AiAgent Model: Defines agent types, protocols, validations, and system prompt templates. It exposes helpers to detect agent types and protocols and resolves system prompts with Redmine context.
- Hooks and UI: Injects a “Send to AI Agent” panel into the issue show page and triggers automatic dispatches when issues are assigned or edited.

**Section sources**
- [redmine_api_skill.rb:19-129](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L129)
- [agent_client.rb:8-261](file://lib/redmine_ai_agent/agent_client.rb#L8-L261)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Architecture Overview
The system composes a tool-enabled payload for compatible agents, sends it to the agent endpoint, and optionally loops through tool_calls to execute Redmine operations. For Kimi Web, the agent manages tool execution internally via WebSocket, so no tool definitions are sent. For Qoder, a separate skill system is used, so tools are omitted.

```mermaid
sequenceDiagram
participant Hook as "Hooks"
participant Job as "AiAgentDispatchJob"
participant AC as "AgentClient"
participant Agent as "Agent Endpoint"
participant RS as "RedmineApiSkill"
participant RM as "Redmine REST"
Hook->>Job : "Triggered by issue assignment/edit"
Job->>AC : "call(issue, triggered_by)"
AC->>AC : "build_payload(issue)"
AC->>Agent : "POST /v1/chat/completions or /v1/responses"
Agent-->>AC : "Initial response (text + optional tool_calls)"
AC-->>Job : "Return {text, raw_response, request}"
alt "Agent supports tool_calls and not Kimi/Qoder"
loop "Up to 10 turns"
Job->>RS : "execute_tool_call(tc)"
RS->>RM : "GET/PUT /issues/.json, /projects/.json, /issue_statuses.json"
RM-->>RS : "JSON response or {ok : true}"
RS-->>Job : "{result or error}"
Job->>AC : "POST next messages (including tool results)"
AC-->>Agent : "Next request"
Agent-->>AC : "Next response"
AC-->>Job : "{text/raw_response/request}"
end
else "Kimi Web or Qoder"
AC-->>Job : "Return {text, raw_response, request}"
end
Job->>Job : "Persist request/response, post journal notes"
```

**Diagram sources**
- [hooks.rb:4-71](file://lib/redmine_ai_agent/hooks.rb#L4-L71)
- [ai_agent_dispatch_job.rb:7-119](file://app/jobs/ai_agent_dispatch_job.rb#L7-L119)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [redmine_api_skill.rb:67-86](file://lib/redmine_ai_agent/redmine_api_skill.rb#L67-L86)

## Detailed Component Analysis

### RedmineApiSkill: Function Definitions, Parameter Validation, and Execution
- Tool dispatch: The execute_tool_call method reads the function name and arguments from the tool_call, parses JSON arguments, and routes to the appropriate method. Unknown tools return an error result.
- Function definitions:
  - redmine_get_issue: Fetches a full issue including journals and attachments.
  - redmine_update_issue: Updates an issue with optional notes, status_id, and done_ratio. Only provided fields are included in the request body.
  - redmine_list_statuses: Lists all available issue statuses.
  - redmine_get_project: Retrieves project details and members.
- Parameter validation and marshaling:
  - Arguments are parsed from JSON; missing or malformed arguments default to safe values (e.g., optional fields absent or nil).
  - PUT body construction excludes nil values to avoid unintended resets.
- Operation execution:
  - GET and PUT methods construct HTTP requests with X-Redmine-API-Key and Content-Type headers.
  - perform handles timeouts, non-success HTTP responses, and JSON parse errors, raising a RedmineApiError with HTTP status.
- Error handling:
  - RedmineApiError captures HTTP status codes.
  - Specific rescue blocks return structured error results with messages and status codes.

```mermaid
flowchart TD
Start(["execute_tool_call"]) --> Parse["Parse function name and arguments"]
Parse --> Route{"Match function name"}
Route --> |redmine_get_issue| GetIssue["Call get_issue(issue_id)"]
Route --> |redmine_update_issue| UpdateIssue["Call update_issue(issue_id, notes?, status_id?, done_ratio?)"]
Route --> |redmine_list_statuses| ListStatuses["Call list_statuses()"]
Route --> |redmine_get_project| GetProject["Call get_project(project_id)"]
Route --> |Other| Unknown["Return {error: 'Unknown tool'}"]
GetIssue --> HTTPGet["GET /issues/{id}.json?include=..."]
UpdateIssue --> BuildBody["Build issue body (only provided fields)"]
BuildBody --> HTTPPut["PUT /issues/{id}.json"]
ListStatuses --> HTTPGet2["GET /issue_statuses.json"]
GetProject --> HTTPGet3["GET /projects/{id}.json?include=..."]
HTTPGet --> Perform["perform(): handle timeouts, non-2xx, JSON parse"]
HTTPPut --> Perform
HTTPGet2 --> Perform
HTTPGet3 --> Perform
Perform --> Success{"HTTP 2xx?"}
Success --> |Yes| ReturnOK["Return parsed JSON or {ok: true}"]
Success --> |No| RaiseErr["Raise RedmineApiError(status)"]
RaiseErr --> Catch["Rescue in execute_tool_call"]
Catch --> ReturnErr["Return {error, status}"]
```

**Diagram sources**
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [redmine_api_skill.rb:67-86](file://lib/redmine_ai_agent/redmine_api_skill.rb#L67-L86)
- [redmine_api_skill.rb:88-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L88-L127)

**Section sources**
- [redmine_api_skill.rb:19-129](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L129)

### Tool Definition Structure for Hermes and Pi
- Dynamic tool loading: The redmine_tools method returns OpenAI-style function definitions only for agents that support tool_calls and are not Kimi Web or Qoder. It constructs four functions with names, descriptions, and JSON Schema parameters.
- Conditional exclusion:
  - Kimi Web: tools are empty because the agent manages tool execution internally via WebSocket.
  - Qoder: tools are empty because a separate skill system is used.
- Tool definitions:
  - redmine_get_issue: requires issue_id.
  - redmine_update_issue: requires issue_id; notes, status_id, done_ratio are optional.
  - redmine_list_statuses: no parameters.
  - redmine_get_project: requires project_id.

```mermaid
classDiagram
class AgentClient {
+call(issue, triggered_by)
-build_payload(issue)
-build_chat_completions_payload(issue)
-build_responses_payload(issue)
-redmine_tools(issue)
-post_to_agent(payload)
-extract_text(raw)
}
class RedmineApiSkill {
+execute_tool_call(tool_call)
+get_issue(issue_id)
+update_issue(issue_id, notes, status_id, done_ratio)
+list_statuses()
+get_project(project_id)
-get(path)
-put(path, body)
-perform(uri, request)
}
AgentClient --> RedmineApiSkill : "executes tool_calls"
```

**Diagram sources**
- [agent_client.rb:50-186](file://lib/redmine_ai_agent/agent_client.rb#L50-L186)
- [redmine_api_skill.rb:19-129](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L129)

**Section sources**
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)

### Integration into Agent Payloads and Agent Type Handling
- Agent types and protocols:
  - Agent types: hermes, pi, qoder, kimi_web, custom.
  - Protocols: chat_completions, responses, kimi_web_ws.
- Payload building:
  - For chat_completions, tools and tool_choice are included; for responses, only system prompt and user message are included.
  - Tools are filtered out when agent is kimi_web_ws or qoder.
- Agent-specific system prompts:
  - AiAgent provides templates for each agent type, including placeholders for Redmine base URL, API key, issue/project IDs, and endpoint references.

```mermaid
sequenceDiagram
participant AC as "AgentClient"
participant Agent as "Agent Endpoint"
AC->>AC : "build_payload(issue)"
alt "chat_completions"
AC->>AC : "build_chat_completions_payload"
AC->>AC : "redmine_tools(issue)"
AC->>Agent : "POST /v1/chat/completions {tools, tool_choice}"
else "responses"
AC->>Agent : "POST /v1/responses {instructions, input}"
end
Agent-->>AC : "Response"
```

**Diagram sources**
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [ai_agent.rb:53-140](file://app/models/ai_agent.rb#L53-L140)

**Section sources**
- [agent_client.rb:24-42](file://lib/redmine_ai_agent/agent_client.rb#L24-L42)
- [agent_client.rb:50-77](file://lib/redmine_ai_agent/agent_client.rb#L50-L77)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-155)

### Dynamic Tool Loading Based on Agent Type
- Conditions:
  - Exclude tools for kimi_web_ws (Kimi Web WebSocket).
  - Exclude tools for qoder (Qoder uses its own skill system).
  - Include tools for hermes and pi (OpenAI-style tool_calls).
- Reasoning:
  - Kimi Web manages tool execution internally via WebSocket and does not accept external tool definitions.
  - Qoder has its own skill system and does not require external tool definitions.

**Section sources**
- [agent_client.rb:119-124](file://lib/redmine_ai_agent/agent_client.rb#L119-L124)

### Parameter Marshaling and Response Handling
- Parameter marshaling:
  - Arguments are parsed from JSON; optional fields are omitted from PUT bodies when nil.
  - Required fields enforce minimal validation at the API level.
- Response handling:
  - HTTP success returns parsed JSON; empty body returns {ok: true}.
  - Non-success HTTP raises RedmineApiError with status code.
  - Timeouts and JSON parse errors are captured and re-raised as RedmineApiError.

**Section sources**
- [redmine_api_skill.rb:38-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L38-L61)
- [redmine_api_skill.rb:71-78](file://lib/redmine_ai_agent/redmine_api_skill.rb#L71-L78)
- [redmine_api_skill.rb:107-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L127)

### Practical Examples of Tool Invocation
- redmine_get_issue:
  - Purpose: Retrieve full issue details including journals and attachments.
  - Invocation: The agent emits a tool_call with function name and JSON arguments containing issue_id.
  - Execution: RedmineApiSkill performs a GET request to the issues endpoint with include parameters.
- redmine_update_issue:
  - Purpose: Post a journal note, change status, or update completion percentage.
  - Invocation: The agent emits a tool_call with function name and JSON arguments including issue_id and optional fields.
  - Execution: RedmineApiSkill builds a PUT request body with provided fields and posts to the issues endpoint.
- redmine_list_statuses:
  - Purpose: Enumerate available statuses and IDs for selection.
  - Invocation: The agent emits a tool_call with function name and empty arguments.
  - Execution: RedmineApiSkill performs a GET request to the statuses endpoint.
- redmine_get_project:
  - Purpose: Obtain project metadata and members.
  - Invocation: The agent emits a tool_call with function name and JSON arguments containing project_id.
  - Execution: RedmineApiSkill performs a GET request to the projects endpoint with include members.

**Section sources**
- [redmine_api_skill.rb:40-56](file://lib/redmine_ai_agent/redmine_api_skill.rb#L40-L56)
- [redmine_api_skill.rb:67-86](file://lib/redmine_ai_agent/redmine_api_skill.rb#L67-L86)

### Error Handling for Failed Operations
- Redmine API errors:
  - Non-success HTTP responses raise RedmineApiError with status code.
  - Timeouts and JSON parse errors are captured and surfaced as RedmineApiError.
- Agent client errors:
  - Non-2xx responses from agent endpoints raise AgentError with status/body.
  - Network timeouts and invalid JSON are handled similarly.
- Job-level error handling:
  - AiAgentDispatchJob catches AgentError and StandardError, updates dispatch status with error payload, posts a journal note, and re-raises to trigger ActiveJob retries.

**Section sources**
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

### Security Considerations
- Authentication:
  - RedmineApiSkill uses X-Redmine-API-Key header for all requests.
  - AgentClient adds Authorization Bearer header for agent endpoints when configured.
- API key exposure:
  - AiAgent masks API keys in serialization (safe_api_key).
  - Logs reference masked values to prevent plaintext exposure.
- Endpoint validation:
  - AgentClient validates endpoint URLs and handles invalid URIs.
- Agent exclusivity:
  - Tools are not sent to Kimi Web or Qoder to avoid conflicts with their internal systems.

**Section sources**
- [redmine_api_skill.rb:90-96](file://lib/redmine_ai_agent/redmine_api_skill.rb#L90-L96)
- [agent_client.rb:196-198](file://lib/redmine_ai_agent/agent_client.rb#L196-L198)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [agent_client.rb:120-124](file://lib/redmine_ai_agent/agent_client.rb#L120-L124)

### Tool Execution Limits, Permission Checking, and Audit Logging
- Execution limits:
  - AiAgentDispatchJob enforces a maximum of 10 turns for tool loops to prevent runaway executions.
- Permission checking:
  - The plugin registers project-level permissions for managing AI agents and dispatches.
  - Agent system prompts include base URL and API key placeholders; actual permissions are enforced by the target Redmine instance.
- Audit logging:
  - AiAgentDispatchJob persists request and response payloads to the dispatch record.
  - Journal notes are posted for dispatch start, completion, and errors.

**Section sources**
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatch_job.rb:17-58](file://app/jobs/ai_agent_dispatch_job.rb#L17-L58)

## Dependency Analysis
The following diagram shows key dependencies among components involved in tool calling and agent dispatch.

```mermaid
graph TB
AC["AgentClient"] --> SK["RedmineApiSkill"]
AC --> JC["AiAgentDispatchJob"]
JC --> SK
JC --> AC
JC --> AM["AiAgent Model"]
HK["Hooks"] --> JC
RT["Routes"] --> Views["Admin UI"]
LO["Locales"] --> Views
MI["Migrations"] --> DB["Database"]
```

**Diagram sources**
- [agent_client.rb:8-261](file://lib/redmine_ai_agent/agent_client.rb#L8-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

**Section sources**
- [agent_client.rb:8-261](file://lib/redmine_ai_agent/agent_client.rb#L8-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

## Performance Considerations
- Timeouts:
  - RedmineApiSkill sets a configurable read timeout for Redmine API calls.
  - AgentClient sets read and open timeouts for agent endpoint calls.
- Concurrency:
  - AiAgentDispatchJob runs as a background job; retries are configured for transient errors.
- Loop limits:
  - The tool loop is bounded to 10 turns to prevent long-running cycles.

**Section sources**
- [redmine_api_skill.rb:107-111](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L111)
- [agent_client.rb:202-209](file://lib/redmine_ai_agent/agent_client.rb#L202-L209)
- [ai_agent_dispatch_job.rb:4-5](file://app/jobs/ai_agent_dispatch_job.rb#L4-L5)
- [ai_agent_dispatch_job.rb:90-112](file://app/jobs/ai_agent_dispatch_job.rb#L90-L112)

## Troubleshooting Guide
- Agent endpoint failures:
  - Verify endpoint URL and protocol; ensure Authorization header is correct for agent endpoints.
  - Check for timeouts and invalid JSON responses.
- Redmine API failures:
  - Confirm X-Redmine-API-Key is valid and the base URL matches the plugin settings.
  - Inspect HTTP status codes and error messages returned by Redmine.
- Tool loop issues:
  - Ensure the agent supports tool_calls and is not Kimi Web or Qoder.
  - Review dispatch logs for request/response payloads and tool results.
- Kimi Web vs. Qoder:
  - For Kimi Web, confirm WebSocket connectivity and session state.
  - For Qoder, rely on its native skill system rather than external tool definitions.

**Section sources**
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)
- [kimi_web_client.rb:142-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L282)
- [agent_client.rb:120-124](file://lib/redmine_ai_agent/agent_client.rb#L120-L124)

## Conclusion
The tool calling mechanism integrates seamlessly with compatible AI agents by dynamically providing OpenAI-style function definitions, securely executing Redmine API operations, and handling errors gracefully. It respects agent-specific constraints (Kimi Web and Qoder) and ensures auditability through dispatch records and journal notes. With execution limits, timeouts, and masking of sensitive credentials, the system balances autonomy with safety.

## Appendices

### Appendix A: Agent Types and Protocols
- Agent types: hermes, pi, qoder, kimi_web, custom.
- Protocols: chat_completions, responses, kimi_web_ws.

**Section sources**
- [ai_agent.rb:2-50](file://app/models/ai_agent.rb#L2-L50)

### Appendix B: Database Schema Overview
- ai_agents table stores agent configuration, including type, protocol, endpoint, model, API key, and flags for Kimi Web.
- ai_agent_assignments and ai_agent_dispatches support assignment and dispatch tracking.

**Section sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

### Appendix C: Kimi Web Integration Notes
- Kimi Web uses WebSocket JSON-RPC 2.0 and manages tool execution internally; therefore, no external tool definitions are sent.
- The client handles session creation, health checks, and message loops.

**Section sources**
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [api-reference.md:1-776](file://kimi-web/reference/api-reference.md#L1-L776)
- [SKILL.md:1-414](file://kimi-web/SKILL.md#L1-L414)