# Communication Failures

<cite>
**Referenced Files in This Document**
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [routes.rb](file://config/routes.rb)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [init.rb](file://init.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [_form.html.erb](file://app/views/ai_agents/_form.html.erb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides comprehensive troubleshooting guidance for AI agent communication failures within the Redmine AI Agent plugin. It focuses on HTTP connection errors, timeouts, API response failures, and WebSocket connection problems. It also documents error codes (HTTP status codes, WebSocket close codes, and JSON-RPC error codes), and outlines debugging strategies for network connectivity, SSL certificate issues, and proxy configuration errors. Diagnostic tools and techniques for testing agent endpoints and validating communication channels are included.

## Project Structure
The plugin integrates with Redmine to manage AI agents and dispatch them to work on issues. Communication pathways include:
- HTTP-based agents using OpenAI-compatible endpoints
- Health checks via a dedicated endpoint
- WebSocket-based Kimi Web interface for streaming and session control

```mermaid
graph TB
subgraph "Redmine Admin UI"
UI["Admin Pages<br/>Settings & Agent Forms"]
end
subgraph "Rails Controllers"
Ctrls["AiAgentsController<br/>test_connection action"]
end
subgraph "Models"
Model["AiAgent<br/>validations & helpers"]
end
subgraph "Routes"
Rts["Routes<br/>resources + test_connection"]
end
subgraph "External Services"
HTTP["OpenAI-compatible API<br/>/v1/chat/completions or /v1/responses"]
HEALTH["Health Probe<br/>/healthz"]
WS["Kimi Web WebSocket<br/>/api/sessions/{session_id}/stream"]
end
UI --> Rts
Rts --> Ctrls
Ctrls --> Model
Ctrls --> HTTP
Ctrls --> HEALTH
Model --> WS
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [api-reference.md:341-346](file://kimi-web/reference/api-reference.md#L341-L346)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

## Core Components
- AiAgentsController.test_connection: Performs health checks and minimal chat completions against configured endpoints, with explicit timeouts and error handling.
- AiAgent model: Provides protocol and agent type helpers, validations for endpoint URLs, and safe API key masking.
- Routes: Exposes the test_connection endpoint for manual verification.
- Kimi Web WebSocket client: Implements JSON-RPC over WebSocket with connection lifecycle, message parsing, and error reporting.
- Plugin settings: Global defaults for Redmine base URL and default timeout.

Key implementation references:
- HTTP test and timeouts: [ai_agents_controller.rb:50-92](file://app/controllers/ai_agents_controller.rb#L50-L92)
- Protocol detection and endpoints: [ai_agents_controller.rb:65-75](file://app/controllers/ai_agents_controller.rb#L65-L75)
- Model helpers and validations: [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50), [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)
- WebSocket client behavior: [kimi-web-ws.py:47-226](file://kimi-web/scripts/kimi-web-ws.py#L47-L226)
- Plugin settings defaults: [init.rb:12-16](file://init.rb#L12-L16)

**Section sources**
- [ai_agents_controller.rb:50-92](file://app/controllers/ai_agents_controller.rb#L50-L92)
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)
- [kimi-web-ws.py:47-226](file://kimi-web/scripts/kimi-web-ws.py#L47-L226)
- [init.rb:12-16](file://init.rb#L12-L16)

## Architecture Overview
The communication architecture supports two primary modes:
- HTTP mode: Uses Net::HTTP to POST to either chat completions or responses endpoints, with Authorization and JSON payloads.
- WebSocket mode: Uses a JSON-RPC over WebSocket client to interact with the Kimi Web interface.

```mermaid
sequenceDiagram
participant Admin as "Admin UI"
participant Ctrl as "AiAgentsController"
participant Agent as "AiAgent"
participant HTTP as "External HTTP API"
participant WS as "Kimi Web WebSocket"
Admin->>Ctrl : "POST /ai_agents/ : id/test_connection"
Ctrl->>Agent : "check protocol and endpoint"
alt "Kimi Web WebSocket"
Ctrl->>WS : "Connect and stream events"
WS-->>Ctrl : "Connection events and messages"
else "Standard HTTP"
Ctrl->>HTTP : "POST /v1/chat/completions or /v1/responses"
HTTP-->>Ctrl : "HTTP response"
end
Ctrl-->>Admin : "JSON { ok, status, body or error }"
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [kimi-web-ws.py:196-226](file://kimi-web/scripts/kimi-web-ws.py#L196-L226)

## Detailed Component Analysis

### HTTP Communication Flow (AiAgentsController.test_connection)
- Determines endpoint and payload based on protocol:
  - chat_completions: POST to /v1/chat/completions with model and messages.
  - responses: POST to /v1/responses with model and input.
  - kimi_web_ws: GET to /healthz with Authorization header.
- Applies timeouts:
  - open_timeout and read_timeout configured to short durations for responsiveness.
- Error handling:
  - Catches exceptions and returns JSON with error message.

```mermaid
flowchart TD
Start(["test_connection"]) --> CheckProto["Check protocol"]
CheckProto --> IsKimi{"kimi_web_ws?"}
IsKimi --> |Yes| HealthReq["GET /healthz with Authorization"]
IsKimi --> |No| BuildPayload["Build payload based on protocol"]
BuildPayload --> SetTimeouts["Set open/read timeouts"]
HealthReq --> SetTimeouts
SetTimeouts --> SendHTTP["Send HTTP request"]
SendHTTP --> Resp{"HTTPSuccess?"}
Resp --> |Yes| Ok["Return { ok: true, status, body }"]
Resp --> |No| Err["Return { ok: false, status, body }"]
Ok --> End(["End"])
Err --> End
```

**Diagram sources**
- [ai_agents_controller.rb:50-92](file://app/controllers/ai_agents_controller.rb#L50-L92)

**Section sources**
- [ai_agents_controller.rb:50-92](file://app/controllers/ai_agents_controller.rb#L50-L92)

### WebSocket Communication Flow (Kimi Web)
- Establishes WebSocket connection to ws://host:port/api/sessions/{session_id}/stream with optional token.
- Handles JSON-RPC messages:
  - On connect: prints connection status and waits for history completion.
  - On messages: parses JSON, reacts to session_status, event types, and requests.
  - On errors: prints error details.
  - On close: prints close status code and message.
- Supports actions:
  - prompt: sends user input and optionally waits for idle state.
  - cancel: cancels current prompt.
  - plan-mode: toggles plan mode.
  - stream: interactive mode.

```mermaid
sequenceDiagram
participant Client as "kimi-web-ws.py"
participant WS as "Kimi Web WebSocket"
Client->>WS : "Connect ws : //host : port/api/sessions/{session_id}/stream"
WS-->>Client : "on_open"
WS-->>Client : "on_message(history_complete)"
Client->>WS : "send_prompt / send_cancel / send_plan_mode"
WS-->>Client : "on_message(session_status/event/request)"
WS-->>Client : "on_error / on_close"
```

**Diagram sources**
- [kimi-web-ws.py:196-226](file://kimi-web/scripts/kimi-web-ws.py#L196-L226)
- [kimi-web-ws.py:68-149](file://kimi-web/scripts/kimi-web-ws.py#L68-L149)

**Section sources**
- [kimi-web-ws.py:47-226](file://kimi-web/scripts/kimi-web-ws.py#L47-L226)

### Data Models and Validations
- AiAgent validates endpoint_url format and protocol selection, ensuring only supported combinations are accepted.
- Provides helpers to detect protocol and agent type, and masks API keys for safe display.

```mermaid
classDiagram
class AiAgent {
+string name
+string agent_type
+string endpoint_url
+string protocol
+string api_key
+string model_name
+boolean active
+chat_completions?()
+responses_api?()
+kimi_web_ws?()
+safe_api_key()
}
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

**Section sources**
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

## Dependency Analysis
- Routes define the test_connection endpoint bound to AiAgentsController.
- AiAgentsController depends on AiAgent for protocol detection and endpoint construction.
- HTTP communication uses Ruby’s Net::HTTP with explicit timeouts.
- WebSocket communication uses a Python client with JSON-RPC message handling.

```mermaid
graph LR
Routes["routes.rb"] --> Ctrl["AiAgentsController"]
Ctrl --> Model["AiAgent"]
Ctrl --> HTTP["Net::HTTP"]
Model --> WS["WebSocket Client (Python)"]
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)

## Performance Considerations
- Short timeouts are used in HTTP tests to prevent blocking UI interactions. Tune these based on external service latency and reliability.
- For WebSocket streaming, ping intervals and timeouts are configured to maintain connection stability.
- Consider batching or caching responses where appropriate to reduce repeated network calls.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### HTTP Connection Errors
Common symptoms:
- Immediate failure or slow response in the test_connection endpoint.
- Non-success HTTP status codes returned.

Diagnostics:
- Verify endpoint_url format and scheme (http/https).
- Confirm Authorization header is present when required.
- Check firewall and proxy configurations.
- Validate SSL certificates if using HTTPS.

Error codes to watch:
- HTTP 401/403: Unauthorized or forbidden.
- HTTP 404: Endpoint not found.
- HTTP 422: Validation error in request payload.
- HTTP 5xx: Server-side errors.

Actionable steps:
- Use curl or a similar tool to manually call the endpoint with Authorization and JSON payload.
- Temporarily disable proxy or configure it correctly.
- Test DNS resolution and port accessibility from the server host.

**Section sources**
- [ai_agents_controller.rb:50-92](file://app/controllers/ai_agents_controller.rb#L50-L92)
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)

### Timeouts
Symptoms:
- test_connection returns quickly with an error or truncated body.
- HTTP open/read timeouts occur.

Root causes:
- External API slow to respond.
- Network latency or routing issues.
- Misconfigured timeouts.

Resolution:
- Increase timeouts cautiously in controlled environments.
- Investigate upstream service health and rate limits.
- Monitor network paths and consider CDN or load balancer issues.

**Section sources**
- [ai_agents_controller.rb:58-86](file://app/controllers/ai_agents_controller.rb#L58-L86)

### API Response Failures
Symptoms:
- Unexpected response bodies or non-JSON responses.
- Protocol mismatch between configured agent and endpoint.

Diagnostics:
- Compare configured protocol with actual endpoint behavior.
- Validate JSON payload structure and required fields.
- Inspect response body length and truncation behavior.

Resolution:
- Align protocol selection with the target API (/v1/chat/completions vs /v1/responses).
- Adjust model_name and payload fields according to the API specification.

**Section sources**
- [ai_agents_controller.rb:65-75](file://app/controllers/ai_agents_controller.rb#L65-L75)

### WebSocket Connection Problems (Kimi Web)
Common symptoms:
- Connection fails immediately or closes shortly after opening.
- No history_complete message received.
- JSON parse errors or unexpected messages.

Error codes and meanings:
- WebSocket close codes:
  - 4004: Session not found.
  - 4401: Authentication required.
  - 4403: Access denied or origin not allowed.
- JSON-RPC error codes:
  - -32700: Parse error.
  - -32600: Invalid request.
  - -32601: Method not found.
  - -32602: Invalid params.
  - -32603: Internal error.
  - -32000: Invalid state (session busy).
  - -32001: LLM not set.
  - -32002: LLM not supported.
  - -32003: Chat provider error.
  - -32004: Authentication expired.

Diagnostics:
- Confirm session_id validity and existence.
- Check token presence and correctness if required.
- Validate host/port and network accessibility.
- Review logs for on_error and on_close events.

Resolution:
- Ensure the Kimi Web service is running and reachable.
- Provide a valid token if required by the server.
- Retry with corrected session_id or re-create the session.

**Section sources**
- [api-reference.md:588-622](file://kimi-web/reference/api-reference.md#L588-L622)
- [kimi-web-ws.py:150-156](file://kimi-web/scripts/kimi-web-ws.py#L150-L156)
- [kimi-web-ws.py:138-140](file://kimi-web/scripts/kimi-web-ws.py#L138-L140)

### SSL Certificate Problems
Symptoms:
- HTTPS requests fail with certificate errors.
- Mixed content warnings or certificate chain issues.

Diagnostics:
- Verify server certificate chain and expiration.
- Check system CA store and environment proxy settings.
- Test with curl to reproduce and capture certificate details.

Resolution:
- Install or update CA certificates.
- Configure proxy with correct certificate authority if applicable.
- Use a trusted certificate authority or internal CA as appropriate.

**Section sources**
- [ai_agents_controller.rb:56-58](file://app/controllers/ai_agents_controller.rb#L56-L58)

### Proxy Configuration Errors
Symptoms:
- HTTP requests succeed locally but fail behind a corporate proxy.
- Timeouts or connection refused when proxy is misconfigured.

Diagnostics:
- Confirm proxy environment variables and credentials.
- Test direct connectivity versus proxied connectivity.
- Validate proxy ACLs and allowed destinations.

Resolution:
- Configure proxy settings correctly in the environment.
- Whitelist external API endpoints if required by the proxy policy.

**Section sources**
- [ai_agents_controller.rb:56-58](file://app/controllers/ai_agents_controller.rb#L56-L58)

### Testing Agent Endpoints
Manual verification steps:
- Health check:
  - GET /healthz on the configured endpoint with Authorization header if required.
- Minimal chat completion:
  - POST /v1/chat/completions with a small JSON payload containing model and a simple message.
- Responses API:
  - POST /v1/responses with model and input fields.

Use the test_connection action in the admin UI to automate these checks.

**Section sources**
- [ai_agents_controller.rb:50-92](file://app/controllers/ai_agents_controller.rb#L50-L92)
- [api-reference.md:341-346](file://kimi-web/reference/api-reference.md#L341-L346)

### Diagnosing Network Connectivity
Tools and techniques:
- curl: Test endpoints with verbose output to capture headers and response codes.
- openssl s_client: Verify TLS handshake and certificate chain for HTTPS endpoints.
- nslookup/dig: Validate DNS resolution for endpoint_url.
- tcping/ping: Measure latency and reachability to host:port.
- Wireshark/tcpdump: Capture and inspect traffic for deeper analysis.

**Section sources**
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)

## Conclusion
This guide consolidates practical strategies for diagnosing and resolving AI agent communication failures across HTTP and WebSocket channels. By leveraging the built-in test_connection action, understanding error codes, and applying the diagnostic techniques outlined above, administrators can quickly isolate and resolve issues related to connectivity, timeouts, SSL, proxies, and endpoint compatibility.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Configuration Options
- Plugin settings:
  - enabled: Toggle plugin functionality.
  - redmine_api_base_url: Base URL for Redmine API access.
  - default_timeout: Default timeout value used by the plugin.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

### Agent Form Fields and Protocols
- Agent type and protocol selection influence endpoint behavior.
- For kimi_web_ws protocol, session_id, work_dir, and timeout are required.

**Section sources**
- [_form.html.erb:1-111](file://app/views/ai_agents/_form.html.erb#L1-L111)
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)