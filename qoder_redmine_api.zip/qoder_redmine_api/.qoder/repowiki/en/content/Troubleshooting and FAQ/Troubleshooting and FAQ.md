# Troubleshooting and FAQ

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Security and Data Protection](#security-and-data-protection)
10. [Conclusion](#conclusion)
11. [Appendices](#appendices)

## Introduction
This document provides comprehensive troubleshooting and FAQ guidance for the Redmine AI Agent Plugin. It focuses on diagnosing and resolving common issues during plugin installation, configuration, agent connectivity, and dispatch processing. It also documents error semantics (including HTTP status codes, WebSocket errors, and API response failures), debugging strategies, performance tuning, and security considerations.

## Project Structure
The plugin extends Redmine via controllers, models, jobs, migrations, and client libraries. Key areas:
- Controllers: admin agent management and per-issue dispatch triggers
- Models: agent definitions, assignments, and dispatch records
- Jobs: asynchronous dispatch execution with retries and tool-loop support
- Clients: OpenAI-compatible and Kimi Web clients
- Routes: plugin-managed endpoints and nested issue dispatches
- Settings: global plugin settings and localization

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentsController"]
C2["AiAgentDispatchesController"]
end
subgraph "Models"
M1["AiAgent"]
M2["AiAgentAssignment"]
M3["AiAgentDispatch"]
end
subgraph "Jobs"
J1["AiAgentDispatchJob"]
end
subgraph "Clients"
L1["AgentClient"]
L2["KimiWebClient"]
end
subgraph "Config"
R1["Routes"]
S1["Settings UI"]
Y1["Locales en.yml"]
end
C1 --> M1
C2 --> M3
J1 --> M1
J1 --> M3
J1 --> L1
J1 --> L2
R1 --> C1
R1 --> C2
S1 --> Y1
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-25](file://app/models/ai_agent_assignment.rb#L1-L25)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:219-260](file://lib/redmine_ai_agent/agent_client.rb#L219-L260)
- [kimi_web_client.rb:1-420](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L420)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Core Components
- AiAgent: defines agent type, protocol, endpoint, model, and safety helpers; resolves system prompts with Redmine context
- AiAgentAssignment: maps users to active agents
- AiAgentDispatch: tracks dispatch lifecycle, payloads, and timing
- AiAgentsController: admin CRUD plus connectivity testing
- AiAgentDispatchesController: manual dispatch initiation from an issue
- AiAgentDispatchJob: async orchestration, tool-loop execution, journaling, and error handling
- AgentClient: OpenAI-compatible chat/completions and responses APIs
- KimiWebClient: WebSocket-driven Kimi Code CLI Web interface
- Settings UI and Locales: plugin configuration and user-facing messages

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-25](file://app/models/ai_agent_assignment.rb#L1-L25)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:219-260](file://lib/redmine_ai_agent/agent_client.rb#L219-L260)
- [kimi_web_client.rb:1-420](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L420)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Architecture Overview
End-to-end dispatch flow from UI to agent and back, including retries and tool-call loops.

```mermaid
sequenceDiagram
participant U as "User"
participant IC as "IssuesController"
participant DC as "AiAgentDispatchesController"
participant DJ as "AiAgentDispatchJob"
participant AC as "AgentClient/KimiWebClient"
participant Skill as "RedmineApiSkill"
participant DB as "Database"
U->>IC : "Open Issue"
IC->>DC : "POST /issues/ : id/ai_agent_dispatches"
DC->>DJ : "perform_later(issue_id, agent_id, user_id)"
DJ->>DB : "Create AiAgentDispatch (running)"
DJ->>AC : "call(issue, triggered_by)"
AC-->>DJ : "{request, raw_response, text}"
DJ->>Skill : "run_tool_loop() with tool_calls"
Skill-->>DJ : "tool results"
DJ->>AC : "post_to_agent(messages)"
AC-->>DJ : "final text"
DJ->>DB : "Update dispatch (done) + journal"
DJ-->>U : "Issue journal updated"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:219-260](file://lib/redmine_ai_agent/agent_client.rb#L219-L260)
- [kimi_web_client.rb:1-420](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L420)

## Detailed Component Analysis

### AiAgent Model and Validation
- Enforces agent_type, protocol, endpoint_url format, model_name (except Kimi WebSocket), and active flag
- Provides safe_api_key masking for logs
- Resolves system prompt with Redmine base URL, API key, issue/project IDs

```mermaid
classDiagram
class AiAgent {
+AGENTS_TYPES
+PROTOCOLS
+safe_api_key()
+chat_completions?()
+responses_api?()
+kimi_web_ws?()
+resolved_system_prompt(issue)
}
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent.rb:9-14](file://app/models/ai_agent.rb#L9-L14)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)

### AiAgentDispatch Job and Tool Loop
- Creates a running dispatch, posts a “started” journal note, calls the agent client, executes tool calls via RedmineApiSkill, and posts a “done” journal note
- Retries on AgentError with polynomial backoff
- Limits tool loop to 10 iterations and logs errors

```mermaid
flowchart TD
Start(["Job Start"]) --> CreateDispatch["Create Dispatch (running)"]
CreateDispatch --> PostStart["Post 'started' journal"]
PostStart --> CallAgent["Call AgentClient"]
CallAgent --> HasToolCalls{"Has tool_calls?"}
HasToolCalls -- "No" --> FinalText["Return final text"]
HasToolCalls -- "Yes" --> ExecuteTools["Execute tools via RedmineApiSkill"]
ExecuteTools --> AppendResults["Append tool results to messages"]
AppendResults --> CallAgent
FinalText --> UpdateDone["Update dispatch (done) + journal"]
UpdateDone --> End(["Job End"])
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### Agent Connectivity Testing
- For Kimi WebSocket agents: GET /healthz with Authorization header
- For OpenAI-compatible agents: minimal chat/completions or responses API ping with Authorization header
- Uses short timeouts and returns HTTP status and body snippet

```mermaid
sequenceDiagram
participant Admin as "Admin"
participant AC as "AiAgentsController"
participant HTTP as "Net : : HTTP"
Admin->>AC : "POST /ai_agents/ : id/test_connection"
alt "Kimi WebSocket"
AC->>HTTP : "GET /healthz (10s timeouts)"
HTTP-->>AC : "HTTP response"
else "OpenAI-compatible"
AC->>HTTP : "POST /v1/chat_completions or /v1/responses (10/15s)"
HTTP-->>AC : "HTTP response"
end
AC-->>Admin : "JSON {ok,status,body or error}"
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

**Section sources**
- [ai_agents_controller.rb:50-92](file://app/controllers/ai_agents_controller.rb#L50-L92)

### Kimi Web Client Protocol
- Uses REST for session creation/health and WebSocket JSON-RPC 2.0 for streaming
- Auto-approves tool and question requests to keep agent running
- Encodes/decodes WebSocket frames and handles masking

```mermaid
sequenceDiagram
participant Job as "AiAgentDispatchJob"
participant KWC as "KimiWebClient"
participant HTTP as "Net : : HTTP"
participant WS as "WebSocket"
Job->>KWC : "Initialize with agent"
KWC->>HTTP : "GET /healthz"
HTTP-->>KWC : "200 OK"
KWC->>WS : "Connect + Upgrade"
WS-->>KWC : "Session events"
KWC->>WS : "Send prompt"
loop "Events"
WS-->>KWC : "agent_text / agent_response / tool_call"
KWC->>WS : "Auto-approve requests"
end
KWC-->>Job : "Final text"
```

**Diagram sources**
- [kimi_web_client.rb:1-420](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L420)
- [ai_agent_dispatch_job.rb:37-39](file://app/jobs/ai_agent_dispatch_job.rb#L37-L39)

**Section sources**
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [kimi_web_client.rb:284-299](file://lib/redmine_ai_agent/kimi_web_client.rb#L284-L299)
- [kimi-web-ws.py:82-114](file://kimi-web/scripts/kimi-web-ws.py#L82-L114)

## Dependency Analysis
- Controllers depend on models and jobs
- Job orchestrates client libraries and database persistence
- Clients encapsulate protocol-specific logic and error translation
- Routes define entry points for admin and per-issue actions

```mermaid
graph LR
AC["AiAgentsController"] --> AM["AiAgent"]
ADiscC["AiAgentDispatchesController"] --> AD["AiAgentDispatch"]
ADiscC --> AJ["AiAgentDispatchJob"]
AJ --> ACli["AgentClient"]
AJ --> KCli["KimiWebClient"]
AJ --> AM
AJ --> AD
AM --> AA["AiAgentAssignment"]
AM --> AD
```

**Diagram sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-25](file://app/models/ai_agent_assignment.rb#L1-L25)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Performance Considerations
- Tune plugin-wide HTTP timeouts via settings to balance responsiveness and reliability
- Reduce tool-loop iterations or refine tool-call scope to minimize repeated API calls
- Monitor job queue backlog and scale workers for high dispatch volumes
- Prefer shorter system prompts and targeted models to reduce latency
- For Kimi WebSocket, adjust session reuse and work directory to avoid cold starts

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Installation and Setup
- Verify plugin registration and minimum Redmine version
- Confirm routes are loaded and admin menu entry appears
- Ensure plugin settings are visible under Administration > Settings

**Section sources**
- [init.rb:3-10](file://init.rb#L3-L10)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

### Configuration Errors
Common symptoms:
- Invalid endpoint URL format
- Missing model name for non-Kimi protocols
- Missing or invalid API key

Resolution steps:
- Validate endpoint_url format (http/https)
- Set model_name for chat_completions or responses protocols
- For Kimi WebSocket, confirm optional token usage and session/work dir settings

**Section sources**
- [ai_agent.rb:10-13](file://app/models/ai_agent.rb#L10-L13)
- [en.yml:54-67](file://config/locales/en.yml#L54-L67)

### Agent Connectivity Failures
Symptoms:
- Test connection returns non-success status
- Immediate timeout or JSON parse error
- Invalid endpoint URL reported

Debugging steps:
- Use the admin “Test Connection” action for the agent
- Check HTTP status codes and response bodies
- For OpenAI-compatible agents, verify Authorization header and endpoint paths
- For Kimi WebSocket, ensure /healthz responds and WebSocket is reachable

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:223-229](file://lib/redmine_ai_agent/agent_client.rb#L223-L229)

### Dispatch Processing Issues
Symptoms:
- Dispatch remains pending or transitions to error
- No journal updates appear
- Tool loop fails or exits early

Debugging steps:
- Inspect AiAgentDispatch records for status and payloads
- Review job logs for AgentError or unexpected errors
- Confirm user permissions to dispatch on the project
- Validate active agent assignment for the issue assignee

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

### WebSocket and Kimi Web Issues
Symptoms:
- Connection refused or read/write errors
- Session busy or timeout waiting for idle state
- Missing or malformed JSON-RPC events

Debugging steps:
- Confirm Kimi web server is running and accessible
- Verify Authorization token and session/work directory settings
- Check auto-approval of tool/question requests
- Monitor WebSocket frame encoding/decoding and masking

**Section sources**
- [kimi_web_client.rb:326-374](file://lib/redmine_ai_agent/kimi_web_client.rb#L326-L374)
- [kimi_web_client.rb:284-299](file://lib/redmine_ai_agent/kimi_web_client.rb#L284-L299)
- [kimi-web-ws.py:82-114](file://kimi-web/scripts/kimi-web-ws.py#L82-L114)

### Error Codes and Meanings
- HTTP status codes:
  - 200 OK: Successful agent response
  - Non-2xx: Endpoint unreachable, unauthorized, or rejected
- WebSocket errors:
  - Connection reset or read/write failures indicate network or server-side closure
  - JSON-RPC errors signal protocol mismatch or server-side faults
- API response failures:
  - Invalid JSON from agent indicates misconfiguration or incompatible endpoint
  - Missing tool_calls suggests model did not propose tools or tool loop exhausted

**Section sources**
- [ai_agents_controller.rb:88-91](file://app/controllers/ai_agents_controller.rb#L88-L91)
- [agent_client.rb:223-229](file://lib/redmine_ai_agent/agent_client.rb#L223-L229)
- [kimi_web_client.rb:276-278](file://lib/redmine_ai_agent/kimi_web_client.rb#L276-L278)

### Step-by-Step Resolution Guides

#### Problem: Cannot connect to agent endpoint
Steps:
1. Navigate to the agent’s “Test Connection”
2. Record HTTP status and body snippet
3. Verify endpoint URL scheme and path
4. Confirm Authorization header presence and correctness
5. Adjust timeouts in plugin settings if needed

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [en.yml:103-104](file://config/locales/en.yml#L103-L104)

#### Problem: Dispatch stuck in pending or error
Steps:
1. Check AiAgentDispatch status and timestamps
2. Review job logs for AgentError or unexpected exceptions
3. Verify active agent assignment for the assignee
4. Re-run dispatch manually from the issue page

**Section sources**
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)

#### Problem: Kimi WebSocket connection fails
Steps:
1. Ensure Kimi web server is started and listening
2. Confirm endpoint URL points to the web UI base
3. Verify optional token and session/work directory settings
4. Check auto-approval of requests and JSON-RPC event handling

**Section sources**
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [kimi_web_client.rb:284-299](file://lib/redmine_ai_agent/kimi_web_client.rb#L284-L299)
- [en.yml:63-67](file://config/locales/en.yml#L63-L67)

## Security and Data Protection
- API key masking: AiAgent.safe_api_key prevents plaintext exposure in logs and UI
- Authorization headers: Controllers and clients attach Authorization where applicable
- Local endpoints: For unauthenticated local agents, leave API key blank
- Tokenized access: Kimi WebSocket supports optional bearer token or query token

Best practices:
- Store API keys securely and limit scope to required endpoints
- Prefer HTTPS endpoints to protect in-transit data
- Restrict agent access to trusted endpoints only

**Section sources**
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agents_controller.rb:79-80](file://app/controllers/ai_agents_controller.rb#L79-L80)
- [kimi_web_client.rb:395-409](file://lib/redmine_ai_agent/kimi_web_client.rb#L395-L409)
- [en.yml:57-58](file://config/locales/en.yml#L57-L58)

## Conclusion
This guide consolidates actionable diagnostics and resolutions for the Redmine AI Agent Plugin. Use the provided sequences and flows to isolate issues quickly, apply the recommended performance and security practices, and leverage built-in tests and logging to maintain reliable agent dispatches.

## Appendices

### Database Schema Notes
- AiAgents table stores agent definitions and credentials
- AiAgentDispatches table persists dispatch lifecycle and payloads

**Section sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)