# Security Concerns

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document focuses on security-related troubleshooting for the Redmine AI Agent Plugin. It covers credential management, API exposure risks, and data protection concerns. It documents secure credential storage, API key rotation procedures, and access control validation. Guidance is provided for securing agent endpoints, protecting sensitive data transmission, and implementing proper authentication mechanisms. Best practices for plugin configuration, network communication security, and data privacy compliance are included.

## Project Structure
The plugin follows a typical Redmine plugin layout with controllers, models, jobs, and libraries. Key security-relevant areas include:
- Controllers enforcing permissions and validating requests
- Models storing agent configurations and masking credentials
- Jobs orchestrating agent calls and logging outcomes
- Clients handling HTTP/WebSocket connections and credential injection
- Settings and routes enabling admin configuration and dispatch endpoints

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentsController"]
C2["AiAgentAssignmentsController"]
C3["AiAgentDispatchesController"]
end
subgraph "Models"
M1["AiAgent"]
M2["AiAgentAssignment"]
M3["AiAgentDispatch"]
end
subgraph "Jobs"
J1["AiAgentDispatchJob"]
end
subgraph "Libraries"
L1["AgentClient"]
L2["KimiWebClient"]
end
subgraph "Config"
R1["Routes"]
S1["Settings"]
end
C1 --> M1
C2 --> M2
C3 --> M3
J1 --> M3
J1 --> L1
J1 --> L2
L1 --> M1
L2 --> M1
R1 --> C1
R1 --> C2
R1 --> C3
S1 --> M1
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:12-29](file://init.rb#L12-L29)

## Core Components
- AiAgent: Stores agent configuration, validates endpoint URLs, masks API keys in serialization, and resolves system prompts with Redmine base URL and user API key.
- AiAgentAssignment: Links users to agents and enforces uniqueness of user-to-agent assignments.
- AiAgentDispatch: Tracks dispatch lifecycle, stores request/response payloads, and computes durations.
- AiAgentDispatchJob: Orchestrates dispatch execution, posts journal notes, runs tool loops, and persists payloads.
- AgentClient: Builds payloads, sends HTTP requests to agent endpoints, injects Authorization headers, and parses responses.
- KimiWebClient: Manages session creation and WebSocket messaging for Kimi Web, handling token injection and timeouts.
- Controllers: Enforce admin-only access for agent management, enforce project-level permissions for dispatch, and validate inputs.
- Routes: Define admin endpoints for agents and per-issue dispatch endpoints.

Security-relevant highlights:
- Credential masking in AiAgent serialization
- Authorization header injection in HTTP requests
- Token handling in WebSocket upgrades
- Access control via before_actions and permissions
- Timeout configuration for outbound requests

**Section sources**
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:156-161](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L161)
- [ai_agents_controller.rb:21-47](file://app/controllers/ai_agents_controller.rb#L21-L47)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

## Architecture Overview
The plugin integrates with external AI endpoints and Redmine’s internal API. Dispatches originate from issue pages and are processed asynchronously. Credentials are injected into outbound requests, and payloads are persisted for auditability.

```mermaid
sequenceDiagram
participant User as "User"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Model as "AiAgent"
participant Client as "AgentClient/KimiWebClient"
participant Ext as "External AI Endpoint"
User->>Ctrl : "POST /issues/ : id/ai_agent_dispatches"
Ctrl->>Ctrl : "authorize_dispatch()"
Ctrl->>Job : "perform_later(issue_id, agent_id, user_id)"
Job->>Model : "load agent"
Job->>Client : "call(issue, triggered_by)"
Client->>Ext : "HTTP POST /v1/... (Authorization : Bearer ...)"
Ext-->>Client : "Response"
Client-->>Job : "Result"
Job->>Job : "persist request/response payloads"
Job-->>User : "journal notes posted"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:38-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L38-L58)

## Detailed Component Analysis

### Credential Management and Storage
- AiAgent stores api_key in cleartext in the database. While serialization masks the key for display, persistence remains a risk.
- AiAgent.safe_api_key returns a masked representation suitable for logs and UI.
- AgentClient and KimiWebClient inject the api_key into Authorization headers for external endpoints.
- KimiWebClient also supports token query parameter injection for session endpoints.

Security implications:
- Database backups and logs must restrict access to minimize exposure.
- Consider rotating keys and updating records promptly after compromise.

Mitigations:
- Prefer environment-backed secrets or Redmine’s encrypted settings if available.
- Limit database access to trusted administrators.
- Regularly review and rotate API keys.

**Section sources**
- [ai_agent.rb:8-11](file://app/models/ai_agent.rb#L8-L11)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:156-161](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L161)

### API Exposure Risks
- Admin endpoints under /ai_agents require admin privileges and permit api_key updates.
- Test connection endpoints call external services with Authorization headers, potentially exposing credentials in logs or responses.
- Per-issue dispatch endpoints are protected by project-level permissions but rely on current user context.

Recommendations:
- Restrict test_connection to internal networks or require explicit confirmation.
- Sanitize logs to avoid printing Authorization headers or API keys.
- Validate external endpoints and enforce HTTPS.

**Section sources**
- [ai_agents_controller.rb:21-47](file://app/controllers/ai_agents_controller.rb#L21-L47)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

### Access Control Validation
- AiAgentsController enforces admin-only access for CRUD operations.
- AiAgentDispatchesController enforces project-level permission :dispatch_ai_agent for manual dispatch.
- AiAgentAssignmentsController enforces admin-only access for assignment management.

Validation checks:
- Before actions ensure authenticated admin for agent management.
- Permission checks ensure only authorized users can trigger dispatches.

Recommendations:
- Verify that project-level permissions are enforced consistently across environments.
- Audit permission grants regularly.

**Section sources**
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_dispatches_controller.rb:3](file://app/controllers/ai_agent_dispatches_controller.rb#L3)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)

### Data Protection and Payload Persistence
- AiAgentDispatch persists request_payload and response_payload as JSON for auditing.
- Logging includes request details and sanitized response bodies.

Recommendations:
- Encrypt payloads at rest if compliance requires it.
- Apply log filtering to remove sensitive fields.
- Limit retention of payloads to operational needs.

**Section sources**
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent_dispatch_job.rb:42-47](file://app/jobs/ai_agent_dispatch_job.rb#L42-L47)

### Network Communication Security
- HTTP clients set use_ssl based on endpoint scheme.
- Timeouts configured for open/read operations.
- WebSocket client supports WSS and TLS handshakes.

Recommendations:
- Enforce HTTPS for all external endpoints.
- Configure strict SSL verification and certificate pinning where applicable.
- Monitor outbound connectivity and rate limits.

**Section sources**
- [agent_client.rb:205-209](file://lib/redmine_ai_agent/agent_client.rb#L205-L209)
- [kimi_web_client.rb:163-174](file://lib/redmine_ai_agent/kimi_web_client.rb#L163-L174)

### Authentication Mechanisms
- External endpoints use Authorization: Bearer <api_key>.
- Kimi Web endpoints optionally accept token via query parameter.
- Internal endpoints rely on Redmine’s built-in authentication and permissions.

Recommendations:
- Prefer short-lived tokens or API keys with minimal scope.
- Rotate keys periodically and invalidate old ones immediately.

**Section sources**
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:156-161](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L161)

### Secure Configuration Practices
- Plugin settings include enabled flag, redmine_api_base_url, and default_timeout.
- Ensure redmine_api_base_url matches the production Redmine instance and is not exposed publicly.

Recommendations:
- Store sensitive settings outside the repository.
- Use environment variables or Redmine’s encrypted settings if supported.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)

## Dependency Analysis
```mermaid
classDiagram
class AiAgent {
+safe_api_key()
+resolved_system_prompt(issue)
}
class AiAgentAssignment {
+for_user(user)
+agent_for(user)
}
class AiAgentDispatch {
+request_data()
+response_data()
}
class AiAgentDispatchJob {
+perform(...)
+run_tool_loop(...)
}
class AgentClient {
+call(issue, triggered_by)
+post_to_agent(payload)
}
class KimiWebClient {
+call(issue)
+websocket_prompt(...)
}
AiAgentDispatchJob --> AiAgent : "loads"
AiAgentDispatchJob --> AgentClient : "uses"
AiAgentDispatchJob --> KimiWebClient : "uses"
AgentClient --> AiAgent : "reads config"
KimiWebClient --> AiAgent : "reads config"
AiAgentAssignment --> AiAgent : "belongs to"
AiAgentAssignment --> User : "belongs to"
AiAgentDispatch --> AiAgent : "belongs to"
AiAgentDispatch --> Issue : "belongs to"
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:22-42](file://lib/redmine_ai_agent/agent_client.rb#L22-L42)
- [kimi_web_client.rb:31-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L58)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agent_assignment.rb:8-20](file://app/models/ai_agent_assignment.rb#L8-L20)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)

**Section sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:22-42](file://lib/redmine_ai_agent/agent_client.rb#L22-L42)
- [kimi_web_client.rb:31-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L58)

## Performance Considerations
- Timeouts for agent calls are configurable via plugin settings and defaults.
- Tool loop retries on transient errors with exponential backoff.
- Payload persistence adds I/O overhead; consider compression or offloading.

Recommendations:
- Tune default_timeout based on provider SLAs.
- Monitor job queue backlog and adjust concurrency.

**Section sources**
- [agent_client.rb:202-209](file://lib/redmine_ai_agent/agent_client.rb#L202-L209)
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)

## Troubleshooting Guide

### Credential Management Issues
Symptoms:
- API calls fail with unauthorized responses.
- Logs show Authorization header exposure.

Actions:
- Verify api_key is set for the agent and not blank.
- Confirm Authorization header is present in outbound requests.
- Rotate keys and update agent records immediately.

References:
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:156-161](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L161)

### API Exposure Risks
Symptoms:
- Test connection returns sensitive data or exposes credentials.

Actions:
- Review test_connection responses and sanitize logs.
- Restrict test endpoints to trusted networks.
- Ensure HTTPS is enforced for external endpoints.

References:
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

### Access Control Validation Failures
Symptoms:
- Unauthorized users trigger dispatches or manage agents.

Actions:
- Confirm admin-only routes are enforced.
- Verify project-level permissions for dispatch triggers.
- Audit permission grants and group memberships.

References:
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

### Data Protection Concerns
Symptoms:
- Sensitive payloads stored without encryption.
- Logs contain API keys or tokens.

Actions:
- Encrypt payloads at rest if required by policy.
- Filter logs to exclude Authorization headers and tokens.
- Limit payload retention periods.

References:
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent_dispatch_job.rb:42-47](file://app/jobs/ai_agent_dispatch_job.rb#L42-L47)

### Network Communication Security
Symptoms:
- SSL/TLS handshake failures or timeouts.
- Untrusted certificates cause rejections.

Actions:
- Enforce HTTPS for all endpoints.
- Configure strict SSL verification.
- Adjust timeouts for provider latency.

References:
- [agent_client.rb:205-209](file://lib/redmine_ai_agent/agent_client.rb#L205-L209)
- [kimi_web_client.rb:163-174](file://lib/redmine_ai_agent/kimi_web_client.rb#L163-L174)

### Authentication Mechanisms
Symptoms:
- External endpoints reject Authorization headers.
- Kimi Web sessions fail with token errors.

Actions:
- Validate Authorization scheme and token format.
- For Kimi Web, confirm token query parameter or Authorization header usage.
- Rotate tokens and update agent configurations.

References:
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)
- [kimi_web_client.rb:156-161](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L161)

## Conclusion
The plugin implements essential security controls such as admin-only management routes, project-level dispatch permissions, credential masking, and outbound request timeouts. However, persistent cleartext API keys and potential exposure in logs and test endpoints require immediate remediation. Strengthening transport security, adopting secret management, and enforcing stricter logging policies will significantly reduce risk.

## Appendices

### API Key Rotation Procedures
Steps:
- Generate a new API key in the external service.
- Update the AiAgent record with the new key.
- Test the connection to ensure successful authentication.
- Remove or invalidate the old key in the external service.
- Audit logs and payloads for traces of the old key.

References:
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)

### Access Control Validation Checklist
- Admin routes are protected by require_admin.
- Dispatch routes check :dispatch_ai_agent permission.
- Assignment routes are admin-only.
- Project membership and permissions are verified before dispatch.

References:
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)

### Secure Configuration Checklist
- redmine_api_base_url points to the production Redmine instance.
- default_timeout is set appropriately for provider SLAs.
- HTTPS is enforced for external endpoints.
- Logs are filtered to avoid credential exposure.

References:
- [init.rb:12-16](file://init.rb#L12-L16)
- [agent_client.rb:202-209](file://lib/redmine_ai_agent/agent_client.rb#L202-L209)