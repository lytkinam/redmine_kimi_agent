# Installation Issues

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [lib/redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [config/routes.rb](file://config/routes.rb)
- [config/locales/en.yml](file://config/locales/en.yml)
- [app/views/settings/_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [db/migrate/001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [db/migrate/002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [db/migrate/003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [db/migrate/004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [app/controllers/ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [app/models/ai_agent.rb](file://app/models/ai_agent.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document provides a comprehensive troubleshooting guide for installing and activating the Redmine AI Agent plugin. It focuses on common installation failures such as plugin loading errors, missing dependencies, and compatibility issues with Redmine versions. It also covers step-by-step solutions for activation problems, route conflicts, configuration file errors, and verification steps to confirm successful installation and initial setup.

## Project Structure
The plugin follows a standard Redmine plugin layout with Ruby on Rails MVC components, database migrations, and i18n localization. Key areas relevant to installation and activation include:
- Plugin registration and settings definition
- Routes for admin and per-issue dispatch
- Models and migrations for agents, assignments, and dispatches
- Settings UI partial and localization keys
- Controller actions for testing connections

```mermaid
graph TB
A["init.rb<br/>Plugin registration and settings"] --> B["config/routes.rb<br/>Admin and dispatch routes"]
A --> C["app/views/settings/_ai_agent_settings.html.erb<br/>Settings UI"]
A --> D["config/locales/en.yml<br/>Localization keys"]
B --> E["app/controllers/ai_agents_controller.rb<br/>Agent CRUD and test_connection"]
F["app/models/ai_agent.rb<br/>Agent validations and helpers"] --> E
G["db/migrate/*.rb<br/>Schema migrations"] --> F
H["lib/redmine_ai_agent.rb<br/>Module loader and hooks"] --> A
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [config/routes.rb:1-17](file://config/routes.rb#L1-L17)
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [app/controllers/ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [app/models/ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [db/migrate/001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [db/migrate/002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [db/migrate/003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [db/migrate/004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)
- [lib/redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [config/routes.rb:1-17](file://config/routes.rb#L1-L17)
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [app/controllers/ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [app/models/ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [db/migrate/001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [db/migrate/002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [db/migrate/003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [db/migrate/004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)
- [lib/redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Core Components
- Plugin registration and settings: Declares plugin metadata, minimum Redmine version, default settings, admin menu entry, and permissions.
- Routes: Defines admin endpoints for agents and assignments, and per-issue dispatch routes.
- Models and migrations: Define agent records, assignments, dispatches, and optional Kimi Web fields.
- Settings UI and localization: Provides enable/disable toggle, base URL, and default timeout configuration.
- Controller connection tests: Validates agent connectivity for both standard and Kimi Web protocols.

Key installation-related checks:
- Redmine version requirement must be satisfied.
- Routes must be loaded without conflicts.
- Migrations must apply cleanly.
- Settings must be saved and accessible.

**Section sources**
- [init.rb:3-30](file://init.rb#L3-L30)
- [config/routes.rb:1-17](file://config/routes.rb#L1-L17)
- [db/migrate/001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [db/migrate/002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [db/migrate/003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [db/migrate/004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:99-104](file://config/locales/en.yml#L99-L104)
- [app/controllers/ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

## Architecture Overview
The plugin integrates with Redmine through:
- Plugin registration and settings initialization
- Route registration under the Redmine application
- Model-backed storage with foreign keys and indexes
- Controller actions for admin and dispatch workflows
- Localization and settings UI partial

```mermaid
graph TB
subgraph "Redmine Host"
RApp["RedmineApp::Application"]
RRoutes["Redmine routing"]
end
subgraph "Plugin"
Init["init.rb"]
Routes["config/routes.rb"]
Models["Models and Migrations"]
Views["Settings UI Partial"]
Locales["config/locales/en.yml"]
Controllers["Controllers"]
end
RApp --> RRoutes
Init --> RApp
Init --> Routes
Init --> Views
Init --> Locales
Routes --> Controllers
Controllers --> Models
Models --> |DB| RApp
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [config/routes.rb:1-17](file://config/routes.rb#L1-L17)
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [app/controllers/ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [app/models/ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

## Detailed Component Analysis

### Plugin Registration and Settings
- Declares plugin identity, description, version, and required Redmine version.
- Registers default settings including enable flag, base URL, and default timeout.
- Adds an admin menu entry and project-level permissions for managing agents and dispatches.

Common installation issues:
- Version mismatch: If the host Redmine version is lower than required, the plugin will not load.
- Settings not persisted: Ensure the settings partial renders and saves correctly.

Verification steps:
- Confirm the plugin appears in the admin menu.
- Verify settings are editable and saved.

**Section sources**
- [init.rb:3-30](file://init.rb#L3-L30)
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:99-104](file://config/locales/en.yml#L99-L104)

### Routes and Permissions
- Admin routes for agents and assignments.
- Per-issue routes for dispatch creation, listing, and viewing.
- Member route for testing agent connections.

Common issues:
- Route conflicts: Another plugin or custom route may conflict with agent or dispatch endpoints.
- Missing permissions: Without proper permissions, users cannot access agent management or dispatch features.

Verification steps:
- Visit admin endpoints and per-issue dispatch URLs.
- Confirm the “Test Connection” action responds.

**Section sources**
- [config/routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:18-29](file://init.rb#L18-L29)
- [app/controllers/ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

### Models and Migrations
- AiAgent: Validates type, protocol, endpoint URL, and model name; supports agent-specific system prompts and Kimi Web flags.
- AiAgentAssignment: Links users to agents with optional auto-dispatch.
- AiAgentDispatch: Tracks dispatch requests, responses, status, and timing.
- Migrations define schema, indexes, and foreign keys; optional Kimi Web columns added later.

Common issues:
- Migration failures: Index or foreign key constraints failing during apply.
- Schema mismatch: Missing columns for Kimi Web features if the latest migration was not applied.

Verification steps:
- Run migrations and confirm tables exist with expected columns.
- Check indexes and foreign keys are present.

**Section sources**
- [app/models/ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [db/migrate/001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [db/migrate/002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [db/migrate/003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [db/migrate/004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

### Settings UI and Localization
- Settings partial renders enable flag, base URL field, and default timeout.
- Localization keys support labels, hints, and UI text for agent configuration.

Common issues:
- Missing translation keys: If keys are absent, labels may not render properly.
- Incorrect field names: Ensure tag names match expected settings keys.

Verification steps:
- Open plugin settings and confirm fields are visible and editable.
- Save settings and verify persistence.

**Section sources**
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:99-104](file://config/locales/en.yml#L99-L104)

### Controller Connection Tests
- The test_connection action supports two protocols:
  - Kimi Web WebSocket health check via a dedicated endpoint.
  - Standard OpenAI-compatible chat completions or responses API ping.

Common issues:
- Network timeouts or SSL misconfiguration.
- Incorrect endpoint URL or missing API key for protected endpoints.
- Protocol mismatch causing unexpected request shapes.

Verification steps:
- Use the “Test Connection” action for each agent to validate connectivity.
- Review returned status and error messages.

**Section sources**
- [app/controllers/ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

## Dependency Analysis
The plugin depends on:
- Redmine version compatibility as declared in plugin registration.
- Rails routing and controller infrastructure.
- Database schema defined by migrations.
- Localization keys and settings UI partial.

Potential dependency conflicts:
- Another plugin registering conflicting routes.
- Missing or outdated migrations preventing model operations.

```mermaid
graph LR
Redmine["Redmine Host"] --> Init["init.rb"]
Init --> Routes["routes.rb"]
Init --> SettingsUI["settings/_ai_agent_settings.html.erb"]
Init --> Locales["locales/en.yml"]
Routes --> Controllers["ai_agents_controller.rb"]
Controllers --> Models["ai_agent.rb"]
Models --> DB["Database Schema"]
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [config/routes.rb:1-17](file://config/routes.rb#L1-L17)
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [app/controllers/ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [app/models/ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [init.rb:10](file://init.rb#L10)
- [config/routes.rb:1-17](file://config/routes.rb#L1-L17)
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [app/controllers/ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [app/models/ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

## Performance Considerations
- HTTP timeouts for agent connections are intentionally short for responsiveness.
- Kimi Web WebSocket mode may require tuning of the session timeout based on workload.
- Ensure indexes exist on frequently queried columns (status, issue_id, ai_agent_id) to optimize dispatch queries.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### 1) Plugin Loading Errors
Symptoms:
- Plugin does not appear in admin menu.
- Redmine logs show load failures.

Steps:
- Verify the plugin’s required Redmine version meets your host version.
- Confirm the plugin directory structure and file names are correct.
- Check that the plugin registration file is present and free of syntax errors.

Verification:
- Restart Redmine and confirm the plugin loads without errors.
- Navigate to the plugin settings page.

**Section sources**
- [init.rb:10](file://init.rb#L10)
- [init.rb:3-30](file://init.rb#L3-L30)

### 2) Missing Dependencies
Symptoms:
- Runtime errors referencing undefined constants or missing libraries.
- Load errors for module files.

Steps:
- Ensure all Ruby dependencies required by the plugin are installed.
- Confirm the module loader file exists and references existing submodules.

Verification:
- Confirm the module loader registers subcomponents without errors.
- Test basic controller actions after restart.

**Section sources**
- [lib/redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

### 3) Compatibility Issues with Redmine Versions
Symptoms:
- Plugin fails to register or routes are not recognized.
- Migrations fail due to unsupported Rails version features.

Steps:
- Align the plugin’s required Redmine version with your host version.
- Apply migrations in order and verify schema matches expectations.

Verification:
- Confirm migrations complete successfully.
- Validate routes and controllers operate normally.

**Section sources**
- [init.rb:10](file://init.rb#L10)
- [db/migrate/001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [db/migrate/002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [db/migrate/003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [db/migrate/004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

### 4) Plugin Activation Problems
Symptoms:
- Settings UI not visible or save fails.
- Admin menu entry missing.

Steps:
- Confirm the settings partial renders and is registered in plugin settings.
- Verify localization keys exist and are correctly named.
- Save settings and confirm persistence.

Verification:
- Open plugin settings and adjust enable flag and base URL.
- Save and reload the page to confirm changes.

**Section sources**
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:99-104](file://config/locales/en.yml#L99-L104)
- [init.rb:12-16](file://init.rb#L12-L16)

### 5) Route Conflicts
Symptoms:
- 404 or routing errors when accessing admin or dispatch endpoints.
- Conflicts reported by Redmine router.

Steps:
- Inspect routes for conflicts with other plugins or custom routes.
- Remove or rename conflicting routes.
- Ensure plugin routes are registered last to avoid shadowing.

Verification:
- Visit admin endpoints and per-issue dispatch URLs.
- Confirm “Test Connection” action responds without routing errors.

**Section sources**
- [config/routes.rb:1-17](file://config/routes.rb#L1-L17)
- [app/controllers/ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

### 6) Configuration File Errors
Symptoms:
- Missing labels or hints in settings UI.
- Incorrect field names causing save failures.

Steps:
- Validate localization keys match the expected keys in the settings partial.
- Ensure tag names and IDs align with the settings structure.

Verification:
- Open plugin settings and confirm all labels and hints render.
- Save settings and verify persistence.

**Section sources**
- [app/views/settings/_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [config/locales/en.yml:99-104](file://config/locales/en.yml#L99-L104)

### 7) Verification Steps for Successful Installation
- Confirm plugin appears in admin menu and settings are editable.
- Apply migrations and verify tables and indexes exist.
- Test agent connectivity using the “Test Connection” action.
- Manually dispatch an issue and verify journal entries.

**Section sources**
- [init.rb:18-29](file://init.rb#L18-L29)
- [db/migrate/001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [db/migrate/002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [db/migrate/003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [app/controllers/ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

### 8) Resolving Gem Dependency Conflicts
Symptoms:
- Bundler or runtime errors indicating missing or conflicting gems.
- Plugin fails to load due to unresolved dependencies.

Steps:
- Identify conflicting gems and versions.
- Align gem versions with Redmine and plugin requirements.
- Use a clean bundle install and restart Redmine.

[No sources needed since this section provides general guidance]

### 9) Environment-Specific Installation Challenges
Symptoms:
- SSL/TLS handshake failures for external endpoints.
- Local network restrictions blocking agent endpoints.
- Timeouts for Kimi Web WebSocket connections.

Steps:
- Configure proxy or SSL settings according to your environment.
- Adjust timeouts and base URL settings for local endpoints.
- For Kimi Web, ensure the web service is reachable and the session timeout is sufficient.

Verification:
- Use “Test Connection” to validate endpoint accessibility.
- Monitor logs for network-related errors.

**Section sources**
- [app/controllers/ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [app/models/ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)

## Conclusion
By following this troubleshooting guide, you can diagnose and resolve most installation issues for the Redmine AI Agent plugin. Focus on verifying Redmine version compatibility, applying migrations, ensuring routes and settings are correctly configured, and validating agent connectivity. Use the provided verification steps to confirm successful installation and initial setup.