# Configuration Errors

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [routes.rb](file://config/routes.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document provides a comprehensive troubleshooting guide for AI agent configuration problems in the Redmine AI Agent plugin. It focuses on diagnosing and resolving common configuration errors such as invalid API keys, incorrect endpoint URLs, missing system prompts, agent type mismatches, protocol selection issues, and parameter validation failures. It also documents plugin settings validation, configuration syntax errors, and offers step-by-step resolution procedures for credential and endpoint misconfigurations. Finally, it describes configuration verification procedures and testing methods to validate agent settings end-to-end.

## Project Structure
The plugin integrates with Redmine’s admin UI and background job system to manage AI agents, assign them to users, and dispatch them to work on issues. Key areas involved in configuration and validation include:
- Plugin registration and default settings
- Agent model validations and defaults
- Admin UI forms and settings partial
- Routes exposing test_connection action
- Controllers implementing validation and connection tests
- Jobs orchestrating dispatch and error handling
- Migrations defining persistent agent attributes

```mermaid
graph TB
subgraph "Plugin Settings"
S1["Settings Partial<br/>_ai_agent_settings.html.erb"]
S2["Plugin Registration<br/>init.rb"]
end
subgraph "Models"
M1["AiAgent<br/>ai_agent.rb"]
M2["AiAgentAssignment<br/>ai_agent_assignment.rb"]
M3["AiAgentDispatch<br/>ai_agent_dispatch.rb"]
end
subgraph "Controllers"
C1["AiAgentsController<br/>ai_agents_controller.rb"]
C2["AiAgentDispatchesController<br/>ai_agent_dispatches_controller.rb"]
end
subgraph "Jobs"
J1["AiAgentDispatchJob<br/>ai_agent_dispatch_job.rb"]
end
subgraph "Routes"
R1["Routes<br/>routes.rb"]
end
subgraph "Migrations"
D1["CreateAiAgents<br/>001_create_ai_agents.rb"]
end
S2 --> S1
R1 --> C1
R1 --> C2
C1 --> M1
C2 --> M2
J1 --> M1
J1 --> M3
M1 --> M2
D1 --> M1
```

**Diagram sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

## Core Components
- Plugin settings: The plugin registers default settings including enabling/disabling the plugin, the Redmine API base URL, and a default timeout. These settings are surfaced in the admin settings UI.
- Agent model: Validates agent type, protocol, endpoint URL, model name, and presence of system prompt when applicable. It also exposes helpers to select agent type and protocol variants and resolves a system prompt template per agent type.
- Admin UI: Provides forms to create/update agents and a settings partial to configure the plugin-level base URL and timeout.
- Routes: Exposes a test_connection action on the AiAgents resource for validating agent connectivity.
- Controllers: Implement creation, editing, and connection testing. The test_connection action performs protocol-aware connectivity checks.
- Jobs: Orchestrates dispatch, retries transient errors, runs a tool-call loop, posts journal notes, and persists request/response payloads.
- Migrations: Define the schema for the ai_agents table and indexes.

Key validation and defaults:
- Agent type must be one of supported values.
- Protocol must be one of supported values.
- Endpoint URL must be present and a valid http/https URL.
- Model name is required except for the Kimi web socket protocol variant.
- Default values for new agents are set in the controller new action.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:11-30](file://app/views/settings/_ai_agent_settings.html.erb#L11-L30)
- [ai_agent.rb:2-15](file://app/models/ai_agent.rb#L2-L15)
- [ai_agent.rb:103-153](file://app/models/ai_agent.rb#L103-L153)
- [ai_agents_controller.rb:12-18](file://app/controllers/ai_agents_controller.rb#L12-L18)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)
- [001_create_ai_agents.rb:3-13](file://db/migrate/001_create_ai_agents.rb#L3-L13)

## Architecture Overview
The configuration lifecycle spans UI entry, server-side validation, and runtime dispatch with retry and error logging.

```mermaid
sequenceDiagram
participant Admin as "Admin User"
participant UI as "Admin UI"
participant Ctrl as "AiAgentsController"
participant Model as "AiAgent"
participant Job as "AiAgentDispatchJob"
participant AgentClient as "AgentClient"
participant Skill as "RedmineApiSkill"
Admin->>UI : "Open AI Agents page"
UI->>Ctrl : "POST /ai_agents/ : id/test_connection"
Ctrl->>Model : "Load agent"
alt "Kimi web WS"
Ctrl->>Ctrl : "GET /healthz with Authorization"
else "Standard OpenAI-compatible"
Ctrl->>Ctrl : "POST /v1/chat/completions or /v1/responses"
end
Ctrl-->>UI : "JSON {ok,status,body/error}"
Admin->>UI : "Create/Edit Agent"
UI->>Ctrl : "POST/PUT with agent params"
Ctrl->>Model : "Save with validations"
Model-->>Ctrl : "Valid/Invalid"
Ctrl-->>UI : "Render form with errors or redirect"
Admin->>UI : "Manual dispatch from Issue"
UI->>Ctrl : "POST /issues/ : id/ai_agent_dispatches"
Ctrl->>Job : "Enqueue dispatch"
Job->>AgentClient : "call(issue, triggered_by)"
AgentClient->>Skill : "Execute tool calls"
AgentClient-->>Job : "Result"
Job-->>UI : "Journal notes and persisted payloads"
```

**Diagram sources**
- [routes.rb:3-6](file://config/routes.rb#L3-L6)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent.rb:103-153](file://app/models/ai_agent.rb#L103-L153)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:37-67](file://app/jobs/ai_agent_dispatch_job.rb#L37-L67)

## Detailed Component Analysis

### Agent Model Validation and Defaults
- Agent types and protocols are constrained to predefined lists.
- Endpoint URL must be present and match http/https scheme.
- Model name is required unless using the Kimi web socket protocol.
- Safe API key masking is provided for serialization/logging safety.
- System prompt resolution substitutes placeholders with runtime values from plugin settings and issue context.

```mermaid
classDiagram
class AiAgent {
+string name
+string agent_type
+string endpoint_url
+string protocol
+string api_key
+string model_name
+text system_prompt
+boolean active
+safe_api_key() string
+chat_completions?() bool
+responses_api?() bool
+hermes?() bool
+pi?() bool
+qoder?() bool
+kimi_web?() bool
+kimi_web_ws?() bool
+resolved_system_prompt(issue) string
}
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent.rb:2-15](file://app/models/ai_agent.rb#L2-L15)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agent.rb:103-153](file://app/models/ai_agent.rb#L103-L153)

### Plugin Settings and Admin UI
- Plugin default settings include enabled flag, Redmine API base URL, and default timeout.
- The settings partial renders fields for enabling the plugin, setting the base URL, and configuring the default timeout.
- The base URL is used to resolve system prompts at runtime.

```mermaid
flowchart TD
Start(["Admin Settings"]) --> Enabled["Toggle Plugin Enabled"]
Enabled --> BaseURL["Set Redmine API Base URL"]
BaseURL --> Timeout["Set Default Timeout (seconds)"]
Timeout --> Save["Save Settings"]
Save --> End(["Effective for System Prompt Resolution"])
```

**Diagram sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

### Routes and Test Connection Action
- Routes define the test_connection member action for agents.
- The action performs protocol-aware connectivity checks:
  - For Kimi web WebSocket protocol, it hits a health endpoint with optional bearer token.
  - For standard OpenAI-compatible protocols, it sends a small chat or responses request with Authorization header.

```mermaid
sequenceDiagram
participant Client as "Admin Browser"
participant Routes as "Rails Routes"
participant Ctrl as "AiAgentsController"
participant HTTP as "Net : : HTTP"
Client->>Routes : "POST /ai_agents/ : id/test_connection"
Routes->>Ctrl : "test_connection"
alt "Kimi web WS"
Ctrl->>HTTP : "GET /healthz with Authorization"
else "Chat Completions"
Ctrl->>HTTP : "POST /v1/chat/completions"
else "Responses"
Ctrl->>HTTP : "POST /v1/responses"
end
HTTP-->>Ctrl : "Response"
Ctrl-->>Client : "JSON {ok,status,body/error}"
```

**Diagram sources**
- [routes.rb:3-6](file://config/routes.rb#L3-L6)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

**Section sources**
- [routes.rb:3-6](file://config/routes.rb#L3-L6)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

### Dispatch Flow and Tool Loop
- Manual dispatch triggers a background job that:
  - Creates a dispatch record
  - Posts a “task sent” journal note
  - Calls the agent client
  - Runs a tool-call loop using the Redmine API skill
  - Persists request/response payloads
  - Posts a “task completed” journal note
- Errors are logged, marked on the dispatch, and retried automatically for transient errors.

```mermaid
flowchart TD
A["Issue Page"] --> B["POST /issues/:id/ai_agent_dispatches"]
B --> C["AiAgentDispatchesController#create"]
C --> D["Find active agent assignment"]
D --> E["Enqueue AiAgentDispatchJob"]
E --> F["Create dispatch record"]
F --> G["Post 'task sent' journal"]
G --> H["AgentClient.call(...)"]
H --> I{"Tool calls?"}
I -- "Yes" --> J["Run tool loop with RedmineApiSkill"]
J --> H
I -- "No" --> K["Persist payloads and post 'task done' journal"]
K --> L["Done"]
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

## Dependency Analysis
- AiAgent depends on plugin settings for base URL substitution in system prompts.
- AiAgentsController depends on AiAgent model validations and routes for test_connection.
- AiAgentDispatchesController depends on AiAgentAssignment to find active agents for users.
- AiAgentDispatchJob depends on AgentClient and RedmineApiSkill to execute tool loops and persist payloads.
- Routes connect UI actions to controllers.

```mermaid
graph LR
Init["init.rb"] --> Settings["_ai_agent_settings.html.erb"]
Routes["routes.rb"] --> CtrlA["ai_agents_controller.rb"]
Routes --> CtrlD["ai_agent_dispatches_controller.rb"]
CtrlA --> Model["ai_agent.rb"]
CtrlD --> Assign["ai_agent_assignment.rb"]
Job["ai_agent_dispatch_job.rb"] --> Model
Job --> Dispatch["ai_agent_dispatch.rb"]
Model --> DB["001_create_ai_agents.rb"]
```

**Diagram sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

## Performance Considerations
- The test_connection action sets explicit open/read timeouts for outbound HTTP requests to avoid hanging connections.
- The dispatch job retries transient errors with exponential backoff to improve resilience.
- Payloads are persisted as JSON for later inspection; ensure storage capacity aligns with expected throughput.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### 1) Invalid API Keys
Symptoms:
- Authentication failures during test_connection or dispatch.
- Error responses indicating invalid or missing credentials.

Resolution steps:
- Verify the API key field is filled for agents that require Authorization.
- Confirm the key matches the provider’s expectations and has permissions for the configured endpoint.
- Use the test_connection action to validate connectivity; it includes Authorization headers when present.
- Review the dispatch logs for error payloads and journal notes posted to the issue.

Verification procedure:
- Run test_connection after saving the agent with the API key.
- Check the returned status and body for authentication-related errors.
- Inspect the dispatch record for persisted error payload.

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)

### 2) Incorrect Endpoint URLs
Symptoms:
- Network timeouts or connection refused during test_connection.
- Protocol mismatch leading to unexpected endpoint paths.

Resolution steps:
- Ensure endpoint_url is a valid http/https URL and matches the provider’s documented base URL.
- For standard OpenAI-compatible agents, the controller constructs /v1/chat/completions or /v1/responses based on protocol.
- For Kimi web WebSocket protocol, the controller calls /healthz.
- Remove trailing slashes in the base URL and rely on controller normalization.

Verification procedure:
- Use test_connection to confirm the constructed endpoint responds.
- For Kimi web, expect a successful health check; for others, expect a minimal success response to the chat/responses endpoint.

**Section sources**
- [ai_agent.rb:11](file://app/models/ai_agent.rb#L11)
- [ai_agents_controller.rb:51-75](file://app/controllers/ai_agents_controller.rb#L51-L75)
- [ai_agents_controller.rb:52-62](file://app/controllers/ai_agents_controller.rb#L52-L62)

### 3) Missing System Prompts
Symptoms:
- Agent behavior may fall back to a generic template if a custom system prompt is not provided.
- Placeholder substitutions might be incomplete if plugin base URL is not set.

Resolution steps:
- If a custom system prompt is not provided, the agent resolves a built-in template based on agent_type.
- Ensure the plugin-level redmine_api_base_url is set in Admin Settings to enable proper placeholder substitution.
- Customize the system prompt per agent if needed.

Verification procedure:
- Confirm plugin settings include the base URL.
- Review the resolved system prompt generated by the agent’s resolved_system_prompt method.

**Section sources**
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [_ai_agent_settings.html.erb:11-20](file://app/views/settings/_ai_agent_settings.html.erb#L11-L20)
- [init.rb:12-16](file://init.rb#L12-L16)

### 4) Agent Type Mismatches
Symptoms:
- Validation errors when selecting unsupported agent types.
- Unexpected protocol choices for certain agent types.

Resolution steps:
- Choose agent_type from the supported list; the model enforces inclusion.
- When selecting kimi_web as agent_type, the protocol is automatically set to kimi_web_ws.
- For other agent types, choose a compatible protocol from the supported list.

Verification procedure:
- Attempt to save an agent with an unsupported type; validation will fail.
- Observe automatic protocol adjustment when choosing kimi_web.

**Section sources**
- [ai_agent.rb:2-15](file://app/models/ai_agent.rb#L2-L15)
- [ai_agent.rb:44-50](file://app/models/ai_agent.rb#L44-L50)
- [ai_agents_controller.rb:12-18](file://app/controllers/ai_agents_controller.rb#L12-L18)

### 5) Protocol Selection Problems
Symptoms:
- Chat completions vs responses endpoint mismatch.
- Kimi web WebSocket protocol not working as expected.

Resolution steps:
- For standard OpenAI-compatible providers, choose chat_completions or responses depending on provider support.
- For Kimi web, select kimi_web_ws protocol; the controller uses a dedicated health endpoint.
- Ensure Authorization header is included when required by the provider.

Verification procedure:
- Use test_connection to validate the selected protocol path.
- For Kimi web, verify /healthz responds successfully.

**Section sources**
- [ai_agent.rb:3-4](file://app/models/ai_agent.rb#L3-L4)
- [ai_agent.rb:48-50](file://app/models/ai_agent.rb#L48-L50)
- [ai_agents_controller.rb:64-92](file://app/controllers/ai_agents_controller.rb#L64-L92)

### 6) Parameter Validation Failures
Common causes:
- Missing model_name for non-Kimi-web protocols.
- Invalid endpoint URL format.
- Duplicate or missing agent name.

Resolution steps:
- Provide model_name for chat_completions or responses protocols.
- Ensure endpoint_url uses http or https scheme.
- Keep agent names unique and non-blank.

Verification procedure:
- Attempt to save the agent; validation errors will be shown on the form.
- Fix fields highlighted by validation and re-save.

**Section sources**
- [ai_agent.rb:13](file://app/models/ai_agent.rb#L13)
- [ai_agent.rb:11](file://app/models/ai_agent.rb#L11)
- [ai_agent.rb:9](file://app/models/ai_agent.rb#L9)

### 7) Configuration Verification Procedures
Recommended steps:
- Set plugin base URL in Admin Settings.
- Create or edit an agent with correct type, protocol, endpoint, and model name.
- Run test_connection to validate connectivity.
- Manually dispatch from an issue page to exercise the tool loop and journal posting.
- Inspect dispatch records for status, durations, and persisted payloads.

Testing methods:
- Use the test_connection action to validate endpoints and credentials.
- Trigger manual dispatch to exercise the full pipeline including tool calls.
- Review job logs for transient error retries and final outcomes.

**Section sources**
- [_ai_agent_settings.html.erb:11-20](file://app/views/settings/_ai_agent_settings.html.erb#L11-L20)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

### 8) Credential Issues (Step-by-step)
- Step 1: Fill the API key in the agent form.
- Step 2: Run test_connection; observe the returned status and body.
- Step 3: If authentication fails, re-check the key and provider requirements.
- Step 4: Re-run test_connection to confirm fix.
- Step 5: Proceed with manual dispatch to validate end-to-end operation.

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

### 9) Endpoint Misconfigurations (Step-by-step)
- Step 1: Confirm endpoint_url uses http or https.
- Step 2: Ensure the base URL matches the provider’s documented host and scheme.
- Step 3: Remove trailing slash and rely on controller normalization.
- Step 4: Run test_connection to validate the constructed endpoint.
- Step 5: Adjust URL if the response indicates a wrong path or authentication failure.

**Section sources**
- [ai_agent.rb:11](file://app/models/ai_agent.rb#L11)
- [ai_agents_controller.rb:51-75](file://app/controllers/ai_agents_controller.rb#L51-L75)

### 10) Protocol Selection Problems (Step-by-step)
- Step 1: Select agent_type; if kimi_web, protocol auto-sets to kimi_web_ws.
- Step 2: For other types, choose chat_completions or responses based on provider support.
- Step 3: Run test_connection to validate the chosen protocol path.
- Step 4: If failing, switch to the other protocol and re-test.
- Step 5: Confirm Authorization header usage if required by the provider.

**Section sources**
- [ai_agent.rb:44-50](file://app/models/ai_agent.rb#L44-L50)
- [ai_agents_controller.rb:64-92](file://app/controllers/ai_agents_controller.rb#L64-L92)

## Conclusion
This guide consolidates the most frequent AI agent configuration pitfalls and provides actionable steps to diagnose and resolve them. By leveraging model validations, plugin settings, the test_connection action, and the dispatch pipeline, administrators can quickly isolate issues related to credentials, endpoints, protocols, and parameter completeness. Regular use of test_connection and manual dispatch testing ensures ongoing configuration correctness and operational reliability.