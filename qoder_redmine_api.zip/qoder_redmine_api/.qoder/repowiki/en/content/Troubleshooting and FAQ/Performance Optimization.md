# Performance Optimization

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [routes.rb](file://config/routes.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides performance-focused guidance for the Redmine AI Agent Plugin. It identifies potential bottlenecks in dispatch jobs, outlines timeout and concurrency tuning, and proposes strategies to reduce response latency, memory usage, and processing overhead. It also covers monitoring techniques and scaling considerations for high-volume environments.

## Project Structure
The plugin follows a conventional Redmine plugin layout with controllers, models, jobs, migrations, and plugin registration. The dispatch lifecycle spans a controller endpoint, a background job, and model persistence.

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentDispatchesController<br/>POST /issues/:issue_id/ai_agent_dispatches"]
end
subgraph "Jobs"
J1["AiAgentDispatchJob<br/>perform_later(...)"]
end
subgraph "Models"
M1["AiAgentDispatch"]
M2["AiAgent"]
M3["AiAgentAssignment"]
end
subgraph "Routing"
R1["Routes<br/>resources :issues { resources :ai_agent_dispatches }"]
end
subgraph "Plugin Settings"
S1["init.rb<br/>settings defaults"]
end
C1 --> J1
J1 --> M1
J1 --> M2
J1 --> M3
R1 --> C1
S1 --> J1
```

**Diagram sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [init.rb:12-16](file://init.rb#L12-L16)

**Section sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [init.rb:12-16](file://init.rb#L12-L16)

## Core Components
- Dispatch Job: Orchestrates agent invocation, tool-loop execution, and journaling. It retries transient errors and records timing metrics.
- Dispatch Model: Tracks dispatch lifecycle, status, payloads, and computed duration.
- Agent Model: Defines agent type, protocol, endpoint, and system prompt resolution.
- Assignment Model: Links users to active agents for auto-dispatch.
- Controller: Triggers manual dispatch via background job.
- Plugin Settings: Provides defaults for enabling the plugin and configuring timeouts.

Key performance-relevant behaviors:
- Dispatch job persists request/response payloads as JSON.
- Tool-loop executes up to a fixed number of iterations and feeds tool results back to the agent.
- Duration calculation is derived from timestamps stored during dispatch lifecycle.

**Section sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:26-30](file://app/models/ai_agent_dispatch.rb#L26-L30)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)
- [ai_agent_dispatches_controller.rb:27-31](file://app/controllers/ai_agent_dispatches_controller.rb#L27-L31)
- [init.rb:12-16](file://init.rb#L12-L16)

## Architecture Overview
The dispatch pipeline is request-triggered and asynchronous. Manual triggers enqueue a job that performs agent processing and posts journal updates.

```mermaid
sequenceDiagram
participant U as "User"
participant C as "AiAgentDispatchesController"
participant Q as "ActiveJob Queue"
participant J as "AiAgentDispatchJob"
participant D as "AiAgentDispatch"
participant A as "AiAgent"
participant S as "RedmineApiSkill"
U->>C : "POST /issues/ : id/ai_agent_dispatches"
C->>Q : "perform_later(issue_id, agent_id, user_id)"
Q->>J : "perform(...)"
J->>D : "create!(status=running, timestamps)"
J->>A : "AgentClient.call(issue, triggered_by)"
J->>S : "execute_tool_call(...) (loop)"
J->>D : "update!(status=done, payloads, timestamps)"
J-->>U : "journal note posted"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:27-31](file://app/controllers/ai_agent_dispatches_controller.rb#L27-L31)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:18-24](file://app/models/ai_agent_dispatch.rb#L18-L24)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)

## Detailed Component Analysis

### Dispatch Job Performance Profile
- Retry policy: Transient errors cause polynomial backoff with up to three attempts.
- Tool-loop: Up to ten iterations; each iteration adds messages and tool results, then resends to the agent.
- Payload persistence: Request and raw response are persisted as JSON; parsing occurs on read.
- Journaling: Two journal entries are posted (start and completion/error), involving issue save operations.

```mermaid
flowchart TD
Start(["Job Entry"]) --> Load["Load records by IDs"]
Load --> Valid{"Records found?"}
Valid --> |No| LogWarn["Log warning and return"]
Valid --> |Yes| CreateDispatch["Create dispatch (running)"]
CreateDispatch --> PostStart["Post start journal"]
PostStart --> CallAgent["AgentClient.call(...)"]
CallAgent --> ToolLoop["run_tool_loop (<=10 iterations)"]
ToolLoop --> Persist["Persist request/response payloads"]
Persist --> PostDone["Post completion journal"]
PostDone --> LogInfo["Log duration"]
LogWarn --> End(["Exit"])
LogInfo --> End
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [ai_agent_dispatch.rb:18-24](file://app/models/ai_agent_dispatch.rb#L18-L24)

**Section sources**
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [ai_agent_dispatch.rb:42-42](file://app/models/ai_agent_dispatch.rb#L42-L42)

### Tool Loop Processing Logic
- Iteration limit: Prevents runaway loops and bounds processing cost.
- Message accumulation: Each tool result is appended as a tool role message.
- Agent continuation: Subsequent requests merge accumulated messages.

```mermaid
flowchart TD
Enter(["Tool Loop Entry"]) --> Choice["Read choices[0].message"]
Choice --> HasTools{"Has tool_calls?"}
HasTools --> |No| ReturnText["Return agent text"]
HasTools --> |Yes| AppendAssistant["Append assistant message + tool_calls"]
AppendAssistant --> ForEach["For each tool_call"]
ForEach --> Exec["skill.execute_tool_call(...)"]
Exec --> AppendTool["Append tool result as role=tool"]
AppendTool --> NextIter["Resend merged messages to agent"]
NextIter --> LoopLimit{"Iterations < 10?"}
LoopLimit --> |Yes| Choice
LoopLimit --> |No| ReturnFallback["Return fallback content"]
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)

### Dispatch Model Metrics
- Duration computation: Difference between timestamps; useful for measuring end-to-end latency.
- Payload parsing: Safe JSON parsing with error handling to avoid crashes on malformed payloads.

**Section sources**
- [ai_agent_dispatch.rb:26-30](file://app/models/ai_agent_dispatch.rb#L26-L30)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)

### Agent Model Prompt Resolution
- Dynamic prompt substitution: Base URL and API key are injected into templates per issue context.
- Implication: Avoids storing sensitive keys in logs by masking; ensures correct endpoint configuration.

**Section sources**
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)

### Controller Trigger Path
- Authorization: Requires permission to dispatch AI agents on the project.
- Enqueue: Uses perform_later to schedule the job asynchronously.

**Section sources**
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatches_controller.rb:27-31](file://app/controllers/ai_agent_dispatches_controller.rb#L27-L31)

## Dependency Analysis
- Controllers depend on models and ActiveJob for dispatch scheduling.
- Jobs depend on models, agent clients, and skills for processing.
- Models encapsulate persistence and lightweight computations (duration).
- Routing binds manual dispatch endpoints to the controller.

```mermaid
graph LR
Routes["routes.rb"] --> Ctrl["AiAgentDispatchesController"]
Ctrl --> Job["AiAgentDispatchJob"]
Job --> ModelD["AiAgentDispatch"]
Job --> ModelA["AiAgent"]
Job --> ModelAs["AiAgentAssignment"]
Init["init.rb settings"] --> Job
```

**Diagram sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [init.rb:12-16](file://init.rb#L12-L16)

**Section sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [init.rb:12-16](file://init.rb#L12-L16)

## Performance Considerations

### Timeout Configuration Tuning
- Plugin default timeout: The plugin settings include a default timeout value suitable for agent interactions.
- Recommendations:
  - Align worker process timeouts with the configured default to prevent premature termination.
  - Ensure queuing backend (Sidekiq/Resque) has sufficient queue TTL and retry window to accommodate the polynomial backoff pattern.
  - Monitor queue latency and adjust worker concurrency to avoid overlapping timeouts.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)

### Concurrent Request Limits
- Background workers: Tune the number of worker processes to match CPU and I/O capacity.
- Agent rate limits: If the external agent service enforces quotas, consider throttling dispatch frequency or batching.
- Database contention: Indexes on dispatches and assignments support filtering but can still contend under load; monitor lock waits.

**Section sources**
- [003_create_ai_agent_dispatches.rb:16-18](file://db/migrate/003_create_ai_agent_dispatches.rb#L16-L18)
- [002_create_ai_agent_assignments.rb:10-11](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L11)

### Resource Allocation Strategies
- Memory footprint:
  - Payloads are persisted as JSON; consider compression or offloading to blob storage for very large responses.
  - Tool-loop message accumulation grows linearly with iterations; keep iteration count low and message sizes reasonable.
- CPU usage:
  - Tool-loop iteration count caps processing cost.
  - Journal saves involve ORM operations; batch or defer non-critical writes if needed.
- I/O:
  - Network calls to agent endpoints dominate latency; ensure network connectivity and DNS resolution are fast.
  - Skill execution invokes Redmine API calls; ensure endpoint URLs and credentials are correct to avoid retries.

**Section sources**
- [ai_agent_dispatch_job.rb:42-47](file://app/jobs/ai_agent_dispatch_job.rb#L42-L47)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)

### Optimizing Agent Response Times
- Reduce payload sizes: Trim unnecessary fields from messages and tool results.
- Shorten tool-loop cycles: Keep the tool-call chain minimal and focused.
- Pre-warm connections: Configure persistent HTTP connections to agent endpoints.
- Parallelism: If multiple issues can be processed independently, increase worker concurrency judiciously.

**Section sources**
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)

### Reducing Processing Overhead
- Avoid redundant journal saves: Consolidate notes or skip posting if the agent already included sufficient detail.
- Minimize JSON parsing: Only parse payloads when required; cache parsed results within the job lifecycle if reused.
- Optimize queries: Use eager loading for related records when reading dispatch history.

**Section sources**
- [ai_agent_dispatch_job.rb:71-78](file://app/jobs/ai_agent_dispatch_job.rb#L71-L78)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent_dispatches_controller.rb:6](file://app/controllers/ai_agent_dispatches_controller.rb#L6)

### Monitoring Techniques for Bottlenecks
- Metrics to track:
  - Dispatch duration (computed difference of timestamps).
  - Queue backlog and per-worker throughput.
  - Retry counts and error rates.
  - Tool-loop iteration counts and average per dispatch.
- Logging signals:
  - Warnings for missing records.
  - Errors for unexpected exceptions and tool-loop failures.
  - Info lines with total duration for successful runs.

**Section sources**
- [ai_agent_dispatch.rb:26-30](file://app/models/ai_agent_dispatch.rb#L26-L30)
- [ai_agent_dispatch_job.rb:13-15](file://app/jobs/ai_agent_dispatch_job.rb#L13-L15)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [ai_agent_dispatch_job.rb:116-118](file://app/jobs/ai_agent_dispatch_job.rb#L116-L118)
- [ai_agent_dispatch_job.rb:59](file://app/jobs/ai_agent_dispatch_job.rb#L59)

### Scaling Considerations for High Volume
- Horizontal scaling:
  - Add worker nodes and configure shared queues.
  - Ensure database connection pooling is sized appropriately.
- Vertical scaling:
  - Increase CPU/memory per worker for heavier payloads.
- Backpressure:
  - Introduce queue length thresholds and graceful degradation.
  - Consider per-project or per-user rate limiting to protect downstream systems.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

Common symptoms and diagnostics:
- Slow response times:
  - Inspect dispatch durations and queue latency.
  - Verify agent endpoint availability and network RTT.
- High memory usage:
  - Review payload sizes and tool-loop message growth.
  - Consider offloading large payloads to external storage.
- Processing bottlenecks:
  - Check retry logs and error patterns.
  - Confirm tool-loop iterations are bounded and not exceeding expectations.

Operational checks:
- Validate plugin settings and endpoint configuration.
- Confirm agent credentials and permissions for Redmine API usage.
- Monitor journal posting failures and fix underlying persistence issues.

**Section sources**
- [ai_agent_dispatch.rb:26-30](file://app/models/ai_agent_dispatch.rb#L26-L30)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [ai_agent_dispatch_job.rb:116-118](file://app/jobs/ai_agent_dispatch_job.rb#L116-L118)
- [ai_agent_dispatch_job.rb:71-78](file://app/jobs/ai_agent_dispatch_job.rb#L71-L78)

## Conclusion
Optimizing the Redmine AI Agent Plugin hinges on controlling agent call latency, bounding tool-loop costs, and managing background worker throughput. By tuning timeouts, limiting concurrent processing, monitoring key metrics, and applying targeted payload and query optimizations, teams can achieve reliable performance at scale.

## Appendices

### Database Schema Overview
```mermaid
erDiagram
AI_AGENTS {
string name
string agent_type
string endpoint_url
string protocol
string api_key
string model_name
text system_prompt
boolean active
}
AI_AGENT_ASSIGNMENTS {
integer user_id
integer ai_agent_id
boolean auto_dispatch
}
AI_AGENT_DISPATCHES {
integer issue_id
integer ai_agent_id
integer triggered_by
string status
text request_payload
text response_payload
integer journal_id
datetime dispatched_at
datetime completed_at
}
AI_AGENTS ||--o{ AI_AGENT_ASSIGNMENTS : "has_many"
AI_AGENTS ||--o{ AI_AGENT_DISPATCHES : "has_many"
AI_AGENT_DISPATCHES }o--|| AI_AGENTS : "belongs_to"
AI_AGENT_DISPATCHES }o--|| AI_AGENTS : "belongs_to"
```

**Diagram sources**
- [001_create_ai_agents.rb:3-12](file://db/migrate/001_create_ai_agents.rb#L3-L12)
- [002_create_ai_agent_assignments.rb:3-7](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L7)
- [003_create_ai_agent_dispatches.rb:3-13](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L13)