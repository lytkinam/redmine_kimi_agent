# Assignment Lookup and Resolution

<cite>
**Referenced Files in This Document**
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [routes.rb](file://config/routes.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [init.rb](file://init.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how the system assigns and resolves AI agents to users when processing Redmine issues. It covers the assignment lookup algorithms, precedence rules, fallback mechanisms, integration with the dispatch system, and end-to-end resolution flow. It also provides examples of assignment resolution scenarios, conflict handling, default agent selection, and performance considerations for large user bases.

## Project Structure
The assignment and dispatch system spans models, controllers, jobs, migrations, and plugin hooks. Routes define the public API surface for manual dispatches, while internal hooks enable automatic dispatch on issue creation or assignment changes. Jobs encapsulate the runtime dispatch workflow, including agent invocation and tool-loop execution.

```mermaid
graph TB
subgraph "Models"
A["AiAgent"]
B["AiAgentAssignment"]
C["AiAgentDispatch"]
end
subgraph "Controllers"
D["AiAgentAssignmentsController"]
E["AiAgentDispatchesController"]
end
subgraph "Jobs"
F["AiAgentDispatchJob"]
end
subgraph "Lib"
G["AgentClient"]
H["RedmineApiSkill"]
I["KimiWebClient"]
J["Hooks"]
end
subgraph "Routes"
R["routes.rb"]
end
A <-- "belongs_to" --> B
B --> C
E --> F
F --> G
F --> H
J --> B
J --> C
R --> E
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:1-31](file://init.rb#L1-L31)

## Core Components
- AiAgentAssignment: Links a user to an AI agent and supports lookup by user and active agent retrieval.
- AiAgent: Defines agent metadata, validation, active scope, and system prompt resolution.
- AiAgentDispatch: Tracks dispatch lifecycle, status transitions, and payload persistence.
- AiAgentDispatchJob: Orchestrates dispatch creation, journal notes, agent invocation, tool-loop execution, and error handling.
- AgentClient: Builds payloads, invokes agent endpoints, and parses responses.
- RedmineApiSkill: Executes tool calls against the Redmine REST API on behalf of the agent.
- Hooks: Provides automatic dispatch on issue creation/assignment and renders UI panels.
- Controllers: Admin CRUD for assignments and manual dispatch triggers from the issue page.

**Section sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

## Architecture Overview
The assignment and dispatch pipeline integrates user assignments, agent selection, and automated issue processing. Automatic dispatch occurs when an issue is created or when the assignee changes, provided an active assignment exists and auto-dispatch is enabled. Manual dispatch is available from the issue page.

```mermaid
sequenceDiagram
participant Hook as "Hooks"
participant Assign as "AiAgentAssignment"
participant Job as "AiAgentDispatchJob"
participant Dispatch as "AiAgentDispatch"
participant Client as "AgentClient"
participant Skill as "RedmineApiSkill"
Hook->>Assign : Lookup active agent for assignee
Assign-->>Hook : Agent if exists and active
Hook->>Job : Queue dispatch with issue_id, agent_id, triggered_by
Job->>Dispatch : Create dispatch record (status=running)
Job->>Client : call(issue, triggered_by)
Client-->>Job : {text, raw_response, request}
Job->>Skill : Execute tool calls (loop)
Skill-->>Job : Tool results
Job->>Dispatch : Update status=done, persist payloads
Job-->>Hook : Dispatch complete (journal notes posted)
```

**Diagram sources**
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

## Detailed Component Analysis

### Assignment Lookup and Precedence
Assignment lookup follows a deterministic precedence:
1. Identify the assignee user from the issue.
2. Find an active agent assignment for that user.
3. If found, select the associated agent; otherwise, dispatch fails with a user-visible error.

Precedence rules:
- Only active agents are considered.
- Each user may have at most one active assignment.
- If auto_dispatch is enabled on the assignment, the system can trigger dispatch automatically.

Fallback mechanisms:
- If no active assignment exists, manual dispatch is blocked and an error is flashed.
- If the selected agent is inactive, the lookup yields no agent and dispatch is prevented.

```mermaid
flowchart TD
Start(["Issue update/create"]) --> GetAssignee["Get issue.assignee"]
GetAssignee --> HasAssignee{"Has assignee?"}
HasAssignee --> |No| End(["No dispatch"])
HasAssignee --> |Yes| Lookup["Lookup active AiAgentAssignment for user"]
Lookup --> Found{"Assignment found?"}
Found --> |No| Error["Flash 'no agent for assignee'"]
Found --> |Yes| SelectAgent["Select AiAgent from assignment"]
SelectAgent --> Proceed["Proceed to dispatch"]
Error --> End
```

**Diagram sources**
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)
- [ai_agent_dispatches_controller.rb:17-25](file://app/controllers/ai_agent_dispatches_controller.rb#L17-L25)

**Section sources**
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_assignment.rb:8-20](file://app/models/ai_agent_assignment.rb#L8-L20)
- [ai_agent_dispatches_controller.rb:17-36](file://app/controllers/ai_agent_dispatches_controller.rb#L17-L36)

### Dispatch Resolution Workflow
Manual dispatch:
- The issue page exposes a “Send to AI Agent” panel when an active assignment exists.
- Submitting the panel triggers a controller action that validates the active assignment and enqueues a job.

Automatic dispatch:
- Hooks listen for issue save events (new and edit).
- If the assignee changed or the issue is newly created and assigned, the system checks for an active assignment with auto_dispatch enabled and enqueues a job.

Job execution:
- Creates a running dispatch record and posts a journal note.
- Invokes the agent via AgentClient, optionally using a specialized Kimi client for WebSocket sessions.
- Executes a tool-loop to call RedmineApiSkill functions until the agent returns final text or max iterations are reached.
- Persists request/response payloads and posts a completion journal note.
- On errors, marks dispatch as error and posts a journal note.

```mermaid
sequenceDiagram
participant UI as "Issue Page"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Model as "AiAgentDispatch"
participant Agent as "AgentClient/KimiWebClient"
participant Skill as "RedmineApiSkill"
UI->>Ctrl : POST /issues/ : id/ai_agent_dispatches
Ctrl->>Ctrl : Validate active assignment
Ctrl->>Job : perform_later(issue_id, agent_id, triggered_by)
Job->>Model : create dispatch (status=running)
Job->>Agent : call(issue, triggered_by)
Agent-->>Job : {text, raw_response, request}
Job->>Skill : Execute tool calls (loop)
Skill-->>Job : Results
Job->>Model : update status=done, payloads
Job-->>UI : Completion journal note
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:17-59](file://app/jobs/ai_agent_dispatch_job.rb#L17-L59)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [kimi_web_client.rb:39-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L39-L58)

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [kimi_web_client.rb:39-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L39-L58)

### Conflict Handling and Default Agent Selection
Conflict handling:
- Duplicate assignments: The assignment model enforces a unique constraint on user_id, preventing conflicts at the database level.
- Inactive agent: If the assigned agent becomes inactive, the lookup yields no agent; dispatch is blocked until the assignment is corrected.
- Auto-dispatch toggled: If auto_dispatch is disabled, the system will not auto-trigger dispatch even if an assignment exists.

Default agent selection:
- There is no global default agent. If no active assignment exists for a user, dispatch is not performed automatically nor manually without an assignment.

**Section sources**
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [ai_agent.rb:15](file://app/models/ai_agent.rb#L15)
- [hooks.rb:63](file://lib/redmine_ai_agent/hooks.rb#L63)

### Integration with the Dispatch System
- Routes: Issues resource nests ai_agent_dispatches for manual dispatch actions.
- Permissions: Project-level permissions control who can dispatch and manage agents.
- Views: Hooks inject a dispatch panel into the issue page when an active assignment exists.

**Section sources**
- [routes.rb:13-15](file://config/routes.rb#L13-L15)
- [init.rb:24-29](file://init.rb#L24-L29)
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)

## Dependency Analysis
The system exhibits clear separation of concerns:
- Models define domain logic and validations.
- Controllers mediate user actions and permissions.
- Jobs encapsulate long-running tasks and error handling.
- Clients abstract agent and API interactions.
- Hooks integrate with Redmine lifecycle events.

```mermaid
classDiagram
class AiAgentAssignment {
+for_user(user)
+agent_for(user)
+auto_dispatch?
}
class AiAgent {
+active
+resolved_system_prompt(issue)
}
class AiAgentDispatch {
+pending()
+running()
+done()
+error()
+finished()
+duration()
}
class AiAgentDispatchJob {
+perform(issue_id, ai_agent_id, triggered_by_user_id)
}
class AgentClient {
+call(issue, triggered_by)
}
class RedmineApiSkill {
+execute_tool_call(tool_call)
}
class Hooks {
+check_and_auto_dispatch(issue, triggered_by)
}
AiAgentAssignment --> AiAgent : "belongs_to"
AiAgentAssignment --> User : "belongs_to"
AiAgentDispatch --> AiAgent : "belongs_to"
AiAgentDispatch --> Issue : "belongs_to"
AiAgentDispatchJob --> AiAgentDispatch : "creates/updates"
AiAgentDispatchJob --> AgentClient : "invokes"
AiAgentDispatchJob --> RedmineApiSkill : "executes tools"
Hooks --> AiAgentAssignment : "lookup"
Hooks --> AiAgentDispatchJob : "enqueues"
```

**Diagram sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

**Section sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Performance Considerations
- Indexes: Database migrations define indexes on frequently queried columns (agent_type, active, user_id, ai_agent_id, status, triggered_by, issue_id). These support efficient assignment and dispatch lookups.
- Active scopes: Models use active scopes to limit queries to enabled agents, reducing unnecessary scans.
- Single assignment per user: Unique constraint on user_id prevents redundant lookups and simplifies cache keys.
- Job retries: Transient agent errors are retried with exponential backoff, minimizing impact of temporary failures.
- Tool-loop limits: A bounded iteration loop prevents runaway processing and caps API usage.
- Timeout tuning: Agent and API clients use configurable timeouts to avoid blocking threads.

Optimization strategies for large user bases:
- Add composite indexes for common filter combinations (e.g., user_id + active).
- Cache assignment lookups per request lifecycle to avoid repeated queries.
- Batch auto-dispatch triggers if needed, and consider rate-limiting to prevent thundering herds.
- Monitor dispatch durations and adjust default timeouts accordingly.

**Section sources**
- [001_create_ai_agents.rb:15-16](file://db/migrate/001_create_ai_agents.rb#L15-L16)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)
- [003_create_ai_agent_dispatches.rb:16-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L16-L22)
- [ai_agent.rb:15](file://app/models/ai_agent.rb#L15)
- [ai_agent_dispatch_job.rb:5](file://app/jobs/ai_agent_dispatch_job.rb#L5)
- [agent_client.rb:202-208](file://lib/redmine_ai_agent/agent_client.rb#L202-L208)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)

## Troubleshooting Guide
Common issues and resolutions:
- No agent assigned to assignee:
  - Symptom: Manual dispatch fails with an error; automatic dispatch does not trigger.
  - Cause: Missing or inactive assignment.
  - Resolution: Create an active assignment for the user or activate an existing one.
  - References: [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25), [hooks.rb:63](file://lib/redmine_ai_agent/hooks.rb#L63)

- Agent endpoint failure:
  - Symptom: Dispatch marked as error with HTTP status or timeout.
  - Cause: Network, invalid endpoint, or non-2xx response.
  - Resolution: Verify endpoint URL, credentials, and network connectivity; adjust timeouts.
  - References: [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229), [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)

- Tool-call failures:
  - Symptom: Errors in tool execution or invalid JSON.
  - Cause: Malformed tool_call or Redmine API errors.
  - Resolution: Inspect tool_call shape and arguments; validate Redmine API responses.
  - References: [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61), [ai_agent_dispatch_job.rb:116-119](file://app/jobs/ai_agent_dispatch_job.rb#L116-L119)

- Journal posting failures:
  - Symptom: Missing completion note.
  - Cause: Issue save or journal initialization errors.
  - Resolution: Check permissions and issue state; review logs for details.
  - References: [ai_agent_dispatch_job.rb:71-78](file://app/jobs/ai_agent_dispatch_job.rb#L71-L78)

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [hooks.rb:63](file://lib/redmine_ai_agent/hooks.rb#L63)
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [ai_agent_dispatch_job.rb:71-78](file://app/jobs/ai_agent_dispatch_job.rb#L71-L78)

## Conclusion
The assignment lookup and resolution system centers on a strict, deterministic precedence: active agent assignment per user, enforced by model validations and unique constraints. Automatic dispatch leverages Redmine hooks, while manual dispatch is exposed via the issue UI. The job orchestrates agent invocation, tool-loop execution, and robust error handling. With proper indexing, caching, and timeout tuning, the system scales effectively for large user bases.