# Permission and Access Control

<cite>
**Referenced Files in This Document**
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the permission and access control model for the user assignment system that links Redmine users to AI agents. It focuses on the require_admin before_action, the security-sensitive nature of assignment management, and how the system prevents unauthorized access. It also outlines scenarios, design rationale, best practices, and considerations for maintaining auditability and safety.

## Project Structure
The assignment system spans controllers, models, routing, permissions, and database schema. The assignment controller enforces administrative access for all assignment operations, while the plugin registration defines project-level permissions that govern who can manage agents and assignments.

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentAssignmentsController<br/>require_admin before_action"]
end
subgraph "Models"
M1["AiAgentAssignment<br/>belongs_to :user, :ai_agent<br/>validations"]
M2["AiAgent<br/>has_many :ai_agent_assignments"]
end
subgraph "Routing"
R1["Routes<br/>resources :ai_agent_assignments"]
end
subgraph "Permissions"
P1["Plugin init.rb<br/>project_module :ai_agent<br/>permissions"]
end
subgraph "Schema"
S1["Migration 002<br/>ai_agent_assignments table<br/>indexes & foreign keys"]
end
C1 --> M1
C1 --> M2
R1 --> C1
P1 --> C1
S1 --> M1
```

**Diagram sources**
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [init.rb:24-30](file://init.rb#L24-L30)
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)

**Section sources**
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [init.rb:24-30](file://init.rb#L24-L30)
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)

## Core Components
- Administrative enforcement: The assignment controller applies a require_admin before_action to protect all assignment operations (index, new, create, edit, update, destroy).
- Permission model: The plugin registers project-level permissions for managing agents and assignments, enabling administrators to grant granular access.
- Data model: Assignments link users to AI agents with validations ensuring uniqueness and referential integrity enforced by database constraints.
- Routing: Assignment resources are exposed under admin-level routes, aligning with administrative intent.

Security implications:
- Assignment management directly controls which users can trigger AI agent dispatches and whether those dispatches are automatic. Unauthorized changes could lead to unintended automation, resource misuse, or exposure of sensitive operations.
- Administrative privileges are required to maintain separation of duties and prevent accidental or malicious misconfiguration.

**Section sources**
- [ai_agent_assignments_controller.rb:2-2](file://app/controllers/ai_agent_assignments_controller.rb#L2-L2)
- [init.rb:24-30](file://init.rb#L24-L30)
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)

## Architecture Overview
The assignment controller orchestrates user-agent assignment CRUD operations. It relies on the plugin permission system to gate access and on the model/schema to enforce data integrity.

```mermaid
sequenceDiagram
participant U as "User"
participant RC as "Rails Router"
participant AC as "AiAgentAssignmentsController"
participant ADM as "require_admin"
participant MOD as "AiAgentAssignment Model"
participant DB as "Database"
U->>RC : "HTTP request to assignment endpoint"
RC->>AC : "Dispatch to controller action"
AC->>ADM : "Run before_action"
ADM-->>AC : "Allow or deny"
alt "Access granted"
AC->>MOD : "Perform operation (find/save/update/destroy)"
MOD->>DB : "Execute SQL"
DB-->>MOD : "Result"
MOD-->>AC : "Success/Failure"
AC-->>U : "Render response"
else "Access denied"
AC-->>U : "Unauthorized response"
end
```

**Diagram sources**
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)

## Detailed Component Analysis

### Access Control Enforcement: require_admin
- Purpose: The require_admin before_action ensures that only users with administrative privileges can access assignment management actions.
- Scope: Applies to all assignment actions (index, new, create, edit, update, destroy).
- Outcome: Prevents unauthorized users from viewing, creating, modifying, or removing assignments.

Security design rationale:
- Assignment management is a privileged operation because it determines which users can trigger AI agent dispatches and whether those dispatches are automatic. Administrative oversight is essential to prevent abuse and maintain system stability.

**Section sources**
- [ai_agent_assignments_controller.rb:2-2](file://app/controllers/ai_agent_assignments_controller.rb#L2-L2)

### Permission Model: Plugin-Level Permissions
- Registration: The plugin registers a project module with two permissions:
  - dispatch_ai_agent: allows dispatching AI agents per issue.
  - manage_ai_agents: allows managing agents and assignments.
- Scope: These permissions apply to controllers for agents and assignments, enabling administrators to grant fine-grained access.

Operational impact:
- Administrators can grant manage_ai_agents to trusted users or roles who need to configure assignments without granting broader system administration rights.
- The require_admin in the assignment controller acts as a hard security boundary, ensuring only administrators can perform assignment operations regardless of project-level permissions.

**Section sources**
- [init.rb:24-30](file://init.rb#L24-L30)

### Data Integrity and Constraints
- Uniqueness: Each user can be assigned to at most one active AI agent, enforced by a unique index on user_id.
- Referential integrity: Foreign keys ensure that user_id and ai_agent_id point to existing records.
- Validations: Presence and uniqueness validations on assignment fields ensure consistent state.

Auditability:
- Timestamps on the assignments table support basic audit trail capabilities (created_at/updated_at).
- Future enhancements could include dedicated audit logs for assignment changes.

**Section sources**
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)

### Assignment Operations Flow
```mermaid
flowchart TD
Start(["Action Entry"]) --> CheckAdmin["require_admin runs"]
CheckAdmin --> Allowed{"Admin authorized?"}
Allowed --> |No| Deny["Return unauthorized"]
Allowed --> |Yes| LoadModel["Load/Validate Assignment"]
LoadModel --> SaveOp{"Save/Update/Delete?"}
SaveOp --> |Create/Update| Persist["Persist to DB"]
SaveOp --> |Delete| Remove["Remove record"]
Persist --> Success["Redirect/Render success"]
Remove --> Success
Success --> End(["Exit"])
Deny --> End
```

**Diagram sources**
- [ai_agent_assignments_controller.rb:16-48](file://app/controllers/ai_agent_assignments_controller.rb#L16-L48)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

### Automatic Dispatch Interaction
While not part of assignment management itself, the assignment model supports automatic dispatch behavior. The system checks assignment.auto_dispatch? during issue lifecycle events and triggers automated dispatches accordingly.

```mermaid
sequenceDiagram
participant Hook as "Issue Lifecycle Hook"
participant Assn as "AiAgentAssignment"
participant Job as "AiAgentDispatchJob"
Hook->>Assn : "Find active assignment for assignee"
Assn-->>Hook : "Assignment (if exists)"
Hook->>Assn : "Check auto_dispatch?"
Assn-->>Hook : "true/false"
alt "Auto-dispatch enabled"
Hook->>Job : "Enqueue job with issue, agent, trigger user"
else "Disabled"
Hook-->>Hook : "No-op"
end
```

**Diagram sources**
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_assignment.rb:22-24](file://app/models/ai_agent_assignment.rb#L22-L24)

**Section sources**
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_assignment.rb:22-24](file://app/models/ai_agent_assignment.rb#L22-L24)

## Dependency Analysis
The assignment controller depends on:
- Plugin permission system for authorization gating.
- Rails routing to expose assignment endpoints.
- Model validations and database constraints for data integrity.
- Hooks for runtime automation based on assignments.

```mermaid
graph LR
Init["init.rb<br/>permissions"] --> Ctrl["AiAgentAssignmentsController"]
Routes["routes.rb<br/>resources :ai_agent_assignments"] --> Ctrl
Ctrl --> Model["AiAgentAssignment"]
Model --> Mig["Migration 002<br/>constraints"]
Hook["hooks.rb<br/>auto-dispatch"] --> Model
```

**Diagram sources**
- [init.rb:24-30](file://init.rb#L24-L30)
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

**Section sources**
- [init.rb:24-30](file://init.rb#L24-L30)
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Performance Considerations
- Indexes on user_id and ai_agent_id improve lookup performance for assignment queries.
- The assignment controller uses eager loading for associations in index/new actions to reduce N+1 queries.
- Automatic dispatch checks leverage joins and filters to minimize overhead.

Recommendations:
- Monitor assignment queries for hotspots as user and agent counts grow.
- Consider caching frequently accessed assignment lookups if needed.

**Section sources**
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)
- [ai_agent_assignments_controller.rb:4-14](file://app/controllers/ai_agent_assignments_controller.rb#L4-L14)

## Troubleshooting Guide
Common permission-related issues:
- Unauthorized access attempts: If a non-admin tries to access assignment endpoints, the require_admin filter blocks the request. Verify the user’s admin status and any applied project-level permissions.
- Missing permissions: Ensure administrators have granted manage_ai_agents where applicable.
- Assignment conflicts: Since each user can only have one active assignment, verify uniqueness constraints and existing assignments before creating new ones.

Operational checks:
- Confirm routes are correctly mapped for assignment resources.
- Validate model validations and database constraints remain intact.
- Review logs for authorization failures and investigate user roles.

**Section sources**
- [ai_agent_assignments_controller.rb:2-2](file://app/controllers/ai_agent_assignments_controller.rb#L2-L2)
- [init.rb:24-30](file://init.rb#L24-L30)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)

## Conclusion
The assignment system enforces strict administrative control over user-to-AI-agent assignments. The require_admin before_action, combined with plugin-level permissions and robust data constraints, ensures that only authorized administrators can manage assignments. This design protects against unauthorized automation and maintains operational integrity. Administrators can further refine access using project-level permissions, while future enhancements can strengthen auditability and monitoring.