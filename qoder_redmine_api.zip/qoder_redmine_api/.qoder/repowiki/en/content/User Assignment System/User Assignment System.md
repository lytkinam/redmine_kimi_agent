# User Assignment System

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [new.html.erb](file://app/views/ai_agent_assignments/new.html.erb)
- [_form.html.erb](file://app/views/ai_agent_assignments/_form.html.erb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the User Assignment System that connects Redmine users to AI agents and orchestrates automated issue processing. It covers:
- How administrators assign AI agents to users and manage the assignment lifecycle
- Auto-dispatch configuration and how it triggers automatic AI processing when issues are assigned
- Permissions governing who can assign agents and dispatch AI actions
- Lookup mechanisms that determine which agent is used for a given user
- Practical assignment scenarios, workflow integration patterns, conflict resolution, and troubleshooting

## Project Structure
The plugin extends Redmine through controllers, models, jobs, migrations, views, and plugin settings. Routes define admin and per-issue endpoints for assignments and dispatches.

```mermaid
graph TB
subgraph "Plugin Entry"
INIT["init.rb"]
end
subgraph "Routing"
ROUTES["config/routes.rb"]
end
subgraph "Controllers"
CTRL_ASS["AiAgentAssignmentsController"]
CTRL_DISP["AiAgentDispatchesController"]
end
subgraph "Models"
MODEL_ASS["AiAgentAssignment"]
MODEL_AGENT["AiAgent"]
MODEL_DISP["AiAgentDispatch"]
end
subgraph "Jobs"
JOB["AiAgentDispatchJob"]
end
subgraph "Views"
VIEW_NEW["ai_agent_assignments/new.html.erb"]
VIEW_FORM["_form.html.erb"]
VIEW_SETTINGS["_ai_agent_settings.html.erb"]
end
INIT --> ROUTES
ROUTES --> CTRL_ASS
ROUTES --> CTRL_DISP
CTRL_ASS --> MODEL_ASS
CTRL_ASS --> MODEL_AGENT
CTRL_DISP --> MODEL_DISP
CTRL_DISP --> MODEL_ASS
MODEL_ASS --> MODEL_AGENT
MODEL_DISP --> MODEL_AGENT
CTRL_DISP --> JOB
VIEW_NEW --> VIEW_FORM
VIEW_SETTINGS --> INIT
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [new.html.erb:1-8](file://app/views/ai_agent_assignments/new.html.erb#L1-L8)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- AiAgentAssignment: Links a Redmine user to an AI agent and supports auto-dispatch flag and active agent lookup.
- AiAgent: Defines agent metadata, validations, system prompts, and protocol/type helpers.
- AiAgentDispatch: Tracks per-issue dispatch runs, status, timing, and payload storage.
- AiAgentDispatchJob: Background job that executes the agent against an issue, posts journal notes, and handles tool loops.
- AiAgentAssignmentsController: Admin CRUD for assignments with admin-only access.
- AiAgentDispatchesController: Manual dispatch endpoint with project-level permissions.
- Plugin settings and permissions: Enablement, base URL, timeouts, and project permissions for dispatch and management.

**Section sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [init.rb:24-29](file://init.rb#L24-L29)

## Architecture Overview
The system integrates assignment management with dispatch automation and background processing.

```mermaid
sequenceDiagram
participant Admin as "Admin User"
participant CtrlAss as "AiAgentAssignmentsController"
participant AssModel as "AiAgentAssignment"
participant AgentModel as "AiAgent"
participant ViewAss as "Assignment Views"
Admin->>CtrlAss : "GET /ai_agent_assignments"
CtrlAss->>AssModel : "List assignments with includes"
AssModel-->>CtrlAss : "Assignments"
CtrlAss->>ViewAss : "Render index/new/edit forms"
Admin->>CtrlAss : "POST create (user, agent, auto_dispatch)"
CtrlAss->>AssModel : "Save assignment"
AssModel-->>CtrlAss : "Success/Failure"
CtrlAss-->>Admin : "Redirect with notice/error"
```

**Diagram sources**
- [ai_agent_assignments_controller.rb:4-26](file://app/controllers/ai_agent_assignments_controller.rb#L4-L26)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [new.html.erb:1-8](file://app/views/ai_agent_assignments/new.html.erb#L1-L8)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)

## Detailed Component Analysis

### Assignment Model and Lookup
- Uniqueness: Each user can have only one active assignment.
- Active agent retrieval: Finds the associated agent only if it is active.
- Auto-dispatch flag: Exposed via a convenience method for UI and logic.

```mermaid
classDiagram
class AiAgentAssignment {
+integer user_id
+integer ai_agent_id
+boolean auto_dispatch
+for_user(user)
+agent_for(user)
+auto_dispatch?()
}
class AiAgent {
+string name
+string agent_type
+string protocol
+string endpoint_url
+string model_name
+boolean active
+has_many ai_agent_assignments
+has_many users
+has_many ai_agent_dispatches
}
AiAgentAssignment --> AiAgent : "belongs_to"
```

**Diagram sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent_assignment.rb:5-24](file://app/models/ai_agent_assignment.rb#L5-L24)
- [002_create_ai_agent_assignments.rb:3-14](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L14)

### Assignment Creation and Management
- Admin-only access ensures only administrators can create, update, or delete assignments.
- New assignment form includes user selection, agent selection, and auto-dispatch toggle.
- Validation prevents duplicate user assignments and enforces presence of agent.

```mermaid
flowchart TD
Start(["Admin opens new assignment"]) --> LoadAgents["Load active agents"]
LoadAgents --> LoadUsers["Load active users excluding existing assignees"]
LoadUsers --> Submit["Submit form with user_id, ai_agent_id, auto_dispatch"]
Submit --> Save{"Save succeeds?"}
Save --> |Yes| Notice["Flash success and redirect"]
Save --> |No| RenderForm["Re-render form with errors"]
Notice --> End(["Done"])
RenderForm --> End
```

**Diagram sources**
- [ai_agent_assignments_controller.rb:10-26](file://app/controllers/ai_agent_assignments_controller.rb#L10-L26)
- [_form.html.erb:3-21](file://app/views/ai_agent_assignments/_form.html.erb#L3-L21)

**Section sources**
- [ai_agent_assignments_controller.rb:2-8](file://app/controllers/ai_agent_assignments_controller.rb#L2-L8)
- [ai_agent_assignments_controller.rb:16-26](file://app/controllers/ai_agent_assignments_controller.rb#L16-L26)
- [_form.html.erb:5-20](file://app/views/ai_agent_assignments/_form.html.erb#L5-L20)

### Auto-Dispatch Configuration and Triggering
- Auto-dispatch is stored per assignment and exposed via a helper.
- Manual dispatch endpoint exists on the issue resource and requires project-level permission.
- Dispatch creates a background job that executes the agent and posts journal notes.

```mermaid
sequenceDiagram
participant User as "Redmine User"
participant Issue as "Issue Page"
participant CtrlDisp as "AiAgentDispatchesController"
participant AssLookup as "AiAgentAssignment"
participant Job as "AiAgentDispatchJob"
participant Agent as "AiAgent"
User->>Issue : "Open issue"
User->>CtrlDisp : "POST /issues/ : id/ai_agent_dispatches"
CtrlDisp->>AssLookup : "Find active assignment for issue.assignee"
AssLookup-->>CtrlDisp : "Assignment or nil"
alt "Assignment found"
CtrlDisp->>Job : "Enqueue dispatch(job)"
Job->>Agent : "Execute agent call"
Job-->>Issue : "Post journal notes"
CtrlDisp-->>User : "Flash notice"
else "No assignment"
CtrlDisp-->>User : "Flash error and redirect"
end
```

**Diagram sources**
- [routes.rb:13-15](file://config/routes.rb#L13-L15)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

**Section sources**
- [ai_agent_assignment.rb:22-24](file://app/models/ai_agent_assignment.rb#L22-L24)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatch_job.rb:37-57](file://app/jobs/ai_agent_dispatch_job.rb#L37-L57)

### Dispatch Execution and Tool Loop
- Dispatch records capture status, timestamps, and serialized request/response payloads.
- The job posts a “dispatch started” journal note, executes the agent, and optionally loops through tool calls using a Redmine API skill.
- Final agent response is posted as a journal note; errors are captured and logged.

```mermaid
flowchart TD
Enter(["DispatchJob.perform"]) --> FindRecords["Load Issue, Agent, Trigger"]
FindRecords --> CreateDispatch["Create AiAgentDispatch (running)"]
CreateDispatch --> PostStart["Post 'dispatch started' journal"]
PostStart --> CallAgent["Call AgentClient with issue"]
CallAgent --> ToolLoop{"Tool calls present?"}
ToolLoop --> |No| DoneText["Use agent text"]
ToolLoop --> |Yes| ExecuteTools["Execute RedmineApiSkill tool calls"]
ExecuteTools --> FeedBack["Send updated messages back to agent"]
FeedBack --> CallAgent
DoneText --> Persist["Persist request/response payloads"]
Persist --> PostDone["Post 'dispatch done' journal"]
PostDone --> Exit(["Exit"])
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-119](file://app/jobs/ai_agent_dispatch_job.rb#L7-L119)
- [ai_agent_dispatch.rb:14-24](file://app/models/ai_agent_dispatch.rb#L14-L24)

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:71-119](file://app/jobs/ai_agent_dispatch_job.rb#L71-L119)

### Permission System
- Project module defines two permissions scoped to the AI Agent module:
  - dispatch_ai_agent: allows creating, viewing dispatches for issues
  - manage_ai_agents: allows managing agents and assignments
- Admin sidebar menu entry for agents is registered under admin_menu.

```mermaid
graph LR
PermDispatch["Permission: dispatch_ai_agent"] --> CtrlDisp["AiAgentDispatchesController"]
PermManage["Permission: manage_ai_agents"] --> CtrlAss["AiAgentAssignmentsController"]
CtrlAss --> AdminMenu["Admin Menu: AI Agents"]
```

**Diagram sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [routes.rb:19-22](file://config/routes.rb#L19-L22)

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)

### Assignment Lookup Mechanisms
- For a given user, the system retrieves the active agent by joining assignments with agents and filtering by active status.
- If no active agent is found, manual dispatch fails with an error message.

```mermaid
flowchart TD
U["User"] --> Join["Join AiAgentAssignment with AiAgent"]
Join --> Filter{"ai_agents.active = true"}
Filter --> Found{"Found assignment?"}
Found --> |Yes| Agent["Return active AiAgent"]
Found --> |No| Nil["Return nil"]
```

**Diagram sources**
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)

**Section sources**
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)

### Practical Scenarios and Workflow Integration
- Scenario 1: Assign a dedicated agent to a lead developer
  - Admin creates an assignment linking the developer to an agent and enables auto-dispatch.
  - When the issue is assigned to the developer, the system automatically dispatches the agent.
- Scenario 2: Manual intervention for a specialized issue
  - An agent is assigned but auto-dispatch is disabled.
  - A user with dispatch permission manually triggers dispatch from the issue page.
- Scenario 3: Multi-agent team
  - Different developers are assigned different agents.
  - Active agent lookup ensures only enabled agents are used.

[No sources needed since this section provides conceptual scenarios]

### Assignment Conflicts and Precedence Rules
- User-to-agent cardinality: Each user has at most one assignment; attempting to create a second assignment for the same user fails validation.
- Active agent precedence: Only active agents are considered for dispatch; inactive agents are ignored.
- Auto-dispatch precedence: When enabled, automatic dispatch occurs on assignment; otherwise manual dispatch is required.

**Section sources**
- [ai_agent_assignment.rb:5](file://app/models/ai_agent_assignment.rb#L5)
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)
- [ai_agent_dispatches_controller.rb:17-25](file://app/controllers/ai_agent_dispatches_controller.rb#L17-L25)

## Dependency Analysis
- Controllers depend on models for data access and on jobs for background processing.
- Models encapsulate business rules, validations, and lookup helpers.
- Routes connect endpoints to controllers.
- Settings and permissions are declared in the plugin initializer.

```mermaid
graph TB
ROUTES["Routes"] --> CTRL_ASS["AiAgentAssignmentsController"]
ROUTES --> CTRL_DISP["AiAgentDispatchesController"]
CTRL_ASS --> MODEL_ASS["AiAgentAssignment"]
CTRL_ASS --> MODEL_AGENT["AiAgent"]
CTRL_DISP --> MODEL_DISP["AiAgentDispatch"]
CTRL_DISP --> MODEL_ASS
MODEL_ASS --> MODEL_AGENT
CTRL_DISP --> JOB["AiAgentDispatchJob"]
INIT["init.rb"] --> ROUTES
INIT --> CTRL_ASS
INIT --> CTRL_DISP
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [init.rb:1-31](file://init.rb#L1-L31)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:1-31](file://init.rb#L1-L31)

## Performance Considerations
- Background processing: Dispatches run asynchronously via ActiveJob to avoid blocking web requests.
- Retries: Transient agent errors are retried with exponential backoff.
- Payload logging: Request/response payloads are persisted as JSON for auditing and debugging.
- Indexes: Database indexes on assignment and dispatch tables improve lookup performance.

**Section sources**
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)
- [003_create_ai_agent_dispatches.rb:16-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L16-L22)

## Troubleshooting Guide
- No agent assigned to assignee
  - Symptom: Manual dispatch fails with an error when no active assignment exists for the assignee.
  - Resolution: Create an assignment for the user and ensure the agent is active.
  - Reference: [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- Missing records during dispatch
  - Symptom: Warning logged if issue, agent, or trigger user is missing.
  - Resolution: Verify records exist and permissions are correct.
  - Reference: [ai_agent_dispatch_job.rb:12-15](file://app/jobs/ai_agent_dispatch_job.rb#L12-L15)
- Dispatch errors
  - Symptom: Dispatch status becomes error with captured payload.
  - Resolution: Inspect request/response payloads and agent configuration.
  - Reference: [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135), [ai_agent_dispatch.rb:12-18](file://app/models/ai_agent_dispatch.rb#L12-L18)
- Plugin settings
  - Ensure plugin is enabled and base URL is configured.
  - Reference: [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31), [init.rb:12-16](file://init.rb#L12-L16)

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [ai_agent_dispatch_job.rb:12-15](file://app/jobs/ai_agent_dispatch_job.rb#L12-L15)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [ai_agent_dispatch.rb:12-18](file://app/models/ai_agent_dispatch.rb#L12-L18)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [init.rb:12-16](file://init.rb#L12-L16)

## Conclusion
The User Assignment System provides a robust framework for associating Redmine users with AI agents, enabling both manual and automatic dispatch workflows. Administrators control assignments and permissions, while the system’s lookup and dispatch mechanisms ensure reliable, auditable, and retryable processing of issues.

## Appendices

### Database Schema Overview
- ai_agent_assignments: user_id, ai_agent_id, auto_dispatch, timestamps; unique index on user_id; foreign keys to users and ai_agents.
- ai_agent_dispatches: issue_id, ai_agent_id, triggered_by, status, request/response payloads, journal_id, timestamps; indexes on issue, agent, status, triggered_by; foreign keys to issues and ai_agents.

**Section sources**
- [002_create_ai_agent_assignments.rb:3-14](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L14)
- [003_create_ai_agent_dispatches.rb:3-22](file://db/migrate/003_create_ai_agent_dispatches.rb#L3-L22)