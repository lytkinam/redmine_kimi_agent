# Auto-Dispatch Configuration

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [_form.html.erb](file://app/views/ai_agent_assignments/_form.html.erb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the auto-dispatch configuration system that enables automatic AI agent processing when issues are assigned to users. It covers how to enable and configure automatic triggering, the role of the auto_dispatch parameter, integration with Redmine’s hook system, and how issue assignments trigger automatic dispatch jobs. It also provides configuration examples, timing considerations, error handling, and troubleshooting guidance.

## Project Structure
The auto-dispatch system spans plugin registration, Redmine hooks, models, controllers, jobs, settings, and database migrations. The following diagram shows the high-level structure and relationships.

```mermaid
graph TB
subgraph "Plugin Registration"
INIT["init.rb"]
ENTRY["lib/redmine_ai_agent.rb"]
end
subgraph "Redmine Hooks"
HOOKS["lib/redmine_ai_agent/hooks.rb"]
end
subgraph "Controllers"
CTRL_ASS["app/controllers/ai_agent_assignments_controller.rb"]
end
subgraph "Models"
MODEL_ASS["app/models/ai_agent_assignment.rb"]
MODEL_DISP["app/models/ai_agent_dispatch.rb"]
end
subgraph "Jobs"
JOB["app/jobs/ai_agent_dispatch_job.rb"]
end
subgraph "Settings & Views"
SETT["app/views/settings/_ai_agent_settings.html.erb"]
FORM["app/views/ai_agent_assignments/_form.html.erb"]
end
subgraph "Routes"
ROUTES["config/routes.rb"]
end
subgraph "Migrations"
MIG_ASS["db/migrate/002_create_ai_agent_assignments.rb"]
MIG_DISP["db/migrate/003_create_ai_agent_dispatches.rb"]
end
INIT --> ENTRY
ENTRY --> HOOKS
HOOKS --> JOB
CTRL_ASS --> MODEL_ASS
MODEL_ASS --> JOB
MODEL_ASS --> HOOKS
ROUTES --> CTRL_ASS
SETT --> INIT
FORM --> CTRL_ASS
MIG_ASS --> MODEL_ASS
MIG_DISP --> MODEL_DISP
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-73](file://lib/redmine_ai_agent/hooks.rb#L1-L73)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-73](file://lib/redmine_ai_agent/hooks.rb#L1-L73)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

## Core Components
- Plugin registration and settings: Defines plugin metadata, default settings, permissions, and admin menu entries. Settings include an enabled flag and other configuration keys.
- Hook listener: Subscribes to Redmine’s issue lifecycle events to detect when issues are edited or created and whether the assignee changed.
- Assignment model and controller: Stores per-user AI agent assignments and exposes the auto_dispatch toggle used to enable automatic dispatch.
- Dispatch job: Executes the AI agent call, manages retries, posts journal updates, and persists request/response payloads.
- Routes and views: Expose admin screens for managing assignments and settings, and inject UI panels into issue pages.

Key configuration parameters:
- Plugin setting “enabled”: Controls whether the auto-dispatch system is active globally.
- Assignment field “auto_dispatch”: Enables automatic dispatch when an issue is assigned to a user.
- Plugin setting “redmine_api_base_url”: Required for the agent to call Redmine’s API during tool-use loops.
- Plugin setting “default_timeout”: Configures default timeouts for agent interactions.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [hooks.rb:51-71](file://lib/redmine_ai_agent/hooks.rb#L51-L71)
- [ai_agent_assignments_controller.rb:52-54](file://app/controllers/ai_agent_assignments_controller.rb#L52-L54)
- [ai_agent_assignment.rb:22-24](file://app/models/ai_agent_assignment.rb#L22-L24)
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Architecture Overview
The auto-dispatch system integrates with Redmine’s hook infrastructure to monitor issue updates and creations. When an issue is assigned to a user with an active AI agent and auto_dispatch enabled, the system schedules a background job to process the issue automatically.

```mermaid
sequenceDiagram
participant User as "Redmine User"
participant Hooks as "RedmineAiAgent : : Hooks"
participant Assign as "AiAgentAssignment"
participant Job as "AiAgentDispatchJob"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
User->>Hooks : "Edit/Create Issue"
Hooks->>Hooks : "plugin_enabled?"
Hooks->>Assign : "Find active assignment for assignee"
Assign-->>Hooks : "Assignment with auto_dispatch=true"
Hooks->>Job : "perform_later(issue_id, agent_id, triggered_by)"
Job->>Job : "Create dispatch record<br/>Post 'started' journal"
Job->>Agent : "call(issue, triggered_by)"
Agent-->>Job : "Initial result"
Job->>Skill : "Execute tool calls (up to 10 iterations)"
Skill-->>Job : "Tool results"
Job->>Agent : "Send updated messages"
Agent-->>Job : "Final text"
Job->>Job : "Persist payloads<br/>Post 'done' journal"
```

**Diagram sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_assignment.rb:13-24](file://app/models/ai_agent_assignment.rb#L13-L24)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

## Detailed Component Analysis

### Auto-Dispatch Parameter and Its Impact
- Location: The assignment form exposes a checkbox labeled “auto_dispatch”.
- Behavior: When true, the hook-based system triggers automatic dispatch upon eligible issue changes.
- Persistence: Stored in the ai_agent_assignments table with a boolean default of false.

Configuration steps:
- Enable the plugin globally via the settings screen.
- Create an assignment for a user and select an active AI agent.
- Toggle “auto_dispatch” to true.
- Save the assignment.

Effects:
- Automatic dispatch occurs when an issue is edited and the assignee changed, or when a newly created issue is assigned.
- Manual dispatch remains available via the issue page panel.

**Section sources**
- [_form.html.erb:16-20](file://app/views/ai_agent_assignments/_form.html.erb#L16-L20)
- [002_create_ai_agent_assignments.rb:6](file://db/migrate/002_create_ai_agent_assignments.rb#L6)
- [ai_agent_assignment.rb:22-24](file://app/models/ai_agent_assignment.rb#L22-L24)
- [ai_agent_assignments_controller.rb:52-54](file://app/controllers/ai_agent_assignments_controller.rb#L52-L54)

### Redmine Hook Integration
- Hook points:
  - After editing an issue (save succeeds): Triggers if the assignee changed.
  - After creating a new issue: Triggers if the issue has an assignee.
- Activation checks:
  - Global plugin enabled flag.
  - Active assignment exists for the assignee.
  - Assignment has auto_dispatch enabled.
- Action: Schedules AiAgentDispatchJob with issue, agent, and trigger user IDs.

```mermaid
flowchart TD
Start(["Issue Edit/New Event"]) --> Enabled{"Plugin enabled?"}
Enabled --> |No| End(["Exit"])
Enabled --> |Yes| AssigneeCheck["Has assignee?"]
AssigneeCheck --> |No| End
AssigneeCheck --> |Yes| FindAssn["Find active assignment"]
FindAssn --> AssnFound{"Assignment found<br/>with auto_dispatch?"}
AssnFound --> |No| End
AssnFound --> |Yes| Schedule["Schedule AiAgentDispatchJob"]
Schedule --> End
```

**Diagram sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

**Section sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:51-71](file://lib/redmine_ai_agent/hooks.rb#L51-L71)

### Dispatch Job Execution and Tool Loop
- Initialization: Loads records, creates a dispatch record, posts a “started” journal note.
- Agent call: Invokes the agent client with the issue and triggered user context.
- Tool loop: Executes tool calls against Redmine’s API using the assignee’s API key and configured base URL, up to ten iterations.
- Completion: Persists request/response payloads, posts a “done” journal note, logs duration.
- Error handling: Categorizes errors, posts an “error” journal note, and leverages ActiveJob retries.

```mermaid
flowchart TD
Enter(["perform(issue_id, agent_id, triggered_by)"]) --> Load["Load Issue/Agent/User"]
Load --> Valid{"Records found?"}
Valid --> |No| LogWarn["Log warning and exit"]
Valid --> |Yes| CreateDisp["Create dispatch record"]
CreateDisp --> JournalStart["Post 'started' journal"]
JournalStart --> CallAgent["Call AgentClient"]
CallAgent --> ToolLoop{"Tool calls present?"}
ToolLoop --> |No| DoneText["Use final text"]
ToolLoop --> |Yes| ExecTools["Execute tools via RedmineApiSkill"]
ExecTools --> CallAgent
DoneText --> Persist["Persist payloads<br/>Post 'done' journal"]
Persist --> Exit(["Exit"])
LogWarn --> Exit
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

### Settings and Permissions
- Plugin settings:
  - enabled: Boolean flag controlling global activation.
  - redmine_api_base_url: Base URL for Redmine API access during tool calls.
  - default_timeout: Default timeout value for agent interactions.
- Permissions:
  - dispatch_ai_agent: Allows creating and viewing dispatches for issues.
  - manage_ai_agents: Allows managing agents and assignments.

These settings and permissions are registered in the plugin initializer and exposed in the admin settings UI.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [init.rb:24-29](file://init.rb#L24-L29)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

### Database Schema and Relationships
- ai_agent_assignments: Links users to AI agents and stores auto_dispatch flag.
- ai_agent_dispatches: Records dispatch executions, statuses, and payloads.

```mermaid
erDiagram
AI_AGENT_ASSIGNMENTS {
integer user_id
integer ai_agent_id
boolean auto_dispatch
datetime created_at
datetime updated_at
}
AI_AGENT_DISPATCHES {
integer issue_id
integer ai_agent_id
integer triggered_by
string status
text request_payload
text response_payload
integer journal_id
datetime dispatched_at
datetime completed_at
datetime created_at
datetime updated_at
}
USERS ||--o{ AI_AGENT_ASSIGNMENTS : "assigns"
AI_AGENTS ||--o{ AI_AGENT_ASSIGNMENTS : "has"
ISSUES ||--o{ AI_AGENT_DISPATCHES : "dispatched_for"
AI_AGENTS ||--o{ AI_AGENT_DISPATCHES : "executed_by"
```

**Diagram sources**
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

**Section sources**
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

## Dependency Analysis
- Hook registration depends on plugin initialization and settings.
- Hooks depend on assignment lookup and the auto_dispatch flag.
- Dispatch job depends on agent client, tool skill, and Redmine API settings.
- Controllers depend on models and enforce permissions.
- Routes connect admin and per-issue dispatch endpoints.

```mermaid
graph LR
INIT["init.rb"] --> REG["Plugin Settings & Permissions"]
REG --> HOOKS["lib/redmine_ai_agent/hooks.rb"]
HOOKS --> ASSN["ai_agent_assignment.rb"]
HOOKS --> JOB["ai_agent_dispatch_job.rb"]
CTRL["ai_agent_assignments_controller.rb"] --> ASSN
ROUTES["config/routes.rb"] --> CTRL
SETT["settings/_ai_agent_settings.html.erb"] --> INIT
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-73](file://lib/redmine_ai_agent/hooks.rb#L1-L73)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-73](file://lib/redmine_ai_agent/hooks.rb#L1-L73)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Performance Considerations
- Background processing: Dispatches run asynchronously via ActiveJob, preventing UI delays.
- Retries: Transient agent errors are retried with polynomial backoff to reduce flakiness.
- Tool loop limit: Maximum ten iterations prevent runaway tool usage.
- Payload persistence: Request/response bodies are stored; consider log rotation and storage policies.
- Queue configuration: Ensure queues are tuned for workload volume.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Auto-dispatch does not trigger:
  - Verify plugin “enabled” setting is true.
  - Confirm the assignee has an active assignment with “auto_dispatch” checked.
  - Check that the issue edit actually changed the assignee.
- Dispatch fails immediately:
  - Review the “error” journal note posted by the job.
  - Inspect job logs for raised exceptions and backtraces.
- Tool loop errors:
  - Ensure “redmine_api_base_url” is set and reachable.
  - Confirm the assignee’s API key is available and valid.
- Retries exhausted:
  - Investigate network timeouts and backend availability.
  - Adjust “default_timeout” setting if appropriate.

Operational tips:
- Monitor ActiveJob queue and failed jobs.
- Validate agent endpoint connectivity and credentials.
- Limit concurrent dispatches if system resources are constrained.

**Section sources**
- [hooks.rb:51-71](file://lib/redmine_ai_agent/hooks.rb#L51-L71)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Conclusion
The auto-dispatch system provides a robust, hook-driven mechanism to automatically process assigned issues using configured AI agents. By enabling the plugin, assigning agents to users, and toggling auto_dispatch, teams can automate routine workflows. Proper configuration of settings, careful handling of errors, and awareness of timing and performance characteristics ensure reliable operation.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Configuration Examples and Scenarios
- Scenario A: Enable auto-dispatch for a single user
  - Steps: Create an assignment for the user with an active agent; set auto_dispatch to true.
  - Effect: Every time the user is assigned to an issue (or the issue is edited with a new assignee), a dispatch job runs automatically.
  - Reference: [ai_agent_assignments_controller.rb:52-54](file://app/controllers/ai_agent_assignments_controller.rb#L52-L54), [_form.html.erb:16-20](file://app/views/ai_agent_assignments/_form.html.erb#L16-L20)

- Scenario B: Global disable
  - Steps: Set plugin “enabled” to false.
  - Effect: Auto-dispatch hooks are inactive; manual dispatch remains available.
  - Reference: [init.rb:12-16](file://init.rb#L12-L16), [hooks.rb:51-53](file://lib/redmine_ai_agent/hooks.rb#L51-L53)

- Scenario C: Tool loop requires API access
  - Steps: Set “redmine_api_base_url”; ensure assignee has a valid API key.
  - Effect: Tool calls can query Redmine resources; otherwise, loop falls back to available text.
  - Reference: [ai_agent_dispatch_job.rb:83-84](file://app/jobs/ai_agent_dispatch_job.rb#L83-L84), [_ai_agent_settings.html.erb:11-20](file://app/views/settings/_ai_agent_settings.html.erb#L11-L20)

- Scenario D: Manual override
  - Steps: Use the “Send to AI Agent” panel on the issue page to trigger dispatch manually.
  - Effect: Works regardless of auto_dispatch setting.
  - Reference: [routes.rb:13-15](file://config/routes.rb#L13-L15)

**Section sources**
- [ai_agent_assignments_controller.rb:52-54](file://app/controllers/ai_agent_assignments_controller.rb#L52-L54)
- [_form.html.erb:16-20](file://app/views/ai_agent_assignments/_form.html.erb#L16-L20)
- [init.rb:12-16](file://init.rb#L12-L16)
- [hooks.rb:51-53](file://lib/redmine_ai_agent/hooks.rb#L51-L53)
- [ai_agent_dispatch_job.rb:83-84](file://app/jobs/ai_agent_dispatch_job.rb#L83-L84)
- [_ai_agent_settings.html.erb:11-20](file://app/views/settings/_ai_agent_settings.html.erb#L11-L20)
- [routes.rb:13-15](file://config/routes.rb#L13-L15)