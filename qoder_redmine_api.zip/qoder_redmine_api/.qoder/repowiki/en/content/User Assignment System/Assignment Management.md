# Assignment Management

<cite>
**Referenced Files in This Document**
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [routes.rb](file://config/routes.rb)
- [_form.html.erb](file://app/views/ai_agent_assignments/_form.html.erb)
- [new.html.erb](file://app/views/ai_agent_assignments/new.html.erb)
- [edit.html.erb](file://app/views/ai_agent_assignments/edit.html.erb)
- [index.html.erb](file://app/views/ai_agent_assignments/index.html.erb)
- [en.yml](file://config/locales/en.yml)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the assignment management functionality for AI agent–user pairings. It covers the complete CRUD lifecycle for assignments, the form interface and validation rules, the assignment lookup process, and how the system prevents duplicate assignments for the same user. It also provides step-by-step examples for creating assignments via the admin interface, handling validation errors, and resolving assignment conflicts. Finally, it documents the relationships among users, agents, and assignments and how data integrity is maintained.

## Project Structure
Assignment management spans controllers, models, database migrations, views, and routing. The controller orchestrates CRUD actions, the model defines validations and lookup helpers, the migration creates the underlying table and constraints, the views render the forms, and the routes expose the endpoints.

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentAssignmentsController<br/>actions: index, new, create, edit, update, destroy"]
end
subgraph "Models"
M1["AiAgentAssignment<br/>validations, associations, helpers"]
M2["AiAgent<br/>associations, scopes, helpers"]
end
subgraph "Views"
V1["_form.html.erb<br/>shared assignment form"]
V2["new.html.erb<br/>create assignment page"]
V3["edit.html.erb<br/>edit assignment page"]
V4["index.html.erb<br/>list assignments"]
end
subgraph "Database"
D1["002_create_ai_agent_assignments.rb<br/>table, indexes, foreign keys"]
end
subgraph "Routing"
R1["routes.rb<br/>resources :ai_agent_assignments"]
end
C1 --> M1
C1 --> M2
V1 --> C1
V2 --> C1
V3 --> C1
V4 --> C1
M1 --> D1
M2 --> D1
R1 --> C1
```

**Diagram sources**
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)
- [new.html.erb:1-8](file://app/views/ai_agent_assignments/new.html.erb#L1-L8)
- [edit.html.erb:1-8](file://app/views/ai_agent_assignments/edit.html.erb#L1-L8)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-L39)

**Section sources**
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)

## Core Components
- AiAgentAssignment model
  - Associations: belongs_to :user, belongs_to :ai_agent
  - Validations: presence and uniqueness of user_id; presence of ai_agent_id
  - Helpers: for_user(user), agent_for(user), auto_dispatch?
- AiAgent model
  - Associations: has_many :ai_agent_assignments, through: :users, has_many :ai_agent_dispatches
  - Scope: active
- AiAgentAssignmentsController
  - Actions: index, new, create, edit, update, destroy
  - Strong parameters: user_id, ai_agent_id, auto_dispatch
  - Pre-population: agents list, users list excluding those already assigned
- Views
  - Shared form partial renders user selection, agent selection, and auto_dispatch checkbox
  - New/Edit pages wrap the form partial and submit buttons
  - Index lists assignments with edit/delete controls

**Section sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)
- [new.html.erb:1-8](file://app/views/ai_agent_assignments/new.html.erb#L1-L8)
- [edit.html.erb:1-8](file://app/views/ai_agent_assignments/edit.html.erb#L1-L8)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-L39)

## Architecture Overview
The assignment management subsystem follows Rails conventions:
- Routes expose REST endpoints for assignments
- Controller handles presentation and persistence
- Model encapsulates business rules and lookups
- Views render forms and listings
- Database enforces referential integrity and uniqueness

```mermaid
sequenceDiagram
participant Admin as "Admin User"
participant Routes as "Rails Routes"
participant Ctrl as "AiAgentAssignmentsController"
participant Model as "AiAgentAssignment"
participant Agent as "AiAgent"
participant DB as "Database"
Admin->>Routes : "GET /ai_agent_assignments"
Routes->>Ctrl : "index"
Ctrl->>DB : "SELECT assignments JOIN users, ai_agents ORDER by users.login"
DB-->>Ctrl : "assignments collection"
Ctrl-->>Admin : "render index"
Admin->>Routes : "GET /ai_agent_assignments/new"
Routes->>Ctrl : "new"
Ctrl->>DB : "SELECT active agents"
Ctrl->>DB : "SELECT active users WHERE user_id NOT IN (assignments)"
DB-->>Ctrl : "agents, users"
Ctrl-->>Admin : "render new form"
Admin->>Routes : "POST /ai_agent_assignments"
Routes->>Ctrl : "create(params)"
Ctrl->>Model : "new(params) + save"
alt "save succeeds"
Model->>DB : "INSERT assignment"
DB-->>Model : "success"
Ctrl-->>Admin : "redirect to index"
else "save fails"
Model-->>Ctrl : "validation errors"
Ctrl-->>Admin : "render new with errors"
end
```

**Diagram sources**
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [ai_agent_assignments_controller.rb:4-48](file://app/controllers/ai_agent_assignments_controller.rb#L4-L48)
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)

## Detailed Component Analysis

### Model: AiAgentAssignment
- Responsibilities
  - Enforce uniqueness of user assignments via presence and uniqueness validations
  - Provide convenience lookups: for_user(user) and agent_for(user)
  - Expose auto_dispatch flag for runtime behavior
- Integrity
  - Database index on user_id ensures uniqueness
  - Foreign keys to users and ai_agents maintain referential integrity

```mermaid
classDiagram
class AiAgentAssignment {
+for_user(user)
+agent_for(user)
+auto_dispatch?()
}
class AiAgent {
+has_many ai_agent_assignments
+has_many users
+has_many ai_agent_dispatches
+scope active
}
AiAgentAssignment --> AiAgent : "belongs_to"
```

**Diagram sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:5-7](file://app/models/ai_agent.rb#L5-L7)

**Section sources**
- [ai_agent_assignment.rb:5-24](file://app/models/ai_agent_assignment.rb#L5-L24)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)

### Controller: AiAgentAssignmentsController
- Actions and responsibilities
  - index: loads assignments with associated user and agent, and preps agent/user dropdown lists
  - new: prepares a blank assignment and pre-filters users who are not already assigned
  - create: persists the assignment; on failure, re-renders the form with errors
  - edit: loads an existing assignment and available agents
  - update: updates an existing assignment; on failure, re-renders edit with errors
  - destroy: deletes an assignment and redirects to index
- Security and permissions
  - Uses a before_action requiring admin access for all actions
- Strong parameters
  - Permit user_id, ai_agent_id, auto_dispatch

```mermaid
flowchart TD
Start([Action Entry]) --> LoadLists["Load agents and users lists"]
LoadLists --> Action{"Action?"}
Action --> |new| RenderNew["Render new form"]
Action --> |create| Save["Build and save assignment"]
Save --> Saved{"Saved?"}
Saved --> |Yes| RedirectIndex["Redirect to index"]
Saved --> |No| RenderNewWithErrors["Render new with errors"]
Action --> |edit| LoadAssignment["Find assignment"]
LoadAssignment --> RenderEdit["Render edit form"]
Action --> |update| FindAndUpdate["Find and update assignment"]
FindAndUpdate --> Updated{"Updated?"}
Updated --> |Yes| RedirectIndex
Updated --> |No| RenderEditWithErrors["Render edit with errors"]
Action --> |destroy| Delete["Find and destroy assignment"]
Delete --> RedirectIndex
```

**Diagram sources**
- [ai_agent_assignments_controller.rb:4-48](file://app/controllers/ai_agent_assignments_controller.rb#L4-L48)

**Section sources**
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)

### Views: Assignment Forms and Listing
- Shared form partial (_form.html.erb)
  - Renders user selection via collection_select
  - Renders agent selection via collection_select
  - Renders auto_dispatch checkbox with help text
- New page (new.html.erb)
  - Wraps the shared form partial and provides a submit button and cancel link
- Edit page (edit.html.erb)
  - Wraps the shared form partial and provides a save button and cancel link
- Index page (index.html.erb)
  - Lists assignments with user, agent, auto_dispatch indicator, protocol, and edit/delete actions

```mermaid
sequenceDiagram
participant Admin as "Admin User"
participant View as "Form View"
participant Ctrl as "Controller"
participant Model as "AiAgentAssignment"
Admin->>View : "Open new assignment form"
View->>Ctrl : "GET new"
Ctrl-->>View : "agents, users (filtered)"
View-->>Admin : "Render form"
Admin->>View : "Submit form"
View->>Ctrl : "POST create(params)"
Ctrl->>Model : "new(params) + save"
alt "valid"
Model-->>Ctrl : "success"
Ctrl-->>Admin : "redirect to index"
else "invalid"
Model-->>Ctrl : "errors"
Ctrl-->>Admin : "render new with errors"
end
```

**Diagram sources**
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)
- [new.html.erb:1-8](file://app/views/ai_agent_assignments/new.html.erb#L1-L8)
- [edit.html.erb:1-8](file://app/views/ai_agent_assignments/edit.html.erb#L1-L8)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-L39)
- [ai_agent_assignments_controller.rb:10-26](file://app/controllers/ai_agent_assignments_controller.rb#L10-L26)

**Section sources**
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)
- [new.html.erb:1-8](file://app/views/ai_agent_assignments/new.html.erb#L1-L8)
- [edit.html.erb:1-8](file://app/views/ai_agent_assignments/edit.html.erb#L1-L8)
- [index.html.erb:1-39](file://app/views/ai_agent_assignments/index.html.erb#L1-L39)

### Validation Rules and Duplicate Prevention
- Model-level validations
  - user_id: presence and uniqueness enforced
  - ai_agent_id: presence enforced
- Database-level enforcement
  - Unique index on user_id prevents duplicates at the storage level
  - Foreign keys ensure referential integrity
- Controller-level prevention
  - Users list in new action excludes currently assigned users, reducing accidental duplicates

```mermaid
flowchart TD
Start([Create Assignment]) --> Validate["Validate params"]
Validate --> UserPresent{"user_id present?"}
UserPresent --> |No| ErrorUser["Show validation error"]
UserPresent --> |Yes| UserUnique{"user_id unique?"}
UserUnique --> |No| ErrorDuplicate["Show duplicate error"]
UserUnique --> |Yes| AgentPresent{"ai_agent_id present?"}
AgentPresent --> |No| ErrorAgent["Show validation error"]
AgentPresent --> |Yes| Persist["Persist record"]
Persist --> Done([Success])
ErrorUser --> Done
ErrorDuplicate --> Done
ErrorAgent --> Done
```

**Diagram sources**
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb#L13)

**Section sources**
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb#L13)

### Assignment Lookup and Active Agent Resolution
- Lookup helpers
  - for_user(user): finds an assignment for a given user (nil if none)
  - agent_for(user): finds the active agent assigned to a user by joining AiAgent
- Purpose
  - Simplifies downstream logic to resolve which agent is active for a given user

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant Model as "AiAgentAssignment"
participant DB as "Database"
Caller->>Model : "agent_for(user)"
Model->>DB : "JOIN ai_agents WHERE user = user AND ai_agents.active = true"
DB-->>Model : "first match or nil"
Model-->>Caller : "ai_agent or nil"
```

**Diagram sources**
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)

**Section sources**
- [ai_agent_assignment.rb:9-20](file://app/models/ai_agent_assignment.rb#L9-L20)

### Step-by-Step Examples

#### Creating an Assignment via Admin Interface
1. Navigate to the Assignments list page.
2. Click the “Assign Agent to User” link to open the new assignment form.
3. Select a user from the dropdown (users already assigned are excluded).
4. Select an agent from the dropdown.
5. Optionally enable “Auto-dispatch on assignment.”
6. Submit the form.
7. On success, the system redirects to the Assignments list; on validation errors, the form re-renders with error messages.

Key behaviors:
- The user list excludes those with existing assignments.
- Validation errors are surfaced via the form’s error rendering.

**Section sources**
- [index.html.erb](file://app/views/ai_agent_assignments/index.html.erb#L3)
- [new.html.erb:1-8](file://app/views/ai_agent_assignments/new.html.erb#L1-L8)
- [_form.html.erb:1-22](file://app/views/ai_agent_assignments/_form.html.erb#L1-L22)
- [ai_agent_assignments_controller.rb:10-26](file://app/controllers/ai_agent_assignments_controller.rb#L10-L26)

#### Handling Validation Errors
- If user_id is missing or already assigned, the model raises a validation error.
- If ai_agent_id is missing, the model raises a validation error.
- The controller re-renders the new or edit form with error messages displayed by the shared error partial.

Resolution steps:
- Correct selections in the form.
- Retry submission.

**Section sources**
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [ai_agent_assignments_controller.rb:16-26](file://app/controllers/ai_agent_assignments_controller.rb#L16-L26)
- [_form.html.erb](file://app/views/ai_agent_assignments/_form.html.erb#L1)

#### Managing Assignment Conflicts
- Duplicate user assignment is prevented by:
  - Model validation on user_id uniqueness
  - Database unique index on user_id
  - Controller filtering out assigned users in the new action
- If a conflict occurs, the model validation triggers and the form displays an error; fix by selecting another user or removing the conflicting assignment.

**Section sources**
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb#L10)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb#L13)

### Relationship Between Users, Agents, and Assignments
- AiAgentAssignment is the join entity linking User and AiAgent.
- AiAgentAssignment belongs_to both User and AiAgent.
- AiAgent has many assignments and users via assignments.
- The system maintains referential integrity via foreign keys and enforces uniqueness of user assignments via a unique index and validation.

```mermaid
erDiagram
USERS {
int id PK
string login
string name
}
AI_AGENTS {
int id PK
string name
boolean active
}
AI_AGENT_ASSIGNMENTS {
int id PK
int user_id FK
int ai_agent_id FK
boolean auto_dispatch
}
USERS ||--o{ AI_AGENT_ASSIGNMENTS : "has_many assignments"
AI_AGENTS ||--o{ AI_AGENT_ASSIGNMENTS : "has_many assignments"
AI_AGENT_ASSIGNMENTS }o--|| USERS : "belongs_to"
AI_AGENT_ASSIGNMENTS }o--|| AI_AGENTS : "belongs_to"
```

**Diagram sources**
- [002_create_ai_agent_assignments.rb:3-13](file://db/migrate/002_create_ai_agent_assignments.rb#L3-L13)
- [ai_agent_assignment.rb:2-3](file://app/models/ai_agent_assignment.rb#L2-L3)
- [ai_agent.rb:5-6](file://app/models/ai_agent.rb#L5-L6)

**Section sources**
- [ai_agent_assignment.rb:2-3](file://app/models/ai_agent_assignment.rb#L2-L3)
- [ai_agent.rb:5-6](file://app/models/ai_agent.rb#L5-L6)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)

## Dependency Analysis
- Controller depends on:
  - AiAgentAssignment model for persistence and queries
  - AiAgent model for agent availability
  - Database for constraints and joins
- Views depend on controller-provided instance variables and localization keys.
- Routes depend on controller actions.

```mermaid
graph LR
Routes["routes.rb"] --> Ctrl["AiAgentAssignmentsController"]
Ctrl --> Model["AiAgentAssignment"]
Ctrl --> Agent["AiAgent"]
Model --> DB["Database Constraints"]
Agent --> DB
Views["Views"] --> Ctrl
Locales["en.yml"] --> Views
```

**Diagram sources**
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Performance Considerations
- Index on user_id in assignments supports fast uniqueness checks and lookup by user.
- JOINs in agent_for(user) are efficient due to the active scope and single-field filter.
- Using includes in index action reduces N+1 queries when rendering assignment lists.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Duplicate assignment error
  - Cause: Attempting to assign a second agent to the same user
  - Resolution: Remove the existing assignment or choose a different user
  - Prevention: The controller filters users in new; rely on model/database uniqueness
- Missing agent or user
  - Cause: ai_agent_id or user_id missing
  - Resolution: Select valid entries from dropdowns; ensure agents/users exist and are active
- Auto-dispatch confusion
  - Verify auto_dispatch flag is set appropriately; consult the assignment list for indicators
- Localization and labels
  - Confirm locale keys exist for field names and hints

**Section sources**
- [ai_agent_assignment.rb:5-6](file://app/models/ai_agent_assignment.rb#L5-L6)
- [002_create_ai_agent_assignments.rb:10-13](file://db/migrate/002_create_ai_agent_assignments.rb#L10-L13)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb#L13)
- [en.yml:52-67](file://config/locales/en.yml#L52-L67)

## Conclusion
Assignment management provides a secure, validated pathway to bind users to AI agents with strong uniqueness guarantees. The controller, model, database, and views collaborate to prevent duplicates, surface errors clearly, and support efficient lookup of active agents per user. Administrators can confidently manage assignments through the provided CRUD interface, with robust safeguards against data integrity violations.