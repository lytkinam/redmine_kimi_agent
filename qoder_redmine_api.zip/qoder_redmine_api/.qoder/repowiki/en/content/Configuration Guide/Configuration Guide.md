# Configuration Guide

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This guide documents the configuration of the Redmine AI Agent Plugin. It explains the plugin settings structure, internationalization and admin menu configuration, permission model, route configuration, and security considerations. It also provides configuration examples for development, staging, and production environments, along with validation and troubleshooting guidance.

## Project Structure
The plugin consists of:
- Plugin registration and settings definition
- Routes for admin and per-issue endpoints
- Internationalization keys for UI labels and hints
- Settings UI partial rendering
- Models for agents, assignments, and dispatches
- Clients for agent communication (including Kimi Web WebSocket)
- Skills to call Redmine’s REST API on behalf of agents
- Controllers for admin and dispatch operations
- Database migrations defining the schema
- Hook integration for auto-dispatch and UI panel injection

```mermaid
graph TB
A["init.rb<br/>Plugin registration, settings, menu, permissions"] --> B["config/routes.rb<br/>Admin and per-issue routes"]
A --> C["config/locales/en.yml<br/>Internationalization keys"]
A --> D["app/views/settings/_ai_agent_settings.html.erb<br/>Settings UI"]
E["app/models/ai_agent.rb<br/>Agent model, validations, prompts"] --> F["lib/redmine_ai_agent/agent_client.rb<br/>HTTP client"]
E --> G["lib/redmine_ai_agent/kimi_web_client.rb<br/>WebSocket client"]
E --> H["lib/redmine_ai_agent/redmine_api_skill.rb<br/>Redmine API skill"]
B --> I["app/controllers/ai_agents_controller.rb<br/>Admin CRUD + test_connection"]
B --> J["app/controllers/ai_agent_dispatches_controller.rb<br/>Manual dispatch"]
K["db/migrate/*<br/>Schema migrations"] --> E
L["lib/redmine_ai_agent/hooks.rb<br/>Auto-dispatch and UI panel"] --> J
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-100](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L100)
- [004_add_kimi_web_to_ai_agents.rb:1-100](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L100)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-100](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L100)
- [004_add_kimi_web_to_ai_agents.rb:1-100](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L100)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Core Components
- Plugin settings
  - enabled: toggles the plugin globally
  - redmine_api_base_url: base URL injected into agent prompts for Redmine API access
  - default_timeout: HTTP timeout in seconds for agent requests
- Admin menu entry under Administration for managing agents and assignments
- Project-level permissions controlling dispatch and management actions
- Routes for admin CRUD and testing, plus per-issue dispatch endpoints
- Internationalization keys for labels, hints, and UI strings
- Settings UI partial rendering the three configuration fields

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [init.rb:18-22](file://init.rb#L18-L22)
- [init.rb:24-29](file://init.rb#L24-L29)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:99-104](file://config/locales/en.yml#L99-L104)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Architecture Overview
The plugin integrates with Redmine via:
- Plugin registration defines settings, menu, and permissions
- Routes expose admin endpoints and per-issue dispatch endpoints
- Controllers enforce permissions and trigger jobs
- Models encapsulate agent configuration and prompt resolution
- Clients handle agent communication (HTTP and WebSocket)
- Skills enable tool-based Redmine API calls
- Hooks enable auto-dispatch and UI panel injection

```mermaid
graph TB
subgraph "Plugin Settings"
S1["init.rb settings<br/>enabled, base_url, timeout"]
S2["Settings UI<br/>_ai_agent_settings.html.erb"]
S3["Locales<br/>en.yml keys"]
end
subgraph "Routes"
R1["Admin agents<br/>resources :ai_agents"]
R2["Assignments<br/>resources :ai_agent_assignments"]
R3["Per-issue dispatches<br/>resources :issues ... :ai_agent_dispatches"]
end
subgraph "Controllers"
C1["AiAgentsController<br/>CRUD + test_connection"]
C2["AiAgentDispatchesController<br/>manual dispatch"]
end
subgraph "Models"
M1["AiAgent<br/>validations, prompts"]
M2["AiAgentAssignment<br/>user ↔ agent"]
M3["AiAgentDispatch<br/>dispatch records"]
end
subgraph "Clients"
CL1["AgentClient<br/>HTTP client"]
CL2["KimiWebClient<br/>WebSocket client"]
SK["RedmineApiSkill<br/>tool calls"]
end
subgraph "Hooks"
H1["Hooks<br/>auto-dispatch + panel"]
end
S1 --> C1
S1 --> C2
S2 --> S1
S3 --> S2
R1 --> C1
R2 --> C1
R3 --> C2
C1 --> M1
C2 --> M2
C2 --> M3
M1 --> CL1
M1 --> CL2
CL1 --> SK
H1 --> C2
```

**Diagram sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Detailed Component Analysis

### Plugin Settings and Defaults
- enabled: Boolean toggle for global activation
- redmine_api_base_url: Base URL used to construct Redmine API endpoints in agent prompts
- default_timeout: Integer seconds for HTTP timeouts when calling agents

These settings are registered in the plugin and rendered in the settings UI. The UI includes labels and hints for each field.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [en.yml:99-104](file://config/locales/en.yml#L99-L104)

### Internationalization Setup
The plugin uses English localization keys for:
- Field labels and captions
- Agent type names
- Headings for forms and panels
- Links and hints
- Notices and errors
- Status labels and journal entries
- Settings labels and hints

These keys are referenced by the settings partial and various views.

**Section sources**
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

### Admin Menu Configuration
The plugin adds an “AI Agents” entry to the admin sidebar, linking to the agents index controller action. The menu entry includes an icon class.

**Section sources**
- [init.rb:18-22](file://init.rb#L18-L22)

### Permission System
Two project-level permissions are defined:
- dispatch_ai_agent: allows manual dispatch of AI agents for issues
- manage_ai_agents: allows CRUD operations on agents, assignments, and viewing related records

Controllers enforce these permissions for relevant actions.

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

### Route Configuration
- Admin endpoints:
  - Resources for ai_agents with a member action to test connections
  - Resources for ai_agent_assignments
- Per-issue endpoints:
  - Nested resources under issues for ai_agent_dispatches (create, index, show)

Controllers implement the corresponding actions and enforce permissions.

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

### Agent Model and Prompt Resolution
The AiAgent model:
- Defines agent types and protocols
- Validates presence and inclusion constraints
- Provides safe_api_key masking for serialization
- Supplies default system prompt templates per agent type
- Resolves system prompts using plugin settings (base URL and API key) and issue context

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

### HTTP Agent Client
The AgentClient:
- Chooses payload format based on protocol (chat completions vs responses)
- Builds payloads with resolved system prompt and issue context
- Sends HTTP requests to agent endpoints with Authorization header
- Applies plugin default timeout or falls back to internal default
- Parses responses and raises structured errors on failure

**Section sources**
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)

### Kimi Web WebSocket Client
The KimiWebClient:
- Manages sessions via REST and communicates via WebSocket JSON-RPC 2.0
- Handles initialization, prompt delivery, and session status
- Supports optional token-based authentication and session reuse
- Enforces a configurable timeout for session readiness

**Section sources**
- [kimi_web_client.rb:1-421](file://lib/redmine_ai_agent/kimi_web_client.rb#L1-L421)

### Redmine API Skill
The RedmineApiSkill:
- Executes tool calls server-side on behalf of agents
- Implements GET/PUT wrappers for Redmine endpoints
- Uses X-Redmine-API-Key header and respects configured timeout

**Section sources**
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

### Auto-dispatch and UI Panel
The Hooks module:
- Triggers auto-dispatch on issue creation/update when assignee exists and auto-dispatch is enabled
- Injects an “AI Agent” panel into the issue show page for quick dispatch and history

**Section sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

### Database Schema
Migrations define:
- ai_agents: agent configuration, credentials, and flags
- ai_agent_assignments: user-to-agent mapping with auto-dispatch flag
- ai_agent_dispatches: dispatch records with timestamps and status

**Section sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-100](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L100)
- [004_add_kimi_web_to_ai_agents.rb:1-100](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L100)

## Architecture Overview

```mermaid
sequenceDiagram
participant Admin as "Admin User"
participant UI as "Settings UI"
participant Plugin as "Plugin Settings"
participant Agent as "AiAgent"
participant AC as "AgentClient"
participant Skill as "RedmineApiSkill"
Admin->>UI : Configure plugin settings
UI->>Plugin : Save settings[enabled, base_url, timeout]
Admin->>Agent : Create/Edit agent (type, protocol, endpoint, model, key)
Agent->>AC : Build payload with resolved system prompt
AC->>AC : Apply timeout from settings/default
AC-->>Agent : Response text/raw/request
Agent->>Skill : Execute tool calls (when applicable)
Skill-->>Agent : Tool results
```

**Diagram sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

## Detailed Component Analysis

### Settings UI and Validation Flow
```mermaid
flowchart TD
Start(["Open Plugin Settings"]) --> Load["Load @settings from plugin registry"]
Load --> Render["Render fields:<br/>enabled, base_url, timeout"]
Render --> Submit["Submit form"]
Submit --> Validate["Validation occurs in model/controller"]
Validate --> Success["Persist settings"]
Validate --> Error["Show validation errors"]
```

**Diagram sources**
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)
- [ai_agents_controller.rb:21-47](file://app/controllers/ai_agents_controller.rb#L21-L47)

### Manual Dispatch Workflow
```mermaid
sequenceDiagram
participant User as "Logged-in User"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Agent as "AiAgent"
participant AC as "AgentClient"
User->>Ctrl : POST /issues/ : id/ai_agent_dispatches
Ctrl->>Ctrl : Authorize dispatch permission
Ctrl->>Agent : Find active assignment for assignee
Agent-->>Ctrl : Assignment found
Ctrl->>Job : Enqueue dispatch job
Job->>AC : Call agent with resolved prompt
AC-->>Job : Response text/raw/request
Job-->>User : Dispatch recorded and visible in journal
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)

### Auto-dispatch Workflow
```mermaid
sequenceDiagram
participant Hook as "Hooks"
participant Job as "AiAgentDispatchJob"
participant Agent as "AiAgent"
participant AC as "AgentClient"
Hook->>Hook : On issue save (new/edit)
Hook->>Hook : Check plugin enabled and auto-dispatch flag
Hook->>Job : Enqueue dispatch job
Job->>AC : Call agent with resolved prompt
AC-->>Job : Response text/raw/request
```

**Diagram sources**
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)

## Dependency Analysis
- Settings dependency chain:
  - Settings stored in plugin registry
  - Accessed by models for prompt resolution
  - Used by clients for timeouts and endpoint construction
- Controller dependency chain:
  - Controllers depend on models and settings
  - Controllers enforce permissions and trigger jobs
- Client dependency chain:
  - AgentClient depends on AiAgent and settings
  - KimiWebClient depends on AiAgent and settings
  - RedmineApiSkill depends on settings for base URL and timeout
- Hook dependency chain:
  - Hooks depend on settings and models to decide auto-dispatch

```mermaid
graph LR
Settings["Plugin Settings"] --> AiAgent["AiAgent"]
Settings --> AgentClient["AgentClient"]
Settings --> KimiWebClient["KimiWebClient"]
Settings --> RedmineApiSkill["RedmineApiSkill"]
AiAgent --> AgentClient
AiAgent --> KimiWebClient
AgentClient --> RedmineApiSkill
Hooks["Hooks"] --> AiAgent
Controllers["Controllers"] --> AiAgent
Controllers --> Hooks
```

**Diagram sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [agent_client.rb:202-203](file://lib/redmine_ai_agent/agent_client.rb#L202-L203)
- [kimi_web_client.rb:35](file://lib/redmine_ai_agent/kimi_web_client.rb#L35)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [hooks.rb:51-53](file://lib/redmine_ai_agent/hooks.rb#L51-L53)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [agent_client.rb:202-203](file://lib/redmine_ai_agent/agent_client.rb#L202-L203)
- [kimi_web_client.rb:35](file://lib/redmine_ai_agent/kimi_web_client.rb#L35)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [hooks.rb:51-53](file://lib/redmine_ai_agent/hooks.rb#L51-L53)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

## Performance Considerations
- Timeout tuning
  - default_timeout controls HTTP request timeouts for agent calls
  - AgentClient applies plugin default or internal default when setting is missing/non-positive
- Kimi Web session lifecycle
  - Configurable session timeout influences total dispatch latency
  - Reusing sessions can reduce overhead but may accumulate state
- Network considerations
  - Ensure agent endpoints are reachable and responsive
  - Consider read/write timeouts for both HTTP and WebSocket paths

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common configuration errors and resolutions:
- Invalid base URL
  - Ensure redmine_api_base_url ends with a slash if needed; the plugin strips trailing slashes during resolution
- Missing or invalid API key
  - For HTTP agents, Authorization header uses Bearer token; for Kimi Web, optional token passed as query parameter
- Incorrect agent type or protocol
  - Verify agent_type and protocol values match supported lists
- Timeout failures
  - Increase default_timeout or adjust agent-side limits
- Auto-dispatch not triggering
  - Confirm plugin enabled, assignment exists, and auto_dispatch flag is set
- Manual dispatch failing
  - Check dispatch permission for the user and project

Validation and error handling:
- Model validations prevent malformed agent records
- HTTP client raises structured errors on non-2xx responses, timeouts, and invalid JSON
- Kimi Web client raises specific errors for session issues and timeouts
- Redmine API skill surfaces HTTP errors and JSON parse errors

**Section sources**
- [ai_agent.rb:9-13](file://app/models/ai_agent.rb#L9-L13)
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [kimi_web_client.rb:217-229](file://lib/redmine_ai_agent/kimi_web_client.rb#L217-L229)
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)
- [hooks.rb:51-53](file://lib/redmine_ai_agent/hooks.rb#L51-L53)

## Conclusion
The Redmine AI Agent Plugin exposes a straightforward configuration surface: a global enabled flag, a base URL for Redmine API access, and a default timeout. Admins configure agents, assign them to users, and control dispatch behavior through project-level permissions. The plugin’s routes and controllers provide both manual dispatch and auto-dispatch capabilities, with robust client implementations supporting both HTTP and WebSocket agent integrations.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Configuration Examples by Environment

- Development
  - enabled: true
  - redmine_api_base_url: https://redmine.example.test
  - default_timeout: 120
  - Notes: Use a local or staging agent endpoint; keep verbose logging enabled

- Staging
  - enabled: true
  - redmine_api_base_url: https://redmine.staging.example.com
  - default_timeout: 180
  - Notes: Align timeouts with agent service SLAs; monitor error rates

- Production
  - enabled: true
  - redmine_api_base_url: https://redmine.example.com
  - default_timeout: 180–300
  - Notes: Use HTTPS endpoints; restrict agent keys; monitor latency and error budgets

[No sources needed since this section provides general guidance]

### Security Considerations
- Credential management
  - Store API keys securely; avoid exposing plaintext in logs (safe_api_key masking is applied)
  - Prefer short-lived tokens or scoped keys for agent endpoints
- Endpoint exposure
  - Restrict admin routes to authorized administrators
  - Limit manual dispatch permissions to trusted roles
- Transport security
  - Use HTTPS for agent endpoints and Redmine base URL
  - Validate agent endpoints and enforce TLS

[No sources needed since this section provides general guidance]