# Internationalization Setup

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [en.yml](file://config/locales/en.yml)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the internationalization (i18n) configuration for the Redmine AI Agent plugin. It covers how locale files are structured, how English translations are organized for plugin-specific strings, and how the plugin integrates with Redmine’s i18n system. It also provides practical guidance for adding new languages, customizing existing translations, troubleshooting missing translations, and maintaining translations across updates.

## Project Structure
The plugin organizes i18n resources under the standard Redmine convention:
- Locale YAML files are placed in config/locales/<lang>.yml
- The plugin currently ships with English (en.yml)
- Translations are accessed via Redmine’s l() helper in views and controllers, and via I18n.t() in jobs/models

```mermaid
graph TB
subgraph "Plugin i18n"
EN["config/locales/en.yml"]
end
subgraph "Views"
V1["app/views/settings/_ai_agent_settings.html.erb"]
end
subgraph "Controllers"
C1["app/controllers/ai_agent_dispatches_controller.rb"]
end
subgraph "Jobs"
J1["app/jobs/ai_agent_dispatch_job.rb"]
end
EN --> V1
EN --> C1
EN --> J1
```

**Diagram sources**
- [en.yml](file://config/locales/en.yml)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)

**Section sources**
- [init.rb](file://init.rb)
- [en.yml](file://config/locales/en.yml)

## Core Components
- Locale file organization: The plugin defines a top-level key redmine_ai_agent: under each language, it groups related translation keys into logical categories such as fields, agent_types, headings, links, hints, notices, errors, confirms, panel, statuses, journal, and settings.
- Translation access patterns:
  - Views: l('redmine_ai_agent.<category>.<key>') to render labels, hints, and settings text.
  - Controllers: l('redmine_ai_agent.<category>.<key>') for flash notices and error messages.
  - Jobs: I18n.t('redmine_ai_agent.<category>.<key>', ...) for dynamic journal entries and error reporting.
- English baseline: The en.yml file provides the canonical English strings used by the plugin.

Examples of translation keys used across the plugin:
- Fields: name, agent_type, protocol, model_name, endpoint_url, api_key, system_prompt, active, user, agent, auto_dispatch, status, triggered_by, dispatched_at, completed_at, duration, assigned_users, kimi_web_session_id, kimi_web_work_dir, kimi_web_timeout
- Agent types: hermes, pi, qoder, kimi_web, custom
- Headings: new_agent, edit_agent, assignments, new_assignment, edit_assignment, dispatch_detail, request_payload, response_payload
- Links: new_agent, manage_assignments, new_assignment, back_to_agents, edit, delete, test, view
- Hints: agent_type, protocol, endpoint_url, model_name, api_key, system_prompt, system_prompt_placeholder, auto_dispatch, select_user, select_agent, kimi_web_info, kimi_web_session_id, kimi_web_session_id_placeholder, kimi_web_work_dir, kimi_web_timeout
- Notices: no_agents, no_assignments, dispatch_enqueued
- Errors: no_agent_for_assignee
- Confirms: delete_agent, delete_assignment, dispatch
- Panel: title, dispatch_button, manual_only, no_dispatches
- Statuses: pending, running, done, error
- Journal: dispatch_started, dispatch_done, dispatch_error
- Settings: enabled, redmine_api_base_url, redmine_api_base_url_hint, default_timeout

**Section sources**
- [en.yml](file://config/locales/en.yml)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)

## Architecture Overview
The plugin relies on Redmine’s i18n infrastructure. Translations are loaded from config/locales/<lang>.yml and accessed through:
- l(): Redmine’s helper for rendering localized strings in views and controllers
- I18n.t(): Ruby’s internationalization API for programmatic lookups in jobs and models

```mermaid
sequenceDiagram
participant U as "User"
participant V as "Settings View (_ai_agent_settings.html.erb)"
participant C as "Controller (ai_agent_dispatches_controller.rb)"
participant J as "Job (ai_agent_dispatch_job.rb)"
participant L as "Locale Loader (config/locales/en.yml)"
U->>V : "Open plugin settings"
V->>L : "l('redmine_ai_agent.settings.*')"
L-->>V : "Localized label/hint"
U->>C : "Trigger dispatch"
C->>L : "l('redmine_ai_agent.notices.*' or 'redmine_ai_agent.errors.*')"
L-->>C : "Localized notice/error"
C->>J : "Enqueue job"
J->>L : "I18n.t('redmine_ai_agent.journal.*')"
L-->>J : "Localized journal messages"
```

**Diagram sources**
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [en.yml](file://config/locales/en.yml)

## Detailed Component Analysis

### Locale File Organization
The en.yml file organizes translations under the redmine_ai_agent namespace with category-based grouping. This structure enables:
- Consistent key naming across the plugin
- Easy maintenance and discoverability
- Scalable extension to additional languages

Categories and representative keys:
- fields: labels for forms and tables
- agent_types: human-readable agent identifiers
- headings: page and panel titles
- links: UI actions and navigation text
- hints: inline help and tooltips
- notices: success messages
- errors: error conditions
- confirms: confirmation dialogs
- panel: issue page panel labels
- statuses: dispatch lifecycle states
- journal: issue journal entries
- settings: plugin configuration labels and hints

**Section sources**
- [en.yml](file://config/locales/en.yml)

### Views Integration (Settings)
The settings partial uses l() to localize labels and hints for plugin configuration fields. This ensures that administrators see translated UI elements when configuring the plugin.

Key integration points:
- Checkbox label for enabling the plugin
- Field labels and info hints for base URL and timeout settings

**Section sources**
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)

### Controllers Integration (Flash Messages)
Controllers use l() to produce localized flash notices and error messages for user feedback during CRUD operations and dispatch attempts.

Representative usages:
- Successful create/update/delete notices
- Error message when no agent is assigned to the current assignee

**Section sources**
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)

### Jobs Integration (Journal Entries)
Jobs leverage I18n.t() to generate localized journal entries for dispatch lifecycle events and error reporting. Dynamic interpolation is supported via named placeholders.

Representative usages:
- Dispatch started message with agent name and timestamp
- Dispatch completed message with agent name and response
- Dispatch error message with agent name and error details

**Section sources**
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)

### Translation Key Reference
Below is a categorized reference of keys used by the plugin. Use these as anchors when adding or updating translations.

- Fields
  - name, agent_type, protocol, model_name, endpoint_url, api_key, system_prompt, active, user, agent, auto_dispatch, status, triggered_by, dispatched_at, completed_at, duration, assigned_users, kimi_web_session_id, kimi_web_work_dir, kimi_web_timeout

- Agent Types
  - hermes, pi, qoder, kimi_web, custom

- Headings
  - new_agent, edit_agent, assignments, new_assignment, edit_assignment, dispatch_detail, request_payload, response_payload

- Links
  - new_agent, manage_assignments, new_assignment, back_to_agents, edit, delete, test, view

- Hints
  - agent_type, protocol, endpoint_url, model_name, api_key, system_prompt, system_prompt_placeholder, auto_dispatch, select_user, select_agent, kimi_web_info, kimi_web_session_id, kimi_web_session_id_placeholder, kimi_web_work_dir, kimi_web_timeout

- Notices
  - no_agents, no_assignments, dispatch_enqueued

- Errors
  - no_agent_for_assignee

- Confirms
  - delete_agent, delete_assignment, dispatch

- Panel
  - title, dispatch_button, manual_only, no_dispatches

- Statuses
  - pending, running, done, error

- Journal
  - dispatch_started, dispatch_done, dispatch_error

- Settings
  - enabled, redmine_api_base_url, redmine_api_base_url_hint, default_timeout

**Section sources**
- [en.yml](file://config/locales/en.yml)

## Dependency Analysis
The plugin’s i18n depends on:
- Redmine’s i18n loader to load config/locales/<lang>.yml
- Redmine helpers (l()) in views and controllers
- Ruby I18n API (I18n.t()) in jobs

```mermaid
graph LR
EN["config/locales/en.yml"] --> L["Redmine I18n Loader"]
L --> V["Views (_ai_agent_settings.html.erb)"]
L --> C["Controllers (ai_agent_dispatches_controller.rb)"]
L --> J["Jobs (ai_agent_dispatch_job.rb)"]
```

**Diagram sources**
- [en.yml](file://config/locales/en.yml)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)

**Section sources**
- [en.yml](file://config/locales/en.yml)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)

## Performance Considerations
- Translation lookups are cached by Redmine’s i18n layer; avoid constructing long translation keys dynamically at runtime.
- Prefer passing interpolated values as hash arguments to I18n.t() to minimize string concatenation overhead.
- Keep translation keys concise and grouped to improve maintainability without impacting performance.

## Troubleshooting Guide
Common issues and resolutions:
- Missing translation fallback
  - Symptom: String appears as a key or untranslated text.
  - Cause: Key missing from the active locale file.
  - Resolution: Add the missing key under the appropriate category in config/locales/<lang>.yml.

- Wrong lookup path
  - Symptom: Translation not found.
  - Cause: Incorrect namespace or dot-separated path.
  - Resolution: Ensure the key path follows redmine_ai_agent.<category>.<key>.

- Dynamic interpolation not applied
  - Symptom: Placeholders like %{agent_name} appear literally.
  - Cause: Missing interpolation arguments.
  - Resolution: Pass a hash with named keys to I18n.t() or l().

- Locale not loading
  - Symptom: Translations not visible.
  - Cause: Locale file not placed under config/locales or incorrect filename.
  - Resolution: Confirm the file exists as config/locales/<lang>.yml and is valid YAML.

- Version compatibility
  - Symptom: Translations not applied after Redmine upgrade.
  - Cause: Locale file location or key paths changed in newer versions.
  - Resolution: Verify the plugin’s locale path and key structure match the target Redmine version.

Best practices for maintaining translations across updates:
- Track changes to en.yml and update other locale files accordingly.
- Use a diff-friendly editor to review additions and deletions.
- Keep category names and nesting consistent to ease merges.
- Test translations after plugin upgrades and Redmine updates.

**Section sources**
- [en.yml](file://config/locales/en.yml)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)

## Conclusion
The Redmine AI Agent plugin adopts a clean, category-based i18n structure under config/locales/en.yml and integrates seamlessly with Redmine’s l() and I18n.t() APIs. By following the established key categories and ensuring consistent paths, contributors can add new languages, customize existing translations, and maintain robust localization across plugin updates.