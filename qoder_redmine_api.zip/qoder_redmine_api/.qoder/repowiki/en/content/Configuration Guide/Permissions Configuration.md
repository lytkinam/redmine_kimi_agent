# Permissions Configuration

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [en.yml](file://config/locales/en.yml)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the Redmine AI Agent plugin’s permission system. It focuses on two project-level permissions:
- dispatch_ai_agent: allows users to manually trigger AI agent processing for a specific issue.
- manage_ai_agents: administrative permission to configure agents, assignments, and related resources.

It details how permissions are declared in the plugin’s project module, how they relate to controller actions, how Redmine’s permission framework applies them, and how to assign and combine permissions for effective team collaboration. It also covers permission validation, troubleshooting access issues, and best practices.

## Project Structure
The plugin defines permissions in the plugin manifest and enforces them in controllers. Controllers gate access to sensitive actions and rely on Redmine’s permission helpers to validate access against the current user and project context.

```mermaid
graph TB
subgraph "Plugin Manifest"
INIT["init.rb<br/>Defines project_module and permissions"]
end
subgraph "Controllers"
CTRL_DISPATCH["AiAgentDispatchesController<br/>Manual dispatch"]
CTRL_AGENTS["AiAgentsController<br/>Admin CRUD"]
CTRL_ASSIGN["AiAgentAssignmentsController<br/>Admin CRUD"]
end
subgraph "Models"
MODEL_AGENT["AiAgent"]
MODEL_ASSIGN["AiAgentAssignment"]
MODEL_DISPATCH["AiAgentDispatch"]
end
subgraph "Runtime"
JOB["AiAgentDispatchJob"]
HOOKS["RedmineAiAgent::Hooks"]
end
INIT --> CTRL_DISPATCH
INIT --> CTRL_AGENTS
INIT --> CTRL_ASSIGN
CTRL_DISPATCH --> MODEL_DISPATCH
CTRL_AGENTS --> MODEL_AGENT
CTRL_ASSIGN --> MODEL_ASSIGN
HOOKS --> MODEL_ASSIGN
HOOKS --> MODEL_AGENT
JOB --> MODEL_DISPATCH
JOB --> MODEL_AGENT
```

**Diagram sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)

## Core Components
- Project-level permissions:
  - dispatch_ai_agent: mapped to actions that allow manual dispatch creation and viewing dispatch records for an issue.
  - manage_ai_agents: mapped to admin actions for agents, assignments, and related resources.
- Controllers enforce permissions:
  - AiAgentDispatchesController checks dispatch permission before allowing manual dispatch.
  - AiAgentsController and AiAgentAssignmentsController use require_admin, which internally relies on Redmine’s permission system.
- Models support the permission ecosystem:
  - AiAgentAssignment connects users to agents and supports auto-dispatch logic.
  - AiAgentDispatch tracks who triggered a dispatch and the resulting outcome.

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

## Architecture Overview
The permission system integrates with Redmine’s project-level permission model. Permissions are declared in the plugin manifest and enforced in controllers. Manual dispatches require the dispatch permission, while administrative tasks require admin privileges. Auto-dispatch is controlled by assignment settings and does not bypass permission checks for manual triggers.

```mermaid
sequenceDiagram
participant U as "User"
participant C as "AiAgentDispatchesController"
participant P as "Redmine Permissions"
participant M as "AiAgentAssignment/AiAgentDispatch"
U->>C : "POST /issues/ : issue_id/ai_agent_dispatches"
C->>P : "allowed_to?( : dispatch_ai_agent, issue.project)?"
alt Allowed
P-->>C : "true"
C->>M : "Lookup assignment for assignee"
M-->>C : "Assignment exists"
C->>C : "Enqueue AiAgentDispatchJob"
C-->>U : "Flash notice and redirect"
else Not allowed
P-->>C : "false"
C-->>U : "403 Forbidden"
end
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_assignment.rb:13-20](file://app/models/ai_agent_assignment.rb#L13-L20)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

## Detailed Component Analysis

### Permission Declaration and Relationship to Controllers
- The plugin declares a project_module named ai_agent and two permissions:
  - dispatch_ai_agent: mapped to issue dispatch actions (create, index, show).
  - manage_ai_agents: mapped to agent and assignment management actions.
- Controllers:
  - AiAgentDispatchesController uses User.current.allowed_to?(:dispatch_ai_agent, issue.project) to guard manual dispatch creation.
  - AiAgentsController and AiAgentAssignmentsController use require_admin, which enforces admin-level access to administrative actions.

```mermaid
flowchart TD
Start(["Permission Check"]) --> CheckDispatch["Check :dispatch_ai_agent on issue.project"]
CheckDispatch --> Allowed{"Allowed?"}
Allowed --> |Yes| Proceed["Proceed to Action"]
Allowed --> |No| Deny["Return 403 Forbidden"]
Proceed --> Dispatch["Create Dispatch Record"]
Dispatch --> Enqueue["Enqueue AiAgentDispatchJob"]
Enqueue --> Done(["Done"])
Deny --> Done
```

**Diagram sources**
- [init.rb:26](file://init.rb#L26)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)

### Permission Enforcement in Controllers
- AiAgentDispatchesController:
  - authorize_dispatch uses allowed_to? to validate dispatch permission against the issue’s project.
  - Manual dispatch action enqueues a background job after validating assignment availability.
- AiAgentsController and AiAgentAssignmentsController:
  - Both use require_admin, ensuring only users with admin rights can access administrative actions.

```mermaid
classDiagram
class AiAgentDispatchesController {
+index()
+show()
+create()
-authorize_dispatch()
-find_issue()
}
class AiAgentsController {
+index()
+show()
+new()
+create()
+edit()
+update()
+destroy()
-find_agent()
}
class AiAgentAssignmentsController {
+index()
+new()
+create()
+edit()
+update()
+destroy()
}
AiAgentDispatchesController --> AiAgentDispatch : "creates records"
AiAgentsController --> AiAgent : "manages"
AiAgentAssignmentsController --> AiAgentAssignment : "manages"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)

**Section sources**
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)

### Permission Inheritance and Redmine Integration
- The plugin leverages Redmine’s project-level permission model:
  - Permissions are scoped to the project context of the target issue.
  - Users inherit permissions from roles assigned at the project level.
  - The dispatch permission is checked against the issue’s project, ensuring least privilege per project.
- Administrative permissions (require_admin) are enforced globally for admin-only actions.

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)

### Permission Validation and Security Implications
- Manual dispatch:
  - Requires dispatch_ai_agent on the issue’s project.
  - Fails fast with 403 if not allowed.
  - Validates that an active agent is assigned to the issue’s assignee before enqueueing.
- Administrative actions:
  - Require admin rights; unauthorized users receive 403.
- Auto-dispatch:
  - Controlled by assignment settings (auto_dispatch). It does not bypass manual permission checks; users still need dispatch permission to manually trigger dispatches.

Security implications:
- Least privilege: Users can trigger dispatches only when explicitly granted dispatch_ai_agent in the project context.
- Separation of duties: Managing agents and assignments is restricted to administrators, reducing risk of misconfiguration.
- Auditability: Dispatches are recorded with timestamps and outcomes, aiding compliance reviews.

**Section sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)
- [ai_agent_assignment.rb:22-24](file://app/models/ai_agent_assignment.rb#L22-L24)

### Examples of Permission Assignments and Team Collaboration
- Single maintainer with dispatch access:
  - Role includes dispatch_ai_agent on the project.
  - Can manually dispatch tasks for issues they own or are assigned to.
- Admin with full management:
  - Role includes manage_ai_agents and admin rights.
  - Can create/update agents, assign agents to users, and manage auto-dispatch settings.
- Cross-functional team:
  - Developers with dispatch access can trigger processing.
  - QA leads with admin rights can configure agents and monitor outcomes.
- Permission combinations:
  - Combine dispatch_ai_agent with project viewer role to allow dispatch without broader editing rights.
  - Combine manage_ai_agents with restricted roles to limit who can manage agents while others can trigger dispatches.

Note: These examples describe typical RBAC setups and do not prescribe specific role configurations; implementers should align with organizational policies.

[No sources needed since this section provides conceptual examples]

### Permission Validation and Troubleshooting
Common symptoms and resolutions:
- 403 Forbidden on manual dispatch:
  - Cause: Missing dispatch_ai_agent on the project.
  - Resolution: Grant dispatch_ai_agent to the user’s role in the project.
- Cannot access admin screens:
  - Cause: Missing admin rights or missing manage_ai_agents.
  - Resolution: Ensure the user has admin privileges or a role with manage_ai_agents.
- Dispatch button not visible:
  - Cause: Auto-dispatch disabled or no active agent assigned to the assignee.
  - Resolution: Enable auto_dispatch in the assignment or assign an active agent to the user.
- Locale messages:
  - The plugin uses localized messages for errors and notices. Verify locale keys if messages appear unexpected.

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [en.yml:74-76](file://config/locales/en.yml#L74-L76)
- [en.yml:69-72](file://config/locales/en.yml#L69-L72)

## Dependency Analysis
The permission system depends on:
- Plugin manifest declaring permissions and mapping them to controllers.
- Controllers enforcing permissions via Redmine’s allowed_to? and require_admin.
- Models supporting assignment and dispatch logic used during permission-gated operations.

```mermaid
graph LR
INIT["init.rb"] --> PERM["Permissions"]
PERM --> CTRL1["AiAgentDispatchesController"]
PERM --> CTRL2["AiAgentsController"]
PERM --> CTRL3["AiAgentAssignmentsController"]
CTRL1 --> MODEL1["AiAgentDispatch"]
CTRL2 --> MODEL2["AiAgent"]
CTRL3 --> MODEL3["AiAgentAssignment"]
HOOKS["hooks.rb"] --> MODEL3
HOOKS --> MODEL2
JOB["ai_agent_dispatch_job.rb"] --> MODEL1
JOB --> MODEL2
```

**Diagram sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

## Performance Considerations
- Permission checks are lightweight and cached by Redmine; they do not introduce significant overhead.
- Manual dispatch enqueues a background job, keeping UI responsiveness unaffected.
- Auto-dispatch occurs asynchronously and is gated by assignment settings.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Verify permission mapping:
  - Confirm dispatch_ai_agent is mapped to the intended actions in the plugin manifest.
- Check user roles:
  - Ensure the user’s role includes the required permissions for the project context.
- Validate assignment:
  - Ensure an active agent is assigned to the issue’s assignee before dispatch.
- Review controller enforcement:
  - Manual dispatch uses allowed_to?; admin actions use require_admin.
- Locale and messaging:
  - Errors and notices are localized; confirm locale entries if messages appear incorrect.

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [en.yml:74-76](file://config/locales/en.yml#L74-L76)
- [en.yml:69-72](file://config/locales/en.yml#L69-L72)

## Conclusion
The Redmine AI Agent plugin’s permission system is intentionally minimal and aligned with Redmine’s project-level permission model. Two permissions cover the core use cases:
- dispatch_ai_agent: enables manual dispatch for authorized users.
- manage_ai_agents: restricts administrative functions to trusted users.

By combining these permissions with Redmine’s roles and projects, teams can achieve secure, auditable automation with clear separation of duties.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Appendix A: Permission-to-Action Mapping
- dispatch_ai_agent
  - Actions: create, index, show under ai_agent_dispatches controller.
- manage_ai_agents
  - Actions: index, show, new, create, edit, update, destroy under ai_agents controller.
  - Actions: index, show, new, create, edit, update, destroy under ai_agent_assignments controller.

**Section sources**
- [init.rb:26-28](file://init.rb#L26-L28)
- [ai_agent_dispatches_controller.rb:5-12](file://app/controllers/ai_agent_dispatches_controller.rb#L5-L12)
- [ai_agents_controller.rb:5-47](file://app/controllers/ai_agents_controller.rb#L5-L47)
- [ai_agent_assignments_controller.rb:4-48](file://app/controllers/ai_agent_assignments_controller.rb#L4-L48)

### Appendix B: Data Model Relationships Relevant to Permissions
```mermaid
erDiagram
ISSUE {
int id PK
int assigned_to_id
}
AI_AGENT {
int id PK
string name
boolean active
}
AI_AGENT_ASSIGNMENT {
int id PK
int user_id
int ai_agent_id
boolean auto_dispatch
}
AI_AGENT_DISPATCH {
int id PK
int issue_id
int ai_agent_id
int triggered_by
string status
datetime dispatched_at
datetime completed_at
}
ISSUE ||--o{ AI_AGENT_DISPATCH : "has"
AI_AGENT ||--o{ AI_AGENT_DISPATCH : "dispatches"
AI_AGENT ||--o{ AI_AGENT_ASSIGNMENT : "assigned_to"
USER ||--o{ AI_AGENT_ASSIGNMENT : "assigned_to"
```

**Diagram sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)