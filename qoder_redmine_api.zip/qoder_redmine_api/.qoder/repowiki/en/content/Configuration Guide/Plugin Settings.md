# Plugin Settings

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [en.yml](file://config/locales/en.yml)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the Redmine AI Agent plugin’s settings configuration. It focuses on the three main settings:
- enabled: activates or deactivates the plugin globally
- redmine_api_base_url: the Redmine instance API endpoint used by agents
- default_timeout: HTTP request timeout for agent communications

It describes how these settings are declared in the plugin registration block, how they appear in the admin interface, how they are accessed at runtime, and how to configure them safely for different environments.

## Project Structure
The plugin exposes a settings partial that renders the admin UI for these settings. The plugin registration block defines defaults and the partial template to render. Runtime code reads these settings to configure HTTP requests and inject the base URL into agent prompts.

```mermaid
graph TB
Init["init.rb<br/>Plugin registration block"] --> Partial["app/views/settings/_ai_agent_settings.html.erb<br/>Admin settings form"]
Partial --> Locales["config/locales/en.yml<br/>Labels and hints"]
Init --> AgentClient["lib/redmine_ai_agent/agent_client.rb<br/>Uses settings for timeouts"]
Init --> RedmineApiSkill["lib/redmine_ai_agent/redmine_api_skill.rb<br/>Uses settings for timeouts"]
Init --> AiAgent["app/models/ai_agent.rb<br/>Injects base URL into prompts"]
```

**Diagram sources**
- [init.rb:3-16](file://init.rb#L3-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [en.yml:99-103](file://config/locales/en.yml#L99-L103)
- [agent_client.rb:202-203](file://lib/redmine_ai_agent/agent_client.rb#L202-L203)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

**Section sources**
- [init.rb:3-16](file://init.rb#L3-L16)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [en.yml:99-103](file://config/locales/en.yml#L99-L103)

## Core Components
- Plugin registration block defines default values and the settings partial.
- Admin settings form renders the three settings fields.
- Runtime code reads the settings to:
  - Inject the base URL into agent system prompts
  - Configure HTTP read timeouts for agent endpoints
  - Configure HTTP read timeouts for Redmine API skill calls

Key behaviors:
- enabled controls whether the plugin is active.
- redmine_api_base_url is used to construct agent prompts and API calls.
- default_timeout is used to set HTTP timeouts; invalid values fall back to a default.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [_ai_agent_settings.html.erb:4-28](file://app/views/settings/_ai_agent_settings.html.erb#L4-L28)
- [agent_client.rb:202-203](file://lib/redmine_ai_agent/agent_client.rb#L202-L203)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

## Architecture Overview
The settings are part of the plugin’s configuration and are consumed by runtime components that perform HTTP requests and prompt construction.

```mermaid
sequenceDiagram
participant Admin as "Admin UI"
participant Partial as "_ai_agent_settings.html.erb"
participant Init as "init.rb"
participant AgentClient as "AgentClient"
participant RedmineApiSkill as "RedmineApiSkill"
participant AiAgent as "AiAgent"
Admin->>Partial : Render plugin settings page
Partial->>Init : Read @settings keys
AgentClient->>Init : Read default_timeout
RedmineApiSkill->>Init : Read default_timeout
AiAgent->>Init : Read redmine_api_base_url
```

**Diagram sources**
- [_ai_agent_settings.html.erb:4-28](file://app/views/settings/_ai_agent_settings.html.erb#L4-L28)
- [init.rb:12-16](file://init.rb#L12-L16)
- [agent_client.rb:202-203](file://lib/redmine_ai_agent/agent_client.rb#L202-L203)
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

## Detailed Component Analysis

### Settings Registration Block
- Declares default values for enabled, redmine_api_base_url, and default_timeout.
- Associates a settings partial to render the admin UI for these settings.

Validation and defaults:
- enabled: boolean-like default true
- redmine_api_base_url: string default empty
- default_timeout: numeric default 120

Access pattern:
- Settings are accessed via the plugin settings hash and used in runtime components.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)

### Admin Settings Form (_ai_agent_settings.html.erb)
- Renders a checkbox for enabled.
- Renders a text field for redmine_api_base_url with a placeholder hint.
- Renders a text field for default_timeout with a default fallback of 120.

Field IDs and labels:
- enabled: checkbox with label from locale key
- redmine_api_base_url: labeled text field with hint from locale key
- default_timeout: labeled text field with “seconds” info

**Section sources**
- [_ai_agent_settings.html.erb:4-28](file://app/views/settings/_ai_agent_settings.html.erb#L4-L28)
- [en.yml:99-103](file://config/locales/en.yml#L99-L103)

### Runtime Usage of Settings

#### Agent Client (HTTP Calls)
- Reads default_timeout from plugin settings and falls back to a constant default if the value is non-positive.
- Applies read_timeout and open_timeout to HTTP requests.

```mermaid
flowchart TD
Start(["AgentClient.post_to_agent"]) --> ReadTimeout["Read default_timeout from settings"]
ReadTimeout --> CheckPositive{"timeout > 0 ?"}
CheckPositive --> |Yes| UseTimeout["Use parsed timeout"]
CheckPositive --> |No| UseDefault["Use default constant"]
UseTimeout --> ApplyHTTP["Set HTTP read_timeout and open_timeout"]
UseDefault --> ApplyHTTP
ApplyHTTP --> SendRequest["Send HTTP request"]
SendRequest --> End(["Return parsed response"])
```

**Diagram sources**
- [agent_client.rb:202-208](file://lib/redmine_ai_agent/agent_client.rb#L202-L208)

**Section sources**
- [agent_client.rb:202-208](file://lib/redmine_ai_agent/agent_client.rb#L202-L208)

#### Redmine API Skill (Server-side Tool Execution)
- Accepts a timeout parameter and stores it as read_timeout for HTTP requests.
- Uses the provided timeout to configure HTTP requests.

```mermaid
classDiagram
class RedmineApiSkill {
+initialize(base_url, api_key, timeout)
+execute_tool_call(tool_call)
-perform(uri, request)
}
RedmineApiSkill : "uses timeout for HTTP read_timeout"
```

**Diagram sources**
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [redmine_api_skill.rb:107-111](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L111)

**Section sources**
- [redmine_api_skill.rb:28-32](file://lib/redmine_ai_agent/redmine_api_skill.rb#L28-L32)
- [redmine_api_skill.rb:107-111](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L111)

#### AiAgent Prompt Construction
- Reads redmine_api_base_url from plugin settings and trims trailing slash.
- Injects the base URL into system prompts and issue context messages.

```mermaid
sequenceDiagram
participant AiAgent as "AiAgent"
participant Settings as "Plugin Settings"
AiAgent->>Settings : Read redmine_api_base_url
Settings-->>AiAgent : Base URL string
AiAgent->>AiAgent : Replace placeholders in templates
```

**Diagram sources**
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

**Section sources**
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

### Practical Configuration Examples

- Local development (no authentication):
  - enabled: true
  - redmine_api_base_url: http://localhost:3000
  - default_timeout: 120

- Production hosted Redmine:
  - enabled: true
  - redmine_api_base_url: https://redmine.example.com
  - default_timeout: 120

- Private network endpoint:
  - enabled: true
  - redmine_api_base_url: https://redmine.internal.company
  - default_timeout: 120

Notes:
- Ensure redmine_api_base_url does not include a trailing slash.
- default_timeout must be a positive integer; non-positive values are treated as invalid and replaced with the default.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [agent_client.rb:202-203](file://lib/redmine_ai_agent/agent_client.rb#L202-L203)
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

## Dependency Analysis
- The settings are consumed by:
  - AgentClient for HTTP request timeouts
  - RedmineApiSkill for HTTP request timeouts
  - AiAgent for prompt URL injection

```mermaid
graph LR
Init["init.rb<br/>settings defaults"] --> AgentClient["agent_client.rb"]
Init --> RedmineApiSkill["redmine_api_skill.rb"]
Init --> AiAgent["ai_agent.rb"]
AgentClient --> NetHTTP["Net::HTTP"]
RedmineApiSkill --> NetHTTP
```

**Diagram sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [agent_client.rb:202-208](file://lib/redmine_ai_agent/agent_client.rb#L202-L208)
- [redmine_api_skill.rb:107-111](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L111)
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [agent_client.rb:202-208](file://lib/redmine_ai_agent/agent_client.rb#L202-L208)
- [redmine_api_skill.rb:107-111](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L111)
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

## Performance Considerations
- default_timeout affects how long the plugin waits for agent responses. Larger values reduce early timeouts but increase latency.
- Ensure the value is reasonable for your environment and agent provider SLAs.
- For Redmine API skill calls, timeouts are configured independently; ensure they align with expected operation durations.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

Common issues and resolutions:
- Invalid default_timeout value
  - Symptom: Unexpected timeout behavior or errors when calling agents.
  - Cause: Non-positive or non-numeric value.
  - Resolution: Set default_timeout to a positive integer. Values less than or equal to zero are treated as invalid and replaced with the default.

- redmine_api_base_url malformed
  - Symptom: Agent prompts or API calls fail due to invalid URLs.
  - Cause: Missing scheme, trailing slash, or malformed host.
  - Resolution: Provide a valid URL without a trailing slash. The code trims trailing slashes internally.

- Settings not taking effect
  - Symptom: Changes to settings do not apply.
  - Cause: Incorrect field names or missing save action.
  - Resolution: Confirm the admin form posts settings under the expected keys and that the settings were saved.

- Timeout errors when calling agents
  - Symptom: Agent calls fail with timeout exceptions.
  - Cause: default_timeout too low for the agent workload or network conditions.
  - Resolution: Increase default_timeout to a higher value suitable for your environment.

- Timeout errors when executing Redmine API skills
  - Symptom: Tool calls fail with timeout.
  - Cause: Redmine API slow responses or low timeout.
  - Resolution: Adjust the timeout passed to the skill or increase the default_timeout setting.

**Section sources**
- [agent_client.rb:202-203](file://lib/redmine_ai_agent/agent_client.rb#L202-L203)
- [agent_client.rb:223-229](file://lib/redmine_ai_agent/agent_client.rb#L223-L229)
- [redmine_api_skill.rb:107-111](file://lib/redmine_ai_agent/redmine_api_skill.rb#L107-L111)
- [ai_agent.rb:143-153](file://app/models/ai_agent.rb#L143-L153)

## Conclusion
The plugin’s settings are straightforward and consistently applied across runtime components. The enabled flag toggles plugin activity, redmine_api_base_url is used to construct agent prompts and API calls, and default_timeout governs HTTP request timeouts. Proper configuration ensures reliable agent interactions and predictable behavior across environments.