# Menu and Navigation

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how the plugin integrates with Redmine’s admin interface navigation. It focuses on the admin_menu configuration that adds the “AI Agents” entry to the Redmine admin sidebar, including the controller/action mapping, caption localization, HTML attributes, and how the menu integrates with Redmine’s menu system. It also covers permission-based visibility, route relationships, customization tips, and troubleshooting.

## Project Structure
The plugin contributes admin navigation via the plugin initializer and defines routes for admin-managed resources. Controllers enforce admin-only access and integrate with Redmine’s permission system.

```mermaid
graph TB
subgraph "Plugin"
INIT["init.rb<br/>Admin menu registration"]
ROUTES["config/routes.rb<br/>Admin routes"]
CTRL_AG["app/controllers/ai_agents_controller.rb"]
CTRL_ASSN["app/controllers/ai_agent_assignments_controller.rb"]
CTRL_DISP["app/controllers/ai_agent_dispatches_controller.rb"]
LOCALE["config/locales/en.yml<br/>Captions and labels"]
HOOKS["lib/redmine_ai_agent/hooks.rb<br/>Issue panel injection"]
end
INIT --> ROUTES
ROUTES --> CTRL_AG
ROUTES --> CTRL_ASSN
ROUTES --> CTRL_DISP
INIT --> LOCALE
INIT --> HOOKS
```

**Diagram sources**
- [init.rb:18-22](file://init.rb#L18-L22)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

**Section sources**
- [init.rb:18-22](file://init.rb#L18-L22)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- Admin menu entry registration:
  - Adds “AI Agents” to the admin sidebar.
  - Maps to the ai_agents controller index action.
  - Uses a localized caption and applies an icon class via HTML attributes.
- Routes:
  - Defines RESTful routes for ai_agents and ai_agent_assignments.
  - Defines nested routes under issues for ai_agent_dispatches.
- Permissions:
  - Declares project-level permissions for managing agents and dispatching.
  - Controllers enforce admin-only access for admin-managed resources.

Key configuration points:
- Admin menu registration and mapping: [init.rb:18-22](file://init.rb#L18-L22)
- Routes for admin resources: [routes.rb:3-10](file://config/routes.rb#L3-L10)
- Nested routes for per-issue dispatch: [routes.rb:13-15](file://config/routes.rb#L13-L15)
- Admin-only enforcement in controllers: [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2), [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)
- Permission declarations: [init.rb:24-29](file://init.rb#L24-L29)

**Section sources**
- [init.rb:18-22](file://init.rb#L18-L22)
- [routes.rb:3-10](file://config/routes.rb#L3-L10)
- [routes.rb:13-15](file://config/routes.rb#L13-L15)
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)
- [init.rb:24-29](file://init.rb#L24-L29)

## Architecture Overview
The admin navigation entry is registered during plugin initialization and links to the ai_agents index page. The routes define the URLs for admin CRUD operations and per-issue dispatch actions. Controllers restrict access to administrators and enforce permissions for dispatch operations.

```mermaid
sequenceDiagram
participant U as "Admin User"
participant R as "Redmine UI"
participant M as "Admin Menu"
participant C as "AiAgentsController"
participant V as "View Template"
U->>R : "Open Admin Sidebar"
R->>M : "Render admin_menu entries"
M-->>U : "Display 'AI Agents' link"
U->>C : "Click 'AI Agents'"
C->>C : "Require admin (before_action)"
C-->>V : "Render index view"
V-->>U : "Show agents list"
```

**Diagram sources**
- [init.rb:18-22](file://init.rb#L18-L22)
- [ai_agents_controller.rb:5-7](file://app/controllers/ai_agents_controller.rb#L5-L7)

## Detailed Component Analysis

### Admin Menu Registration
- Entry name: “AI Agents”
- Target: controller: ai_agents, action: index
- Caption localization: Provided via the caption option
- Icon class: Applied via HTML attributes (class: icon icon-robot)
- Location: admin_menu

```mermaid
flowchart TD
Start(["Plugin Initialization"]) --> Reg["Register admin_menu entry"]
Reg --> Map["Map to controller 'ai_agents' action 'index'"]
Reg --> Loc["Caption localization lookup"]
Reg --> Attr["Apply HTML attributes (icon class)"]
Map --> End(["Entry appears in Admin Sidebar"])
Loc --> End
Attr --> End
```

**Diagram sources**
- [init.rb:18-22](file://init.rb#L18-L22)

**Section sources**
- [init.rb:18-22](file://init.rb#L18-L22)

### Route-to-Controller Mapping
- Admin resources:
  - ai_agents: index, show, new, create, edit, update, destroy
  - ai_agent_assignments: index, show, new, create, edit, update, destroy
- Per-issue dispatch:
  - issues/:issue_id/ai_agent_dispatches: create, index, show

```mermaid
graph LR
A["Admin Sidebar 'AI Agents'"] --> B["GET /ai_agents (index)"]
B --> C["AiAgentsController#index"]
D["Admin Sidebar 'Assignments'"] --> E["GET /ai_agent_assignments (index)"]
E --> F["AiAgentAssignmentsController#index"]
G["Issue Page Panel"] --> H["POST /issues/:id/ai_agent_dispatches (create)"]
H --> I["AiAgentDispatchesController#create"]
```

**Diagram sources**
- [routes.rb:3-10](file://config/routes.rb#L3-L10)
- [routes.rb:13-15](file://config/routes.rb#L13-L15)
- [ai_agents_controller.rb:5-7](file://app/controllers/ai_agents_controller.rb#L5-L7)
- [ai_agent_assignments_controller.rb:4-8](file://app/controllers/ai_agent_assignments_controller.rb#L4-L8)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)

**Section sources**
- [routes.rb:3-10](file://config/routes.rb#L3-L10)
- [routes.rb:13-15](file://config/routes.rb#L13-L15)

### Caption Localization
- The menu caption is provided via the caption option in the admin_menu registration.
- Localized labels for UI strings are defined in the locale file and used in views and controllers.

**Section sources**
- [init.rb:21](file://init.rb#L21)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

### HTML Attributes and Theme Integration
- The HTML attributes include an icon class applied to the menu item.
- Redmine themes typically rely on icon classes and standard link rendering; ensure the class aligns with your theme’s icon set.

**Section sources**
- [init.rb:22](file://init.rb#L22)

### Permission-Based Visibility
- Admin-only controllers:
  - AiAgentsController and AiAgentAssignmentsController enforce admin access.
- Project-level permissions:
  - dispatch_ai_agent: controls manual dispatch capability.
  - manage_ai_agents: controls CRUD operations on agents and assignments.
- Dispatch authorization:
  - AiAgentDispatchesController checks permission against the current issue’s project.

```mermaid
flowchart TD
A["User attempts access"] --> B{"Is user admin?"}
B -- "No" --> D["Deny access (admin requirement)"]
B -- "Yes" --> C{"Has project permission?"}
C -- "No" --> E["Deny access (permission check)"]
C -- "Yes" --> F["Allow access"]
```

**Diagram sources**
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [init.rb:24-29](file://init.rb#L24-L29)

**Section sources**
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_assignments_controller.rb:2](file://app/controllers/ai_agent_assignments_controller.rb#L2)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [init.rb:24-29](file://init.rb#L24-L29)

### Relationship Between Menu Entries and Routes
- The menu targets the ai_agents index action.
- The routes define the URL pattern for the index action.
- Views and helpers use route helpers to link to the same resource.

**Section sources**
- [init.rb:18-22](file://init.rb#L18-L22)
- [routes.rb:3-7](file://config/routes.rb#L3-L7)
- [ai_agents_controller.rb:5-7](file://app/controllers/ai_agents_controller.rb#L5-L7)

### Customization Examples
- Change the icon:
  - Modify the HTML class in the admin_menu registration to use another icon class supported by your theme.
  - Reference: [init.rb:22](file://init.rb#L22)
- Add a second admin entry:
  - Register another entry in the same location with a distinct caption and controller/action mapping.
  - Reference: [init.rb:18-22](file://init.rb#L18-L22)
- Localize the caption:
  - Ensure the caption value corresponds to a translation key present in the locale file.
  - Reference: [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [init.rb:22](file://init.rb#L22)
- [init.rb:18-22](file://init.rb#L18-L22)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Dependency Analysis
- The admin menu depends on:
  - Plugin initialization to register the entry.
  - Routes to define the target URL.
  - Controllers to enforce access and render content.
- Permissions influence visibility and access to related pages.

```mermaid
graph LR
INIT["init.rb<br/>admin_menu"] --> ROUTE["routes.rb<br/>resource routes"]
ROUTE --> CTRL1["AiAgentsController"]
ROUTE --> CTRL2["AiAgentAssignmentsController"]
ROUTE --> CTRL3["AiAgentDispatchesController"]
INIT --> PERM["Permissions in init.rb"]
PERM --> CTRL1
PERM --> CTRL2
PERM --> CTRL3
```

**Diagram sources**
- [init.rb:18-29](file://init.rb#L18-L29)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

**Section sources**
- [init.rb:18-29](file://init.rb#L18-L29)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Performance Considerations
- Menu rendering occurs during admin UI generation; keep the number of entries minimal and avoid heavy computations in the plugin initializer.
- Ensure route helpers and controller actions remain lightweight to maintain responsive admin navigation.

## Troubleshooting Guide
- Menu entry does not appear:
  - Verify the plugin is activated and the initializer executed.
  - Confirm the admin_menu registration syntax and keys.
  - References: [init.rb:18-22](file://init.rb#L18-L22)
- Link leads to a 404:
  - Ensure routes are defined for the target controller/action.
  - Confirm the controller responds to the action and is reachable.
  - References: [routes.rb:3-10](file://config/routes.rb#L3-L10), [ai_agents_controller.rb:5-7](file://app/controllers/ai_agents_controller.rb#L5-L7)
- Access denied:
  - Admin-only controllers require administrator privileges.
  - Dispatch actions require the dispatch_ai_agent permission in the current project context.
  - References: [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2), [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- Icon not visible:
  - Ensure the icon class exists in the active theme.
  - References: [init.rb:22](file://init.rb#L22)
- Caption not localized:
  - Confirm the caption value matches a translation key in the locale file.
  - References: [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [init.rb:18-22](file://init.rb#L18-L22)
- [routes.rb:3-10](file://config/routes.rb#L3-L10)
- [ai_agents_controller.rb:2](file://app/controllers/ai_agents_controller.rb#L2)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Conclusion
The plugin integrates cleanly with Redmine’s admin navigation by registering a single menu entry mapped to the ai_agents index action. The setup leverages Redmine’s menu system, localization, and permission model. Routes support admin CRUD and per-issue dispatch workflows, while controllers enforce admin-only access and project-level permissions. Customization is straightforward via HTML attributes, captions, and additional menu registrations.