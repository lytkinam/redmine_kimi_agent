# Hook System Implementation

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [_dispatch_panel.html.erb](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb)
- [routes.rb](file://config/routes.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the Redmine hook system implementation that integrates AI agent processing with Redmine’s core event system. The Hooks class extends Redmine::Hook::ViewListener to listen to issue lifecycle events and inject AI agent panels into issue pages. It automatically dispatches AI agents when issues are assigned or newly created, based on user-to-agent assignments and plugin configuration.

## Project Structure
The plugin is organized around a clear separation of concerns:
- Plugin registration and settings live in the plugin initializer.
- The hook listener resides under lib/redmine_ai_agent/hooks.rb.
- Controllers manage manual dispatch triggers.
- Jobs process asynchronous AI agent calls and tool loops.
- Models represent agents, assignments, and dispatch records.
- Views render the injected AI panel and dispatch history.
- Routes define the manual dispatch endpoints.

```mermaid
graph TB
subgraph "Plugin Initialization"
INIT["init.rb"]
REG["lib/redmine_ai_agent.rb"]
end
subgraph "Hooks"
HOOKS["lib/redmine_ai_agent/hooks.rb"]
end
subgraph "Controllers"
CTRL["app/controllers/ai_agent_dispatches_controller.rb"]
end
subgraph "Jobs"
JOB["app/jobs/ai_agent_dispatch_job.rb"]
end
subgraph "Models"
MODEL_AI["app/models/ai_agent.rb"]
MODEL_ASS["app/models/ai_agent_assignment.rb"]
MODEL_DISP["app/models/ai_agent_dispatch.rb"]
end
subgraph "Views"
VIEW_PANEL["_dispatch_panel.html.erb"]
end
subgraph "Routes"
ROUTES["config/routes.rb"]
end
INIT --> REG --> HOOKS
HOOKS --> CTRL
HOOKS --> JOB
CTRL --> JOB
JOB --> MODEL_DISP
MODEL_AI --> JOB
MODEL_ASS --> HOOKS
HOOKS --> VIEW_PANEL
ROUTES --> CTRL
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- Hooks class: Extends Redmine::Hook::ViewListener to receive issue lifecycle events and inject UI panels.
- AiAgentDispatchesController: Handles manual dispatch requests from the issue page.
- AiAgentDispatchJob: Performs asynchronous AI agent calls, tool-loop execution, and journal updates.
- AiAgent, AiAgentAssignment, AiAgentDispatch: Domain models for agents, user-agent assignments, and dispatch records.
- AgentClient and RedmineApiSkill: Clients for interacting with AI endpoints and Redmine REST APIs respectively.

Key responsibilities:
- Automatic dispatch: Detects assignee changes and new issues, checks assignments, and enqueues jobs.
- Manual dispatch: Provides a UI button to trigger dispatches from the issue page.
- View injection: Renders an AI panel with dispatch history and controls.

**Section sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

## Architecture Overview
The hook system listens to Redmine’s issue controller events and orchestrates AI agent dispatches. Automatic dispatch occurs when an issue is edited (assignee change) or created (if assigned). The view hook injects a panel into the issue page for manual dispatch and history.

```mermaid
sequenceDiagram
participant Redmine as "Redmine Core"
participant Hooks as "RedmineAiAgent : : Hooks"
participant Ctx as "Issue Controller Context"
participant Job as "AiAgentDispatchJob"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
Redmine->>Hooks : "controller_issues_edit_after_save(context)"
Hooks->>Ctx : "Read issue and current_user"
Hooks->>Hooks : "check_and_auto_dispatch(issue, triggered_by)"
Hooks->>Job : "perform_later(issue_id, agent_id, user_id)"
Redmine->>Hooks : "controller_issues_new_after_save(context)"
Hooks->>Ctx : "Read issue and current_user"
Hooks->>Hooks : "check_and_auto_dispatch(issue, triggered_by)"
Hooks->>Job : "perform_later(issue_id, agent_id, user_id)"
Job->>Agent : "call(issue, triggered_by)"
Agent-->>Job : "{text, raw_response, request}"
Job->>Skill : "run_tool_loop(client, agent, issue, result)"
Skill-->>Job : "Final agent text"
Job-->>Redmine : "Post journal notes and persist dispatch"
```

**Diagram sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

## Detailed Component Analysis

### Hooks Class and Event Handlers
The Hooks class extends Redmine::Hook::ViewListener and registers two controller event handlers:
- controller_issues_edit_after_save: Triggers when an existing issue is saved. It checks if the assignee changed and dispatches the AI agent accordingly.
- controller_issues_new_after_save: Triggers when a new issue is saved. It dispatches the AI agent if the issue is assigned.

It also defines a view hook:
- view_issues_show_details_bottom: Injects an AI panel into the issue page when an active agent is assigned to the issue.

```mermaid
classDiagram
class RedmineAiAgent_Hooks {
+controller_issues_edit_after_save(context)
+controller_issues_new_after_save(context)
+view_issues_show_details_bottom(context)
-plugin_enabled() bool
-check_and_auto_dispatch(issue, triggered_by)
}
class AiAgentAssignment {
+user_id int
+ai_agent_id int
+auto_dispatch bool
+auto_dispatch?() bool
}
class AiAgentDispatchJob {
+perform(issue_id, ai_agent_id, triggered_by_user_id)
-post_journal(issue,user,message)
-run_tool_loop(client, agent, issue, result)
-handle_error(dispatch, issue, trigger, agent, error_message)
}
RedmineAiAgent_Hooks --> AiAgentAssignment : "finds assignment"
RedmineAiAgent_Hooks --> AiAgentDispatchJob : "enqueues"
```

**Diagram sources**
- [hooks.rb:2-72](file://lib/redmine_ai_agent/hooks.rb#L2-L72)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

**Section sources**
- [hooks.rb:2-72](file://lib/redmine_ai_agent/hooks.rb#L2-L72)

### Automatic Dispatch Logic
Automatic dispatch is controlled by:
- Plugin enabled setting.
- Presence of an active agent assignment for the assignee.
- Assignment’s auto_dispatch flag.
- Triggered by user context (current user or system user fallback).

```mermaid
flowchart TD
Start(["Edit/New Issue Saved"]) --> Enabled{"Plugin enabled?"}
Enabled --> |No| EndNo["Exit"]
Enabled --> |Yes| LoadIssue["Load issue from context"]
LoadIssue --> AssigneeCheck{"Has assignee?"}
AssigneeCheck --> |No| EndNo
AssigneeCheck --> |Yes| FindAssignment["Find active agent assignment for assignee"]
FindAssignment --> HasAssignment{"Assignment found<br/>and auto_dispatch?"}
HasAssignment --> |No| EndNo
HasAssignment --> |Yes| Enqueue["Enqueue AiAgentDispatchJob"]
Enqueue --> EndOk(["Dispatch queued"])
```

**Diagram sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

**Section sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

### View Hook: Injecting the AI Panel
The view hook renders a panel that:
- Shows the assigned AI agent’s name and type/protocol.
- Provides a manual dispatch button if permissions allow.
- Displays recent dispatch history with status badges and links.

```mermaid
sequenceDiagram
participant Redmine as "Redmine Core"
participant Hooks as "RedmineAiAgent : : Hooks"
participant View as "_dispatch_panel.html.erb"
participant Ctrl as "AiAgentDispatchesController"
Redmine->>Hooks : "view_issues_show_details_bottom(context)"
Hooks->>Hooks : "Find active agent assignment for assignee"
Hooks->>View : "Render partial with locals"
View->>Ctrl : "POST /issues/ : id/ai_agent_dispatches"
Ctrl-->>View : "Redirect with notice"
```

**Diagram sources**
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)

**Section sources**
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)

### Manual Dispatch Controller
The controller:
- Authorizes the current user to dispatch AI agents for the project.
- Finds the active agent assignment for the issue’s assignee.
- Enqueues a job to process the dispatch.
- Redirects back to the issue with a notice.

```mermaid
sequenceDiagram
participant User as "User"
participant Ctrl as "AiAgentDispatchesController"
participant Model as "AiAgentAssignment"
participant Job as "AiAgentDispatchJob"
User->>Ctrl : "POST /issues/ : id/ai_agent_dispatches"
Ctrl->>Model : "Find active agent assignment"
Model-->>Ctrl : "Assignment or nil"
alt "No assignment"
Ctrl-->>User : "Flash error and redirect"
else "Assignment exists"
Ctrl->>Job : "perform_later(issue_id, agent_id, current_user_id)"
Ctrl-->>User : "Flash notice and redirect"
end
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_assignment.rb:14-20](file://app/models/ai_agent_assignment.rb#L14-L20)
- [ai_agent_dispatch_job.rb:6-10](file://app/jobs/ai_agent_dispatch_job.rb#L6-L10)

**Section sources**
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_assignment.rb:14-20](file://app/models/ai_agent_assignment.rb#L14-L20)
- [ai_agent_dispatch_job.rb:6-10](file://app/jobs/ai_agent_dispatch_job.rb#L6-L10)

### Dispatch Job: Execution and Tool Loop
The job:
- Loads the issue, agent, and triggering user.
- Creates a dispatch record and posts a “dispatch started” journal note.
- Calls the agent client, executes tool calls against the Redmine API via the skill, and feeds results back until completion or max iterations.
- Persists request/response payloads and posts a “dispatch done” journal note.
- Handles errors by marking the dispatch as error and logging.

```mermaid
flowchart TD
JStart(["Job.perform"]) --> Load["Load issue, agent, user"]
Load --> Valid{"Records exist?"}
Valid --> |No| LogWarn["Log warning and exit"]
Valid --> |Yes| CreateDisp["Create dispatch record (running)"]
CreateDisp --> PostStart["Post 'dispatch started' journal"]
PostStart --> CallAgent["AgentClient.call(issue, triggered_by)"]
CallAgent --> ToolLoop{"Tool calls present?"}
ToolLoop --> |No| SaveDone["Save done with payloads"]
ToolLoop --> |Yes| ExecTools["Execute tool calls via RedmineApiSkill"]
ExecTools --> FeedBack["Feed results back to agent"]
FeedBack --> ToolLoop
SaveDone --> PostDone["Post 'dispatch done' journal"]
PostDone --> JEnd(["Job complete"])
subgraph "Error Handling"
CallAgent --> |AgentError| HandleErr["Mark error and post journal"]
FeedBack --> |Error| HandleErr
end
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

**Section sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

### Data Models and Relationships
The models define the domain for agents, assignments, and dispatches, along with indexes and validations.

```mermaid
erDiagram
AI_AGENT {
int id PK
string name
string agent_type
string endpoint_url
string protocol
string api_key
string model_name
text system_prompt
boolean active
timestamps
}
AI_AGENT_ASSIGNMENT {
int id PK
int user_id FK
int ai_agent_id FK
boolean auto_dispatch
timestamps
}
AI_AGENT_DISPATCH {
int id PK
int issue_id FK
int ai_agent_id FK
int triggered_by FK
string status
text request_payload
text response_payload
int journal_id
datetime dispatched_at
datetime completed_at
timestamps
}
ISSUE {
int id PK
}
USER {
int id PK
}
AI_AGENT ||--o{ AI_AGENT_ASSIGNMENT : "has many"
AI_AGENT_ASSIGNMENT ||--|| USER : "belongs to"
AI_AGENT_ASSIGNMENT ||--|| AI_AGENT : "belongs to"
AI_AGENT_DISPATCH ||--|| ISSUE : "belongs to"
AI_AGENT_DISPATCH ||--|| AI_AGENT : "belongs to"
AI_AGENT_DISPATCH ||--|| USER : "triggered_by"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

## Dependency Analysis
- Hooks depends on:
  - AiAgentAssignment to find active agent assignments.
  - AiAgentDispatchJob to enqueue asynchronous processing.
  - AiAgentDispatch for rendering recent dispatch history in the view hook.
- Controllers depend on AiAgentAssignment and AiAgentDispatchJob.
- Jobs depend on AgentClient and RedmineApiSkill.
- Models encapsulate validations, scopes, and associations.

```mermaid
graph LR
Hooks["Hooks"] --> Assignments["AiAgentAssignment"]
Hooks --> Job["AiAgentDispatchJob"]
Hooks --> Dispatch["AiAgentDispatch"]
Controller["AiAgentDispatchesController"] --> Assignments
Controller --> Job
Job --> AgentClient["AgentClient"]
Job --> Skill["RedmineApiSkill"]
AgentClient --> Models["AiAgent/AiAgentDispatch"]
Skill --> Models
```

**Diagram sources**
- [hooks.rb:2-72](file://lib/redmine_ai_agent/hooks.rb#L2-L72)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

**Section sources**
- [hooks.rb:2-72](file://lib/redmine_ai_agent/hooks.rb#L2-L72)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

## Performance Considerations
- Asynchronous processing: Dispatches run in ActiveJob to avoid blocking UI threads.
- Retries: Transient agent errors are retried with exponential backoff.
- Timeouts: Configurable agent and Redmine API timeouts prevent long hangs.
- Tool loop limits: Maximum iterations protect against runaway tool-call loops.
- Indexes: Database indexes on foreign keys and status improve query performance.
- Minimal rendering: View hook only queries recent dispatches to limit overhead.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Plugin disabled: Automatic dispatch does not trigger if the plugin is disabled. Verify the enabled setting.
- No agent assignment: Ensure an active agent is assigned to the user and auto_dispatch is enabled.
- Missing permissions: Manual dispatch requires the dispatch permission for the project; verify user permissions.
- Agent endpoint errors: Network or non-2xx responses raise agent errors; check endpoint URL, API key, and timeouts.
- Redmine API errors: Tool calls failing indicate incorrect base URL or missing API key; verify plugin settings and user API key.
- Job failures: Inspect logs for error payloads and journal notes posted during dispatch.

**Section sources**
- [hooks.rb:51-53](file://lib/redmine_ai_agent/hooks.rb#L51-L53)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatch_job.rb:61-67](file://app/jobs/ai_agent_dispatch_job.rb#L61-L67)
- [agent_client.rb:214-229](file://lib/redmine_ai_agent/agent_client.rb#L214-L229)
- [redmine_api_skill.rb:115-127](file://lib/redmine_ai_agent/redmine_api_skill.rb#L115-L127)

## Conclusion
The hook system seamlessly integrates AI agent automation with Redmine’s issue lifecycle. Automatic dispatch responds to assignee changes and new issues, while the injected panel enables manual control and visibility into agent actions. Robust asynchronous processing, error handling, and tool-loop execution ensure reliable operation within Redmine’s event-driven architecture.