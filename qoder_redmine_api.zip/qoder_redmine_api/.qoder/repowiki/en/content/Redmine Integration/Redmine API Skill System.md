# Redmine API Skill System

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the Redmine AI Agent plugin that enables AI agents to execute Redmine operations through a skill-based tool calling system. The system integrates with Redmine’s REST API to perform issue-related tasks such as reading, updating, creating, and changing status, while preserving user context and enforcing permissions. It supports multiple AI agent types and protocols, and provides a robust job-based dispatch mechanism with retries, logging, and journaling.

## Project Structure
The plugin follows a standard Redmine plugin layout with controllers, models, jobs, and plugin registration. Key areas:
- Plugin registration and permissions
- Routing for admin and per-issue dispatch
- Models for agents, assignments, and dispatch records
- Controllers for managing agents, assignments, and manual dispatch
- Job orchestrating agent execution and tool loops
- Library entry points for clients and hooks

```mermaid
graph TB
subgraph "Plugin Registration"
INIT["init.rb"]
ROUTES["config/routes.rb"]
end
subgraph "Controllers"
CTRL_AGENTS["AiAgentsController"]
CTRL_ASSIGN["AiAgentAssignmentsController"]
CTRL_DISPATCH["AiAgentDispatchesController"]
end
subgraph "Models"
MODEL_AGENT["AiAgent"]
MODEL_ASSIGN["AiAgentAssignment"]
MODEL_DISPATCH["AiAgentDispatch"]
end
subgraph "Jobs"
JOB_DISPATCH["AiAgentDispatchJob"]
end
subgraph "Library"
LIB_ENTRY["lib/redmine_ai_agent.rb"]
end
INIT --> ROUTES
ROUTES --> CTRL_AGENTS
ROUTES --> CTRL_ASSIGN
ROUTES --> CTRL_DISPATCH
CTRL_DISPATCH --> JOB_DISPATCH
JOB_DISPATCH --> MODEL_DISPATCH
MODEL_AGENT --> JOB_DISPATCH
MODEL_ASSIGN --> CTRL_DISPATCH
MODEL_DISPATCH --> CTRL_DISPATCH
LIB_ENTRY --> JOB_DISPATCH
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Core Components
- Plugin registration defines settings, permissions, and admin menu entry.
- Routes expose admin endpoints for agents and assignments, plus per-issue dispatch endpoints.
- Models define agent profiles, user-agent assignments, and dispatch records with status tracking.
- Controllers manage agent CRUD, assignment CRUD, and manual dispatch creation with permission checks.
- Job performs dispatch, posts journal notes, runs tool loop against a Redmine API skill, persists payloads, and handles errors.

Key capabilities:
- Issue reading and updating via a Redmine API skill invoked through tool calls.
- Status modification by executing appropriate tool calls.
- User context preservation via the triggering user and agent assignment.
- Permission enforcement for dispatch actions at the project level.

**Section sources**
- [init.rb:12-29](file://init.rb#L12-L29)
- [routes.rb:2-16](file://config/routes.rb#L2-L16)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

## Architecture Overview
The system architecture centers on a job-driven dispatch pipeline that:
- Validates permissions and finds the assigned agent for an issue.
- Posts a “task sent” journal note.
- Invokes an AI agent client to generate a response that may include tool calls.
- Executes Redmine API skill tool calls and feeds results back iteratively.
- Persists request/response payloads and posts a final journal note.
- Handles errors and retries.

```mermaid
sequenceDiagram
participant User as "Triggering User"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
participant Redmine as "Redmine REST API"
User->>Ctrl : "POST /issues/ : id/ai_agent_dispatches"
Ctrl->>Ctrl : "authorize_dispatch()"
Ctrl->>Job : "perform_later(issue_id, agent_id, user_id)"
Job->>Job : "create dispatch record (status=running)"
Job->>Redmine : "post journal note"
Job->>Agent : "call(issue, triggered_by=user)"
Agent-->>Job : "initial result (text + request)"
loop Tool Loop (max 10)
Job->>Agent : "send updated messages"
Agent-->>Job : "response with tool_calls?"
alt Has tool_calls
Job->>Skill : "execute_tool_call(call)"
Skill->>Redmine : "HTTP request"
Redmine-->>Skill : "HTTP response"
Skill-->>Job : "tool_result"
Job->>Agent : "messages.append({role='tool', ...})"
else No tool_calls
break Agent finished
end
end
Job->>Job : "persist request/response payloads"
Job->>Redmine : "post final journal note"
Job-->>Ctrl : "dispatch status=done"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

## Detailed Component Analysis

### Plugin Registration and Permissions
- Registers plugin metadata and settings including base URL and default timeout.
- Defines project-level permissions for dispatching agents and managing agents/assignments.
- Adds an admin menu entry for AI Agents.

Security and configuration highlights:
- Settings include a base URL for Redmine REST API and a default timeout.
- Permissions enforce that only authorized users can dispatch agents per project.

**Section sources**
- [init.rb:3-16](file://init.rb#L3-L16)
- [init.rb:24-29](file://init.rb#L24-L29)

### Routes and Authorization
- Admin routes for agents (with test_connection) and assignments.
- Per-issue dispatch routes for create/index/show.
- Dispatch creation is protected by a project-level permission check.

Authorization enforcement:
- Dispatch action checks the current user’s permission against the issue’s project.

**Section sources**
- [routes.rb:2-16](file://config/routes.rb#L2-L16)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

### Models: Agent, Assignment, and Dispatch
- AiAgent stores agent profile, type, protocol, endpoint, and system prompt templates.
- AiAgentAssignment links users to agents and supports auto_dispatch flag.
- AiAgentDispatch tracks dispatch lifecycle, request/response payloads, and timing.

Key behaviors:
- AiAgent resolves a system prompt with placeholders for base URL, API key, issue ID, and project ID.
- AiAgentAssignment provides convenience methods to fetch the active agent for a user.
- AiAgentDispatch includes scopes for status filtering and helpers to parse payloads.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### Controllers: Management and Dispatch
- AiAgentsController: Admin CRUD for agents, including a connectivity test against configured endpoints.
- AiAgentAssignmentsController: Admin CRUD for user-agent assignments.
- AiAgentDispatchesController: Manual dispatch from an issue page with permission checks.

Connectivity testing:
- Supports both Kimi Web WebSocket and standard OpenAI-compatible endpoints.
- Uses short timeouts and returns structured JSON results.

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

### Job: Dispatch Pipeline and Tool Loop
- Creates a dispatch record and posts a “task sent” journal note.
- Invokes AgentClient and executes a tool loop:
  - Parses tool_calls from agent responses.
  - Executes Redmine API skill tool calls.
  - Appends tool results back to messages and queries the agent again.
  - Limits iterations to prevent runaway loops.
- Persists request/response payloads and posts a final journal note.
- Handles errors by marking dispatch as error and posting a journal note.

```mermaid
flowchart TD
Start(["Dispatch Job Start"]) --> CreateDispatch["Create dispatch record<br/>status=running"]
CreateDispatch --> PostStartNote["Post 'task sent' journal note"]
PostStartNote --> CallAgent["Call AgentClient with issue"]
CallAgent --> CheckToolCalls{"Has tool_calls?"}
CheckToolCalls --> |No| Finalize["Persist payloads<br/>Post final journal note<br/>status=done"]
CheckToolCalls --> |Yes| AppendMessages["Append tool_calls to messages"]
AppendMessages --> ExecuteTools["Execute RedmineApiSkill.tool_call(s)"]
ExecuteTools --> FeedBack["Append tool results as role='tool'"]
FeedBack --> CallAgent
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### Redmine API Skill System
The job constructs a Redmine API skill with:
- Base URL from plugin settings
- API key from the issue assignee
- Tool execution method to handle tool calls and return structured results

Capabilities:
- Issue reading via GET endpoints
- Issue updating via PUT endpoints
- Status enumeration via status endpoints
- Project context retrieval
- Attachment metadata retrieval

```mermaid
classDiagram
class RedmineApiSkill {
+execute_tool_call(tool_call)
+http_get(url)
+http_put(url, body)
}
class AiAgentDispatchJob {
+run_tool_loop(client, agent, issue, result)
}
AiAgentDispatchJob --> RedmineApiSkill : "instantiates and executes"
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

## Dependency Analysis
High-level dependencies:
- Controllers depend on models and ActiveJob for dispatch.
- Job depends on AgentClient and RedmineApiSkill.
- Models encapsulate business rules and validations.
- Plugin registration ties permissions and settings into Redmine.

```mermaid
graph LR
CTRL1["AiAgentsController"] --> MODEL1["AiAgent"]
CTRL2["AiAgentAssignmentsController"] --> MODEL2["AiAgentAssignment"]
CTRL3["AiAgentDispatchesController"] --> MODEL3["AiAgentDispatch"]
CTRL3 --> JOB["AiAgentDispatchJob"]
JOB --> MODEL1
JOB --> MODEL3
LIB["lib/redmine_ai_agent.rb"] --> JOB
INIT["init.rb"] --> ROUTES["config/routes.rb"]
```

**Diagram sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

## Performance Considerations
- Retries: The job retries transient errors with polynomial backoff to improve resilience.
- Timeouts: Controllers use short open/read timeouts for connectivity tests.
- Payload limits: Responses are truncated in logs to avoid excessive logging overhead.
- Iteration cap: Tool loop limits iterations to prevent long-running cycles.
- Journaling: Minimal journal writes reduce overhead while preserving audit trails.

Recommendations:
- Tune plugin settings for base URL and timeout based on network conditions.
- Monitor job queue backlog and adjust concurrency.
- Consider caching or memoizing repeated reads for the same resource.

**Section sources**
- [ai_agent_dispatch_job.rb:4-5](file://app/jobs/ai_agent_dispatch_job.rb#L4-L5)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [ai_agents_controller.rb:58-61](file://app/controllers/ai_agents_controller.rb#L58-L61)

## Troubleshooting Guide
Common issues and resolutions:
- Missing agent for assignee: Ensure a user is assigned an active agent via assignments.
- Permission denied: Verify the current user has the project-level dispatch permission.
- Connectivity failures: Use the agent test_connection endpoint to validate endpoint reachability and credentials.
- Empty agent response: The system posts a note indicating an empty response; review agent configuration and prompts.
- Tool loop errors: Inspect persisted request/response payloads and logs; the loop captures and logs errors internally.

Operational tips:
- Review dispatch records for status, durations, and payloads.
- Confirm plugin settings for base URL and timeout.
- Check journal entries for automated notes.

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)

## Conclusion
The Redmine AI Agent plugin provides a structured, permission-aware framework for AI agents to operate on Redmine issues. Through a job-driven dispatch pipeline and a tool-loop mechanism, it supports reading, updating, and status modification via a Redmine API skill. Built-in error handling, retries, and journaling ensure reliability and traceability. Administrators can configure agents, assign them to users, and monitor dispatch outcomes, while developers can extend the system by adding new tool calls to the Redmine API skill.

## Appendices

### Authentication and Authorization
- Authentication: The system uses a Redmine API key header for REST API calls. Keys are masked in logs and derived from the issue assignee.
- Authorization: Dispatch actions require project-level permissions; controllers enforce this during manual dispatch creation.

**Section sources**
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

### Practical Examples
- Manual dispatch: Trigger a dispatch from an issue page; the system enqueues a job and posts journal notes.
- Agent connectivity test: Use the agent test_connection endpoint to validate endpoint URLs and credentials.
- Tool loop: The job iteratively executes tool calls returned by the agent until completion or iteration limit.

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

### Extending the Skill System
To add custom operations:
- Extend the Redmine API skill to support new tool calls.
- Define tool call schemas and map them to REST API endpoints.
- Integrate tool execution into the job’s tool loop and ensure proper message appending.
- Add permission checks and journaling for new operations as needed.

[No sources needed since this section provides general guidance]