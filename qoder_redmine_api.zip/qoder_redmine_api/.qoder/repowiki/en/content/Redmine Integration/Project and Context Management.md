# Project and Context Management

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Privacy and Data Protection](#privacy-and-data-protection)
10. [Conclusion](#conclusion)

## Introduction
This document explains how AI agents maintain awareness of project boundaries, issue hierarchies, and contextual information during interactions with Redmine. It details context preservation mechanisms that ensure agents understand project-specific requirements, custom fields, and workflow states. It also covers attachment handling capabilities, allowing agents to reference and process file attachments within project contexts. Examples demonstrate context-aware AI behavior, project-specific prompt engineering, and maintaining conversational coherence across multiple interactions. Privacy and data protection considerations are addressed for handling sensitive project information.

## Project Structure
The plugin integrates with Redmine via controllers, models, jobs, and routing. It exposes admin and per-issue interfaces to configure agents, assign them to users, and dispatch them to work on issues. The job orchestrates agent execution, tool-loop processing, and journaling outcomes.

```mermaid
graph TB
subgraph "Admin UI"
A1["AI Agents<br/>CRUD + Test Connection"]
A2["Assignments<br/>User ↔ Agent"]
end
subgraph "Issue Context"
I1["Issue"]
P1["Project"]
J1["Journal Notes"]
end
subgraph "Agent Runtime"
M1["AiAgent"]
M2["AiAgentAssignment"]
M3["AiAgentDispatch"]
Jb["AiAgentDispatchJob"]
end
R1["Routes"]
A1 --> M1
A2 --> M2
I1 --> M3
P1 --> M3
Jb --> M3
Jb --> M1
Jb --> J1
R1 --> A1
R1 --> A2
R1 --> I1
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- AiAgent: Defines agent types, protocols, and system prompts. Provides resolved system prompts with issue/project tokens injected at runtime.
- AiAgentAssignment: Links users to active agents and supports auto-dispatch flags.
- AiAgentDispatch: Tracks dispatch lifecycle (pending, running, done, error), timing, and serialized request/response payloads.
- AiAgentDispatchJob: Orchestrates dispatch creation, journaling, agent invocation, tool-loop execution, and outcome persistence.
- Controllers: Admin CRUD for agents and assignments; per-issue dispatch creation and viewing.
- Routing: Exposes admin and per-issue endpoints.

Key context preservation mechanisms:
- System prompts include placeholders for Redmine base URL, API key, issue ID, and project ID, resolved per issue.
- Tool-loop augments messages with tool-call results, preserving context across turns.
- Dispatch records capture request/response payloads for auditability and reproducibility.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

## Architecture Overview
The system follows a job-orchestrated pattern: a user triggers a dispatch from an issue page, the job creates a dispatch record, posts a “task sent” journal note, invokes the agent client, executes tool calls against the Redmine API, and finally posts the agent’s response as a journal note. Status transitions and timing are tracked centrally.

```mermaid
sequenceDiagram
participant U as "User"
participant C as "AiAgentDispatchesController"
participant Q as "AiAgentDispatchJob"
participant D as "AiAgentDispatch"
participant A as "AiAgent"
participant S as "RedmineApiSkill"
participant R as "Redmine REST API"
U->>C : "Create dispatch for Issue"
C->>Q : "Enqueue job(issue_id, agent_id, user_id)"
Q->>D : "Create dispatch (status=running)"
Q->>R : "Post 'task sent' journal"
Q->>A : "Resolve system prompt (issue/project tokens)"
Q->>S : "Initialize skill with base_url/api_key"
Q->>A : "Call agent (initial request)"
A-->>Q : "Initial response (may include tool_calls)"
loop "Tool-loop (up to N turns)"
Q->>S : "Execute tool_call(s)"
S->>R : "GET/PUT project/issue/statuses/attachments"
R-->>S : "Resource data"
S-->>Q : "Tool results"
Q->>A : "Send updated messages"
A-->>Q : "Next response"
end
Q->>D : "Persist request/response payloads"
Q->>R : "Post 'agent response' journal"
Q->>D : "Set status=done/completed_at"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)

## Detailed Component Analysis

### AiAgent: Agent Types, Protocols, and System Prompts
- Supports agent types and protocols enabling different client behaviors and endpoints.
- Provides system prompt templates per agent type, embedding Redmine base URL, API key, issue ID, and project ID.
- Resolves system prompts per issue by injecting current values, ensuring context-awareness.

```mermaid
classDiagram
class AiAgent {
+AGENTS
+PROTOCOLS
+has_many ai_agent_assignments
+has_many ai_agent_dispatches
+safe_api_key()
+chat_completions?()
+responses_api?()
+hermes?()
+pi?()
+qoder?()
+kimi_web?()
+kimi_web_ws?()
+resolved_system_prompt(issue)
}
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [ai_agent.rb:52-140](file://app/models/ai_agent.rb#L52-L140)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)

### AiAgentAssignment: User-Agent Linkage and Auto-Dispatch
- Enforces uniqueness of user-to-agent assignment.
- Provides convenience methods to fetch the active agent for a user and check auto-dispatch flag.

```mermaid
classDiagram
class AiAgentAssignment {
+belongs_to user
+belongs_to ai_agent
+for_user(user)
+agent_for(user)
+auto_dispatch?
}
```

**Diagram sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

**Section sources**
- [ai_agent_assignment.rb:8-20](file://app/models/ai_agent_assignment.rb#L8-L20)

### AiAgentDispatch: Lifecycle, Payloads, and Timing
- Tracks dispatch status transitions and computes duration.
- Parses and exposes request/response payloads for auditing.
- Associates with triggering user and optional journal.

```mermaid
classDiagram
class AiAgentDispatch {
+STATUSES
+belongs_to issue
+belongs_to ai_agent
+belongs_to triggered_by_user
+pending?()
+running?()
+done?()
+error?()
+finished?()
+duration()
+request_data()
+response_data()
}
```

**Diagram sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [ai_agent_dispatch.rb:14-31](file://app/models/ai_agent_dispatch.rb#L14-L31)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)

### AiAgentDispatchJob: Orchestration, Tool-Loop, and Journaling
- Creates a running dispatch, posts “task sent” journal, and invokes the agent client.
- Executes a tool-loop to call Redmine API skills and feeds results back to the agent.
- Persists request/response payloads and posts the agent’s final response as a journal note.
- Handles errors by marking status as error and posting a journal note.

```mermaid
flowchart TD
Start(["Job Start"]) --> Load["Load Issue/Agent/Trigger"]
Load --> Valid{"Records Found?"}
Valid --> |No| LogWarn["Log warning and exit"]
Valid --> |Yes| CreateDisp["Create Dispatch (running)"]
CreateDisp --> PostStart["Post 'task sent' journal"]
PostStart --> InitClient["Init AgentClient"]
InitClient --> CallAgent["Call Agent (initial request)"]
CallAgent --> ToolLoop{"Has tool_calls?"}
ToolLoop --> |No| SaveDone["Save request/response payloads<br/>Set status=done"]
ToolLoop --> |Yes| ExecTools["Execute tool calls via RedmineApiSkill"]
ExecTools --> FeedBack["Append tool results to messages"]
FeedBack --> CallAgent
SaveDone --> PostDone["Post 'agent response' journal"]
PostDone --> End(["Job End"])
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:17-47](file://app/jobs/ai_agent_dispatch_job.rb#L17-L47)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

### Controllers and Routing: Dispatch Triggers and Admin Management
- Admin endpoints manage agents and assignments.
- Per-issue dispatches support manual trigger and viewing dispatch history.
- Authorization checks ensure only authorized users can dispatch agents on a given project.

```mermaid
sequenceDiagram
participant U as "User"
participant RC as "AiAgentDispatchesController"
participant AJ as "AiAgentDispatchJob"
participant AD as "AiAgentDispatch"
U->>RC : "POST /issues/ : id/ai_agent_dispatches"
RC->>RC : "Authorize dispatch"
RC->>AJ : "Enqueue job"
AJ->>AD : "Create dispatch"
AJ-->>U : "Flash notice"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [routes.rb:12-15](file://config/routes.rb#L12-L15)

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_assignments_controller.rb:16-26](file://app/controllers/ai_agent_assignments_controller.rb#L16-L26)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [routes.rb:2-7](file://config/routes.rb#L2-L7)
- [routes.rb:9-15](file://config/routes.rb#L9-L15)

## Dependency Analysis
- AiAgentDispatch depends on Issue, AiAgent, and User (triggered_by).
- AiAgentDispatchJob depends on AiAgent, Issue, User, and RedmineApiSkill.
- Controllers depend on models and enforce permissions.
- Routes connect UI actions to controllers.

```mermaid
graph LR
Issue --> AiAgentDispatch
AiAgent --> AiAgentDispatch
User --> AiAgentDispatch
AiAgentDispatch --> AiAgentDispatchJob
AiAgent --> AiAgentDispatchJob
Issue --> AiAgentDispatchJob
AiAgentDispatchJob --> RedmineApiSkill
AiAgentDispatchesController --> AiAgentDispatchJob
AiAgentsController --> AiAgent
AiAgentAssignmentsController --> AiAgentAssignment
```

**Diagram sources**
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)
- [ai_agent_dispatch_job.rb:37-85](file://app/jobs/ai_agent_dispatch_job.rb#L37-L85)
- [ai_agent_dispatches_controller.rb:17-31](file://app/controllers/ai_agent_dispatches_controller.rb#L17-L31)
- [ai_agents_controller.rb:102-108](file://app/controllers/ai_agents_controller.rb#L102-L108)
- [ai_agent_assignments_controller.rb:52-54](file://app/controllers/ai_agent_assignments_controller.rb#L52-L54)

**Section sources**
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)
- [ai_agent_dispatch_job.rb:37-85](file://app/jobs/ai_agent_dispatch_job.rb#L37-L85)
- [ai_agent_dispatches_controller.rb:17-31](file://app/controllers/ai_agent_dispatches_controller.rb#L17-L31)

## Performance Considerations
- Tool-loop iteration limit prevents runaway loops; adjust as needed for complex tasks.
- Job retries with exponential backoff mitigate transient network errors.
- Request/response payloads are persisted; consider storage implications for large attachments or long histories.
- Journaling occurs synchronously within the job; monitor for latency under heavy load.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and remedies:
- Missing agent for assignee: Ensure a user has an active agent assignment.
- Dispatch not enqueued: Verify permissions and that the agent is active.
- Empty agent response: The job falls back to a neutral message and still posts a journal note.
- Tool-loop failures: Errors are logged; inspect request/response payloads and tool-call results.
- Connection tests: Use the agent’s test connection endpoint to validate endpoint reachability and credentials.

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [ai_agent_dispatch_job.rb:50-57](file://app/jobs/ai_agent_dispatch_job.rb#L50-L57)
- [ai_agent_dispatch_job.rb:116-119](file://app/jobs/ai_agent_dispatch_job.rb#L116-L119)
- [ai_agents_controller.rb:50-92](file://app/controllers/ai_agents_controller.rb#L50-L92)

## Privacy and Data Protection
- API keys are masked in serializations to avoid exposure in logs.
- System prompts embed the API key placeholder; ensure only authorized users can configure agents and that prompts are not stored in plaintext logs.
- Request/response payloads are persisted; restrict access to dispatch records and logs to authorized users.
- Attachment metadata is exposed via endpoints; ensure agents only access attachments relevant to the current issue and project.
- Consider encryption at rest for payloads if handling highly sensitive data.

**Section sources**
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent.rb:64-74](file://app/models/ai_agent.rb#L64-L74)

## Conclusion
The plugin establishes robust context preservation for AI agents interacting with Redmine by resolving system prompts per issue, maintaining a tool-loop with augmented messages, and persisting dispatch payloads. Dispatches are journaled for transparency, and the architecture supports project-level permissions and secure handling of credentials. By leveraging these mechanisms, agents remain aware of project boundaries, issue hierarchies, and contextual requirements while operating within strict privacy and data protection constraints.