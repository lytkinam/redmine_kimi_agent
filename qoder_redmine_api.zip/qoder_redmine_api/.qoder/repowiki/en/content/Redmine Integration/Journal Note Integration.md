# Journal Note Integration

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [en.yml](file://config/locales/en.yml)
- [_dispatch_panel.html.erb](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Privacy and Security Considerations](#privacy-and-security-considerations)
10. [Customization Guide](#customization-guide)
11. [Conclusion](#conclusion)

## Introduction
This document explains how AI agent activities and responses are integrated into Redmine’s journal system to maintain audit trails and activity tracking. It documents the journal note posting mechanism that captures AI agent interactions, decisions, and outcomes, and how dispatch records are linked to issue histories. It also covers the integration with Redmine’s journal API, examples of journal note formatting and metadata inclusion, user attribution, privacy considerations for sensitive AI interactions, and guidance for customizing journal note content and formatting.

## Project Structure
The plugin extends Redmine through a combination of models, controllers, jobs, hooks, and localization resources. The journal integration is implemented primarily in the job that orchestrates AI agent calls and posts journal notes, with auxiliary components handling tool execution, view injection, and configuration.

```mermaid
graph TB
subgraph "Plugin Entry"
INIT["init.rb"]
REG["lib/redmine_ai_agent.rb"]
end
subgraph "Models"
DISPATCH["app/models/ai_agent_dispatch.rb"]
end
subgraph "Controllers"
CTRL["app/controllers/ai_agent_dispatches_controller.rb"]
end
subgraph "Jobs"
JOB["app/jobs/ai_agent_dispatch_job.rb"]
end
subgraph "Hooks"
HOOKS["lib/redmine_ai_agent/hooks.rb"]
end
subgraph "Clients"
AC["lib/redmine_ai_agent/agent_client.rb"]
SKILL["lib/redmine_ai_agent/redmine_api_skill.rb"]
end
subgraph "Views"
PANEL["_dispatch_panel.html.erb"]
end
subgraph "Locales"
I18N["config/locales/en.yml"]
end
INIT --> REG
REG --> HOOKS
REG --> AC
REG --> SKILL
CTRL --> JOB
JOB --> DISPATCH
JOB --> AC
JOB --> SKILL
HOOKS --> PANEL
I18N --> JOB
I18N --> PANEL
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Core Components
- AiAgentDispatch: Tracks each AI agent invocation per issue, including status, timestamps, request/response payloads, and the associated journal entry.
- AiAgentDispatchesController: Provides manual dispatch initiation from the issue page and lists dispatch history.
- AiAgentDispatchJob: Orchestrates the end-to-end process: creates the dispatch record, posts “task sent” journal notes, calls the agent, executes tool calls against Redmine, persists results, and posts completion/error journal notes.
- AgentClient: Builds agent requests, posts to the AI provider, and extracts textual output; includes issue context and optional tool definitions for supported agents.
- RedmineApiSkill: Executes tool calls server-side to read/update Redmine resources, enabling autonomous actions by the agent.
- Hooks: Injects a panel into the issue view for manual dispatch and auto-dispatches when issues are assigned or created.
- Localization: Provides journal note templates and UI labels.

Key integration points for journaling:
- Dispatch creation and initial “task sent” note posted via the job.
- Completion note containing agent response text.
- Error note capturing failures.
- Tool execution results appended to the agent loop and reflected in subsequent steps.

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)

## Architecture Overview
The journal note integration is centered around the dispatch job. It manages lifecycle events and posts notes at each stage, linking the dispatch record to the journal entry for traceability.

```mermaid
sequenceDiagram
participant U as "User"
participant C as "AiAgentDispatchesController"
participant J as "AiAgentDispatchJob"
participant M as "AiAgentDispatch (Model)"
participant AC as "AgentClient"
participant RS as "RedmineApiSkill"
participant R as "Redmine API"
participant I as "Issue (Journal)"
U->>C : "POST /issues/ : id/ai_agent_dispatches"
C->>J : "Enqueue dispatch job"
J->>M : "Create dispatch (status=running)"
J->>I : "Post 'task sent' journal note"
J->>AC : "Call agent with issue context"
AC-->>J : "Raw response + parsed text"
J->>RS : "Execute tool calls (optional)"
RS->>R : "GET/PUT Redmine resources"
R-->>RS : "Responses"
RS-->>J : "Tool results"
J->>M : "Persist request/response payloads"
alt Success
J->>I : "Post 'completed' journal note"
else Error
J->>I : "Post 'error' journal note"
end
J->>M : "Set status=done/error, completed_at"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch.rb:18-47](file://app/models/ai_agent_dispatch.rb#L18-L47)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)

## Detailed Component Analysis

### AiAgentDispatch Job: Journal Note Lifecycle
The job encapsulates the entire lifecycle and journal note posting:
- Creates the dispatch record with initial status and timestamps.
- Posts the “task sent” journal note using the issue’s journal API.
- Calls the agent and optionally runs a tool loop to execute Redmine API calls.
- Persists request/response payloads and sets completion timestamps.
- Posts either a “completed” or “error” journal note depending on outcome.

```mermaid
flowchart TD
Start(["Job Start"]) --> CreateDispatch["Create dispatch record<br/>status=running, set dispatched_at"]
CreateDispatch --> PostStartNote["Post 'task sent' journal note"]
PostStartNote --> CallAgent["Call AgentClient with issue context"]
CallAgent --> ToolLoop{"Tool calls present?"}
ToolLoop --> |Yes| ExecuteTools["Execute tool calls via RedmineApiSkill"]
ExecuteTools --> FeedBack["Feed tool results back to agent"]
FeedBack --> CallAgent
ToolLoop --> |No| Persist["Persist request/response payloads<br/>set status=done, completed_at"]
Persist --> PostDone["Post 'completed' journal note"]
CallAgent --> HandleError{"Error occurred?"}
HandleError --> |Yes| MarkError["Mark dispatch error<br/>persist error payload"]
MarkError --> PostError["Post 'error' journal note"]
PostDone --> End(["Job End"])
PostError --> End
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:17-67](file://app/jobs/ai_agent_dispatch_job.rb#L17-L67)
- [ai_agent_dispatch.rb:18-47](file://app/models/ai_agent_dispatch.rb#L18-L47)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### AgentClient: Issue Context and Tool Definitions
The client builds a contextualized prompt for the agent, including recent journal notes, and optionally exposes Redmine API tools for agents that support function/tool calling. This ensures the agent can reference prior human interactions and act autonomously when permitted.

```mermaid
classDiagram
class AgentClient {
+call(issue, triggered_by)
-build_payload(issue)
-build_chat_completions_payload(issue)
-build_responses_payload(issue)
-issue_context_message(issue)
-redmine_tools(issue)
-post_to_agent(payload)
-extract_text(raw)
}
class RedmineApiSkill {
+execute_tool_call(tool_call)
+get_issue(issue_id)
+update_issue(issue_id, notes, status_id, done_ratio)
+list_statuses()
+get_project(project_id)
}
AgentClient --> RedmineApiSkill : "executes tool calls"
```

**Diagram sources**
- [agent_client.rb:28-112](file://lib/redmine_ai_agent/agent_client.rb#L28-L112)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [redmine_api_skill.rb:36-86](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L86)

**Section sources**
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)

### Hooks and View Panel: Auto-dispatch and Manual Trigger
The hooks integrate with Redmine’s lifecycle to auto-dispatch when an issue is assigned or created, and inject a panel into the issue view for manual dispatch and history.

```mermaid
sequenceDiagram
participant S as "Redmine System"
participant H as "RedmineAiAgent : : Hooks"
participant V as "_dispatch_panel.html.erb"
participant C as "AiAgentDispatchesController"
S->>H : "Issues edit/new save callbacks"
H->>H : "check_and_auto_dispatch()"
H->>C : "Enqueue dispatch job"
S->>V : "Render issue details bottom"
V->>V : "Render dispatch panel with history"
```

**Diagram sources**
- [hooks.rb:4-22](file://lib/redmine_ai_agent/hooks.rb#L4-L22)
- [hooks.rb:28-47](file://lib/redmine_ai_agent/hooks.rb#L28-L47)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)

**Section sources**
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

### Data Model: Dispatch Records and Journal Linkage
Dispatch records capture the end-to-end execution and link to the initial journal note for traceability.

```mermaid
erDiagram
AI_AGENT_DISPATCHES {
integer id PK
integer issue_id FK
integer ai_agent_id FK
integer triggered_by
string status
text request_payload
text response_payload
integer journal_id
datetime dispatched_at
datetime completed_at
timestamps
}
ISSUES ||--o{ AI_AGENT_DISPATCHES : "has many"
AI_AGENTS ||--o{ AI_AGENT_DISPATCHES : "has many"
```

**Diagram sources**
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

## Dependency Analysis
- The job depends on the model for dispatch state, the agent client for external API calls, and the skill module for tool execution.
- The controller depends on the job and authorization checks.
- The hooks depend on settings and assignment lookup to decide auto-dispatch.
- Localization defines the journal note templates used by the job.

```mermaid
graph LR
CTRL["Controller"] --> JOB["Job"]
JOB --> MODEL["Model"]
JOB --> AC["AgentClient"]
JOB --> SKILL["RedmineApiSkill"]
HOOKS["Hooks"] --> JOB
I18N["Localization"] --> JOB
VIEW["View Panel"] --> CTRL
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)

**Section sources**
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)

## Performance Considerations
- Network timeouts: The agent client and skill module define explicit timeouts for outbound calls. Configure the plugin’s default timeout to balance responsiveness and reliability.
- Retries: The job retries transient errors for agent calls, reducing manual intervention for temporary failures.
- Tool loop limits: The agent loop caps iterations to prevent runaway processing and excessive API calls.
- Payload persistence: Request/response payloads are stored as text; consider log rotation and storage policies for long-running instances.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and diagnostics:
- Missing agent for assignee: The controller surfaces a user-facing notice when no active agent is assigned to the current assignee.
- Dispatch enqueue notice: After manual dispatch, a notice indicates the task was enqueued and to check the journal for updates.
- Journal posting failures: The job logs errors when journal posting fails and continues processing; check logs for details.
- Error journal note: On exceptions, the job posts an error note with sanitized details and marks the dispatch as failed.
- Timeout and invalid JSON: Agent client raises specific errors for timeouts and malformed responses; verify endpoint URLs and credentials.

**Section sources**
- [ai_agent_dispatches_controller.rb:22-35](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L35)
- [ai_agent_dispatch_job.rb:75-78](file://app/jobs/ai_agent_dispatch_job.rb#L75-L78)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [agent_client.rb:223-229](file://lib/redmine_ai_agent/agent_client.rb#L223-L229)
- [en.yml:69-72](file://config/locales/en.yml#L69-L72)

## Privacy and Security Considerations
- Sensitive data exposure: The agent receives a contextualized prompt that includes recent journal notes. Review the prompt building logic to ensure sensitive information is not inadvertently exposed to the agent.
- API keys and tokens: Ensure the plugin’s base URL and agent endpoint configurations are correct and secure. Avoid exposing secrets in logs or UI.
- Tool execution scope: Only agents that support function/tool calling can autonomously update Redmine resources. Verify agent capabilities and restrict assignments accordingly.
- User attribution: Journal notes are attributed to the triggering user, ensuring traceability while respecting user privacy.

[No sources needed since this section provides general guidance]

## Customization Guide
- Journal note formatting: Customize the templates used by the job under the localization keys for dispatch started, done, and error notes.
- Content inclusion: Adjust the agent client’s issue context builder to include or exclude specific fields from the prompt.
- Tool availability: Modify the tool definitions for agents that support function/tool calling to expand or constrain Redmine API access.
- Auto-dispatch behavior: Control auto-dispatch via the assignment settings and hooks; adjust conditions in the hooks module if needed.
- UI panel: Extend the view panel to display additional metrics or actions related to dispatch history.

Examples of customization targets:
- Journal note templates: [en.yml:94-97](file://config/locales/en.yml#L94-L97)
- Issue context builder: [agent_client.rb:83-112](file://lib/redmine_ai_agent/agent_client.rb#L83-L112)
- Tool definitions: [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- Auto-dispatch logic: [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- View panel rendering: [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)

**Section sources**
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)
- [agent_client.rb:83-112](file://lib/redmine_ai_agent/agent_client.rb#L83-L112)
- [agent_client.rb:119-186](file://lib/redmine_ai_agent/agent_client.rb#L119-L186)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [_dispatch_panel.html.erb:1-85](file://app/views/ai_agent_dispatches/_dispatch_panel.html.erb#L1-L85)

## Conclusion
The journal note integration provides a robust audit trail for AI agent interactions within Redmine. Dispatch records capture the lifecycle of each invocation, while journal notes communicate start, completion, and error states to all stakeholders. The system supports both manual triggers and auto-dispatch, integrates agent tool calls with Redmine’s API, and offers extensibility through localization and configuration. Careful attention to privacy and customization ensures responsible and effective use of AI-assisted issue processing.