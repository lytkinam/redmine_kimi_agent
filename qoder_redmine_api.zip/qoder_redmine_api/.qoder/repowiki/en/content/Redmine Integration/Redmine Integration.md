# Redmine Integration

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [SKILL.md](file://kimi-web/SKILL.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the Redmine Integration plugin that connects AI agents to Redmine’s event system and API. It covers:
- Hook-based automation that triggers AI processing on issue assignment and creation
- Journal note posting to log AI actions and outcomes
- Issue status updates and property modifications via the Redmine API
- Attachment handling and project context management during agent interactions
- The Redmine API skill system enabling tool-calling for executing Redmine operations
- Practical integration scenarios and troubleshooting guidance

## Project Structure
The plugin is organized around Redmine’s plugin conventions:
- Plugin registration and permissions in init.rb
- Routing for admin and per-issue dispatch in routes.rb
- Models for agents, assignments, and dispatch records
- Jobs for asynchronous AI processing
- Libraries implementing hooks, agent clients, and skills
- Migrations defining database schema
- Views and controllers for administration and manual dispatch
- Optional Kimi Web integration scripts and documentation

```mermaid
graph TB
subgraph "Plugin Core"
INIT["init.rb"]
ROUTES["config/routes.rb"]
end
subgraph "Models"
AI_AGENT["app/models/ai_agent.rb"]
AI_ASSIGN["app/models/ai_agent_assignment.rb"]
AI_DISPATCH["app/models/ai_agent_dispatch.rb"]
end
subgraph "Jobs"
JOB["app/jobs/ai_agent_dispatch_job.rb"]
end
subgraph "Libraries"
HOOKS["lib/redmine_ai_agent/hooks.rb"]
CLIENT["lib/redmine_ai_agent/agent_client.rb"]
SKILL["lib/redmine_ai_agent/redmine_api_skill.rb"]
REG["lib/redmine_ai_agent.rb"]
end
subgraph "Controllers & Views"
CTRL_AGENTS["app/controllers/ai_agents_controller.rb"]
CTRL_ASSIGNS["app/controllers/ai_agent_assignments_controller.rb"]
CTRL_DISPATCH["app/controllers/ai_agent_dispatches_controller.rb"]
VIEW_SETTINGS["app/views/settings/_ai_agent_settings.html.erb"]
end
subgraph "Migrations"
MIG1["db/migrate/001_create_ai_agents.rb"]
MIG2["db/migrate/002_create_ai_agent_assignments.rb"]
MIG3["db/migrate/003_create_ai_agent_dispatches.rb"]
MIG4["db/migrate/004_add_kimi_web_to_ai_agents.rb"]
end
INIT --> ROUTES
INIT --> HOOKS
INIT --> CLIENT
INIT --> SKILL
ROUTES --> CTRL_AGENTS
ROUTES --> CTRL_ASSIGNS
ROUTES --> CTRL_DISPATCH
CTRL_AGENTS --> AI_AGENT
CTRL_ASSIGNS --> AI_ASSIGN
CTRL_DISPATCH --> AI_DISPATCH
JOB --> AI_DISPATCH
JOB --> CLIENT
JOB --> SKILL
HOOKS --> JOB
AI_AGENT --> AI_DISPATCH
AI_ASSIGN --> AI_AGENT
MIG1 --> AI_AGENT
MIG2 --> AI_ASSIGN
MIG3 --> AI_DISPATCH
MIG4 --> AI_AGENT
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [hooks.rb:1-36](file://lib/redmine_ai_agent/hooks.rb#L1-L36)
- [agent_client.rb:115-149](file://lib/redmine_ai_agent/agent_client.rb#L115-L149)
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch.rb:1-43](file://app/models/ai_agent_dispatch.rb#L1-L43)
- [ai_agent_dispatch_job.rb:1-102](file://app/jobs/ai_agent_dispatch_job.rb#L1-L102)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb:1-23](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L23)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- Plugin registration and permissions define the module, settings, and admin menu entries.
- Hook listeners integrate with Redmine’s lifecycle events to auto-dispatch AI agents on issue updates and creation.
- Agent client composes prompts, attaches issue context, and defines tool schemas for supported agents.
- Redmine API skill executes tool calls server-side against Redmine endpoints.
- Dispatch job orchestrates asynchronous processing, posts journal notes, and manages tool loops.
- Models encapsulate agent definitions, user-agent assignments, and dispatch records with indexing and validations.
- Routes expose admin CRUD and per-issue dispatch endpoints.

**Section sources**
- [init.rb:3-30](file://init.rb#L3-L30)
- [hooks.rb:1-36](file://lib/redmine_ai_agent/hooks.rb#L1-L36)
- [agent_client.rb:84-116](file://lib/redmine_ai_agent/agent_client.rb#L84-L116)
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [ai_agent_dispatch_job.rb:1-102](file://app/jobs/ai_agent_dispatch_job.rb#L1-L102)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_dispatch.rb:1-43](file://app/models/ai_agent_dispatch.rb#L1-L43)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Architecture Overview
The integration uses Redmine hooks to detect issue changes, queues a background job to process the issue with an AI agent, and posts journal notes to track progress and outcomes. Tool-calling responses are executed via the Redmine API skill system.

```mermaid
sequenceDiagram
participant Hook as "Hooks"
participant Job as "AiAgentDispatchJob"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
participant Redmine as "Redmine API"
Hook->>Job : "Auto-dispatch on issue update/new"
Job->>Job : "Create dispatch record<br/>Post 'dispatch started' journal"
Job->>Agent : "Call agent with issue context"
Agent-->>Job : "Response (text or tool_calls)"
alt "tool_calls present"
loop "Up to 10 turns"
Job->>Skill : "execute_tool_call()"
Skill->>Redmine : "HTTP request"
Redmine-->>Skill : "Response"
Skill-->>Job : "Execution result"
Job->>Agent : "Feed tool result"
end
end
Job->>Redmine : "Optional issue updates (status, notes)"
Job->>Job : "Post final journal note(s)"
Job->>Job : "Mark dispatch complete/error"
```

**Diagram sources**
- [hooks.rb:3-22](file://lib/redmine_ai_agent/hooks.rb#L3-L22)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:115-149](file://lib/redmine_ai_agent/agent_client.rb#L115-L149)
- [redmine_api_skill.rb:34-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L41)

## Detailed Component Analysis

### Hook System and Issue Assignment Triggers
- The hook listener listens to issue edit save and new issue save events.
- It checks whether the assignee changed (on edits) or the issue is newly assigned (on creation).
- On match, it triggers an auto-dispatch to the assigned AI agent.

```mermaid
flowchart TD
Start(["Issue Edit/New Save"]) --> CheckAssignee["Check assignee change<br/>or new assignment"]
CheckAssignee --> |No| EndNoop["Do nothing"]
CheckAssignee --> |Yes| FindAgent["Find active agent for assignee"]
FindAgent --> Found{"Agent found?"}
Found --> |No| EndNoop
Found --> |Yes| QueueJob["Queue AiAgentDispatchJob"]
QueueJob --> EndDone["Dispatch queued"]
```

**Diagram sources**
- [hooks.rb:3-22](file://lib/redmine_ai_agent/hooks.rb#L3-L22)

**Section sources**
- [hooks.rb:3-22](file://lib/redmine_ai_agent/hooks.rb#L3-L22)

### Journal Note Posting Mechanism
- The dispatch job posts a “task sent” journal note immediately upon starting.
- After agent processing, it posts additional notes summarizing progress and outcomes.
- Journal posting is performed via the issue’s journal initialization and save.

```mermaid
sequenceDiagram
participant Job as "AiAgentDispatchJob"
participant Issue as "Issue"
participant User as "Trigger User"
Job->>Issue : "init_journal(User, message)"
Issue-->>Job : "Journal object"
Job->>Issue : "save!"
Issue-->>Job : "Success"
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:71-78](file://app/jobs/ai_agent_dispatch_job.rb#L71-L78)

**Section sources**
- [ai_agent_dispatch_job.rb:26-34](file://app/jobs/ai_agent_dispatch_job.rb#L26-L34)
- [ai_agent_dispatch_job.rb:71-78](file://app/jobs/ai_agent_dispatch_job.rb#L71-L78)

### Issue Status Updates and Property Modifications
- The agent client defines tool schemas for reading and updating issues.
- The skill system executes tool calls to update issue fields and post notes.
- The job feeds tool results back to the agent and repeats the loop until completion.

```mermaid
flowchart TD
A["Agent returns tool_calls"] --> B["Parse function name and arguments"]
B --> C{"Operation?"}
C --> |GET issue| D["Fetch issue details"]
C --> |UPDATE issue| E["Update fields and post notes"]
D --> F["Append tool result to messages"]
E --> F
F --> G{"More tool_calls?"}
G --> |Yes| B
G --> |No| H["Return final text to user"]
```

**Diagram sources**
- [agent_client.rb:115-149](file://lib/redmine_ai_agent/agent_client.rb#L115-L149)
- [redmine_api_skill.rb:34-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L41)
- [ai_agent_dispatch_job.rb:80-102](file://app/jobs/ai_agent_dispatch_job.rb#L80-L102)

**Section sources**
- [agent_client.rb:115-149](file://lib/redmine_ai_agent/agent_client.rb#L115-L149)
- [redmine_api_skill.rb:34-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L41)
- [ai_agent_dispatch_job.rb:80-102](file://app/jobs/ai_agent_dispatch_job.rb#L80-L102)

### Attachment Handling and Project Context Management
- The agent prompt templates include project context retrieval and issue attachments metadata endpoints.
- The agent client composes a contextualized prompt including recent journal notes and issue details.
- This ensures the agent can reason about project conventions and referenced attachments when proposing updates.

**Section sources**
- [ai_agent.rb:52-140](file://app/models/ai_agent.rb#L52-L140)
- [agent_client.rb:84-112](file://lib/redmine_ai_agent/agent_client.rb#L84-L112)

### Redmine API Skill System (Tool Calling)
- The skill system parses tool_call payloads and executes corresponding Redmine API operations.
- It supports GET and PUT operations on issues and project metadata.
- Errors are captured with status codes for robust handling.

```mermaid
classDiagram
class RedmineApiSkill {
+initialize(base_url, api_key, timeout)
+execute_tool_call(tool_call) Hash
}
class AgentClient {
+redmine_tools(issue) Array
}
RedmineApiSkill <.. AgentClient : "used by job"
```

**Diagram sources**
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [agent_client.rb:115-149](file://lib/redmine_ai_agent/agent_client.rb#L115-L149)

**Section sources**
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [agent_client.rb:115-149](file://lib/redmine_ai_agent/agent_client.rb#L115-L149)

### Dispatch Workflow and Manual Triggering
- Routes enable per-issue dispatch creation and viewing dispatch details.
- Controllers manage agent CRUD, assignment CRUD, and dispatch creation.
- The job updates dispatch status and timestamps, and posts journal notes.

```mermaid
sequenceDiagram
participant User as "User"
participant Ctrl as "Issues/ : id/ai_agent_dispatches"
participant Job as "AiAgentDispatchJob"
participant Model as "AiAgentDispatch"
User->>Ctrl : "POST create dispatch"
Ctrl->>Model : "Create dispatch record"
Ctrl->>Job : "Enqueue job"
Job->>Model : "Update status to running/completed"
Job->>User : "Post journal notes"
```

**Diagram sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb:17-24](file://app/jobs/ai_agent_dispatch_job.rb#L17-L24)
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)

**Section sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb:17-24](file://app/jobs/ai_agent_dispatch_job.rb#L17-L24)
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)

### Kimi Web Integration
- The agent type includes a web socket variant for Kimi Web.
- A Python script and skill documentation support the external integration.
- The agent client excludes built-in tool definitions for this agent type.

**Section sources**
- [ai_agent.rb:2, 44-50](file://app/models/ai_agent.rb#L2,L44-L50)
- [agent_client.rb:120-124](file://lib/redmine_ai_agent/agent_client.rb#L120-L124)
- [kimi-web-ws.py:116-148](file://kimi-web/scripts/kimi-web-ws.py#L116-L148)
- [SKILL.md](file://kimi-web/SKILL.md)

## Dependency Analysis
The plugin exhibits clear separation of concerns:
- Hooks depend on models and jobs to orchestrate processing
- Jobs depend on agent clients and skills to execute operations
- Models encapsulate persistence and validations
- Routes connect UI actions to controllers and jobs

```mermaid
graph LR
Hooks["Hooks"] --> Job["AiAgentDispatchJob"]
Job --> Client["AgentClient"]
Job --> Skill["RedmineApiSkill"]
Client --> Models["AiAgent/AiAgentDispatch"]
Skill --> RedmineAPI["Redmine REST API"]
Routes["Routes"] --> Controllers["Controllers"]
Controllers --> Models
Controllers --> Job
```

**Diagram sources**
- [hooks.rb:1-36](file://lib/redmine_ai_agent/hooks.rb#L1-L36)
- [ai_agent_dispatch_job.rb:1-102](file://app/jobs/ai_agent_dispatch_job.rb#L1-L102)
- [agent_client.rb:115-149](file://lib/redmine_ai_agent/agent_client.rb#L115-L149)
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

**Section sources**
- [hooks.rb:1-36](file://lib/redmine_ai_agent/hooks.rb#L1-L36)
- [ai_agent_dispatch_job.rb:1-102](file://app/jobs/ai_agent_dispatch_job.rb#L1-L102)
- [agent_client.rb:115-149](file://lib/redmine_ai_agent/agent_client.rb#L115-L149)
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Performance Considerations
- Asynchronous processing: All agent interactions run in background jobs to avoid blocking UI threads.
- Retries: Jobs retry transient errors with exponential backoff to improve resilience.
- Tool loop limits: The agent tool loop caps at a fixed number of iterations to prevent runaway processing.
- Indexing: Database indexes on dispatches accelerate filtering and reporting.
- Prompt composition: Efficiently includes only recent journal notes to reduce token usage.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Plugin disabled or misconfigured
  - Verify plugin enabled and base URL configured in settings.
  - Confirm permissions for dispatch and management actions.
- Missing agent or assignment
  - Ensure an active agent exists and is assigned to the user who was assigned to the issue.
- Network timeouts or API errors
  - Check endpoint URLs and API keys; confirm network connectivity to Redmine.
  - Review job logs for transient error retries.
- Tool call failures
  - Inspect tool_call payloads and ensure required fields are present.
  - Validate that the agent supports tool calls and the function names match the skill definitions.
- Journal note not posted
  - Confirm the dispatch job reaches the journal posting step and that saving the issue succeeds.
- Kimi Web integration
  - Ensure the external WebSocket script is running and configured according to the skill documentation.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [ai_agent_dispatch_job.rb:5, 66](file://app/jobs/ai_agent_dispatch_job.rb#L5,L66)
- [redmine_api_skill.rb:20-26](file://lib/redmine_ai_agent/redmine_api_skill.rb#L20-L26)
- [ai_agent_dispatch_job.rb:26-34](file://app/jobs/ai_agent_dispatch_job.rb#L26-L34)

## Conclusion
The Redmine Integration plugin seamlessly connects AI agents to Redmine’s event system and API. Through hooks, background jobs, and a skill-based tool execution system, it automates issue processing, logs progress via journal notes, and safely updates issue properties. Administrators can configure agents, assign them to users, and manually dispatch agents per issue. The modular design and clear separation of concerns make it maintainable and extensible.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Practical Integration Scenarios
- Auto-dispatch on assignment
  - Assign an issue to a user with an active agent; the hook triggers automatic processing.
- Manual dispatch
  - Navigate to an issue and create a dispatch to trigger the agent regardless of assignment changes.
- Tool-driven updates
  - Configure agents that support tool calls; the agent proposes operations, the skill executes them, and the job posts progress notes.
- Project context and attachments
  - Use prompts that reference project metadata and attachment details to guide agent decisions.

[No sources needed since this section provides general guidance]