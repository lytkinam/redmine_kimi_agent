# Installation and Setup

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides comprehensive installation and setup instructions for the Redmine AI Agent Plugin. It covers prerequisites, step-by-step installation, configuration, activation, verification, and troubleshooting. It also outlines update and rollback procedures grounded in the repository’s plugin manifest, migrations, and runtime behavior.

## Project Structure
The plugin is structured as a standard Redmine plugin with Ruby on Rails components:
- Plugin manifest and settings registration
- Routes for admin and per-issue dispatch
- Models for agents, assignments, and dispatches
- Controllers for admin UI and dispatch triggers
- Job for asynchronous dispatch execution
- Settings UI partial and locale strings
- Database migrations for persistent state

```mermaid
graph TB
A["init.rb<br/>Plugin manifest and settings"] --> B["config/routes.rb<br/>Admin and issue routes"]
A --> C["config/locales/en.yml<br/>UI labels and hints"]
B --> D["app/controllers/*<br/>Admin and dispatch controllers"]
D --> E["app/jobs/ai_agent_dispatch_job.rb<br/>Asynchronous dispatch"]
D --> F["app/models/*<br/>Agent, Assignment, Dispatch"]
F --> G["db/migrate/*.rb<br/>Schema creation"]
A --> H["app/views/settings/_ai_agent_settings.html.erb<br/>Settings UI"]
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Core Components
- Plugin manifest registers the plugin, sets Redmine version requirement, default settings, admin menu entry, and project-level permissions.
- Routes define admin endpoints for agents and assignments, and per-issue dispatch endpoints.
- Models encapsulate agent configuration, user-to-agent assignments, and dispatch records with lifecycle states.
- Controllers provide admin CRUD for agents and assignments, plus manual dispatch triggering from an issue.
- Job executes asynchronous dispatch, supports tool-call loops, and posts journal updates.
- Settings UI exposes enable flag, Redmine API base URL, and default timeout.

Key configuration defaults and requirements:
- Redmine version requirement: 6.0+
- Default settings include enabled flag, Redmine API base URL, and default timeout.
- Permissions include dispatch and management actions scoped to projects.

**Section sources**
- [init.rb:3-30](file://init.rb#L3-L30)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Architecture Overview
The plugin integrates with Redmine via:
- Plugin manifest and routes
- Admin UI for agent and assignment management
- Per-issue UI to manually trigger dispatches
- Background job to execute agent calls and tool loops
- Journal entries to surface progress and outcomes

```mermaid
graph TB
subgraph "Redmine Admin"
M["Admin Menu: AI Agents"]
N["Agents CRUD"]
O["Assignments CRUD"]
end
subgraph "Issue Page"
P["Dispatch Panel"]
Q["Manual Trigger Button"]
end
subgraph "Plugin Runtime"
R["AiAgentDispatchesController#create"]
S["AiAgentDispatchJob.perform"]
T["AgentClient.call + tool loop"]
U["Journal Updates"]
end
M --> N
M --> O
P --> Q
Q --> R
R --> S
S --> T
S --> U
```

**Diagram sources**
- [init.rb:18-29](file://init.rb#L18-L29)
- [routes.rb:2-16](file://config/routes.rb#L2-L16)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

## Detailed Component Analysis

### Prerequisites
- Redmine 6.0 or higher is required by the plugin manifest.
- Ruby environment compatible with Redmine’s runtime (as defined by the Redmine installation).
- Background job infrastructure configured for ActiveJob queues.

Verification of requirements:
- The plugin declares a minimum Redmine version in its manifest.
- Routes and controllers rely on Redmine’s routing and controller base classes.
- Jobs depend on ActiveJob queueing.

**Section sources**
- [init.rb:10](file://init.rb#L10)
- [routes.rb:1](file://config/routes.rb#L1)
- [ai_agent_dispatches_controller.rb:1](file://app/controllers/ai_agent_dispatches_controller.rb#L1)

### Installation Steps
1. Download the plugin archive or clone the repository into Redmine’s plugin directory.
2. Extract the plugin folder under Redmine’s plugins path so the directory structure appears as expected.
3. Run database migrations to create the plugin tables.
4. Restart Redmine to load the plugin.
5. Navigate to Administration > Plugins and enable the AI Agent plugin.
6. Configure the plugin settings: enable flag, Redmine API base URL, and default timeout.
7. Create AI agents, assign them to users, and optionally enable auto-dispatch.
8. Verify functionality by dispatching an issue manually and checking the journal.

Notes:
- The plugin registers default settings and a settings UI partial.
- Routes and controllers are defined for admin and per-issue operations.
- Migrations create the necessary tables and indexes.

**Section sources**
- [init.rb:12-16](file://init.rb#L12-L16)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

### Activation and Basic Configuration
- Enable the plugin in Redmine’s administration panel.
- Set the Redmine API base URL in plugin settings so agents can call Redmine endpoints.
- Adjust default timeout if needed.
- Create AI agents with endpoint URLs, protocols, and credentials.
- Assign agents to users and configure auto-dispatch if desired.
- Test agent connectivity using the admin UI’s connection test.

Permissions:
- Project-level permissions include dispatch and management actions for AI agents.

**Section sources**
- [init.rb:18-29](file://init.rb#L18-L29)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

### Verification and Testing
- Manual dispatch: From an issue page, trigger a dispatch and observe journal updates.
- Status checks: Inspect dispatch records and statuses.
- Error handling: Confirm error journal entries appear when agent calls fail.

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:18-57](file://app/jobs/ai_agent_dispatch_job.rb#L18-L57)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### Update and Rollback Procedures
- Back up the database before applying migrations.
- Apply migrations to upgrade to the latest schema.
- If downgrading is necessary, revert migrations to the target version.
- Restart Redmine after applying or reverting migrations.

Migration coverage:
- Initial tables for agents, assignments, and dispatches.
- Additional migration adds fields for Kimi Web support.

**Section sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)

## Dependency Analysis
The plugin depends on:
- Redmine framework and Rails routing/controller base classes
- ActiveJob for asynchronous dispatch execution
- Net::HTTP for agent connectivity tests
- Plugin settings for base URL and timeouts
- Models and migrations for persistence

```mermaid
graph LR
Init["init.rb"] --> Routes["routes.rb"]
Routes --> Ctrl1["ai_agents_controller.rb"]
Routes --> Ctrl2["ai_agent_assignments_controller.rb"]
Routes --> Ctrl3["ai_agent_dispatches_controller.rb"]
Ctrl3 --> Job["ai_agent_dispatch_job.rb"]
Ctrl1 --> ModelA["ai_agent.rb"]
Ctrl2 --> ModelB["ai_agent_assignment.rb"]
Ctrl3 --> ModelC["ai_agent_dispatch.rb"]
Job --> ModelA
Job --> ModelC
Init --> Settings["settings UI partial"]
Init --> Locales["en.yml"]
Migs["migrate/*.rb"] --> ModelA
Migs --> ModelB
Migs --> ModelC
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

## Performance Considerations
- Asynchronous dispatch via ActiveJob prevents blocking user requests.
- Tool-call loops limit iterations to avoid long-running agent cycles.
- Default timeout values can be adjusted in plugin settings for network conditions.
- Indexes on foreign keys and status fields improve query performance.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Plugin does not appear in Administration menu:
  - Ensure migrations were applied and Redmine was restarted.
  - Confirm the plugin directory structure matches expectations.
- Agents not found for assignees:
  - Verify user-to-agent assignments and that agents are active.
- Dispatch fails with errors:
  - Check agent endpoint connectivity and credentials.
  - Review journal entries for detailed error messages.
- Timeout or slow responses:
  - Increase default timeout in plugin settings.
  - Verify network latency and endpoint availability.

Operational diagnostics:
- Use the admin UI’s connection test for agents.
- Inspect dispatch records and statuses for lifecycle details.
- Monitor ActiveJob queue processing.

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [en.yml:74-98](file://config/locales/en.yml#L74-L98)

## Conclusion
The Redmine AI Agent Plugin integrates seamlessly with Redmine 6.0+ through a well-defined plugin structure, routes, models, controllers, and background jobs. By following the installation and configuration steps outlined here, administrators can deploy the plugin, connect AI agents, and automate issue processing while maintaining visibility through journal updates.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### A. Step-by-Step Installation Checklist
- Confirm Redmine 6.0+ and Ruby environment compatibility.
- Place plugin files under Redmine’s plugins directory.
- Run database migrations.
- Restart Redmine.
- Enable plugin in Administration > Plugins.
- Configure plugin settings (enable flag, base URL, timeout).
- Create agents, assign to users, and test connectivity.
- Manually dispatch an issue and verify journal updates.

**Section sources**
- [init.rb:10](file://init.rb#L10)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

### B. Data Model Overview
```mermaid
erDiagram
AI_AGENT {
int id PK
string name
string agent_type
string endpoint_url
string protocol
string api_key
string model_name
text system_prompt
boolean active
timestamp created_at
timestamp updated_at
}
AI_AGENT_ASSIGNMENT {
int id PK
int user_id FK
int ai_agent_id FK
boolean auto_dispatch
timestamp created_at
timestamp updated_at
}
AI_AGENT_DISPATCH {
int id PK
int issue_id FK
int ai_agent_id FK
int triggered_by
string status
text request_payload
text response_payload
int journal_id
datetime dispatched_at
datetime completed_at
timestamp created_at
timestamp updated_at
}
AI_AGENT ||--o{ AI_AGENT_ASSIGNMENT : "has many"
AI_AGENT ||--o{ AI_AGENT_DISPATCH : "has many"
ISSUE ||--o{ AI_AGENT_DISPATCH : "has many"
USER ||--o{ AI_AGENT_ASSIGNMENT : "has many"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)