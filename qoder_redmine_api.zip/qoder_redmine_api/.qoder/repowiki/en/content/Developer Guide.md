# Developer Guide

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Testing Strategies](#testing-strategies)
8. [Extension Mechanisms](#extension-mechanisms)
9. [Development Workflow](#development-workflow)
10. [Debugging and Logging](#debugging-and-logging)
11. [Performance Considerations](#performance-considerations)
12. [Contribution Guidelines](#contribution-guidelines)
13. [Troubleshooting Guide](#troubleshooting-guide)
14. [Conclusion](#conclusion)

## Introduction
This guide documents the Redmine AI Agent Plugin, a Redmine extension that assigns AI agents to users and orchestrates autonomous issue processing via Redmine’s REST API. It explains the plugin architecture (MVC, plugin lifecycle, and integration points), contribution standards, testing strategies, extension mechanisms, debugging/logging, and development workflow.

## Project Structure
The plugin follows a standard Redmine plugin layout with Ruby on Rails conventions:
- Plugin registration and settings in init.rb
- Routing in config/routes.rb
- Localization in config/locales/en.yml
- MVC components under app/
- Jobs under app/jobs/
- Database migrations under db/migrate/
- Library modules under lib/redmine_ai_agent/

```mermaid
graph TB
A["init.rb<br/>Plugin registration"] --> B["config/routes.rb<br/>Admin and issue routes"]
A --> C["config/locales/en.yml<br/>UI labels and hints"]
D["lib/redmine_ai_agent.rb<br/>Module loader"] --> E["lib/redmine_ai_agent/*.rb<br/>Clients and skills"]
F["app/models/*.rb<br/>AiAgent, Assignment, Dispatch"] --> G["app/controllers/*.rb<br/>Admin CRUD and test actions"]
H["app/jobs/ai_agent_dispatch_job.rb<br/>Asynchronous orchestration"] --> F
I["db/migrate/*.rb<br/>Schema migrations"] --> F
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Core Components
- Models encapsulate agent configuration, user-agent assignments, and dispatch records with validations, scopes, and helpers.
- Controllers provide admin CRUD for agents and assignments, plus a connection test endpoint.
- Jobs handle asynchronous dispatch execution, tool-loop orchestration, and journal updates.
- Routes define admin and per-issue endpoints.
- Localization supplies UI labels, hints, notices, and journal messages.

Key responsibilities:
- AiAgent: agent configuration, protocol/type checks, system prompt templating, and safe API key masking.
- AiAgentAssignment: user-to-agent mapping and active agent lookup.
- AiAgentDispatch: dispatch lifecycle, status tracking, and payload persistence.
- AiAgentsController: admin CRUD and test_connection.
- AiAgentDispatchJob: async execution, tool-call loop, journaling, and error handling.
- Routes: admin resources and nested issue dispatch routes.
- Locales: UI and messaging.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Architecture Overview
The plugin adheres to MVC and integrates with Redmine via:
- Plugin lifecycle: registered in init.rb with settings, permissions, and admin menu entry.
- Controllers: inherit from Redmine’s ApplicationController and enforce admin access.
- Models: ActiveRecord-backed with validations and associations.
- Jobs: ActiveJob-based, retryable on agent errors, persist dispatch state, and update issue journals.
- Hooks: module loader registers hooks for integration points.

```mermaid
graph TB
subgraph "Plugin Layer"
R["Routes<br/>config/routes.rb"]
M["Models<br/>AiAgent, Assignment, Dispatch"]
C["Controllers<br/>AiAgentsController"]
J["Job<br/>AiAgentDispatchJob"]
L["Locales<br/>config/locales/en.yml"]
end
subgraph "Redmine Core"
AC["ApplicationController"]
U["User"]
I["Issue"]
S["Settings"]
end
R --> C
C --> M
J --> M
M --> I
M --> U
C --> AC
J --> AC
L --> C
L --> J
S --> M
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)
- [init.rb:1-31](file://init.rb#L1-L31)

## Detailed Component Analysis

### Models
- AiAgent: defines agent types and protocols, validates configuration, exposes helpers for protocol/type checks, and resolves system prompts with Redmine context.
- AiAgentAssignment: enforces unique user-to-agent mapping and provides convenience methods to fetch active agent for a user.
- AiAgentDispatch: tracks dispatch lifecycle, status transitions, durations, and safely parses request/response payloads.

```mermaid
classDiagram
class AiAgent {
+AGENTS
+PROTOCOLS
+safe_api_key()
+chat_completions?()
+responses_api?()
+hermes?()
+pi?()
+qoder?()
+kimi_web?()
+kimi_web_ws?()
+resolved_system_prompt(issue)
}
class AiAgentAssignment {
+for_user(user)
+agent_for(user)
+auto_dispatch?()
}
class AiAgentDispatch {
+STATUSES
+pending?()
+running?()
+done?()
+error?()
+finished?()
+duration()
+request_data()
+response_data()
}
AiAgentAssignment --> AiAgent : "belongs_to"
AiAgentAssignment --> User : "belongs_to"
AiAgentDispatch --> AiAgent : "belongs_to"
AiAgentDispatch --> Issue : "belongs_to"
AiAgentDispatch --> User : "triggered_by"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### Controllers
- AiAgentsController handles admin CRUD for agents, enforces admin access, and provides a test_connection endpoint that validates agent connectivity using either a health check (Kimi Web) or a minimal chat/responses API call.

```mermaid
sequenceDiagram
participant Admin as "Admin User"
participant Ctrl as "AiAgentsController"
participant Agent as "AiAgent"
participant HTTP as "HTTP Client"
Admin->>Ctrl : "POST /ai_agents/ : id/test_connection"
Ctrl->>Agent : "Load agent by id"
alt "Kimi Web WebSocket"
Ctrl->>HTTP : "GET /healthz with Authorization"
HTTP-->>Ctrl : "HTTP response"
else "OpenAI-compatible"
Ctrl->>HTTP : "POST /v1/chat/completions or /v1/responses"
HTTP-->>Ctrl : "HTTP response"
end
Ctrl-->>Admin : "JSON {ok,status,body|error}"
```

**Diagram sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)

### Jobs
- AiAgentDispatchJob performs asynchronous dispatches, posts initial journal entries, executes agent calls, runs a tool-call loop using RedmineApiSkill, persists payloads, posts completion notes, and handles errors with retries.

```mermaid
sequenceDiagram
participant Scheduler as "Scheduler"
participant Job as "AiAgentDispatchJob"
participant Agent as "AiAgent"
participant Skill as "RedmineApiSkill"
participant Issue as "Issue"
Scheduler->>Job : "perform(issue_id, ai_agent_id, triggered_by)"
Job->>Agent : "Load agent"
Job->>Issue : "Create dispatch record and start journal"
Job->>Agent : "call(issue, triggered_by)"
loop "Tool-call loop (max 10)"
Job->>Skill : "execute_tool_call(tc)"
Skill-->>Job : "tool_result"
Job->>Agent : "post_to_agent(messages with tool results)"
end
Job->>Issue : "Post final journal note"
Job-->>Scheduler : "Done"
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### Routes and Permissions
- Routes define admin resources for agents and assignments, and nested routes for per-issue dispatches.
- Plugin settings include defaults and a settings partial.
- Permissions are defined at the project module level for managing agents and dispatching tasks.

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:12-29](file://init.rb#L12-L29)

## Dependency Analysis
- Controllers depend on models and Redmine’s ApplicationController.
- Jobs depend on models, ActiveJob, and the AgentClient/RedmineApiSkill abstractions.
- Models depend on Redmine settings and associations.
- Routes connect controllers to URLs.
- Localization keys are referenced across controllers and jobs.

```mermaid
graph LR
Ctrl["AiAgentsController"] --> ModelA["AiAgent"]
Ctrl --> ModelB["AiAgentAssignment"]
Job["AiAgentDispatchJob"] --> ModelA
Job --> ModelC["AiAgentDispatch"]
Job --> ModelB
Job --> Skill["RedmineApiSkill"]
Route["Routes"] --> Ctrl
Route --> Job
Locale["Locales"] --> Ctrl
Locale --> Job
```

**Diagram sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Testing Strategies
Recommended strategies align with Rails conventions and the plugin’s architecture:

- Unit tests
  - Model validations and scopes: verify AiAgent, AiAgentAssignment, AiAgentDispatch validations and scopes.
  - Helpers and computed fields: test safe_api_key, protocol/type helpers, resolved_system_prompt, and duration calculation.
  - Localization coverage: ensure label keys are present and translated.

- Integration tests
  - Controller actions: test AiAgentsController CRUD and test_connection with mocked HTTP responses.
  - Job behavior: stub AgentClient and RedmineApiSkill to validate dispatch creation, journal posting, and tool-loop execution.
  - Settings integration: verify system prompt resolution using plugin settings.

- End-to-end tests
  - Full dispatch flow: trigger a dispatch, assert journal entries, status transitions, and persisted payloads.
  - Error scenarios: simulate network failures and agent errors to verify retry and error journaling.

- Mocking and stubbing
  - Use Net::HTTP mocks for agent endpoints.
  - Stub ActiveJob to avoid background processing during tests.

- Test data and factories
  - Use factories or fixtures to create users, issues, agents, assignments, and dispatches.

[No sources needed since this section provides general guidance]

## Extension Mechanisms
Add new AI agent types, protocols, and Redmine API integrations by extending the following:

- New agent types
  - Add to AiAgent::AGENT_TYPES and define a system prompt template in AiAgent.SYSTEM_PROMPT_TEMPLATES.
  - Update localization keys for labels, hints, and journal messages.

- New protocols
  - Extend AiAgent::PROTOCOLS and add protocol-specific logic in AgentClient and related clients.
  - Update AiAgentsController.test_connection to support the new protocol.

- Additional Redmine API integrations
  - Enhance RedmineApiSkill to support new tools and endpoints.
  - Update AiAgentDispatchJob to incorporate new tool-call patterns.

- UI and settings
  - Add form fields and hints in the settings partial and locales.
  - Extend routes if new endpoints are needed.

**Section sources**
- [ai_agent.rb:2-140](file://app/models/ai_agent.rb#L2-L140)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Development Workflow
Local development setup:
- Install Redmine 6.0+ and configure a plugin directory.
- Place the plugin under plugins/redmine_ai_agent and run database migrations.
- Start Redmine and navigate to the AI Agents admin section.

Testing environments:
- Use Rails test suite with RSpec or Minitest.
- Configure separate databases for CI and local testing.
- Use environment variables for agent endpoints and API keys.

Deployment procedures:
- Package the plugin as a gem or zip and install into production Redmine.
- Run migrations on the target database.
- Configure plugin settings and permissions in the Redmine admin UI.

[No sources needed since this section provides general guidance]

## Debugging and Logging
Logging strategies:
- Use Rails.logger.info/warn/error in jobs and controllers for operational visibility.
- Avoid logging sensitive data; use safe_api_key for masked display.
- Capture request/response payloads for debugging, but sanitize logs.

Debugging techniques:
- Inspect AiAgentDispatch.request_data and response_data for payloads.
- Verify agent connectivity via AiAgentsController.test_connection.
- Monitor ActiveJob retries and error journal entries.

**Section sources**
- [ai_agent_dispatch_job.rb:13,59,66,117,121-135:13-135](file://app/jobs/ai_agent_dispatch_job.rb#L13-L135)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

## Performance Considerations
- Asynchronous processing: rely on AiAgentDispatchJob to prevent blocking requests.
- Retries: ActiveJob retry_on with polynomial backoff for transient errors.
- Payload sizes: limit log payload lengths and avoid unnecessary serialization.
- Tool-loop limits: cap iterations in the tool-call loop to prevent long-running jobs.

[No sources needed since this section provides general guidance]

## Contribution Guidelines
Coding standards:
- Follow Rails naming conventions and style.
- Keep controllers thin; move logic to jobs and service objects.
- Validate inputs and sanitize outputs, especially API keys and payloads.

Testing requirements:
- Write unit tests for models and helpers.
- Add integration tests for controllers and jobs.
- Include end-to-end tests for critical flows.

Pull request procedures:
- Open PRs against the develop branch with clear descriptions.
- Include test coverage and changelog updates.
- Ensure migrations are additive and backward compatible.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Missing agent for assignee: verify AiAgentAssignment.active and user mapping.
- Dispatch stuck in pending/running: check job queue and agent connectivity.
- Empty agent response: inspect tool-call loop and fallback text.
- Authentication failures: confirm API keys and endpoint URLs.

Operational checks:
- Use test_connection to validate agent endpoints.
- Review dispatch logs and journal entries for error details.

**Section sources**
- [ai_agent_assignment.rb:8-20](file://app/models/ai_agent_assignment.rb#L8-L20)
- [ai_agent_dispatch.rb:14-24](file://app/models/ai_agent_dispatch.rb#L14-L24)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)

## Conclusion
The Redmine AI Agent Plugin integrates seamlessly with Redmine’s MVC architecture and ActiveJob infrastructure. It supports multiple AI agent types and protocols, provides robust dispatch orchestration, and offers extensibility for new agents, protocols, and Redmine API tools. Follow the testing, debugging, and contribution guidelines to maintain quality and reliability.