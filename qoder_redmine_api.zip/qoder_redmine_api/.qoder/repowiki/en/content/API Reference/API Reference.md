# API Reference

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [kimi-web.sh](file://kimi-web/scripts/kimi-web.sh)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [SKILL.md](file://kimi-web/SKILL.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides a comprehensive API reference for the Redmine AI Agent Plugin. It covers:
- REST API endpoints for admin management of AI agents, assignments, and dispatches
- WebSocket integration with Kimi Web for real-time agent interactions
- Tool calling interface enabling AI agents to execute Redmine API operations programmatically
- Authentication, error handling, security, rate limiting, versioning, and migration guidance

The plugin exposes admin-managed endpoints to configure AI agents, assign them to users, and manually trigger issue dispatches. It also integrates with the Kimi Code CLI Web Interface via REST and WebSocket to enable advanced agent workflows.

## Project Structure
The plugin is organized into controllers, models, migrations, routing, and a Kimi Web integration layer:
- Controllers handle REST endpoints for agents, assignments, and dispatches
- Models define agent configuration, user-agent assignments, and dispatch records
- Migrations define the database schema for agents, assignments, and dispatches
- Routing defines REST URL patterns
- Kimi Web integration provides REST and WebSocket clients and protocol reference

```mermaid
graph TB
subgraph "Controllers"
C1["AiAgentsController"]
C2["AiAgentAssignmentsController"]
C3["AiAgentDispatchesController"]
end
subgraph "Models"
M1["AiAgent"]
M2["AiAgentAssignment"]
M3["AiAgentDispatch"]
end
subgraph "Routing"
R["Routes"]
end
subgraph "Kimi Web Integration"
KRef["api-reference.md"]
KSh["kimi-web.sh"]
KPy["kimi-web-ws.py"]
end
R --> C1
R --> C2
R --> C3
C1 --> M1
C2 --> M2
C3 --> M3
M1 --> KRef
M1 --> KSh
M1 --> KPy
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [api-reference.md:1-776](file://kimi-web/reference/api-reference.md#L1-L776)
- [kimi-web.sh:1-367](file://kimi-web/scripts/kimi-web.sh#L1-L367)
- [kimi-web-ws.py:1-363](file://kimi-web/scripts/kimi-web-ws.py#L1-L363)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:1-31](file://init.rb#L1-L31)

## Core Components
- Admin REST endpoints for AI agents and assignments
- Per-issue dispatch creation and viewing
- Agent configuration model supporting multiple providers and protocols
- Assignment model linking users to active agents
- Dispatch model tracking runs, status, and payloads

Key responsibilities:
- AiAgentsController: admin CRUD and connection testing
- AiAgentAssignmentsController: manage user-agent assignments
- AiAgentDispatchesController: manual dispatch triggers
- AiAgent: validations, protocol selection, system prompts
- AiAgentAssignment: user-agent binding and auto-dispatch flag
- AiAgentDispatch: run lifecycle, status tracking, payload parsing

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

## Architecture Overview
High-level architecture:
- Admin REST endpoints exposed under Redmine’s routing
- Agent configuration supports multiple protocols (OpenAI-compatible chat completions, responses, and Kimi Web WebSocket)
- Dispatches are queued via a background job and tracked in the database
- Kimi Web integration provides REST and WebSocket protocols for advanced agent workflows

```mermaid
sequenceDiagram
participant Admin as "Admin UI"
participant Routes as "Rails Routes"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant DB as "AiAgentDispatch"
Admin->>Routes : "POST /issues/ : issue_id/ai_agent_dispatches"
Routes->>Ctrl : "create"
Ctrl->>Ctrl : "find issue and authorize"
Ctrl->>Job : "perform_later(issue_id, agent_id, user_id)"
Job->>DB : "persist dispatch record"
Ctrl-->>Admin : "flash notice and redirect"
```

**Diagram sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

## Detailed Component Analysis

### REST API: Admin Management Endpoints

#### Agents
- Index: GET /ai_agents
- Show: GET /ai_agents/:id
- New/Create: GET/POST /ai_agents/new, POST /ai_agents
- Edit/Update: GET/POST /ai_agents/:id/edit, PUT/PATCH /ai_agents/:id
- Destroy: DELETE /ai_agents/:id
- Test connection: POST /ai_agents/:id/test_connection

Authentication:
- Admin-only endpoints protected by a before_action requiring admin privileges

Request/response characteristics:
- Create/Update accepts agent configuration including name, type, endpoint URL, protocol, API key, model name, system prompt, activation flag, and Kimi Web-specific fields
- Test connection endpoint performs a protocol-specific connectivity check:
  - For Kimi Web: HTTP GET to /healthz with optional Authorization header
  - For OpenAI-compatible agents: minimal chat completions or responses API ping

Permissions:
- Project-level permissions defined for dispatch and management actions

**Section sources**
- [routes.rb:2-7](file://config/routes.rb#L2-L7)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [init.rb:24-29](file://init.rb#L24-L29)

#### Assignments
- Index: GET /ai_agent_assignments
- New/Create: GET/POST /ai_agent_assignments/new, POST /ai_agent_assignments
- Edit/Update: GET/POST /ai_agent_assignments/:id/edit, PUT/PATCH /ai_agent_assignments/:id
- Destroy: DELETE /ai_agent_assignments/:id

Request/response characteristics:
- Create/Update accepts user_id, ai_agent_id, and auto_dispatch flag
- Index lists assignments with associated users and agents

Permissions:
- Admin-only endpoints protected by a before_action requiring admin privileges

**Section sources**
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [init.rb:24-29](file://init.rb#L24-L29)

#### Per-Issue Dispatches
- Index: GET /issues/:issue_id/ai_agent_dispatches
- Show: GET /issues/:issue_id/ai_agent_dispatches/:id
- Create: POST /issues/:issue_id/ai_agent_dispatches

Request/response characteristics:
- Create triggers a dispatch for the issue’s currently assigned user if an active agent exists
- Permissions enforced via allowed_to? checks against the project

Background processing:
- Dispatches are queued via a background job and tracked with status and timestamps

**Section sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### Data Models and Schemas

```mermaid
erDiagram
AI_AGENT {
int id PK
string name
string agent_type
string endpoint_url
string protocol
string api_key
string model_name
text system_prompt
boolean active
datetime created_at
datetime updated_at
string kimi_web_session_id
string kimi_web_work_dir
int kimi_web_timeout
}
AI_AGENT_ASSIGNMENT {
int id PK
int user_id FK
int ai_agent_id FK
boolean auto_dispatch
datetime created_at
datetime updated_at
}
AI_AGENT_DISPATCH {
int id PK
int issue_id FK
int ai_agent_id FK
int triggered_by FK
string status
text request_payload
text response_payload
int journal_id
datetime dispatched_at
datetime completed_at
datetime created_at
datetime updated_at
}
USER ||--o{ AI_AGENT_ASSIGNMENT : "has_many"
AI_AGENT ||--o{ AI_AGENT_ASSIGNMENT : "has_many"
ISSUE ||--o{ AI_AGENT_DISPATCH : "has_many"
AI_AGENT ||--o{ AI_AGENT_DISPATCH : "has_many"
```

**Diagram sources**
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### Agent Configuration and Protocols
Supported agent types and protocols:
- Agent types: hermes, pi, qoder, kimi_web, custom
- Protocols: chat_completions, responses, kimi_web_ws

Protocol-specific behaviors:
- chat_completions: OpenAI-compatible chat completions endpoint
- responses: OpenAI-compatible responses endpoint
- kimi_web_ws: WebSocket-based integration with Kimi Web

System prompts:
- Built-in templates per agent type with placeholders for Redmine base URL, API key, issue/project IDs
- Overridable via custom system prompt

Security:
- API keys are masked in serialization to avoid exposure in logs

**Section sources**
- [ai_agent.rb:2-50](file://app/models/ai_agent.rb#L2-L50)
- [ai_agent.rb:52-140](file://app/models/ai_agent.rb#L52-L140)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)

### Tool Calling Interface for Redmine API Operations
The agent system enables AI agents to execute Redmine API operations programmatically. The agent’s system prompt includes:
- Base URL and authentication header
- Available endpoints for reading issues, projects, statuses, and attachments
- Guidance to post progress notes via journal updates

Implementation pattern:
- Agents use the Redmine REST API with X-Redmine-API-Key header
- Dispatches capture request/response payloads for auditing and debugging

**Section sources**
- [ai_agent.rb:52-140](file://app/models/ai_agent.rb#L52-L140)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)

### WebSocket API: Kimi Web Integration

#### Connection Handling
- Base URL: ws://{host}:{port}/api/sessions/{session_id}/stream
- Optional query parameter: token={KIMI_WEB_TOKEN}
- Connection lifecycle:
  - On connect, server replays history from wire.jsonl
  - Server emits history_complete when ready
  - Client sends initialize, prompt, steer, cancel, set_plan_mode
  - Server emits session_status, event, request

#### Message Formats and Event Types
- Server-to-client events:
  - history_complete: signaling readiness
  - session_status: state transitions (stopped, idle, busy, error, restarting)
  - event: agent_text, agent_response, tool_call, tool_result, notice
  - request: ApprovalRequest, QuestionRequest with JSON-RPC response required

- Client-to-server messages:
  - initialize, prompt, steer, set_plan_mode, cancel, replay

#### Real-Time Interaction Patterns
- Interactive streaming mode for continuous conversation
- Plan mode approval workflow for controlled tool execution
- History replay ensures continuity across reconnects

**Section sources**
- [api-reference.md:349-586](file://kimi-web/reference/api-reference.md#L349-L586)
- [kimi-web-ws.py:47-226](file://kimi-web/scripts/kimi-web-ws.py#L47-L226)
- [SKILL.md:105-234](file://kimi-web/SKILL.md#L105-L234)

### REST API: Kimi Web Integration
- Sessions: list, create, get, update, delete, fork, generate-title, git-diff
- Files: upload, get, list
- Config: get, patch, toml get/put
- Utility: work-dirs, open-in, health

CLI tools:
- kimi-web.sh: REST API CLI wrapper
- kimi-web-ws.py: WebSocket client

**Section sources**
- [api-reference.md:14-348](file://kimi-web/reference/api-reference.md#L14-L348)
- [kimi-web.sh:1-367](file://kimi-web/scripts/kimi-web.sh#L1-L367)
- [SKILL.md:62-102](file://kimi-web/SKILL.md#L62-L102)

## Dependency Analysis

```mermaid
graph LR
Init["init.rb<br/>Plugin registration"] --> Routes["routes.rb<br/>Admin + dispatch routes"]
Routes --> CtrlA["AiAgentsController"]
Routes --> CtrlB["AiAgentAssignmentsController"]
Routes --> CtrlC["AiAgentDispatchesController"]
CtrlA --> ModelA["AiAgent"]
CtrlB --> ModelB["AiAgentAssignment"]
CtrlC --> ModelC["AiAgentDispatch"]
ModelA --> Mig1["001_create_ai_agents.rb"]
ModelB --> Mig2["002_create_ai_agent_assignments.rb"]
ModelC --> Mig3["003_create_ai_agent_dispatches.rb"]
ModelA --> Mig4["004_add_kimi_web_to_ai_agents.rb"]
ModelA --> KimiRef["api-reference.md"]
ModelA --> KimiCLI["kimi-web.sh"]
ModelA --> KimiWS["kimi-web-ws.py"]
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)
- [api-reference.md:1-776](file://kimi-web/reference/api-reference.md#L1-L776)
- [kimi-web.sh:1-367](file://kimi-web/scripts/kimi-web.sh#L1-L367)
- [kimi-web-ws.py:1-363](file://kimi-web/scripts/kimi-web-ws.py#L1-L363)

**Section sources**
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [init.rb:1-31](file://init.rb#L1-L31)

## Performance Considerations
- Connection timeouts: HTTP client timeouts configured for agent tests and general requests
- Background processing: Dispatches are queued to prevent blocking requests
- Payload handling: Request/response payloads are stored as text; consider compression or limits for very large outputs
- WebSocket concurrency: Only one prompt per session at a time; avoid overlapping prompts to prevent errors

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Authentication failures:
  - Verify API key presence and correctness for agent endpoints
  - For Kimi Web, ensure token parameter is set if required
- Connection test failures:
  - Confirm endpoint URL and protocol match agent configuration
  - Check network reachability and TLS settings
- Dispatch errors:
  - Ensure the issue’s assignee has an active agent assignment
  - Review dispatch status and captured payloads for insights
- WebSocket errors:
  - Inspect close codes and JSON-RPC error codes
  - Validate session_id format and server availability

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatches_controller.rb:16-36](file://app/controllers/ai_agent_dispatches_controller.rb#L16-L36)
- [api-reference.md:588-622](file://kimi-web/reference/api-reference.md#L588-L622)

## Conclusion
The Redmine AI Agent Plugin provides a robust framework for configuring AI agents, assigning them to users, and triggering automated issue processing. Its integration with Kimi Web via REST and WebSocket enables advanced real-time workflows. Administrators can manage agents and assignments through secure admin endpoints, while developers can leverage the tool calling interface to integrate AI-driven Redmine operations seamlessly.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Security Considerations
- API keys are masked in serialized output to prevent accidental exposure
- Admin-only endpoints require administrative privileges
- Kimi Web WebSocket supports optional token-based authentication

**Section sources**
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agents_controller.rb:2-3](file://app/controllers/ai_agents_controller.rb#L2-L3)
- [api-reference.md:355-359](file://kimi-web/reference/api-reference.md#L355-L359)

### Rate Limiting Information
- No explicit rate limiting is implemented in the plugin code
- External providers’ rate limits apply when agents call upstream APIs
- Consider implementing client-side throttling for high-volume dispatch scenarios

[No sources needed since this section provides general guidance]

### API Versioning and Backwards Compatibility
- Plugin version: 0.1.0
- Migration 004 adds Kimi Web fields to the ai_agents table without breaking existing records
- Backward compatibility maintained by default values and optional fields

**Section sources**
- [init.rb](file://init.rb#L8)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

### Migration Guidance for Deprecated Features
- Ensure agent configurations specify a valid protocol and endpoint URL
- For Kimi Web integration, set session_id, work_dir, and timeout as needed
- Review system prompts for accuracy and update as required

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)

### Common Use Cases and Client Implementation Guidelines
- Use per-issue dispatches to trigger agent processing from the issue page
- Configure agent types and protocols based on target provider (OpenAI-compatible or Kimi Web)
- Implement WebSocket clients for interactive sessions and plan mode approvals
- Store and audit dispatch payloads for compliance and debugging

**Section sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [kimi-web-ws.py:292-313](file://kimi-web/scripts/kimi-web-ws.py#L292-L313)