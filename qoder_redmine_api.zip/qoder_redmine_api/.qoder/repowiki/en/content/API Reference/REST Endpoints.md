# REST Endpoints

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the REST API exposed by the Redmine AI Agent Plugin for administrative management of AI agents, assignments, and issue dispatches. It covers HTTP methods, URL patterns, request/response schemas, authentication requirements, permissions, and operational behaviors. It also documents the test_connection endpoint for validating AI provider configurations and outlines rate limiting, pagination, and filtering capabilities where applicable.

## Project Structure
The plugin defines routes under the admin scope for AI agent CRUD and assignment management, plus per-issue dispatch endpoints. Controllers enforce admin-only access and apply project-level permissions for dispatch actions.

```mermaid
graph TB
subgraph "Routes"
R1["/ai_agents<br/>resources"]
R2["/ai_agents/:id/test_connection<br/>member route"]
R3["/ai_agent_assignments<br/>resources"]
R4["/issues/:issue_id/ai_agent_dispatches<br/>nested resources"]
end
subgraph "Controllers"
C1["AiAgentsController"]
C2["AiAgentAssignmentsController"]
C3["AiAgentDispatchesController"]
end
R1 --> C1
R2 --> C1
R3 --> C2
R4 --> C3
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:18-29](file://init.rb#L18-L29)

## Core Components
- AI Agents: Administrative CRUD for AI providers and configurations.
- Assignments: Link users to AI agents and configure auto-dispatch behavior.
- Dispatches: Trigger manual dispatches per issue and track status.

Key permissions:
- Project-level permission for dispatching AI agents on issues.
- Project-level permission for managing AI agents and assignments.

**Section sources**
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)

## Architecture Overview
The plugin exposes admin endpoints for managing AI agents and assignments, and per-issue dispatch endpoints for triggering AI processing. Dispatches are queued asynchronously and tracked in the database.

```mermaid
sequenceDiagram
participant Admin as "Admin Client"
participant Routes as "Rails Routes"
participant Agents as "AiAgentsController"
participant Assign as "AiAgentAssignmentsController"
participant Issues as "Issues"
participant Dispatch as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
Admin->>Routes : "POST /ai_agents"
Routes->>Agents : "create"
Agents-->>Admin : "Redirect or render form"
Admin->>Routes : "POST /ai_agent_assignments"
Routes->>Assign : "create"
Assign-->>Admin : "Redirect or render form"
Admin->>Routes : "POST /issues/ : issue_id/ai_agent_dispatches"
Routes->>Dispatch : "create"
Dispatch->>Job : "perform_later"
Job-->>Dispatch : "status update"
Dispatch-->>Admin : "Flash notice and redirect"
```

**Diagram sources**
- [routes.rb:3-15](file://config/routes.rb#L3-L15)
- [ai_agents_controller.rb:21-47](file://app/controllers/ai_agents_controller.rb#L21-L47)
- [ai_agent_assignments_controller.rb:16-42](file://app/controllers/ai_agent_assignments_controller.rb#L16-L42)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)

## Detailed Component Analysis

### AI Agents Endpoints
- Base URL pattern: /ai_agents
- Member route: /ai_agents/:id/test_connection

Authentication and permissions:
- Requires admin access.
- Uses strong parameters to permit agent attributes.

Endpoints:
- GET /ai_agents
  - Purpose: List agents.
  - Response: HTML view rendering a list of agents.
  - Permissions: Not enforced in controller; admin required.
- GET /ai_agents/:id
  - Purpose: View agent details.
  - Response: HTML view.
  - Permissions: Not enforced in controller; admin required.
- GET /ai_agents/new
  - Purpose: Render creation form with defaults.
  - Response: HTML form.
  - Permissions: Not enforced in controller; admin required.
- POST /ai_agents
  - Purpose: Create a new agent.
  - Request: Form-encoded parameters permitted by agent_params.
  - Response: Redirect on success; render form on validation failure.
  - Permissions: Not enforced in controller; admin required.
- GET /ai_agents/:id/edit
  - Purpose: Edit an existing agent.
  - Response: HTML form.
  - Permissions: Not enforced in controller; admin required.
- PUT/PATCH /ai_agents/:id
  - Purpose: Update an agent.
  - Request: Form-encoded parameters permitted by agent_params.
  - Response: Redirect on success; render form on validation failure.
  - Permissions: Not enforced in controller; admin required.
- DELETE /ai_agents/:id
  - Purpose: Delete an agent.
  - Response: Redirect with notice.
  - Permissions: Not enforced in controller; admin required.
- POST /ai_agents/:id/test_connection
  - Purpose: Validate agent configuration against the provider.
  - Request: None (uses agent settings).
  - Response: JSON object with keys:
    - ok: boolean indicating success
    - status: HTTP status code string or nil
    - body: provider response body excerpt (provider-dependent)
    - error: present if an exception occurred
  - Behavior:
    - For Kimi Web (kimi_web_ws): GET /healthz to endpoint_url with Authorization: Bearer api_key.
    - For OpenAI-compatible (chat_completions): POST /v1/chat/completions with minimal payload.
    - For responses protocol: POST /v1/responses with minimal payload.
  - Permissions: Not enforced in controller; admin required.

Request parameters (agent creation/update):
- name: string, required, unique
- agent_type: string, required, one of hermes, pi, qoder, kimi_web, custom
- endpoint_url: string, required, valid HTTP/HTTPS URL
- protocol: string, required, one of chat_completions, responses, kimi_web_ws
- api_key: string, optional
- model_name: string, required unless kimi_web_ws
- system_prompt: text, optional
- active: boolean, default true
- kimi_web_session_id: string, optional
- kimi_web_work_dir: string, optional
- kimi_web_timeout: integer, optional

Response examples:
- Successful creation: Redirect to list.
- Validation error: Render form with errors.
- test_connection success: { ok: true, status: "200", body: "<excerpt>" }
- test_connection failure: { ok: false, error: "<message>" }

curl examples:
- Create agent:
  - curl -X POST "[BASE]/ai_agents" -F "ai_agent[name]=..." -F "ai_agent[agent_type]=..." -F "ai_agent[endpoint_url]=..." -F "ai_agent[protocol]=..." -F "ai_agent[model_name]=..." -F "ai_agent[api_key]=..."
- Test connection:
  - curl -X POST "[BASE]/ai_agents/1/test_connection"

Notes:
- Pagination and filtering are not supported for /ai_agents; server-side ordering is applied.
- Rate limiting is not implemented in the controller; provider-side limits apply.

**Section sources**
- [routes.rb:2-7](file://config/routes.rb#L2-L7)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)

### AI Agent Assignments Endpoints
- Base URL pattern: /ai_agent_assignments

Authentication and permissions:
- Requires admin access.

Endpoints:
- GET /ai_agent_assignments
  - Purpose: List current assignments.
  - Response: HTML view with agents/users lists and ordering.
  - Permissions: Not enforced in controller; admin required.
- GET /ai_agent_assignments/new
  - Purpose: Render creation form with available users and agents.
  - Response: HTML form.
  - Permissions: Not enforced in controller; admin required.
- POST /ai_agent_assignments
  - Purpose: Create a new assignment.
  - Request: Form-encoded parameters permitted by assignment_params.
  - Response: Redirect on success; render form on validation failure.
  - Permissions: Not enforced in controller; admin required.
- GET /ai_agent_assignments/:id/edit
  - Purpose: Edit an existing assignment.
  - Response: HTML form.
  - Permissions: Not enforced in controller; admin required.
- PUT/PATCH /ai_agent_assignments/:id
  - Purpose: Update an assignment.
  - Request: Form-encoded parameters permitted by assignment_params.
  - Response: Redirect on success; render form on validation failure.
  - Permissions: Not enforced in controller; admin required.
- DELETE /ai_agent_assignments/:id
  - Purpose: Remove an assignment.
  - Response: Redirect with notice.
  - Permissions: Not enforced in controller; admin required.

Request parameters (assignment creation/update):
- user_id: integer, required, unique per user
- ai_agent_id: integer, required
- auto_dispatch: boolean, default false

Response examples:
- Successful creation: Redirect to list.
- Validation error: Render form with errors.

curl examples:
- Create assignment:
  - curl -X POST "[BASE]/ai_agent_assignments" -F "ai_agent_assignment[user_id]=1" -F "ai_agent_assignment[ai_agent_id]=1" -F "ai_agent_assignment[auto_dispatch]=true"

Notes:
- Pagination and filtering are not supported for /ai_agent_assignments; server-side ordering is applied.
- Rate limiting is not implemented in the controller.

**Section sources**
- [routes.rb:9-10](file://config/routes.rb#L9-L10)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)

### Issue Dispatch Endpoints
- Base URL pattern: /issues/:issue_id/ai_agent_dispatches

Authentication and permissions:
- Requires project-level permission :dispatch_ai_agent for the target issue’s project.
- Requires admin access for listing/show actions (controllers enforce admin in assignments controller but not explicitly in dispatch controller; however, dispatches are scoped to the issue and require authorization).

Endpoints:
- GET /issues/:issue_id/ai_agent_dispatches
  - Purpose: List dispatch history for the issue.
  - Response: HTML view with related dispatch records.
  - Permissions: Enforced via :dispatch_ai_agent on the project.
- GET /issues/:issue_id/ai_agent_dispatches/:id
  - Purpose: Show a single dispatch record.
  - Response: HTML view; returns 404 if dispatch does not belong to the issue.
  - Permissions: Enforced via :dispatch_ai_agent on the project.
- POST /issues/:issue_id/ai_agent_dispatches
  - Purpose: Manually trigger a dispatch for the issue.
  - Request: None.
  - Response: Queues a background job and redirects with a notice; returns 404 if issue not found.
  - Permissions: Enforced via :dispatch_ai_agent on the project.
  - Behavior: Finds the active agent assigned to the issue’s assignee; enqueues AiAgentDispatchJob.

Request parameters:
- None for POST create.

Response examples:
- Success: Redirect with notice.
- Failure: Redirect with error if no agent is assigned to the issue’s assignee.

curl examples:
- Trigger dispatch:
  - curl -X POST "[BASE]/issues/1/ai_agent_dispatches"

Notes:
- Pagination and filtering are not supported for dispatch listing; server-side ordering is applied.
- Rate limiting is not implemented in the controller.

**Section sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

### Background Dispatch Workflow
```mermaid
sequenceDiagram
participant User as "User"
participant Dispatch as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Model as "AiAgent"
participant Skill as "RedmineApiSkill"
participant Provider as "AI Provider"
User->>Dispatch : "POST /issues/ : id/ai_agent_dispatches"
Dispatch->>Job : "perform_later(issue_id, agent_id, user_id)"
Job->>Model : "load agent"
Job->>Job : "create dispatch record (status=running)"
Job->>Provider : "call agent (supports tool-calls)"
Provider-->>Job : "response (may include tool_calls)"
Job->>Skill : "execute tool calls"
Skill-->>Job : "results"
Job->>Provider : "send updated messages"
Provider-->>Job : "final text"
Job->>Job : "persist request/response payloads"
Job->>Job : "status=done"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Dependency Analysis
```mermaid
classDiagram
class AiAgent {
+has_many ai_agent_assignments
+has_many users
+has_many ai_agent_dispatches
+validates name, agent_type, endpoint_url, protocol, model_name
+scope active
}
class AiAgentAssignment {
+belongs_to user
+belongs_to ai_agent
+validates user_id(unique), ai_agent_id
+auto_dispatch?
}
class AiAgentDispatch {
+belongs_to issue
+belongs_to ai_agent
+belongs_to triggered_by_user
+belongs_to journal
+STATUSES
+scope for_issue, pending, running, completed, errored
+pending?() running?() done?() error?() finished?()
+duration()
+request_data()
+response_data()
}
AiAgent "1" --> "many" AiAgentAssignment : "assigns"
AiAgent "1" --> "many" AiAgentDispatch : "triggers"
AiAgentAssignment "many" --> "1" AiAgent : "assigned_to"
AiAgentDispatch "1" --> "1" AiAgent : "agent"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [ai_agent.rb:5-7](file://app/models/ai_agent.rb#L5-L7)
- [ai_agent_assignment.rb:2-3](file://app/models/ai_agent_assignment.rb#L2-L3)
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)

## Performance Considerations
- Dispatches are processed asynchronously via ActiveJob with exponential backoff on transient errors.
- Tool-loop iteration is capped at 10 turns to prevent runaway processing.
- Request/response payloads are stored as text; large responses may increase storage overhead.
- No built-in rate limiting exists in controllers; provider-side quotas and timeouts apply.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- test_connection failures:
  - Verify endpoint_url and protocol match the provider.
  - Ensure api_key is set when required.
  - For Kimi Web, confirm /healthz is reachable and returns success.
- Dispatch errors:
  - Check agent configuration (active, model_name, endpoint_url).
  - Review dispatch status and persisted response payload for provider error details.
  - Confirm the assignee has an active agent assignment.
- Permission denied:
  - Ensure the user has :dispatch_ai_agent permission for the issue’s project.

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

## Conclusion
The plugin provides a focused admin API for managing AI agents, assigning them to users, and triggering per-issue dispatches. The test_connection endpoint simplifies provider configuration validation. Dispatches are asynchronous, robustly handled with retries and tool-call support, and tracked with explicit status states.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Endpoint Reference Summary
- AI Agents
  - GET /ai_agents
  - GET /ai_agents/:id
  - GET /ai_agents/new
  - POST /ai_agents
  - GET /ai_agents/:id/edit
  - PUT|PATCH /ai_agents/:id
  - DELETE /ai_agents/:id
  - POST /ai_agents/:id/test_connection
- AI Agent Assignments
  - GET /ai_agent_assignments
  - GET /ai_agent_assignments/new
  - POST /ai_agent_assignments
  - GET /ai_agent_assignments/:id/edit
  - PUT|PATCH /ai_agent_assignments/:id
  - DELETE /ai_agent_assignments/:id
- Issue Dispatches
  - GET /issues/:issue_id/ai_agent_dispatches
  - GET /issues/:issue_id/ai_agent_dispatches/:id
  - POST /issues/:issue_id/ai_agent_dispatches

Authentication and permissions:
- Admin access required for agent and assignment endpoints.
- Project-level :dispatch_ai_agent permission required for dispatch operations.

Pagination and filtering:
- Not implemented for agent, assignment, or dispatch listings; server-side ordering applies.

Rate limiting:
- Not implemented in controllers; provider-side limits apply.

**Section sources**
- [routes.rb:2-15](file://config/routes.rb#L2-L15)
- [init.rb:24-29](file://init.rb#L24-L29)