# WebSocket API

<cite>
**Referenced Files in This Document**
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [SKILL.md](file://kimi-web/SKILL.md)
- [kimi-web.sh](file://kimi-web/scripts/kimi-web.sh)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [kimi_web_client.rb](file://lib/redmine_ai_agent/kimi_web_client.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document specifies the WebSocket API used by the Kimi Web integration. It covers connection establishment, authentication, session management, message formats, event types, and real-time interaction patterns. It also documents the client implementations, heartbeat and retry behavior, and provides troubleshooting guidance for common issues.

## Project Structure
The WebSocket integration spans three primary areas:
- CLI tooling for REST and WebSocket interactions
- Ruby-based WebSocket client used by the Redmine plugin
- Server-side integration points for configuration and health checks

```mermaid
graph TB
subgraph "CLI Tools"
SH["kimi-web.sh<br/>REST CLI"]
WS_PY["kimi-web-ws.py<br/>WebSocket CLI"]
end
subgraph "Ruby Client"
AGC["AgentClient<br/>delegates to KimiWebClient"]
KWC["KimiWebClient<br/>WebSocket JSON-RPC"]
end
subgraph "Server"
BASE["Base URL: http://127.0.0.1:5494"]
WS_PATH["/api/sessions/{session_id}/stream"]
end
SH --> BASE
WS_PY --> BASE
AGC --> KWC
KWC --> BASE
BASE --> WS_PATH
```

**Diagram sources**
- [kimi-web.sh:32-40](file://kimi-web/scripts/kimi-web.sh#L32-L40)
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [kimi_web_client.rb:156-161](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L161)

**Section sources**
- [kimi-web.sh:1-60](file://kimi-web/scripts/kimi-web.sh#L1-L60)
- [kimi-web-ws.py:1-30](file://kimi-web/scripts/kimi-web-ws.py#L1-L30)
- [kimi_web_client.rb:31-40](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L40)

## Core Components
- WebSocket endpoint: ws://127.0.0.1:5494/api/sessions/{session_id}/stream
- Optional query parameter: token={KIMI_WEB_TOKEN}
- Protocol: JSON-RPC 2.0 over WebSocket
- Message categories:
  - Server-to-client: history_complete, session_status, event, request
  - Client-to-server: initialize, prompt, steer, set_plan_mode, cancel, replay

Key behaviors:
- Every connection receives full history before history_complete
- Only one prompt per session at a time; sending prompt while busy yields an error
- Plan mode causes the agent to pause and request approval before executing actions

**Section sources**
- [api-reference.md:353-372](file://kimi-web/reference/api-reference.md#L353-L372)
- [api-reference.md:470-584](file://kimi-web/reference/api-reference.md#L470-L584)
- [SKILL.md:107-119](file://kimi-web/SKILL.md#L107-L119)
- [api-reference.md:733-737](file://kimi-web/reference/api-reference.md#L733-L737)

## Architecture Overview
The WebSocket API enables bidirectional real-time communication between clients and the Kimi Code CLI Web Interface. Clients connect to the session stream, receive historical context, and exchange prompts and events.

```mermaid
sequenceDiagram
participant C as "Client"
participant S as "Server"
participant W as "Worker"
C->>S : "Connect ws : //.../stream?token=..."
S-->>C : "history_complete"
C->>S : "initialize"
S-->>C : "session_status (idle)"
C->>S : "prompt"
S->>W : "process"
W-->>S : "events"
S-->>C : "event (agent_text/agent_response/tool_call/notice)"
S-->>C : "request (ApprovalRequest/QuestionRequest)"
C->>S : "response to request"
S-->>C : "session_status (busy/idle/error)"
C->>S : "cancel / set_plan_mode / steer"
S-->>C : "session_status"
```

**Diagram sources**
- [api-reference.md:353-466](file://kimi-web/reference/api-reference.md#L353-L466)
- [kimi-web-ws.py:62-156](file://kimi-web/scripts/kimi-web-ws.py#L62-L156)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)

## Detailed Component Analysis

### Connection Establishment and Authentication
- Base URL and endpoint:
  - REST base: http://127.0.0.1:5494
  - WebSocket endpoint: ws://127.0.0.1:5494/api/sessions/{session_id}/stream
- Authentication:
  - Optional token query parameter: token={KIMI_WEB_TOKEN}
  - Authorization header for REST: Bearer {KIMI_WEB_TOKEN}
- Health check:
  - GET /healthz returns {"status":"ok"}

Implementation notes:
- CLI builds ws URL with optional token query param
- Ruby client constructs ws URI from http base and adds token if present
- REST client sets Authorization header when token is configured

**Section sources**
- [api-reference.md:5-10](file://kimi-web/reference/api-reference.md#L5-L10)
- [api-reference.md:353-359](file://kimi-web/reference/api-reference.md#L353-L359)
- [kimi-web.sh:32-40](file://kimi-web/scripts/kimi-web.sh#L32-L40)
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [kimi_web_client.rb:156-161](file://lib/redmine_ai_agent/kimi_web_client.rb#L156-L161)
- [kimi-web.sh:253-255](file://kimi-web/scripts/kimi-web.sh#L253-L255)

### Session Management
- Sessions are created via REST and referenced by UUID
- The Ruby client can reuse a pinned session or create a new one
- Session liveness is verified via GET /api/sessions/{id}

Lifecycle:
- ensure_session! checks pinned session, otherwise creates new
- session_alive? performs a HEAD-like GET to verify existence

**Section sources**
- [kimi_web_client.rb:66-100](file://lib/redmine_ai_agent/kimi_web_client.rb#L66-L100)
- [kimi_web_client.rb:77-83](file://lib/redmine_ai_agent/kimi_web_client.rb#L77-L83)
- [kimi-web.sh:116-130](file://kimi-web/scripts/kimi-web.sh#L116-L130)

### Message Formats and Event Types
Server-to-client messages:
- history_complete: Signals readiness after history replay
- session_status: Session state transitions (stopped, idle, busy, error, restarting)
- event: Streaming text, complete response, tool call, tool result, notice
- request: ApprovalRequest or QuestionRequest requiring client response

Client-to-server messages:
- initialize: Capability negotiation and client metadata
- prompt: User input (string or rich content)
- steer: Steering instruction for active turn
- set_plan_mode: Enable/disable plan mode
- cancel: Cancel current prompt
- replay: Request history replay

JSON-RPC 2.0 envelopes apply to all messages.

**Section sources**
- [api-reference.md:362-466](file://kimi-web/reference/api-reference.md#L362-L466)
- [api-reference.md:472-584](file://kimi-web/reference/api-reference.md#L472-L584)
- [SKILL.md:187-232](file://kimi-web/SKILL.md#L187-L232)

### Real-Time Interaction Patterns
- History replay: On connect, server replays conversation history; client waits for history_complete
- Initialization: Client sends initialize immediately upon connection
- Prompting: After history_complete, client sends prompt; server emits agent_text fragments and agent_response
- Requests: When plan mode is enabled or agent needs clarification, server emits request; client responds with result
- Cancellation: Client can cancel in-flight prompts

**Section sources**
- [api-reference.md:734-737](file://kimi-web/reference/api-reference.md#L734-L737)
- [kimi-web-ws.py:196-226](file://kimi-web/scripts/kimi-web-ws.py#L196-L226)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)

### Heartbeat and Keepalive
- Python CLI: run_forever with ping_interval and ping_timeout
- Ruby client: Implements WebSocket frame handling; responds to PING with PONG and masks outgoing frames

Note: The Ruby client reads frames and handles PING/PONG internally; the Python CLI uses library-level ping configuration.

**Section sources**
- [kimi-web-ws.py:222-225](file://kimi-web/scripts/kimi-web-ws.py#L222-L225)
- [kimi_web_client.rb:360-363](file://lib/redmine_ai_agent/kimi_web_client.rb#L360-L363)
- [kimi_web_client.rb:305-328](file://lib/redmine_ai_agent/kimi_web_client.rb#L305-L328)

### Retry Logic
- Python CLI: Uses a bounded wait loop for history_complete and optional timeouts for actions
- Ruby client: Uses a global deadline derived from agent.kimi_web_timeout; raises KimiTimeoutError on expiry
- Automatic retry is not implemented in either client; errors propagate to caller

Recommendation: Implement exponential backoff and jitter around connection attempts and prompt retries in higher-level orchestrators.

**Section sources**
- [kimi-web-ws.py:206-216](file://kimi-web/scripts/kimi-web-ws.py#L206-L216)
- [kimi_web_client.rb:217-230](file://lib/redmine_ai_agent/kimi_web_client.rb#L217-L230)
- [kimi_web_client.rb:22-25](file://lib/redmine_ai_agent/kimi_web_client.rb#L22-L25)

### Security Considerations
- Transport security:
  - WebSocket endpoint defaults to ws://; TLS variant wss:// is supported by the Ruby client
  - REST endpoints can be secured with HTTPS; Authorization header carries bearer token
- Access control:
  - Optional token query param for WebSocket
  - Authorization header for REST
  - Server may enforce origin checks and deny access (close codes 4401/4403)
- Sensitive paths:
  - REST file endpoints restrict access to sensitive directories and file types

**Section sources**
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [kimi_web_client.rb:163-174](file://lib/redmine_ai_agent/kimi_web_client.rb#L163-L174)
- [kimi-web.sh:38-40](file://kimi-web/scripts/kimi-web.sh#L38-L40)
- [api-reference.md:604-607](file://kimi-web/reference/api-reference.md#L604-L607)
- [api-reference.md:738-738](file://kimi-web/reference/api-reference.md#L738-L738)

### Error Handling Strategies
- WebSocket close codes:
  - 4004: Session not found
  - 4401: Authentication required
  - 4403: Access denied / Origin not allowed
- JSON-RPC error codes:
  - -32700: Parse error
  - -32600: Invalid request
  - -32601: Method not found
  - -32602: Invalid params
  - -32603: Internal error
  - -32000: Invalid state (session busy)
  - -32001: LLM not set
  - -32002: LLM not supported
  - -32003: Chat provider error
  - -32004: Auth expired
- HTTP status codes (REST):
  - 400, 403, 404, 422 as applicable

Clients should translate these into actionable errors and consider retry/backoff policies.

**Section sources**
- [api-reference.md:600-622](file://kimi-web/reference/api-reference.md#L600-L622)
- [kimi-web.sh:29-52](file://kimi-web/scripts/kimi-web.sh#L29-L52)

### Client Implementations

#### Python WebSocket Client (kimi-web-ws.py)
- Builds ws URL with optional token query param
- Handles on_open/on_message/on_error/on_close
- Parses inbound messages and prints events
- Supports prompt, cancel, plan-mode, and interactive streaming modes
- Uses run_forever with ping_interval/ping_timeout
- Implements a bounded wait for history_complete and optional timeouts for actions

```mermaid
classDiagram
class WebSocketClient {
+string session_id
+string url
+bool wait_idle
+float timeout
+WebSocketApp ws
+bool history_complete
+bool connected
+float start_time
+string prompt_id
+string state
+on_open(ws)
+on_message(ws, message)
+on_error(ws, error)
+on_close(ws, code, msg)
+send_message(msg)
+send_response(req_id, result)
+send_prompt(text)
+send_cancel()
+send_plan_mode(enabled)
+run(action)
}
```

**Diagram sources**
- [kimi-web-ws.py:47-156](file://kimi-web/scripts/kimi-web-ws.py#L47-L156)

**Section sources**
- [kimi-web-ws.py:32-36](file://kimi-web/scripts/kimi-web-ws.py#L32-L36)
- [kimi-web-ws.py:62-156](file://kimi-web/scripts/kimi-web-ws.py#L62-L156)
- [kimi-web-ws.py:196-226](file://kimi-web/scripts/kimi-web-ws.py#L196-L226)

#### Ruby WebSocket Client (KimiWebClient)
- Delegated by AgentClient for kimi_web_ws protocol
- Creates/validates sessions via REST
- Performs WebSocket handshake and message loop
- Encodes/decodes frames per RFC 6455, masks outgoing frames
- Responds to PING with PONG and auto-approves requests to keep agent running
- Enforces a global timeout derived from agent.kimi_web_timeout

```mermaid
classDiagram
class AgentClient {
+call(issue) Hash
}
class KimiWebClient {
+call(issue) Hash
-ensure_session! String
-session_alive?(id) bool
-create_session! String
-build_prompt(issue) String
-websocket_prompt(id, text) String
-drive_session(socket, text) String
-handle_agent_request(socket, request)
-send_frame(socket, data)
-read_frame(socket, timeout) String
}
AgentClient --> KimiWebClient : "delegates for kimi_web_ws"
```

**Diagram sources**
- [agent_client.rb:26-42](file://lib/redmine_ai_agent/agent_client.rb#L26-L42)
- [kimi_web_client.rb:21-58](file://lib/redmine_ai_agent/kimi_web_client.rb#L21-L58)

**Section sources**
- [agent_client.rb:29-32](file://lib/redmine_ai_agent/agent_client.rb#L29-L32)
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)
- [kimi_web_client.rb:66-100](file://lib/redmine_ai_agent/kimi_web_client.rb#L66-L100)
- [kimi_web_client.rb:142-180](file://lib/redmine_ai_agent/kimi_web_client.rb#L142-L180)
- [kimi_web_client.rb:212-282](file://lib/redmine_ai_agent/kimi_web_client.rb#L212-L282)
- [kimi_web_client.rb:305-385](file://lib/redmine_ai_agent/kimi_web_client.rb#L305-L385)

### Connection Lifecycle Examples
- Create session via REST, then connect WebSocket, send initialize, send prompt, wait for idle, collect text
- Interactive mode: connect WebSocket, stream prompts until Ctrl+C
- Cancel: send cancel message to abort in-flight prompt

**Section sources**
- [SKILL.md:329-357](file://kimi-web/SKILL.md#L329-L357)
- [kimi-web-ws.py:228-257](file://kimi-web/scripts/kimi-web-ws.py#L228-L257)
- [kimi-web-ws.py:292-314](file://kimi-web/scripts/kimi-web-ws.py#L292-L314)

## Dependency Analysis
The Redmine plugin integrates with the Kimi Web WebSocket client through AgentClient. Configuration fields enable session reuse and timeout control.

```mermaid
graph LR
A["AiAgent (ActiveRecord)"] --> |has fields| F["kimi_web_session_id<br/>kimi_web_work_dir<br/>kimi_web_timeout"]
AC["AgentClient"] --> KC["KimiWebClient"]
KC --> S["Kimi Web Server"]
```

**Diagram sources**
- [004_add_kimi_web_to_ai_agents.rb:6-10](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L6-L10)
- [agent_client.rb:29-32](file://lib/redmine_ai_agent/agent_client.rb#L29-L32)
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)

**Section sources**
- [004_add_kimi_web_to_ai_agents.rb:1-12](file://db/migrate/004_add_kimi_web_to_ai_agents.rb#L1-L12)
- [agent_client.rb:29-32](file://lib/redmine_ai_agent/agent_client.rb#L29-L32)
- [kimi_web_client.rb:31-36](file://lib/redmine_ai_agent/kimi_web_client.rb#L31-L36)

## Performance Considerations
- Concurrency: Only one prompt per session at a time; avoid overlapping prompts
- History replay: Expect initial delay proportional to conversation length
- Timeouts: Configure agent.kimi_web_timeout to prevent indefinite waits
- Network: Prefer local ws://127.0.0.1 for low latency; wss:// adds TLS overhead
- Backpressure: Client should throttle prompt bursts and respect session_status transitions

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Connection refused or host unreachable:
  - Verify server is running on http://127.0.0.1:5494
  - Check firewall and port binding
- Authentication failures:
  - Ensure token query param or Authorization header matches server expectations
  - Confirm token validity and scope
- Session not found (close code 4004):
  - Recreate session via REST and reconnect with new session_id
- Busy session (JSON-RPC -32000):
  - Wait until session_status becomes idle or error, then retry
- Timeouts:
  - Increase agent.kimi_web_timeout or client timeout settings
  - Ensure network stability and server responsiveness
- Unicode display issues:
  - Set UTF-8 environment variables in terminal before running Python CLI

**Section sources**
- [api-reference.md:604-607](file://kimi-web/reference/api-reference.md#L604-L607)
- [api-reference.md:617-617](file://kimi-web/reference/api-reference.md#L617-L617)
- [SKILL.md:368-376](file://kimi-web/SKILL.md#L368-L376)

## Conclusion
The Kimi Web WebSocket API provides a robust, JSON-RPC 2.0–based bidirectional channel for real-time interaction with the Kimi Code CLI Web Interface. The provided clients demonstrate connection, authentication, session management, and event handling. For production use, implement retry/backoff, proper error translation, and consider TLS for secure deployments.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### API Definitions and Examples
- Base URLs and endpoint:
  - REST: http://127.0.0.1:5494
  - WebSocket: ws://127.0.0.1:5494/api/sessions/{session_id}/stream
- Example workflows:
  - Create → Prompt → Fork
  - Upload and Analyze
  - Batch Archive Old Sessions
  - Plan Mode Approval
  - Config Change and Restart

**Section sources**
- [api-reference.md:5-10](file://kimi-web/reference/api-reference.md#L5-L10)
- [api-reference.md:668-728](file://kimi-web/reference/api-reference.md#L668-L728)