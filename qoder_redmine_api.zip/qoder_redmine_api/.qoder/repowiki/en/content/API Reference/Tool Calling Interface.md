# Tool Calling Interface

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the AI agent tool calling interface that enables Redmine API operations. It explains how agents are configured, how tool definitions are structured, and how tool calls are validated and executed server-side. It also documents the available Redmine API operations exposed via tool calls, the integration with AI providers, and the security, permissions, and auditing aspects of the system. Guidance is provided for extending the tool calling interface with custom operations.

## Project Structure
The plugin integrates with Redmine’s routing, models, controllers, jobs, and a small library that implements the agent client and Redmine API skill executor. The plugin registers settings, permissions, and admin menu entries, and exposes routes for managing agents, assignments, and dispatches.

```mermaid
graph TB
subgraph "Plugin"
INIT["init.rb"]
ROUTES["config/routes.rb"]
LIB["lib/redmine_ai_agent.rb"]
SKILL["lib/redmine_ai_agent/redmine_api_skill.rb"]
CLIENT["lib/redmine_ai_agent/agent_client.rb"]
MODELS["Models<br/>ai_agent.rb<br/>ai_agent_assignment.rb<br/>ai_agent_dispatch.rb"]
CONTROLLERS["Controllers<br/>ai_agents_controller.rb<br/>ai_agent_assignments_controller.rb<br/>ai_agent_dispatches_controller.rb"]
JOB["app/jobs/ai_agent_dispatch_job.rb"]
end
INIT --> ROUTES
INIT --> MODELS
INIT --> CONTROLLERS
INIT --> JOB
LIB --> CLIENT
LIB --> SKILL
CLIENT --> JOB
SKILL --> JOB
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [redmine_api_skill.rb:1-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L41)
- [agent_client.rb:47-149](file://lib/redmine_ai_agent/agent_client.rb#L47-L149)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:66-102](file://app/jobs/ai_agent_dispatch_job.rb#L66-L102)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- Plugin registration and settings: Defines defaults for enabling the plugin, base URL for Redmine API, and default timeout. Registers admin menu and project-level permissions for dispatch and management.
- Models: Define agent configuration, user-to-agent assignment, and dispatch records with status tracking and timing.
- Controllers: Provide CRUD for agents and assignments, manual dispatch triggers from issue pages, and connection tests for agent endpoints.
- Agent client: Builds provider-specific payloads and defines OpenAI-style tool schemas for Redmine operations when supported by the agent type.
- Redmine API skill: Executes tool calls server-side against Redmine’s REST API using the configured base URL and API key.
- Job: Orchestrates agent dispatch, runs the tool loop, posts journal notes, and persists request/response payloads.

**Section sources**
- [init.rb:12-29](file://init.rb#L12-L29)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [agent_client.rb:47-149](file://lib/redmine_ai_agent/agent_client.rb#L47-L149)
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [ai_agent_dispatch_job.rb:66-102](file://app/jobs/ai_agent_dispatch_job.rb#L66-L102)

## Architecture Overview
The system integrates AI agents with Redmine via a tool calling mechanism. Agents can either:
- Use native tool execution (e.g., Kimi Web), or
- Return tool calls that are executed server-side by the Redmine API skill.

```mermaid
sequenceDiagram
participant User as "User"
participant Controller as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Client as "AgentClient"
participant Skill as "RedmineApiSkill"
participant Redmine as "Redmine REST API"
User->>Controller : "Create dispatch for issue"
Controller->>Job : "Enqueue dispatch"
Job->>Client : "Build payload and call provider"
Client-->>Job : "Provider response (text or tool_calls)"
alt "Has tool_calls"
loop "Up to 10 turns"
Job->>Skill : "execute_tool_call(tool_call)"
Skill->>Redmine : "HTTP request"
Redmine-->>Skill : "HTTP response"
Skill-->>Job : "Execution result"
Job->>Client : "Feed tool result back"
end
Client-->>Job : "Final text"
else "No tool_calls"
Client-->>Job : "Final text"
end
Job->>Redmine : "Post journal note(s)"
Job-->>Controller : "Dispatch status updated"
```

**Diagram sources**
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch_job.rb:66-102](file://app/jobs/ai_agent_dispatch_job.rb#L66-L102)
- [agent_client.rb:47-149](file://lib/redmine_ai_agent/agent_client.rb#L47-L149)
- [redmine_api_skill.rb:34-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L41)

## Detailed Component Analysis

### Agent Model and System Prompts
- Stores agent configuration: type, protocol, endpoint, model, API key, and flags for Kimi Web WebSocket protocol.
- Provides system prompt templates per agent type, including Redmine base URL, API key placeholder, and available endpoints.
- Resolves placeholders in system prompts using plugin settings and issue context.

```mermaid
classDiagram
class AiAgent {
+string name
+string agent_type
+string protocol
+string endpoint_url
+string model_name
+string api_key
+boolean active
+safe_api_key()
+resolved_system_prompt(issue)
}
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

### Assignment Model and Lookup
- Links users to agents with uniqueness constraints and convenience methods to fetch the active agent for a user.

```mermaid
classDiagram
class AiAgentAssignment {
+integer user_id
+integer ai_agent_id
+boolean auto_dispatch
+for_user(user)
+agent_for(user)
}
class AiAgent
AiAgentAssignment --> AiAgent : "belongs_to"
```

**Diagram sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

**Section sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

### Dispatch Model and Status Tracking
- Tracks dispatch lifecycle: pending, running, done, error.
- Persists request and response payloads as JSON for auditing.
- Computes duration based on timestamps.

```mermaid
classDiagram
class AiAgentDispatch {
+integer issue_id
+integer ai_agent_id
+integer triggered_by
+string status
+duration()
+request_data()
+response_data()
}
class Issue
class AiAgent
class User
AiAgentDispatch --> Issue : "belongs_to"
AiAgentDispatch --> AiAgent : "belongs_to"
AiAgentDispatch --> User : "triggered_by_user"
```

**Diagram sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### Agent Client: Payload Building and Tool Definitions
- Builds provider-specific payloads:
  - Chat completions: includes system prompt, user context, and optional tools.
  - Responses API: includes instructions and input.
- Defines OpenAI-style function/tool definitions for Redmine operations when supported by the agent type and protocol.
- Excludes tools for Kimi Web WebSocket and Qoder agent types.

```mermaid
flowchart TD
Start(["Build Payload"]) --> CheckProtocol{"Protocol?"}
CheckProtocol --> |chat_completions| BuildChat["Build chat_completions payload<br/>+ system prompt + user context + tools"]
CheckProtocol --> |responses| BuildResp["Build responses payload<br/>+ instructions + input"]
BuildChat --> Tools{"Agent supports tools?"}
Tools --> |Yes| IncludeTools["Include Redmine tools"]
Tools --> |No| SkipTools["No tools"]
IncludeTools --> Done
SkipTools --> Done
BuildResp --> Done(["Payload Ready"])
```

**Diagram sources**
- [agent_client.rb:47-149](file://lib/redmine_ai_agent/agent_client.rb#L47-L149)

**Section sources**
- [agent_client.rb:47-149](file://lib/redmine_ai_agent/agent_client.rb#L47-L149)

### Redmine API Skill: Tool Execution Engine
- Parses tool call name and arguments.
- Executes tool calls against Redmine REST API using configured base URL and API key.
- Wraps errors with status information for robust error handling.

```mermaid
flowchart TD
Entry(["execute_tool_call(tool_call)"]) --> Parse["Parse function name and arguments"]
Parse --> Route{"Tool name?"}
Route --> |redmine_get_issue| GetIssue["GET /issues/{id}.json"]
Route --> |redmine_update_issue| UpdateIssue["PUT /issues/{id}.json"]
Route --> |other| NotImplemented["Unsupported tool"]
GetIssue --> Return["Return parsed JSON"]
UpdateIssue --> Return
NotImplemented --> Error["Raise error"]
```

**Diagram sources**
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)

**Section sources**
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)

### Dispatch Job: Orchestrating Tool Loops and Journal Posting
- Posts initial journal notes for progress.
- Runs a tool loop up to ten turns, feeding tool results back to the provider.
- Posts final summary note upon completion.
- Persists request and response payloads for auditing.

```mermaid
sequenceDiagram
participant Job as "AiAgentDispatchJob"
participant Skill as "RedmineApiSkill"
participant Provider as "Provider"
Job->>Provider : "Initial request"
loop "Up to 10 turns"
Provider-->>Job : "Response (text or tool_calls)"
alt "tool_calls present"
Job->>Skill : "Execute each tool_call"
Skill-->>Job : "Results"
Job->>Provider : "Feed tool results"
else "no tool_calls"
Job->>Provider : "Final text"
end
end
Job->>Provider : "Post final summary"
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:66-102](file://app/jobs/ai_agent_dispatch_job.rb#L66-L102)
- [redmine_api_skill.rb:34-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L41)

**Section sources**
- [ai_agent_dispatch_job.rb:66-102](file://app/jobs/ai_agent_dispatch_job.rb#L66-L102)

### Controllers and Routes
- Admin routes for agents and assignments.
- Issue-scoped routes for dispatch creation, listing, and viewing.
- Manual dispatch trigger authorized by project permission.

```mermaid
graph LR
Routes["config/routes.rb"] --> Agents["ai_agents_controller.rb"]
Routes --> Assignments["ai_agent_assignments_controller.rb"]
Routes --> Dispatches["ai_agent_dispatches_controller.rb"]
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)

## Dependency Analysis
- Plugin initialization depends on models, controllers, and jobs.
- Agent client depends on agent configuration and plugin settings.
- Redmine API skill depends on plugin settings and agent API key.
- Dispatch job orchestrates client and skill execution and writes to Redmine journals.

```mermaid
graph TB
INIT["init.rb"] --> MODELS["ai_agent*.rb"]
INIT --> CONTROLLERS["controllers/*"]
INIT --> JOB["ai_agent_dispatch_job.rb"]
CLIENT["agent_client.rb"] --> JOB
SKILL["redmine_api_skill.rb"] --> JOB
MODELS --> CONTROLLERS
CONTROLLERS --> JOB
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [agent_client.rb:47-149](file://lib/redmine_ai_agent/agent_client.rb#L47-L149)
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [ai_agent_dispatch_job.rb:66-102](file://app/jobs/ai_agent_dispatch_job.rb#L66-L102)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [agent_client.rb:47-149](file://lib/redmine_ai_agent/agent_client.rb#L47-L149)
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)
- [ai_agent_dispatch_job.rb:66-102](file://app/jobs/ai_agent_dispatch_job.rb#L66-L102)

## Performance Considerations
- Timeout configuration: Plugin default timeout and per-agent settings influence request latency and reliability.
- Tool loop limit: The job enforces a maximum number of tool-execution turns to prevent runaway loops.
- Payload persistence: Storing request/response JSON adds I/O overhead; consider retention policies for audit logs.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Connection tests: Use the agent test endpoint to validate provider connectivity and credentials.
- Dispatch failures: Inspect dispatch status and payloads for clues; review job logs for exceptions.
- Tool call errors: The skill wraps errors with status codes; check provider responses and network conditions.
- Permissions: Ensure the user has the required project permission to dispatch agents.

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [redmine_api_skill.rb:20-26](file://lib/redmine_ai_agent/redmine_api_skill.rb#L20-L26)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)

## Conclusion
The tool calling interface provides a secure, auditable pathway for AI agents to interact with Redmine via REST API. By structuring agent prompts with tool definitions and executing tool calls server-side, the system centralizes validation, error handling, and journaling. Administrators can manage agents, assign them to users, and monitor dispatches, while developers can extend the tool set to support additional Redmine operations.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Tool Definition Syntax and Parameter Validation
- Tool definitions are OpenAI-style function schemas included when the agent supports tool calls and the protocol permits.
- Validation ensures:
  - Agent type and protocol are permitted.
  - Endpoint URL is a valid HTTP(S) URL.
  - Model name is present for non-Kimi Web WebSocket agents.
  - Dispatch status values are constrained.

**Section sources**
- [agent_client.rb:119-149](file://lib/redmine_ai_agent/agent_client.rb#L119-L149)
- [ai_agent.rb:9-14](file://app/models/ai_agent.rb#L9-L14)
- [ai_agent_dispatch.rb:9-12](file://app/models/ai_agent_dispatch.rb#L9-L12)

### Available Redmine API Operations via Tool Calls
- redmine_get_issue
  - Purpose: Fetch full details of a Redmine issue including description, journals, and status.
  - Parameters: issue_id (integer)
- redmine_update_issue
  - Purpose: Update a Redmine issue — post a journal note, change status, or update other fields.
  - Parameters: issue_id (integer), plus any writable fields supported by the provider’s tool schema.

Notes:
- The tool definitions are conditionally included for compatible agent types and protocols.
- Unsupported tool names are ignored by the skill executor.

**Section sources**
- [agent_client.rb:119-149](file://lib/redmine_ai_agent/agent_client.rb#L119-L149)
- [redmine_api_skill.rb:34-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L41)

### Invocation Payloads and Response Schemas
- Invocation payload example (OpenAI tool call format):
  - tool_call: { "function": { "name": "...", "arguments": "{...}" } }
- Response payload example (skill result):
  - { "success": true, "result": { ... }, "error": null }
- Errors:
  - Skill raises a specialized error with an attached status code for HTTP-related failures.

**Section sources**
- [redmine_api_skill.rb:19-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L19-L41)

### Security, Permissions, and Audit Logging
- Security:
  - API keys are masked in serializations.
  - Base URL and API key are injected into system prompts and used by the skill.
- Permissions:
  - Project-level permission required to dispatch agents on an issue.
  - Admin-level permissions for managing agents and assignments.
- Audit logging:
  - Dispatch records persist request and response payloads as JSON.
  - Job logs capture runtime errors and backtraces.

**Section sources**
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [ai_agent_dispatches_controller.rb:46-48](file://app/controllers/ai_agent_dispatches_controller.rb#L46-L48)
- [init.rb:24-29](file://init.rb#L24-L29)
- [ai_agent_dispatch.rb:32-42](file://app/models/ai_agent_dispatch.rb#L32-L42)
- [ai_agent_dispatch_job.rb:66-78](file://app/jobs/ai_agent_dispatch_job.rb#L66-L78)

### Extending the Tool Calling Interface
- Add new tool definitions in the agent client’s tool schema builder.
- Implement execution logic in the skill executor with proper argument parsing and error handling.
- Ensure parameter validation aligns with the tool schema and Redmine API constraints.
- Update agent system prompts to guide the model on new capabilities.

**Section sources**
- [agent_client.rb:119-149](file://lib/redmine_ai_agent/agent_client.rb#L119-L149)
- [redmine_api_skill.rb:34-41](file://lib/redmine_ai_agent/redmine_api_skill.rb#L34-L41)