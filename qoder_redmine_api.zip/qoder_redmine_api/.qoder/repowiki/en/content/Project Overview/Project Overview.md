# Project Overview

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
The Redmine AI Agent Plugin is an AI-powered automation extension designed to streamline Redmine issue management by integrating autonomous AI agents into everyday workflows. Its core value proposition is enabling seamless orchestration of AI agents (including Hermes, Pi, Qoder, Kimi Web, and custom OpenAI-compatible endpoints) to process issues automatically, reducing manual effort and accelerating resolution cycles.

Key benefits include:
- Automated issue processing powered by AI agents
- Reduced manual workload for support teams and developers
- Enhanced productivity through intelligent dispatch and tool-use capabilities
- Flexible agent management and per-user assignment controls
- Transparent audit trails via Redmine journals

Target audience:
- Redmine administrators responsible for plugin configuration and permissions
- Developers and advanced users who configure agents, manage assignments, and monitor dispatches

## Project Structure
The plugin follows a standard Redmine plugin layout with controllers, models, jobs, migrations, localization, and routing. It extends Redmine’s core functionality using plugin hooks, controllers, and background jobs while maintaining clean separation of concerns.

```mermaid
graph TB
subgraph "Plugin Root"
INIT["init.rb"]
ROUTES["config/routes.rb"]
LOCALE["config/locales/en.yml"]
LIB["lib/redmine_ai_agent.rb"]
end
subgraph "Controllers"
CTRL_AGENTS["app/controllers/ai_agents_controller.rb"]
CTRL_DISPATCH["app/controllers/ai_agent_dispatches_controller.rb"]
CTRL_ASSIGN["app/controllers/ai_agent_assignments_controller.rb"]
end
subgraph "Models"
MODEL_AGENT["app/models/ai_agent.rb"]
MODEL_ASSIGN["app/models/ai_agent_assignment.rb"]
MODEL_DISPATCH["app/models/ai_agent_dispatch.rb"]
end
subgraph "Jobs"
JOB_DISPATCH["app/jobs/ai_agent_dispatch_job.rb"]
end
subgraph "Database Migrations"
MIG_001["db/migrate/001_create_ai_agents.rb"]
MIG_002["db/migrate/002_create_ai_agent_assignments.rb"]
MIG_003["db/migrate/003_create_ai_agent_dispatches.rb"]
end
INIT --> ROUTES
INIT --> LIB
ROUTES --> CTRL_AGENTS
ROUTES --> CTRL_DISPATCH
ROUTES --> CTRL_ASSIGN
CTRL_AGENTS --> MODEL_AGENT
CTRL_DISPATCH --> MODEL_DISPATCH
CTRL_ASSIGN --> MODEL_ASSIGN
JOB_DISPATCH --> MODEL_DISPATCH
MODEL_AGENT --> MIG_001
MODEL_ASSIGN --> MIG_002
MODEL_DISPATCH --> MIG_003
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [001_create_ai_agents.rb:1-19](file://db/migrate/001_create_ai_agents.rb#L1-L19)
- [002_create_ai_agent_assignments.rb:1-16](file://db/migrate/002_create_ai_agent_assignments.rb#L1-L16)
- [003_create_ai_agent_dispatches.rb:1-24](file://db/migrate/003_create_ai_agent_dispatches.rb#L1-L24)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Core Components
- Plugin registration and settings: Declares plugin metadata, minimum Redmine version, admin menu entry, and project-level permissions. Provides default settings for enabling the plugin and configuring the Redmine API base URL and default timeout.
- Controllers: Manage CRUD operations for AI agents, user-agent assignments, and per-issue dispatches, including a connection test endpoint for agent health verification.
- Models: Define agent configuration, user-agent assignments, and dispatch records with status tracking and payload persistence.
- Jobs: Asynchronous dispatch execution with tool-use loop support, journal posting, and robust error handling.
- Routing: Exposes REST endpoints for admin agent management, user-agent assignments, and per-issue dispatch creation and viewing.
- Localization: Comprehensive English translations for UI labels, hints, notices, errors, and journal entries.

Key features overview:
- AI agent management: Create, update, delete, and test connections for agents with multiple types and protocols.
- User assignment system: Map users to active agents and control whether auto-dispatch is enabled on issue assignment.
- Automatic dispatch triggers: Auto-dispatch when an issue is assigned to a user with an active agent assignment.
- Redmine API integration: Injects Redmine base URL and API key into agent prompts, enabling agents to read/update issues and post journal notes.

**Section sources**
- [init.rb:3-30](file://init.rb#L3-L30)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Architecture Overview
The plugin architecture centers on a Redmine plugin that registers hooks and exposes admin and project-level UIs. Dispatches are queued as background jobs, executed asynchronously, and leverage an agentic loop to call Redmine API tools when supported by the agent protocol.

```mermaid
graph TB
subgraph "Admin UI"
ADMIN_AGENTS["Admin: AI Agents"]
ADMIN_ASSIGN["Admin: Assignments"]
end
subgraph "Issue UI"
ISSUE_PANEL["Issue Panel: Dispatch Button"]
end
subgraph "Controllers"
CTRL_AGENTS["AiAgentsController"]
CTRL_ISSUES["IssuesController<br/>+ AiAgentDispatchesController"]
end
subgraph "Models"
MODEL_AGENT["AiAgent"]
MODEL_ASSIGN["AiAgentAssignment"]
MODEL_DISPATCH["AiAgentDispatch"]
end
subgraph "Background Job"
JOB["AiAgentDispatchJob"]
end
subgraph "Agent Clients"
CLIENT["AgentClient"]
SKILL["RedmineApiSkill"]
end
ADMIN_AGENTS --> CTRL_AGENTS
ADMIN_ASSIGN --> CTRL_AGENTS
ISSUE_PANEL --> CTRL_ISSUES
CTRL_AGENTS --> MODEL_AGENT
CTRL_ISSUES --> MODEL_DISPATCH
MODEL_ASSIGN --> MODEL_AGENT
MODEL_DISPATCH --> JOB
JOB --> CLIENT
CLIENT --> SKILL
```

**Diagram sources**
- [init.rb:18-29](file://init.rb#L18-L29)
- [routes.rb:2-15](file://config/routes.rb#L2-L15)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

## Detailed Component Analysis

### Plugin Registration and Settings
- Registers the plugin with metadata, minimum Redmine version, and default settings.
- Adds an admin menu entry for AI Agents and defines project-level permissions for managing agents and dispatching tasks.
- Exposes settings for enabling the plugin, setting the Redmine API base URL, and configuring default timeouts.

**Section sources**
- [init.rb:3-30](file://init.rb#L3-L30)

### Routes and Permissions
- Defines REST routes for:
  - Admin CRUD actions for AI agents with a test_connection endpoint.
  - User-agent assignment CRUD.
  - Per-issue dispatch creation, listing, and detail views.
- Grants project-level permissions for dispatching and managing agents/assignments.

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:24-29](file://init.rb#L24-L29)

### Models: Agent, Assignment, and Dispatch
- AiAgent: Validates agent configuration, supports multiple agent types and protocols, and resolves system prompts with Redmine context.
- AiAgentAssignment: Links users to agents, ensures unique user-to-agent mapping, and provides convenience methods for retrieving active agents.
- AiAgentDispatch: Tracks dispatch lifecycle, status transitions, timing metrics, and persists request/response payloads.

```mermaid
classDiagram
class AiAgent {
+String name
+String agent_type
+String endpoint_url
+String protocol
+String model_name
+Boolean active
+String system_prompt
+resolved_system_prompt(issue)
}
class AiAgentAssignment {
+Integer user_id
+Integer ai_agent_id
+Boolean auto_dispatch
+for_user(user)
+agent_for(user)
+auto_dispatch?()
}
class AiAgentDispatch {
+Integer issue_id
+Integer ai_agent_id
+Integer triggered_by
+String status
+Text request_payload
+Text response_payload
+DateTime dispatched_at
+DateTime completed_at
+duration()
+request_data()
+response_data()
}
AiAgentAssignment --> AiAgent : "belongs_to"
AiAgentAssignment --> User : "belongs_to"
AiAgentDispatch --> AiAgent : "belongs_to"
AiAgentDispatch --> Issue : "belongs_to"
AiAgentDispatch --> User : "triggered_by"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### Dispatch Job Execution Flow
The job orchestrates asynchronous dispatches, posts initial journal notes, executes agent calls, and supports a tool-use loop to call Redmine API skills. It captures request/response payloads, updates dispatch status, and posts completion/error journal notes.

```mermaid
sequenceDiagram
participant UI as "Issue UI"
participant Ctrl as "IssuesController"
participant Job as "AiAgentDispatchJob"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
participant DB as "AiAgentDispatch"
UI->>Ctrl : "Create Dispatch"
Ctrl->>Job : "Enqueue dispatch(job_args)"
Job->>DB : "Create dispatch record"
Job->>UI : "Post 'dispatch started' journal"
Job->>Agent : "call(issue, triggered_by)"
Agent-->>Job : "initial result"
Job->>Skill : "execute tool calls (loop)"
Skill-->>Job : "tool results"
Job->>Agent : "send updated messages"
Agent-->>Job : "final text"
Job->>DB : "update payloads/status"
Job->>UI : "Post 'dispatch done' journal"
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### Agent Management Controller
Handles admin CRUD for agents, including:
- Listing, viewing, creating, updating, and deleting agents.
- Testing connectivity for both standard OpenAI-compatible endpoints and Kimi Web WebSocket endpoints.
- Permitting sensitive fields like API keys and system prompts during updates.

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)

### Localization and UI Text
Provides comprehensive English translations for:
- Field labels, hints, and placeholders guiding agent configuration.
- Status labels and journal messages for dispatch lifecycle.
- Settings labels for plugin configuration.

**Section sources**
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Dependency Analysis
The plugin integrates tightly with Redmine’s plugin framework, controllers, models, and ActiveJob. It depends on:
- Redmine plugin registration and settings subsystems.
- ActiveRecord models and migrations for persistent state.
- ActiveJob for asynchronous dispatch execution.
- Agent clients and skills for external AI service communication.

```mermaid
graph LR
INIT["init.rb"] --> ROUTES["routes.rb"]
INIT --> LIB["lib/redmine_ai_agent.rb"]
ROUTES --> CTRL_AGENTS["ai_agents_controller.rb"]
CTRL_AGENTS --> MODEL_AGENT["ai_agent.rb"]
MODEL_ASSIGN["ai_agent_assignment.rb"] --> MODEL_AGENT
CTRL_ISSUES["issues routes"] --> MODEL_DISPATCH["ai_agent_dispatch.rb"]
MODEL_DISPATCH --> JOB["ai_agent_dispatch_job.rb"]
JOB --> CLIENT["AgentClient"]
CLIENT --> SKILL["RedmineApiSkill"]
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Performance Considerations
- Asynchronous dispatch via ActiveJob prevents blocking UI interactions and allows retries on transient failures.
- Tool-use loop limits iterations to avoid long-running agent conversations.
- Payload serialization and masked API keys reduce log noise and protect secrets.
- Indexes on frequently queried columns (agent_type, active, status) improve query performance.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common operational checks:
- Verify plugin settings: Ensure the Redmine API base URL is configured and timeouts are reasonable.
- Test agent connectivity: Use the agent test_connection endpoint to validate endpoint reachability and authentication.
- Confirm assignments: Ensure a user has an active agent assignment with auto-dispatch enabled if automatic processing is expected.
- Inspect dispatch logs: Review job logs and dispatch records for status, durations, and error payloads.
- Journal visibility: Confirm that dispatch start/done/error messages appear in the issue journal.

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [en.yml:94-98](file://config/locales/en.yml#L94-L98)

## Conclusion
The Redmine AI Agent Plugin delivers a robust, extensible framework for integrating AI agents into Redmine workflows. Administrators can configure diverse agents and assign them to users, while developers benefit from a clear API surface, asynchronous dispatch execution, and transparent auditing via journals. The plugin’s architecture balances flexibility with reliability, enabling organizations to automate routine issue processing and boost team productivity.