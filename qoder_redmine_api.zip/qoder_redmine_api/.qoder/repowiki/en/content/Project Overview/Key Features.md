# Key Features

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [kimi-web.sh](file://kimi-web/scripts/kimi-web.sh)
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [SKILL.md](file://kimi-web/SKILL.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the key features of the Redmine AI Agent Plugin and how they contribute to an automated workflow for Redmine issue processing. The plugin enables AI agents to autonomously triage, update, and resolve issues using Redmine's REST API, with support for multiple agent types, flexible user assignment, and both automatic and manual dispatch triggers. It also provides an extensible framework for custom agents and tools.

## Project Structure
The plugin follows a standard Redmine plugin layout with models, controllers, jobs, migrations, localization, and routing. It integrates with Redmine through hooks and exposes admin-managed resources for agents, assignments, and dispatches.

```mermaid
graph TB
subgraph "Plugin Root"
INIT["init.rb"]
ROUTES["config/routes.rb"]
LOCALE["config/locales/en.yml"]
LIB["lib/redmine_ai_agent.rb"]
end
subgraph "Models"
MODEL_AI_AGENT["app/models/ai_agent.rb"]
MODEL_ASSIGNMENT["app/models/ai_agent_assignment.rb"]
MODEL_DISPATCH["app/models/ai_agent_dispatch.rb"]
end
subgraph "Controllers"
CTRL_AGENTS["app/controllers/ai_agents_controller.rb"]
CTRL_ASSIGNMENTS["app/controllers/ai_agent_assignments_controller.rb"]
end
subgraph "Jobs"
JOB_DISPATCH["app/jobs/ai_agent_dispatch_job.rb"]
end
subgraph "Database Migrations"
MIG_001["db/migrate/001_create_ai_agents.rb"]
MIG_002["db/migrate/002_create_ai_agent_assignments.rb"]
MIG_003["db/migrate/003_create_ai_agent_dispatches.rb"]
MIG_004["db/migrate/004_add_kimi_web_to_ai_agents.rb"]
end
subgraph "Kimi Web Integration"
KWS_PY["kimi-web/scripts/kimi-web-ws.py"]
KWS_SH["kimi-web/scripts/kimi-web.sh"]
KREF["kimi-web/reference/api-reference.md"]
KSKILL["kimi-web/SKILL.md"]
end
INIT --> ROUTES
INIT --> LIB
ROUTES --> CTRL_AGENTS
ROUTES --> CTRL_ASSIGNMENTS
CTRL_AGENTS --> MODEL_AI_AGENT
CTRL_ASSIGNMENTS --> MODEL_ASSIGNMENT
MODEL_DISPATCH --> JOB_DISPATCH
MODEL_AI_AGENT --> MODEL_ASSIGNMENT
MODEL_AI_AGENT --> MODEL_DISPATCH
MODEL_ASSIGNMENT --> MODEL_DISPATCH
LIB --> KWS_PY
LIB --> KWS_SH
LIB --> KREF
LIB --> KSKILL
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
- [004_add_kimi_web_to_ai_agents.rb](file://db/migrate/004_add_kimi_web_to_ai_agents.rb)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [kimi-web.sh](file://kimi-web/scripts/kimi-web.sh)
- [api-reference.md](file://kimi-web/reference/api-reference.md)
- [SKILL.md](file://kimi-web/SKILL.md)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Core Components
This section outlines the five main feature areas and how they fit into the automation workflow:

- AI agent management with multiple agent types and protocols
- User assignment system with auto-dispatch configuration
- Issue dispatch system with automatic and manual triggering
- AI communication layer supporting HTTP and WebSocket protocols
- Redmine integration through hooks and API operations

Each feature area is documented with practical use cases and extensibility notes.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [en.yml:25-67](file://config/locales/en.yml#L25-L67)

## Architecture Overview
The plugin orchestrates AI-driven issue processing through a job-based dispatch system. When an issue is assigned to a user with an active AI agent, the system can automatically dispatch the agent to process the issue. Alternatively, users can manually trigger dispatches from the issue page. The AI agent communicates via HTTP (OpenAI-compatible APIs) or WebSocket (Kimi Code CLI Web), executes tool calls against the Redmine API, and posts updates to the issue journal.

```mermaid
sequenceDiagram
participant User as "User"
participant Issue as "Issue"
participant Assignment as "AiAgentAssignment"
participant Job as "AiAgentDispatchJob"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
participant Redmine as "Redmine API"
User->>Issue : "Assign issue to user"
Issue->>Assignment : "Lookup active agent assignment"
Assignment-->>Job : "Auto-dispatch trigger"
User->>Issue : "Manual dispatch"
Issue->>Job : "Dispatch requested"
Job->>Agent : "Prepare request with system prompt"
Agent-->>Job : "Initial response"
Job->>Skill : "Execute tool calls"
Skill->>Redmine : "GET/PUT issue/project/status"
Redmine-->>Skill : "API responses"
Skill-->>Job : "Tool results"
Job->>Agent : "Feed tool results back"
Agent-->>Job : "Final text"
Job->>Issue : "Post journal notes"
Job-->>User : "Dispatch status and completion"
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [ai_agent_assignment.rb:13-24](file://app/models/ai_agent_assignment.rb#L13-L24)

## Detailed Component Analysis

### AI Agent Management
The AI agent management feature defines supported agent types, protocols, and system prompts. It ensures secure handling of credentials and provides default system prompts tailored to each agent type. Administrators can configure agents with different providers and protocols, including OpenAI-compatible endpoints and Kimi Code CLI Web via WebSocket.

- Supported agent types: Hermes, Pi, Qoder, Kimi Web, and Custom/OpenRouter
- Supported protocols: Chat Completions, Responses API, and Kimi Web WebSocket
- Default system prompts per agent type embed Redmine base URL and API key placeholders
- Secure credential masking during serialization

Practical use cases:
- Automated issue triaging: An agent reads the issue, determines priority and status, and posts a journal note summarizing findings.
- Status updates: An agent updates the issue status to resolved after verifying fixes.
- Assignment processing: An agent posts initial progress notes upon starting work.

Extensibility:
- New agent types can be added by extending the agent type list and adding a system prompt template.
- Custom endpoints are supported via the Custom/OpenRouter agent type.

**Section sources**
- [ai_agent.rb:2-15](file://app/models/ai_agent.rb#L2-L15)
- [ai_agent.rb:53-140](file://app/models/ai_agent.rb#L53-L140)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [en.yml:25-30](file://config/locales/en.yml#L25-L30)
- [en.yml:52-58](file://config/locales/en.yml#L52-L58)

### User Assignment System with Auto-Dispatch
The user assignment system links users to active AI agents and supports auto-dispatch on issue assignment. Administrators configure assignments and enable auto-dispatch per user. The system prevents duplicate assignments and ensures only active agents are used.

- Unique user-to-agent assignment
- Auto-dispatch toggle per assignment
- Lookup of active agent for a given user

Practical use cases:
- Auto-triage: When a developer is assigned to an issue, their AI agent automatically starts processing it.
- Manual override: Users can still choose to dispatch manually when needed.

**Section sources**
- [ai_agent_assignment.rb:5-24](file://app/models/ai_agent_assignment.rb#L5-L24)
- [ai_agent_assignment.rb:8-20](file://app/models/ai_agent_assignment.rb#L8-L20)
- [en.yml:14](file://config/locales/en.yml#L14)
- [en.yml:60](file://config/locales/en.yml#L60)

### Issue Dispatch System
The dispatch system manages the lifecycle of AI-driven issue processing. Dispatch records track status, timing, and payloads. Jobs encapsulate the dispatch logic, including journal posting, tool-loop execution, and error handling. Dispatches can be triggered automatically when an issue is assigned to a user with an active agent, or manually from the issue page.

- Dispatch statuses: pending, running, done, error
- Duration calculation and payload storage
- Tool-call loop for executing Redmine API operations
- Journal notes for start, completion, and error events

Practical use cases:
- Automated triage: Agent reads issue, posts progress notes, and updates status.
- Manual dispatch: Developer initiates processing for a specific issue.
- Audit trail: All requests and responses are stored for review.

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [routes.rb:12-15](file://config/routes.rb#L12-L15)

### AI Communication Layer
The communication layer supports multiple protocols to accommodate different AI providers and capabilities. Standard OpenAI-compatible agents use HTTP endpoints, while Kimi Code CLI Web uses WebSocket JSON-RPC 2.0. The layer handles connection testing and payload construction.

- HTTP endpoints for Chat Completions and Responses API
- WebSocket for Kimi Code CLI Web
- Connection testing for HTTP and health checks for WebSocket
- Protocol-specific payload construction

Practical use cases:
- OpenAI-compatible providers: Use Chat Completions or Responses API depending on provider support.
- Kimi Code CLI Web: Connect via WebSocket for advanced tooling and stateful sessions.

**Section sources**
- [ai_agent.rb:3-4](file://app/models/ai_agent.rb#L3-L4)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [en.yml:54](file://config/locales/en.yml#L54)
- [kimi-web-ws.py](file://kimi-web/scripts/kimi-web-ws.py)
- [kimi-web.sh](file://kimi-web/scripts/kimi-web.sh)

### Redmine Integration Through Hooks and API Operations
The plugin integrates with Redmine through hooks and exposes API operations for agents to read and update issues. The system injects the Redmine base URL and API key into agent prompts, enabling agents to call the REST API autonomously. A tool-call loop allows agents to execute Redmine API operations and receive structured results.

- Injected Redmine base URL and API key into system prompts
- Tool-call loop for executing Redmine API operations
- Journal posting for dispatch start, completion, and error events

Practical use cases:
- Fetch issue details and project context before acting.
- Update issue fields (status, priority, notes) based on agent decisions.
- Post progress notes and summaries to the issue journal.

**Section sources**
- [ai_agent.rb:142-153](file://app/models/ai_agent.rb#L142-L153)
- [ai_agent_dispatch_job.rb:82-119](file://app/jobs/ai_agent_dispatch_job.rb#L82-L119)
- [en.yml:94-97](file://config/locales/en.yml#L94-L97)

## Dependency Analysis
The plugin’s components depend on each other to form a cohesive automation pipeline. Models define relationships and validations; controllers expose admin interfaces; jobs orchestrate dispatches; and the communication layer interacts with external AI providers and Redmine.

```mermaid
classDiagram
class AiAgent {
+String name
+String agent_type
+String protocol
+String endpoint_url
+String model_name
+Boolean active
+String api_key
+String system_prompt
+safe_api_key()
+resolved_system_prompt(issue)
}
class AiAgentAssignment {
+Integer user_id
+Integer ai_agent_id
+Boolean auto_dispatch
+for_user(user)
+agent_for(user)
+auto_dispatch?()
}
class AiAgentDispatch {
+Integer issue_id
+Integer ai_agent_id
+Integer triggered_by
+String status
+DateTime dispatched_at
+DateTime completed_at
+duration()
+request_data()
+response_data()
}
class AiAgentDispatchJob {
+perform(issue_id, ai_agent_id, triggered_by_user_id)
-run_tool_loop(client, agent, issue, result)
-handle_error(dispatch, issue, trigger, agent, error_message)
}
AiAgent "1" --> "*" AiAgentAssignment : "has_many"
AiAgent "1" --> "*" AiAgentDispatch : "has_many"
AiAgentAssignment "1" --> "1" AiAgent : "belongs_to"
AiAgentDispatch "1" --> "1" AiAgent : "belongs_to"
AiAgentDispatch "1" --> "1" Issue : "belongs_to"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

**Section sources**
- [ai_agent.rb:5-7](file://app/models/ai_agent.rb#L5-L7)
- [ai_agent_assignment.rb:2-3](file://app/models/ai_agent_assignment.rb#L2-L3)
- [ai_agent_dispatch.rb:4-7](file://app/models/ai_agent_dispatch.rb#L4-L7)

## Performance Considerations
- Retry strategy: Dispatch jobs retry transient errors using polynomial backoff to improve resilience.
- Timeout configuration: HTTP timeouts and Kimi WebSocket timeouts are configurable to balance responsiveness and reliability.
- Payload storage: Request and response payloads are persisted for auditability but should be monitored to avoid excessive storage growth.
- Tool-loop limits: The tool-call loop caps iterations to prevent runaway processing.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- No active agent for assignee: Ensure a user has an active agent assignment configured.
- Dispatch errors: Review the dispatch record’s error payload and check agent connectivity and credentials.
- Connection failures: Use the agent test connection feature to validate HTTP endpoints and WebSocket health.

Operational tips:
- Verify agent type and protocol match the target provider.
- Confirm Redmine base URL and API key injection in system prompts.
- Monitor job queue and retry logs for transient failures.

**Section sources**
- [en.yml:74-80](file://config/locales/en.yml#L74-L80)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

## Conclusion
The Redmine AI Agent Plugin provides a robust foundation for automating Redmine workflows through AI agents. Its modular design supports multiple agent types and protocols, integrates seamlessly with Redmine via hooks and API operations, and offers both automatic and manual dispatch modes. Administrators can configure agents, assign them to users, and monitor dispatch outcomes, while developers can extend the system with custom agents and tools to meet evolving needs.