# Architecture Overview

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [redmine_ai_agent.rb](file://lib/redmine_ai_agent.rb)
- [agent_client.rb](file://lib/redmine_ai_agent/agent_client.rb)
- [redmine_api_skill.rb](file://lib/redmine_ai_agent/redmine_api_skill.rb)
- [hooks.rb](file://lib/redmine_ai_agent/hooks.rb)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the architecture of the Redmine AI Agent Plugin as a Redmine plugin that extends core functionality using an MVC-like pattern with a plugin architecture. The system integrates AI agents with Redmine through:
- Controllers orchestrating user interactions (admin UI and per-issue dispatch)
- Jobs handling asynchronous AI agent processing
- Models managing data persistence for agents, assignments, and dispatch records
- Libraries encapsulating cross-cutting concerns (AI client, skills, and Redmine API integration)
- Hooks integrating with Redmine’s event system to trigger automatic dispatches

The plugin defines system boundaries, integration patterns, and the lifecycle from user actions to AI agent processing and Redmine API updates.

## Project Structure
The plugin follows a conventional Redmine plugin layout:
- init.rb registers the plugin, settings, admin menu, and permissions
- config/routes.rb defines REST endpoints for admin and per-issue dispatch
- app/* contains MVC components (controllers, models, jobs, views)
- lib/redmine_ai_agent contains reusable libraries for AI client, skills, and hooks
- db/migrate contains database schema migrations
- kimi-web contains external tooling references

```mermaid
graph TB
subgraph "Plugin Root"
INIT["init.rb"]
ROUTES["config/routes.rb"]
end
subgraph "Controllers"
C_AGENTS["AiAgentsController"]
C_ASSIGN["AiAgentAssignmentsController"]
end
subgraph "Models"
M_AGENT["AiAgent"]
M_ASSIGN["AiAgentAssignment"]
M_DISPATCH["AiAgentDispatch"]
end
subgraph "Jobs"
J_DISPATCH["AiAgentDispatchJob"]
end
subgraph "Libraries"
L_CLIENT["AgentClient"]
L_SKILL["RedmineApiSkill"]
L_HOOKS["Hooks"]
L_MAIN["redmine_ai_agent.rb"]
end
INIT --> ROUTES
ROUTES --> C_AGENTS
ROUTES --> C_ASSIGN
C_AGENTS --> M_AGENT
C_ASSIGN --> M_ASSIGN
M_DISPATCH --> J_DISPATCH
L_MAIN --> L_CLIENT
L_MAIN --> L_SKILL
L_MAIN --> L_HOOKS
L_CLIENT --> L_SKILL
L_HOOKS --> J_DISPATCH
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- Plugin registration and settings: Defines plugin metadata, minimum Redmine version, default settings, admin menu, and project-level permissions.
- Routes: Exposes admin endpoints for AI agents and assignments, plus per-issue dispatch endpoints under issues.
- Controllers: Manage admin CRUD for agents and assignments, and per-issue manual dispatch initiation.
- Models: Define agent profiles, user-to-agent assignments, and dispatch records with status tracking.
- Job: Performs asynchronous AI agent invocation, tool-loop execution, and Redmine journal updates.
- Libraries: AgentClient encapsulates AI provider communication; RedmineApiSkill executes Redmine API calls; Hooks integrate with Redmine events.

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Architecture Overview
The plugin adheres to a layered architecture:
- Presentation Layer: Controllers and views present admin and per-issue UIs.
- Application Layer: Controllers orchestrate user actions; Jobs encapsulate long-running tasks.
- Domain Layer: Models represent agents, assignments, and dispatches.
- Integration Layer: AgentClient and RedmineApiSkill connect to AI providers and Redmine APIs.
- Event Integration: Hooks listen to Redmine lifecycle events to trigger automatic dispatches.

```mermaid
graph TB
UI["User Interface<br/>Admin & Issue Pages"] --> CTRL["Controllers<br/>AiAgentsController, AiAgentAssignmentsController"]
CTRL --> MODEL["Models<br/>AiAgent, AiAgentAssignment, AiAgentDispatch"]
MODEL --> JOB["Job<br/>AiAgentDispatchJob"]
JOB --> LIB_CLIENT["AgentClient<br/>AI Provider HTTP Client"]
JOB --> LIB_SKILL["RedmineApiSkill<br/>Redmine API Client"]
HOOKS["Hooks<br/>Issue create/update events"] --> JOB
CTRL -. "Manual dispatch" .-> JOB
LIB_CLIENT --> |POST| AI_PROVIDER["AI Provider Endpoint"]
LIB_SKILL --> |REST| REDMINE_API["Redmine REST API"]
```

**Diagram sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Detailed Component Analysis

### Plugin Lifecycle and Initialization
- Registration: init.rb registers the plugin, sets metadata, declares minimum Redmine version, and registers default settings and admin menu.
- Settings: Default settings include enabled flag, Redmine API base URL, and default timeout.
- Permissions: Project-level permissions define who can manage agents and dispatch agents on issues.
- Library loading: lib/redmine_ai_agent.rb loads clients, hooks, and skills and registers the hook listener.

```mermaid
sequenceDiagram
participant Rails as "Rails Engine"
participant Init as "init.rb"
participant Settings as "Settings"
participant Menu as "Admin Menu"
participant Lib as "lib/redmine_ai_agent.rb"
Rails->>Init : Load plugin
Init->>Settings : Register defaults
Init->>Menu : Add admin menu entry
Init->>Lib : Require libraries
Lib->>Lib : Register Hooks
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

### Routing and Controller Orchestration
- Admin routes: Resources for AI agents (including a test_connection action) and agent-user assignments.
- Per-issue routes: Nested routes under issues for creating, listing, and viewing AI agent dispatches.
- Controllers:
  - AiAgentsController: Admin CRUD for agents, including connection testing against AI provider endpoints.
  - AiAgentAssignmentsController: Admin CRUD for user-to-agent assignments, including auto-dispatch toggles.

```mermaid
sequenceDiagram
participant User as "User"
participant Ctrl as "AiAgentsController"
participant Agent as "AiAgent"
participant HTTP as "Net : : HTTP"
participant Provider as "AI Provider"
User->>Ctrl : POST /ai_agents/ : id/test_connection
Ctrl->>Agent : Resolve endpoint and payload
Ctrl->>HTTP : POST /v1/chat/completions or /v1/responses
HTTP-->>Provider : Request
Provider-->>HTTP : Response
HTTP-->>Ctrl : Status + Body
Ctrl-->>User : JSON { ok, status, body }
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [agent_client.rb:192-229](file://lib/redmine_ai_agent/agent_client.rb#L192-L229)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)

### Model Layer and Data Persistence
- AiAgent: Validates agent type, protocol, endpoint URL, and model name; provides system prompt templates and safe API key masking; scopes for active agents.
- AiAgentAssignment: Links users to agents; validates uniqueness; exposes convenience methods to fetch active agent for a user and auto_dispatch flag.
- AiAgentDispatch: Tracks dispatch lifecycle (pending, running, done, error); stores request/response payloads; computes duration; scopes for filtering.

```mermaid
classDiagram
class AiAgent {
+String name
+String agent_type
+String protocol
+String endpoint_url
+String model_name
+Boolean active
+safe_api_key()
+resolved_system_prompt(issue)
}
class AiAgentAssignment {
+Integer user_id
+Integer ai_agent_id
+Boolean auto_dispatch
+for_user(user)
+agent_for(user)
}
class AiAgentDispatch {
+Integer issue_id
+Integer ai_agent_id
+Integer triggered_by
+String status
+duration()
+request_data()
+response_data()
}
AiAgent "1" --> "*" AiAgentAssignment : "has_many"
AiAgent "1" --> "*" AiAgentDispatch : "has_many"
AiAgentAssignment "1" --> "1" AiAgent : "belongs_to"
AiAgentDispatch "1" --> "1" AiAgent : "belongs_to"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### Background Processing and Tool Loop
- AiAgentDispatchJob: Creates a dispatch record, posts a “task sent” journal note, invokes AgentClient, runs a tool-call loop via RedmineApiSkill, persists payloads, posts completion note, and handles errors.
- Tool loop: If the agent responds with tool_calls, the job executes each tool via RedmineApiSkill, feeds results back to the agent, and repeats up to a fixed number of turns.

```mermaid
sequenceDiagram
participant Hook as "Hooks"
participant Job as "AiAgentDispatchJob"
participant Dispatch as "AiAgentDispatch"
participant Client as "AgentClient"
participant Skill as "RedmineApiSkill"
participant API as "Redmine REST API"
Hook->>Job : perform_later(issue_id, agent_id, user_id)
Job->>Dispatch : create running record
Job->>API : post journal "dispatch started"
Job->>Client : call(issue, triggered_by)
alt tool_calls present
loop up to N turns
Client-->>Job : raw_response with tool_calls
Job->>Skill : execute_tool_call(call)
Skill->>API : GET/PUT ...
API-->>Skill : result
Skill-->>Job : result
Job->>Client : send updated messages
end
end
Job->>Dispatch : update status=done, payloads
Job->>API : post journal "dispatch done"
```

**Diagram sources**
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [agent_client.rb:28-42](file://lib/redmine_ai_agent/agent_client.rb#L28-L42)
- [redmine_api_skill.rb:36-61](file://lib/redmine_ai_agent/redmine_api_skill.rb#L36-L61)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

### Integration Patterns and Cross-Cutting Concerns
- AgentClient: Builds provider-specific payloads (Chat Completions vs Responses), resolves endpoints, performs HTTP requests, extracts text, and raises structured AgentError on failures.
- RedmineApiSkill: Executes tool-call functions (GET issue, PUT issue, list statuses, get project) against Redmine REST API using configured base URL and API key.
- Hooks: Listen to issue creation and update events; if assignee changed and auto_dispatch is enabled, enqueue AiAgentDispatchJob.

```mermaid
flowchart TD
Start(["Issue Updated"]) --> CheckAssignee["Has assignee changed?"]
CheckAssignee --> |No| EndNo["No dispatch"]
CheckAssignee --> |Yes| FindAssignment["Find active agent assignment with auto_dispatch"]
FindAssignment --> |None| EndNo
FindAssignment --> |Found| Enqueue["Enqueue AiAgentDispatchJob"]
Enqueue --> EndYes["Dispatch queued"]
```

**Diagram sources**
- [hooks.rb:10-22](file://lib/redmine_ai_agent/hooks.rb#L10-L22)
- [hooks.rb:55-71](file://lib/redmine_ai_agent/hooks.rb#L55-L71)

**Section sources**
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)

## Dependency Analysis
- Controllers depend on Models for data access and on Jobs for background processing.
- Jobs depend on Models for dispatch records, AgentClient for provider communication, and RedmineApiSkill for API operations.
- Libraries (AgentClient, RedmineApiSkill, Hooks) are loaded by lib/redmine_ai_agent.rb and registered during plugin initialization.
- Routes bind URLs to controller actions, forming the entry points for user interactions.

```mermaid
graph LR
Routes["Routes"] --> CtrlAgents["AiAgentsController"]
Routes --> CtrlAssign["AiAgentAssignmentsController"]
CtrlAgents --> ModelAgent["AiAgent"]
CtrlAssign --> ModelAssign["AiAgentAssignment"]
ModelDispatch["AiAgentDispatch"] --> Job["AiAgentDispatchJob"]
Job --> Client["AgentClient"]
Job --> Skill["RedmineApiSkill"]
Hooks["Hooks"] --> Job
Init["init.rb"] --> LibMain["lib/redmine_ai_agent.rb"]
LibMain --> Client
LibMain --> Skill
LibMain --> Hooks
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [agent_client.rb:1-261](file://lib/redmine_ai_agent/agent_client.rb#L1-L261)
- [redmine_api_skill.rb:1-130](file://lib/redmine_ai_agent/redmine_api_skill.rb#L1-L130)
- [hooks.rb:1-74](file://lib/redmine_ai_agent/hooks.rb#L1-L74)
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [init.rb:1-31](file://init.rb#L1-L31)
- [redmine_ai_agent.rb:1-13](file://lib/redmine_ai_agent.rb#L1-L13)

## Performance Considerations
- Timeouts: AgentClient uses a configurable default timeout and explicit open/read timeouts; RedmineApiSkill also applies timeouts for API calls.
- Retries: AiAgentDispatchJob retries transient AgentError occurrences with exponential backoff.
- Payloads: Dispatch records persist request/response payloads; consider storage limits and log sanitization.
- Tool loop bounds: The tool loop caps iterations to avoid runaway processing.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Agent connectivity tests: Use AiAgentsController test_connection to validate provider endpoints and credentials.
- Dispatch status tracking: Inspect AiAgentDispatch records for pending/running/done/error states and durations.
- Error logging: AiAgentDispatchJob captures and logs errors, posting a journal note with error details.
- Hook activation: Verify plugin enabled setting and auto_dispatch flag on assignments; ensure assignee changes trigger the hook.

**Section sources**
- [ai_agents_controller.rb:49-92](file://app/controllers/ai_agents_controller.rb#L49-L92)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [hooks.rb:51-53](file://lib/redmine_ai_agent/hooks.rb#L51-L53)

## Conclusion
The Redmine AI Agent Plugin extends Redmine through a clean separation of concerns: controllers for user interactions, jobs for background processing, models for persistence, libraries for integrations, and hooks for event-driven automation. The architecture supports multiple AI providers and protocols, provides robust error handling and retries, and integrates tightly with Redmine’s REST API to automate issue resolution workflows.