# Introduction

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
The Redmine AI Agent Plugin is an AI-powered automation solution designed to streamline Redmine issue management by bridging artificial intelligence with Redmine’s workflow. It enables administrators and teams to assign AI agents (including Hermes, Pi, Qoder, Kimi Web, and custom OpenAI-compatible endpoints) to users, who can then trigger autonomous issue processing through Redmine’s REST API. This integration reduces repetitive administrative tasks, accelerates issue resolution, and improves consistency across projects by automating routine operations such as status updates, progress notes, and cross-project coordination.

Why AI integration enhances productivity in project management:
- Reduced manual effort: AI agents can parse issues, draft updates, and execute status changes without human intervention.
- Consistent workflows: Predefined system prompts and standardized API interactions ensure uniform processing across diverse teams.
- Faster turnaround: Automated processing and optional auto-dispatch on issue assignment accelerate issue lifecycle completion.
- Scalable orchestration: Centralized configuration and dispatch management scale across large teams and complex projects.

Target audience:
- Redmine administrators: Configure agents, manage permissions, and monitor dispatches.
- Developers: Integrate custom AI endpoints and extend capabilities via the plugin’s architecture.
- Project teams: Benefit from automated issue handling and improved transparency via journal notes.

## Project Structure
The plugin follows a standard Redmine plugin layout with controllers, models, jobs, routing, localization, and database migrations. It exposes admin-managed resources for agents and assignments, per-issue dispatch endpoints, and a background job system for asynchronous processing.

```mermaid
graph TB
subgraph "Plugin Root"
INIT["init.rb"]
ROUTES["config/routes.rb"]
LOCALE["config/locales/en.yml"]
end
subgraph "Controllers"
CTRL_AGENTS["AiAgentsController"]
CTRL_DISPATCHES["AiAgentDispatchesController"]
end
subgraph "Models"
MODEL_AGENT["AiAgent"]
MODEL_ASSIGNMENT["AiAgentAssignment"]
MODEL_DISPATCH["AiAgentDispatch"]
end
subgraph "Jobs"
JOB_DISPATCH["AiAgentDispatchJob"]
end
INIT --> ROUTES
ROUTES --> CTRL_AGENTS
ROUTES --> CTRL_DISPATCHES
CTRL_AGENTS --> MODEL_AGENT
CTRL_DISPATCHES --> MODEL_DISPATCH
MODEL_ASSIGNMENT --> MODEL_AGENT
MODEL_DISPATCH --> MODEL_AGENT
CTRL_DISPATCHES --> JOB_DISPATCH
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

**Section sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Core Components
- AiAgent: Defines agent configurations, supported agent types, protocols, and system prompts. Provides helpers to detect agent type and protocol, and resolves a tailored system prompt with Redmine context.
- AiAgentAssignment: Links users to active agents and supports auto-dispatch preferences.
- AiAgentDispatch: Tracks individual dispatches, their status, timing, and serialized request/response payloads.
- AiAgentsController: Admin interface for creating, updating, testing connections, and deleting agents.
- AiAgentDispatchJob: Asynchronous job orchestrating agent calls, tool-loop execution, journal updates, and error handling.

Key value proposition:
- Autonomous processing: Dispatches are queued and executed asynchronously, enabling reliable long-running operations.
- Redmine REST API integration: Agents receive a curated system prompt embedding Redmine base URL, API key, issue/project identifiers, and available endpoints for autonomous actions.
- Flexible agent ecosystem: Support for multiple providers and protocols, including stateful responses and WebSocket-based Kimi Web.

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

## Architecture Overview
The plugin integrates with Redmine through a plugin entry point, admin routes for agents and assignments, per-issue dispatch routes, and a background job system. The job performs the AI call, optionally loops through tool calls using a Redmine API skill, and posts structured journal updates.

```mermaid
sequenceDiagram
participant Admin as "Admin User"
participant UI as "Issue Page"
participant Ctrl as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Agent as "AgentClient"
participant Skill as "RedmineApiSkill"
participant Redmine as "Redmine API"
Admin->>UI : "Click Send to AI Agent"
UI->>Ctrl : "POST /issues/ : id/ai_agent_dispatches"
Ctrl->>Job : "Enqueue dispatch"
Job->>Agent : "call(issue, triggered_by)"
Agent->>Redmine : "REST calls (as per system prompt)"
Agent-->>Job : "Initial result"
Job->>Skill : "Execute tool calls (optional)"
Skill->>Redmine : "Read/Update issues/projects"
Skill-->>Job : "Tool results"
Job->>Agent : "Feed tool results back"
Agent-->>Job : "Final text"
Job->>UI : "Post journal notes"
```

**Diagram sources**
- [routes.rb:12-15](file://config/routes.rb#L12-L15)
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent.rb:52-140](file://app/models/ai_agent.rb#L52-L140)

## Detailed Component Analysis

### AiAgent: Agent configuration and system prompts
- Purpose: Encapsulates agent metadata, validation rules, and system prompt templates per agent type.
- Key behaviors:
  - Validates agent type, protocol, endpoint URL, and model name (when applicable).
  - Provides helpers to detect agent type and protocol.
  - Resolves a system prompt with Redmine base URL, API key, issue/project IDs injected at runtime.
- Supported agent types: Hermes, Pi, Qoder, Kimi Web, and custom/OpenAI-compatible.
- Protocols: Chat Completions, Responses API, and Kimi WebSocket.

```mermaid
classDiagram
class AiAgent {
+AGENTS_TYPES
+PROTOCOLS
+chat_completions?()
+responses_api?()
+hermes?()
+pi?()
+qoder?()
+kimi_web?()
+kimi_web_ws?()
+safe_api_key()
+resolved_system_prompt(issue)
}
class AiAgentAssignment {
+for_user(user)
+agent_for(user)
+auto_dispatch?()
}
class AiAgentDispatch {
+STATUSES
+pending?()
+running?()
+done?()
+error?()
+finished?()
+duration()
+request_data()
+response_data()
}
AiAgent "1" --> "*" AiAgentAssignment : "has_many"
AiAgent "1" --> "*" AiAgentDispatch : "has_many"
AiAgentAssignment "1" --> "1" AiAgent : "belongs_to"
AiAgentDispatch "1" --> "1" AiAgent : "belongs_to"
```

**Diagram sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)

### AiAgentAssignment: User-to-agent mapping and auto-dispatch
- Purpose: Associates a single user with an active agent and controls whether auto-dispatch is enabled.
- Validation ensures a unique user-to-agent mapping and prevents duplicates.

**Section sources**
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)

### AiAgentDispatch: Dispatch lifecycle and persistence
- Purpose: Records each dispatch attempt, its status, timestamps, and serialized payloads.
- Includes convenience methods to compute duration and safely parse request/response JSON.

**Section sources**
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

### AiAgentsController: Admin agent management and connectivity testing
- Purpose: Provides CRUD operations for agents and a dedicated test connection endpoint.
- Tests:
  - For Kimi Web: health check against a dedicated endpoint.
  - For standard agents: minimal chat or responses API ping with short timeouts.

**Section sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)

### AiAgentDispatchJob: Asynchronous dispatch execution
- Purpose: Orchestrates the end-to-end dispatch process, including journaling, agent invocation, optional tool-loop execution, and error handling.
- Features:
  - Retries on transient agent errors using exponential backoff.
  - Tool-loop support for agents that return tool calls; executes Redmine API skill and feeds results back.
  - Journal updates for start, completion, and error events.
  - Serialization of request/response payloads for auditability.

```mermaid
flowchart TD
Start(["Dispatch Job Start"]) --> FindRecords["Load Issue, Agent, Trigger User"]
FindRecords --> Valid{"All records found?"}
Valid --> |No| LogWarn["Log warning and exit"]
Valid --> |Yes| CreateDispatch["Create Dispatch (running)"]
CreateDispatch --> PostStartNote["Post 'dispatch started' journal"]
PostStartNote --> CallAgent["Call AgentClient"]
CallAgent --> ToolCalls{"Tool calls present?"}
ToolCalls --> |No| SaveDone["Save done + response payload"]
ToolCalls --> |Yes| ExecuteTools["Execute RedmineApiSkill tool calls"]
ExecuteTools --> FeedBack["Feed tool results back to agent"]
FeedBack --> CallAgent
SaveDone --> PostDoneNote["Post 'dispatch done' journal"]
PostDoneNote --> End(["Exit"])
LogWarn --> End
```

**Diagram sources**
- [ai_agent_dispatch_job.rb:7-67](file://app/jobs/ai_agent_dispatch_job.rb#L7-L67)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)

**Section sources**
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

### Routing and Localization
- Routes:
  - Admin endpoints for agents (with a test connection action).
  - Admin endpoints for agent-user assignments.
  - Per-issue dispatch endpoints for manual triggering and viewing dispatch details.
- Localization:
  - Comprehensive labels, hints, notices, errors, and journal entries for UI and logging.

**Section sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [en.yml:1-104](file://config/locales/en.yml#L1-L104)

## Dependency Analysis
- Controllers depend on models for validation and persistence.
- Jobs encapsulate business logic for dispatch execution and tool-loop handling.
- Models define agent capabilities and system prompts, which inform agent-client behavior.
- Routes connect UI actions to controllers and jobs.

```mermaid
graph LR
CTRL_AGENTS["AiAgentsController"] --> MODEL_AGENT["AiAgent"]
CTRL_DISPATCHES["AiAgentDispatchesController"] --> MODEL_DISPATCH["AiAgentDispatch"]
MODEL_DISPATCH --> MODEL_AGENT
MODEL_ASSIGNMENT["AiAgentAssignment"] --> MODEL_AGENT
JOB_DISPATCH["AiAgentDispatchJob"] --> MODEL_DISPATCH
JOB_DISPATCH --> MODEL_AGENT
JOB_DISPATCH --> REDMINE_API["Redmine REST API"]
```

**Diagram sources**
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:52-140](file://app/models/ai_agent.rb#L52-L140)

**Section sources**
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

## Performance Considerations
- Asynchronous execution: Background jobs prevent UI blocking and enable retries for transient failures.
- Tool-loop limits: A bounded number of iterations prevents runaway processing while allowing practical tool-call workflows.
- Payload serialization: Storing request/response JSON aids debugging but should be monitored for large outputs.
- Network timeouts: Short open/read timeouts during connectivity tests ensure quick feedback for misconfigured endpoints.

## Troubleshooting Guide
Common scenarios and guidance:
- No active agent assigned: Ensure a user has an active agent assignment configured.
- Dispatch errors: Review the dispatch record’s status and response payload; check agent connectivity and endpoint configuration.
- Auto-dispatch not triggering: Verify the assignment’s auto-dispatch flag and agent activation.
- Kimi Web issues: Confirm the web server is running and reachable; validate session ID and working directory settings.

**Section sources**
- [en.yml:74-80](file://config/locales/en.yml#L74-L80)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)

## Conclusion
The Redmine AI Agent Plugin modernizes issue management by combining AI intelligence with Redmine’s robust workflow engine. Through configurable agents, flexible protocols, and asynchronous dispatches, it automates repetitive tasks, improves transparency via journal notes, and scales across teams and projects. Administrators can centrally manage agents and assignments, while developers can integrate custom endpoints and extend capabilities. Teams benefit from faster issue resolution, consistent processes, and reduced manual overhead—making AI-driven automation a practical and powerful addition to project management workflows.