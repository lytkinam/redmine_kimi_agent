# Target Audience

<cite>
**Referenced Files in This Document**
- [init.rb](file://init.rb)
- [routes.rb](file://config/routes.rb)
- [en.yml](file://config/locales/en.yml)
- [ai_agent.rb](file://app/models/ai_agent.rb)
- [ai_agent_assignment.rb](file://app/models/ai_agent_assignment.rb)
- [ai_agent_dispatch.rb](file://app/models/ai_agent_dispatch.rb)
- [ai_agents_controller.rb](file://app/controllers/ai_agents_controller.rb)
- [ai_agent_assignments_controller.rb](file://app/controllers/ai_agent_assignments_controller.rb)
- [ai_agent_dispatches_controller.rb](file://app/controllers/ai_agent_dispatches_controller.rb)
- [ai_agent_dispatch_job.rb](file://app/jobs/ai_agent_dispatch_job.rb)
- [_ai_agent_settings.html.erb](file://app/views/settings/_ai_agent_settings.html.erb)
- [001_create_ai_agents.rb](file://db/migrate/001_create_ai_agents.rb)
- [002_create_ai_agent_assignments.rb](file://db/migrate/002_create_ai_agent_assignments.rb)
- [003_create_ai_agent_dispatches.rb](file://db/migrate/003_create_ai_agent_dispatches.rb)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document defines the target audience for the Redmine AI Agent Plugin and explains how different user roles interact with the system. The primary audiences are:
- Redmine administrators: responsible for plugin configuration, agent definitions, and user-agent assignments.
- Developers: who implement custom integrations, extend capabilities, and leverage API endpoints for automation.
- End users (project managers and team members): who benefit from automated issue processing through AI agents.

The plugin enables assigning AI agents (including Hermes, Pi, Qoder, Kimi Web, and custom OpenAI-compatible endpoints) to Redmine users. When an issue is assigned, the AI agent can autonomously process it via the Redmine REST API, posting progress notes and updating status as needed.

## Project Structure
The plugin follows a standard Redmine plugin layout with controllers, models, jobs, views, routes, and migrations. It exposes admin interfaces for managing agents and assignments, per-issue dispatch controls, and global settings.

```mermaid
graph TB
subgraph "Admin UI"
A1["AI Agents<br/>Index/Edit/Create/Delete"]
A2["Assignments<br/>Index/Edit/Create/Delete"]
A3["Settings<br/>Enable/URL/Timeout"]
end
subgraph "Issue UI"
U1["Issue Page Panel<br/>Manual Dispatch Button"]
end
subgraph "Backend"
R["Routes"]
C1["AiAgentsController"]
C2["AiAgentAssignmentsController"]
C3["AiAgentDispatchesController"]
J["AiAgentDispatchJob"]
M1["AiAgent"]
M2["AiAgentAssignment"]
M3["AiAgentDispatch"]
end
A1 --> C1
A2 --> C2
A3 --> R
U1 --> C3
R --> C1
R --> C2
R --> C3
C1 --> M1
C2 --> M2
C3 --> M3
C3 --> J
```

**Diagram sources**
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)

**Section sources**
- [init.rb:18-30](file://init.rb#L18-L30)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)

## Core Components
- Admin menu entry and permissions define who can manage agents and assignments, and who can dispatch agents on issues.
- Routes expose admin CRUD endpoints for agents and assignments, plus per-issue dispatch creation and viewing.
- Models encapsulate agent definitions, user-agent assignments, and dispatch records with status tracking.
- Controllers enforce authorization, render admin UIs, and trigger asynchronous dispatches.
- Jobs perform the AI agent call, support a tool-call loop using Redmine API skills, and post journal updates.
- Settings allow enabling/disabling the plugin, configuring the Redmine base URL for agent API access, and setting timeouts.

Key capabilities:
- Administrators configure agents, test connections, assign agents to users, and enable auto-dispatch.
- Developers can customize agent types, protocols, and system prompts; integrate custom skills; and extend endpoints.
- End users trigger manual dispatches from the issue page and observe autonomous processing via journal entries.

**Section sources**
- [init.rb:12-29](file://init.rb#L12-L29)
- [routes.rb:2-16](file://config/routes.rb#L2-L16)
- [ai_agent.rb:1-155](file://app/models/ai_agent.rb#L1-L155)
- [ai_agent_assignment.rb:1-26](file://app/models/ai_agent_assignment.rb#L1-L26)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Architecture Overview
The plugin integrates three primary interaction modes:
- Admin configuration: define agents, assign agents to users, and configure plugin settings.
- Manual dispatch: users trigger AI processing from the issue page.
- Automated dispatch: optional auto-dispatch when issues are assigned to users with active agent assignments.

```mermaid
sequenceDiagram
participant Admin as "Administrator"
participant AdminUI as "Admin UI"
participant Routes as "Routes"
participant AgentsC as "AiAgentsController"
participant AssignmentsC as "AiAgentAssignmentsController"
participant SettingsV as "Settings View"
participant DispatchC as "AiAgentDispatchesController"
participant Job as "AiAgentDispatchJob"
participant Model as "Models"
Admin->>AdminUI : Navigate to Admin Menu
AdminUI->>Routes : GET /ai_agents, /ai_agent_assignments
Routes->>AgentsC : Index/Edit/Create/Delete
Routes->>AssignmentsC : Manage Assignments
Admin->>SettingsV : Enable plugin, set base URL, timeout
Admin->>AgentsC : Create/Test Agent
Admin->>AssignmentsC : Assign Agent to Users
Admin->>DispatchC : Manual Dispatch (per issue)
DispatchC->>Job : Enqueue dispatch
Job->>Model : Create dispatch record, post journal
Job->>Model : Tool-call loop via Redmine API skill
Job-->>DispatchC : Status update (done/error)
```

**Diagram sources**
- [init.rb:18-29](file://init.rb#L18-L29)
- [routes.rb:2-16](file://config/routes.rb#L2-L16)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

## Detailed Component Analysis

### Redmine Administrators
Primary responsibilities:
- Configure plugin settings (enable/disable, base URL injection, default timeout).
- Define AI agents (types, endpoints, protocols, models, system prompts).
- Test agent connectivity.
- Assign agents to users and enable auto-dispatch.
- Monitor dispatches and troubleshoot failures.

Interaction touchpoints:
- Admin menu entry for AI Agents.
- Settings partial for global plugin configuration.
- Admin CRUD for agents and assignments.
- Dispatch listing and detail views.

Use cases:
- Onboarding new AI agents: create agent entries, set endpoint URLs and keys, choose protocols, and test connectivity.
- Team onboarding: assign agents to users, optionally enable auto-dispatch, and confirm availability on the issue panel.
- Operational oversight: review dispatch statuses, durations, and journal notes; investigate errors.

Permissions and authorization:
- Project-level permissions for dispatch and management actions are declared in the plugin registration.

**Section sources**
- [init.rb:18-29](file://init.rb#L18-L29)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)

### Developers
Primary responsibilities:
- Extend agent capabilities by integrating custom skills and tools.
- Customize system prompts and agent behavior.
- Integrate with API endpoints for advanced automation.
- Maintain and monitor job retries and error handling.

Interaction touchpoints:
- Routes for agents and assignments.
- Models exposing agent types, protocols, and dispatch statuses.
- Job orchestrating tool-call loops and Redmine API skill execution.
- Localization keys for UI labels and hints.

Use cases:
- Custom agent integration: define new agent types and protocols; implement custom system prompts; connect to OpenAI-compatible or local endpoints.
- Automation pipeline: leverage dispatch endpoints to trigger processing programmatically; parse request/response payloads for monitoring.
- Observability: inspect dispatch records, status transitions, and journal notes; diagnose tool-call failures.

Developer-facing features:
- Agent types and protocols supported.
- System prompt templates and placeholders.
- Dispatch status lifecycle and payload parsing.
- Retry policy for transient errors.

**Section sources**
- [routes.rb:2-16](file://config/routes.rb#L2-L16)
- [ai_agent.rb:24-50](file://app/models/ai_agent.rb#L24-L50)
- [ai_agent.rb:52-140](file://app/models/ai_agent.rb#L52-L140)
- [ai_agent_dispatch.rb:1-44](file://app/models/ai_agent_dispatch.rb#L1-L44)
- [ai_agent_dispatch_job.rb:80-119](file://app/jobs/ai_agent_dispatch_job.rb#L80-L119)
- [en.yml:25-67](file://config/locales/en.yml#L25-L67)

### End Users (Project Managers and Team Members)
Primary responsibilities:
- Trigger manual dispatches from the issue page.
- Observe autonomous processing via journal entries.
- Track dispatch status and outcomes.

Interaction touchpoints:
- Issue panel button to send tasks to AI agents.
- Dispatch listing and detail pages.
- Journal notes indicating start, completion, and errors.

Use cases:
- Request assistance: manually dispatch an agent to triage, estimate, refactor, or resolve an issue.
- Monitor progress: watch journal updates posted by the agent during processing.
- Escalate issues: if an error occurs, review dispatch details and retry or escalate.

**Section sources**
- [en.yml:82-97](file://config/locales/en.yml#L82-L97)
- [ai_agent_dispatches_controller.rb:14-36](file://app/controllers/ai_agent_dispatches_controller.rb#L14-L36)
- [ai_agent_dispatch.rb:14-24](file://app/models/ai_agent_dispatch.rb#L14-L24)

## Dependency Analysis
The plugin’s runtime depends on:
- Redmine core permissions and routing.
- Rails Active Record models and Active Job for asynchronous processing.
- Agent clients and skills for external API communication.
- Plugin settings for base URL and timeouts.

```mermaid
graph LR
Init["init.rb<br/>Plugin Registration"] --> Routes["routes.rb<br/>Admin & Issue Routes"]
Routes --> C1["AiAgentsController"]
Routes --> C2["AiAgentAssignmentsController"]
Routes --> C3["AiAgentDispatchesController"]
C1 --> M1["AiAgent"]
C2 --> M2["AiAgentAssignment"]
C3 --> M3["AiAgentDispatch"]
C3 --> Job["AiAgentDispatchJob"]
Job --> M3
Job --> M1
Job --> Skill["RedmineApiSkill"]
Settings["Settings Partial"] --> M1
Settings --> Job
```

**Diagram sources**
- [init.rb:1-31](file://init.rb#L1-L31)
- [routes.rb:1-17](file://config/routes.rb#L1-L17)
- [ai_agents_controller.rb:1-110](file://app/controllers/ai_agents_controller.rb#L1-L110)
- [ai_agent_assignments_controller.rb:1-56](file://app/controllers/ai_agent_assignments_controller.rb#L1-L56)
- [ai_agent_dispatches_controller.rb:1-54](file://app/controllers/ai_agent_dispatches_controller.rb#L1-L54)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)
- [_ai_agent_settings.html.erb:1-31](file://app/views/settings/_ai_agent_settings.html.erb#L1-L31)

**Section sources**
- [init.rb:12-29](file://init.rb#L12-L29)
- [routes.rb:2-16](file://config/routes.rb#L2-L16)
- [ai_agent_dispatch_job.rb:1-137](file://app/jobs/ai_agent_dispatch_job.rb#L1-L137)

## Performance Considerations
- Async processing: dispatches are queued and processed asynchronously to avoid blocking UI interactions.
- Retries: transient errors trigger exponential backoff retries to improve resilience.
- Payload logging: request/response payloads are stored for observability; sensitive keys are masked in serialized outputs.
- Timeouts: configurable default timeout for HTTP requests to external agents; settings also allow tuning per agent (e.g., Kimi WebSocket timeout).

Recommendations:
- Monitor dispatch durations and error rates to tune agent configurations.
- Use auto-dispatch judiciously to prevent unnecessary load.
- Keep agent endpoints responsive and within network latency expectations.

**Section sources**
- [ai_agent_dispatch_job.rb:4-6](file://app/jobs/ai_agent_dispatch_job.rb#L4-L6)
- [ai_agent_dispatch_job.rb:26-57](file://app/jobs/ai_agent_dispatch_job.rb#L26-L57)
- [ai_agent.rb:17-22](file://app/models/ai_agent.rb#L17-L22)
- [_ai_agent_settings.html.erb:22-30](file://app/views/settings/_ai_agent_settings.html.erb#L22-L30)

## Troubleshooting Guide
Common scenarios and resolutions:
- No agent assigned to the current assignee: ensure a user has an active agent assignment; otherwise, manual dispatch will fail.
- Dispatch error recorded: check the dispatch detail page for error payloads; verify agent endpoint connectivity and credentials.
- Auto-dispatch not triggering: confirm the assignment has auto-dispatch enabled and the agent is active.
- Agent connection test fails: validate endpoint URL, protocol, model name, and API key; for Kimi Web, ensure the web server is running and reachable.

Operational checks:
- Review dispatch statuses (pending, running, done, error) and timestamps.
- Inspect journal notes for start, completion, and error messages.
- Confirm plugin settings (enabled flag, base URL, default timeout).

**Section sources**
- [ai_agent_dispatches_controller.rb:22-25](file://app/controllers/ai_agent_dispatches_controller.rb#L22-L25)
- [ai_agent_dispatch_job.rb:121-135](file://app/jobs/ai_agent_dispatch_job.rb#L121-L135)
- [ai_agent_dispatch.rb:14-18](file://app/models/ai_agent_dispatch.rb#L14-L18)
- [en.yml:74-80](file://config/locales/en.yml#L74-L80)

## Conclusion
The Redmine AI Agent Plugin targets three distinct but interconnected user groups:
- Administrators configure and operate the system, ensuring agents are properly defined, tested, and assigned.
- Developers extend and integrate the plugin, customizing agent behavior and automating workflows.
- End users benefit from streamlined issue processing through AI-assisted automation.

By leveraging admin interfaces, API endpoints, and automated workflows, the plugin accelerates Redmine operations while maintaining transparency and control through dispatch records and journal updates.