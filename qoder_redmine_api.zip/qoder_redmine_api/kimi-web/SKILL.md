---
name: kimi-web
description: Full-featured HTTP/WebSocket client for Kimi Code CLI Web Interface. Provides REST API wrappers and WebSocket messaging for session management, file uploads, config updates, and real-time prompt streaming.
---

# Kimi Web Skill

Complete toolkit for interacting with **Kimi Code CLI Web Interface** via HTTP REST and WebSocket protocols.

## Quick Start

```bash
# From skill directory
cd .kimi/skills/kimi-web

# REST API examples
bash scripts/kimi-web.sh health
bash scripts/kimi-web.sh session list
bash scripts/kimi-web.sh session get <uuid>

# WebSocket examples
python3 scripts/kimi-web-ws.py prompt <uuid> "Your message" --wait
python3 scripts/kimi-web-ws.py cancel <uuid>
```

## Architecture

```
┌─────────────┐     HTTP REST      ┌─────────────────────────────┐
│   Client    │ ◄───────────────►  │  Kimi Code CLI Web UI       │
│  (this skill)│    WebSocket      │  (uvicorn on 127.0.0.1:5494) │
└─────────────┘ ◄───────────────►  └─────────────────────────────┘
```

- **REST API**: Session CRUD, file uploads, config management, git diff
- **WebSocket**: Real-time bidirectional messaging (prompts, events, status)

## Base Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `KIMI_WEB_HOST` | `127.0.0.1` | Server host |
| `KIMI_WEB_PORT` | `5494` | Server port |
| `KIMI_WEB_BASE` | `http://${KIMI_WEB_HOST}:${KIMI_WEB_PORT}` | REST base URL |
| `KIMI_WEB_WS_BASE` | `ws://${KIMI_WEB_HOST}:${KIMI_WEB_PORT}` | WebSocket base URL |
| `KIMI_WEB_TOKEN` | *(optional)* | Auth token if server requires it |

## Directory Structure

```
kimi-web/
├── SKILL.md                          # This file
├── scripts/
│   ├── kimi-web.sh                   # REST API CLI wrapper
│   └── kimi-web-ws.py                # WebSocket client
└── reference/
    └── api-reference.md              # Complete endpoint schema
```

---

## REST API Quick Reference

### Sessions

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/sessions/` | `GET` | List sessions (paginated, searchable) |
| `/api/sessions/` | `POST` | Create new session |
| `/api/sessions/{id}` | `GET` | Get session metadata |
| `/api/sessions/{id}` | `PATCH` | Update title or archive status |
| `/api/sessions/{id}` | `DELETE` | Delete session |
| `/api/sessions/{id}/fork` | `POST` | Fork session at specific turn |
| `/api/sessions/{id}/generate-title` | `POST` | AI-generate session title |
| `/api/sessions/{id}/git-diff` | `GET` | Get git diff stats |

### Files

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/sessions/{id}/files` | `POST` | Upload file to session |
| `/api/sessions/{id}/files/{path}` | `GET` | Read file / list directory from work_dir |
| `/api/sessions/{id}/uploads/{path}` | `GET` | Get uploaded file from session uploads |

### Config

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/config/` | `GET` | Get global config snapshot |
| `/api/config/` | `PATCH` | Update default model / thinking mode |
| `/api/config/toml` | `GET` | Read config.toml content |
| `/api/config/toml` | `PUT` | Update config.toml content |

### Utility

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/work-dirs/` | `GET` | List available work directories |
| `/api/work-dirs/startup` | `GET` | Get startup directory |
| `/api/open-in` | `POST` | Open path in local application |
| `/healthz` | `GET` | Health probe |

---

## WebSocket Protocol

**Endpoint:** `ws://{host}:{port}/api/sessions/{session_id}/stream`

**Query params (optional):**
- `token={KIMI_WEB_TOKEN}` — if server requires auth

### Connection Flow

1. **Connect** → Server accepts
2. **History replay** → Server sends past messages from `wire.jsonl`
3. **`history_complete`** → Server signals readiness
4. **Client sends commands** → `initialize`, `prompt`, `steer`, `cancel`, etc.
5. **Server pushes events** → `event`, `request`, `session_status`

### Inbound Messages (Client → Server)

All messages are JSON-RPC 2.0.

#### `initialize`
```json
{
  "jsonrpc": "2.0",
  "method": "initialize",
  "id": "uuid-v4",
  "params": {
    "protocol_version": "1.0",
    "client": {"name": "kimi-web-skill", "version": "1.0"},
    "capabilities": {"supports_question": true, "supports_plan_mode": true},
    "hooks": [],
    "external_tools": []
  }
}
```

#### `prompt`
```json
{
  "jsonrpc": "2.0",
  "method": "prompt",
  "id": "uuid-v4",
  "params": {
    "user_input": "Your message here"
  }
}
```

#### `steer`
```json
{
  "jsonrpc": "2.0",
  "method": "steer",
  "id": "uuid-v4",
  "params": {
    "user_input": "Steer instruction"
  }
}
```

#### `set_plan_mode`
```json
{
  "jsonrpc": "2.0",
  "method": "set_plan_mode",
  "id": "uuid-v4",
  "params": {
    "enabled": true
  }
}
```

#### `cancel`
```json
{
  "jsonrpc": "2.0",
  "method": "cancel",
  "id": "uuid-v4"
}
```

### Outbound Messages (Server → Client)

#### `history_complete`
```json
{"jsonrpc": "2.0", "method": "history_complete", "id": "uuid-v4"}
```

#### `session_status`
```json
{
  "jsonrpc": "2.0",
  "method": "session_status",
  "params": {
    "session_id": "uuid",
    "state": "idle|busy|stopped|error|restarting",
    "seq": 1,
    "worker_id": "uuid",
    "reason": "start|prompt|stop|error",
    "detail": null,
    "updated_at": "2026-01-01T00:00:00Z"
  }
}
```

#### `event`
```json
{
  "jsonrpc": "2.0",
  "method": "event",
  "params": {
    "type": "agent_text|agent_response|tool_call|tool_result|notice",
    "payload": {}
  }
}
```

#### `request`
```json
{
  "jsonrpc": "2.0",
  "method": "request",
  "id": "req-uuid",
  "params": {
    "type": "ApprovalRequest|QuestionRequest",
    "payload": {}
  }
}
```

---

## CLI Tools

### REST API: `kimi-web.sh`

```bash
# Environment (optional)
export KIMI_WEB_HOST=127.0.0.1
export KIMI_WEB_PORT=5494

# Sessions
./scripts/kimi-web.sh session list
./scripts/kimi-web.sh session get <session_id>
./scripts/kimi-web.sh session create [--work-dir /path] [--create-dir]
./scripts/kimi-web.sh session update <session_id> --title "New Title"
./scripts/kimi-web.sh session archive <session_id>
./scripts/kimi-web.sh session unarchive <session_id>
./scripts/kimi-web.sh session delete <session_id>
./scripts/kimi-web.sh session fork <session_id> --turn 3
./scripts/kimi-web.sh session title <session_id>        # AI generate title
./scripts/kimi-web.sh session git-diff <session_id>

# Files
./scripts/kimi-web.sh file upload <session_id> /path/to/file.txt
./scripts/kimi-web.sh file get <session_id> path/inside/workdir
./scripts/kimi-web.sh file list <session_id> [path/]

# Config
./scripts/kimi-web.sh config get
./scripts/kimi-web.sh config patch --model gpt-4o
./scripts/kimi-web.sh config toml-get
./scripts/kimi-web.sh config toml-put /path/to/config.toml

# Utility
./scripts/kimi-web.sh health
./scripts/kimi-web.sh work-dirs
```

### WebSocket: `kimi-web-ws.py`

```bash
# Send a prompt and stream response for 10 seconds
python3 scripts/kimi-web-ws.py prompt <session_id> "Your message here"

# Send prompt, wait for completion (idle state)
python3 scripts/kimi-web-ws.py prompt <session_id> "Your message" --wait

# Send cancel
python3 scripts/kimi-web-ws.py cancel <session_id>

# Toggle plan mode
python3 scripts/kimi-web-ws.py plan-mode <session_id> --enable
python3 scripts/kimi-web-ws.py plan-mode <session_id> --disable

# Interactive streaming (Ctrl+C to stop)
python3 scripts/kimi-web-ws.py stream <session_id>
```

---

## Error Codes

### REST HTTP Statuses
| Code | Meaning |
|------|---------|
| `200` | Success |
| `400` | Bad request (session busy, invalid params) |
| `403` | Forbidden (sensitive path, origin check) |
| `404` | Session or file not found |
| `422` | Validation error |

### WebSocket Close Codes
| Code | Meaning |
|------|---------|
| `4004` | Session not found |
| `4401` | Auth required |
| `4403` | Access denied / Origin not allowed |

### JSON-RPC Error Codes
| Code | Meaning |
|------|---------|
| `-32700` | Parse error |
| `-32600` | Invalid request |
| `-32601` | Method not found |
| `-32000` | Invalid state (session busy) |
| `-32001` | LLM not set |
| `-32002` | LLM not supported |
| `-32003` | Chat provider error |
| `-32004` | Auth expired |

---

## Usage Examples

### Example 1: Create session and send first prompt

```bash
# Create session
SESSION=$(./scripts/kimi-web.sh session create --work-dir ~/projects/demo | jq -r '.session_id')

# Send prompt via WebSocket
python3 scripts/kimi-web-ws.py prompt "$SESSION" "Hello, explain how you work" --wait
```

### Example 2: Upload file and reference it

```bash
./scripts/kimi-web.sh file upload "$SESSION" ./data.csv
python3 scripts/kimi-web-ws.py prompt "$SESSION" "Analyze the uploaded data.csv file"
```

### Example 3: Fork conversation at turn 5

```bash
./scripts/kimi-web.sh session fork "$SESSION" --turn 5
```

### Example 4: Update model config

```bash
./scripts/kimi-web.sh config patch --model kimi-k2 --thinking enabled
```

### Example 5: Batch list and filter

```bash
./scripts/kimi-web.sh session list | jq '.[] | select(.archived==false) | {id: .session_id, title}'
```

---

## Platform Notes

### Windows (Git Bash / MSYS2)
If Cyrillic or other non-ASCII characters display as `?` or `�` in the terminal, set UTF-8 mode before running scripts:
```bash
export PYTHONIOENCODING=utf-8
export LC_ALL=C.UTF-8
# Or use Python with -X utf8
python3 -X utf8 scripts/kimi-web-ws.py prompt <uuid> "Текст"
```

## Implementation Notes

1. **Session state lifecycle**: `stopped` → `idle` → `busy` → `idle` → `stopped`
2. **Only one prompt at a time**: If session is `busy`, new `prompt` returns error `-32000`
3. **File uploads**: Max 100MB per file. Files are stored in session uploads dir.
4. **History replay**: New WebSocket connections automatically receive full conversation history from `wire.jsonl`
5. **Auto-start**: Sending `prompt` auto-starts the worker subprocess if not running
6. **Plan mode**: When enabled, agent enters plan-approval mode before executing changes

## Roadmap / Planned Capabilities

The following features are architecturally planned but **require implementation and testing** before production use.

### Webhook Relay
A lightweight relay service that bridges Kimi CLI WebSocket events to external HTTP endpoints:
- **Use case**: Notify external services (Slack, Telegram, CI/CD, custom backend) when a session completes, fails, or requires approval
- **Approach**: A standalone `kimi-web-relay.py` process maintains WebSocket connection and forwards selected events via HTTP POST
- **Events to forward**: `session_status` (`idle`/`error`), `TurnEnd`, `ApprovalRequest`
- **Retry policy**: Exponential backoff for failed webhook deliveries
- **Status**: ⏳ Requires implementation and testing

### Callback Hooks
In-process callback mechanism for the WebSocket client:
- **Use case**: Execute a Python function when the session reaches a specific state (e.g., `idle` after prompt completion)
- **Approach**: Add `--on-idle-callback` / `--on-error-callback` arguments to `kimi-web-ws.py`
- **Status**: ⏳ Requires implementation and testing

### SSE Fallback
Server-Sent Events fallback for environments where WebSocket is blocked:
- **Use case**: Corporate proxies or browsers with disabled WebSocket support
- **Approach**: Proxy WebSocket messages through an SSE endpoint served by a local relay
- **Status**: ⏳ Requires implementation and testing

## See Also

- `./reference/api-reference.md` — Complete OpenAPI schema details
- Kimi Code CLI docs: `kimi --help` and web UI at `http://127.0.0.1:5494`
