#!/usr/bin/env bash
#
# kimi-web.sh — REST API CLI for Kimi Code CLI Web Interface
#
# Usage:
#   export KIMI_WEB_HOST=127.0.0.1
#   export KIMI_WEB_PORT=5494
#   export KIMI_WEB_TOKEN=""        # optional
#
#   ./kimi-web.sh session list
#   ./kimi-web.sh session get <uuid>
#   ./kimi-web.sh session create [--work-dir PATH] [--create-dir]
#   ./kimi-web.sh session update <uuid> [--title TEXT] [--archive|--unarchive]
#   ./kimi-web.sh session delete <uuid>
#   ./kimi-web.sh session fork <uuid> --turn N
#   ./kimi-web.sh session title <uuid>
#   ./kimi-web.sh session git-diff <uuid>
#   ./kimi-web.sh file upload <uuid> <local-path>
#   ./kimi-web.sh file get <uuid> <remote-path>
#   ./kimi-web.sh file list <uuid> [remote-path]
#   ./kimi-web.sh config get
#   ./kimi-web.sh config patch [--model MODEL] [--thinking enabled|disabled]
#   ./kimi-web.sh config toml-get
#   ./kimi-web.sh config toml-put <local-toml-path>
#   ./kimi-web.sh health
#   ./kimi-web.sh work-dirs
#

set -euo pipefail

# ─── Configuration ──────────────────────────────────────────────────────────
HOST="${KIMI_WEB_HOST:-127.0.0.1}"
PORT="${KIMI_WEB_PORT:-5494}"
TOKEN="${KIMI_WEB_TOKEN:-}"
BASE_URL="http://${HOST}:${PORT}"

CURL="curl -s -S"
if [[ -n "$TOKEN" ]]; then
  CURL="$CURL -H \"Authorization: Bearer ${TOKEN}\""
fi

# ─── Helpers ────────────────────────────────────────────────────────────────

die() { echo "[ERROR] $*" >&2; exit 1; }

json_pp() {
  if command -v jq &>/dev/null; then
    jq . 2>/dev/null || cat
  else
    python3 -m json.tool 2>/dev/null || cat
  fi
}

check_uuid() {
  local id="$1"
  if [[ ! "$id" =~ ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$ ]]; then
    die "Invalid UUID format: $id"
  fi
}

http_get() {
  local url="$1"
  eval "$CURL \"$url\"" | json_pp
}

http_post() {
  local url="$1"
  local body="${2:-}"
  if [[ -n "$body" ]]; then
    eval "$CURL -X POST -H \"Content-Type: application/json\" -d '$body' \"$url\"" | json_pp
  else
    eval "$CURL -X POST \"$url\"" | json_pp
  fi
}

http_patch() {
  local url="$1"
  local body="$2"
  eval "$CURL -X PATCH -H \"Content-Type: application/json\" -d '$body' \"$url\"" | json_pp
}

http_delete() {
  local url="$1"
  eval "$CURL -X DELETE \"$url\"" | json_pp
}

http_put_file() {
  local url="$1"
  local file="$2"
  eval "$CURL -X PUT -H \"Content-Type: application/json\" -d '@$file' \"$url\"" | json_pp
}

http_upload() {
  local url="$1"
  local file="$2"
  eval "$CURL -X POST -F \"file=@$file\" \"$url\"" | json_pp
}

# ─── Session Commands ───────────────────────────────────────────────────────

cmd_session_list() {
  local q="${1:-}"
  local url="${BASE_URL}/api/sessions/"
  if [[ -n "$q" ]]; then
    url="${url}?q=$(printf '%s' "$q" | python3 -c 'import urllib.parse,sys;print(urllib.parse.quote(sys.stdin.read().strip()))')"
  fi
  http_get "$url"
}

cmd_session_get() {
  local id="$1"
  check_uuid "$id"
  http_get "${BASE_URL}/api/sessions/${id}"
}

cmd_session_create() {
  local work_dir=""
  local create_dir="false"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --work-dir) work_dir="$2"; shift 2 ;;
      --create-dir) create_dir="true"; shift ;;
      *) die "Unknown option: $1" ;;
    esac
  done
  local body="{"
  [[ -n "$work_dir" ]] && body="${body}\"work_dir\":\"${work_dir}\","
  body="${body}\"create_dir\":${create_dir}}"
  http_post "${BASE_URL}/api/sessions/" "$body"
}

cmd_session_update() {
  local id="$1"; shift
  check_uuid "$id"
  local title=""
  local archived=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --title) title="$2"; shift 2 ;;
      --archive) archived="true"; shift ;;
      --unarchive) archived="false"; shift ;;
      *) die "Unknown option: $1" ;;
    esac
  done
  local body="{"
  [[ -n "$title" ]] && body="${body}\"title\":\"${title}\","
  [[ -n "$archived" ]] && body="${body}\"archived\":${archived},"
  body="${body%,}}"
  [[ "$body" == "{}" ]] && die "No fields to update. Use --title, --archive, or --unarchive"
  http_patch "${BASE_URL}/api/sessions/${id}" "$body"
}

cmd_session_delete() {
  local id="$1"
  check_uuid "$id"
  http_delete "${BASE_URL}/api/sessions/${id}"
}

cmd_session_fork() {
  local id="$1"; shift
  check_uuid "$id"
  local turn=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --turn) turn="$2"; shift 2 ;;
      *) die "Unknown option: $1" ;;
    esac
  done
  [[ -z "$turn" ]] && die "--turn is required"
  http_post "${BASE_URL}/api/sessions/${id}/fork" "{\"turn_index\":${turn}}"
}

cmd_session_title() {
  local id="$1"
  check_uuid "$id"
  http_post "${BASE_URL}/api/sessions/${id}/generate-title"
}

cmd_session_git_diff() {
  local id="$1"
  check_uuid "$id"
  http_get "${BASE_URL}/api/sessions/${id}/git-diff"
}

# ─── File Commands ──────────────────────────────────────────────────────────

cmd_file_upload() {
  local id="$1"
  local file="$2"
  check_uuid "$id"
  [[ -f "$file" ]] || die "File not found: $file"
  http_upload "${BASE_URL}/api/sessions/${id}/files" "$file"
}

cmd_file_get() {
  local id="$1"
  local path="$2"
  check_uuid "$id"
  local encoded_path
  encoded_path=$(printf '%s' "$path" | python3 -c 'import urllib.parse,sys;print(urllib.parse.quote(sys.stdin.read().strip(), safe=""))')
  http_get "${BASE_URL}/api/sessions/${id}/files/${encoded_path}"
}

cmd_file_list() {
  local id="$1"
  local path="${2:-}"
  check_uuid "$id"
  if [[ -n "$path" ]]; then
    local encoded_path
    encoded_path=$(printf '%s' "$path" | python3 -c 'import urllib.parse,sys;print(urllib.parse.quote(sys.stdin.read().strip(), safe=""))')
    http_get "${BASE_URL}/api/sessions/${id}/files/${encoded_path}"
  else
    http_get "${BASE_URL}/api/sessions/${id}/files/"
  fi
}

# ─── Config Commands ────────────────────────────────────────────────────────

cmd_config_get() {
  http_get "${BASE_URL}/api/config/"
}

cmd_config_patch() {
  local model=""
  local thinking=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --model) model="$2"; shift 2 ;;
      --thinking) thinking="$2"; shift 2 ;;
      *) die "Unknown option: $1" ;;
    esac
  done
  local body="{"
  [[ -n "$model" ]] && body="${body}\"model\":\"${model}\","
  [[ -n "$thinking" ]] && body="${body}\"thinking\":\"${thinking}\","
  body="${body%,}}"
  [[ "$body" == "{}" ]] && die "No fields to patch. Use --model or --thinking"
  http_patch "${BASE_URL}/api/config/" "$body"
}

cmd_config_toml_get() {
  http_get "${BASE_URL}/api/config/toml"
}

cmd_config_toml_put() {
  local file="$1"
  [[ -f "$file" ]] || die "File not found: $file"
  http_put_file "${BASE_URL}/api/config/toml" "$file"
}

# ─── Utility Commands ───────────────────────────────────────────────────────

cmd_health() {
  http_get "${BASE_URL}/healthz"
}

cmd_work_dirs() {
  http_get "${BASE_URL}/api/work-dirs/"
}

# ─── Main Dispatcher ────────────────────────────────────────────────────────

usage() {
  cat << 'EOF'
Usage: kimi-web.sh <group> <command> [args...]

Groups:
  session   Session management
  file      File operations
  config    Configuration
  utility   Health & work dirs

Session commands:
  list [query]              List sessions (optional search query)
  get <uuid>                Get session details
  create [--work-dir PATH] [--create-dir]
                            Create new session
  update <uuid> [--title TEXT] [--archive|--unarchive]
                            Update session
  delete <uuid>             Delete session
  fork <uuid> --turn N      Fork session at turn index
  title <uuid>              AI-generate title
  git-diff <uuid>           Get git diff stats

File commands:
  upload <uuid> <local-path>   Upload file to session
  get <uuid> <remote-path>     Get file content
  list <uuid> [remote-path]    List directory

Config commands:
  get                        Get global config
  patch [--model MODEL] [--thinking enabled|disabled]
                             Update config
  toml-get                   Read config.toml
  toml-put <local-path>      Update config.toml from file

Utility commands:
  health                     Health probe
  work-dirs                  List available work directories

Environment:
  KIMI_WEB_HOST (default: 127.0.0.1)
  KIMI_WEB_PORT (default: 5494)
  KIMI_WEB_TOKEN (optional auth token)
EOF
  exit 1
}

[[ $# -lt 1 ]] && usage

GROUP="$1"; shift

# Handle top-level utility shortcuts
if [[ "$GROUP" == "health" ]]; then
  cmd_health
  exit 0
elif [[ "$GROUP" == "work-dirs" ]]; then
  cmd_work_dirs
  exit 0
fi

[[ $# -lt 1 ]] && usage
COMMAND="$1"; shift

case "$GROUP" in
  session|sessions)
    case "$COMMAND" in
      list)   cmd_session_list "${1:-}" ;;
      get)    cmd_session_get "$1" ;;
      create) cmd_session_create "$@" ;;
      update) cmd_session_update "$@" ;;
      delete) cmd_session_delete "$1" ;;
      fork)   cmd_session_fork "$@" ;;
      title)  cmd_session_title "$1" ;;
      git-diff) cmd_session_git_diff "$1" ;;
      *) die "Unknown session command: $COMMAND" ;;
    esac
    ;;
  file|files)
    case "$COMMAND" in
      upload) cmd_file_upload "$1" "$2" ;;
      get)    cmd_file_get "$1" "$2" ;;
      list)   cmd_file_list "$1" "${2:-}" ;;
      *) die "Unknown file command: $COMMAND" ;;
    esac
    ;;
  config)
    case "$COMMAND" in
      get)        cmd_config_get ;;
      patch)      cmd_config_patch "$@" ;;
      toml-get)   cmd_config_toml_get ;;
      toml-put)   cmd_config_toml_put "$1" ;;
      *) die "Unknown config command: $COMMAND" ;;
    esac
    ;;
  utility|util)
    case "$COMMAND" in
      health)    cmd_health ;;
      work-dirs) cmd_work_dirs ;;
      *) die "Unknown utility command: $COMMAND" ;;
    esac
    ;;
  *)
    usage
    ;;
esac
