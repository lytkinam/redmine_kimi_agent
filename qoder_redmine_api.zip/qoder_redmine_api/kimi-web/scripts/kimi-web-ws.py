#!/usr/bin/env python3
"""
kimi-web-ws.py — WebSocket client for Kimi Code CLI Web Interface

Usage:
    python3 kimi-web-ws.py prompt <session_id> "Your message" [--wait] [--timeout N]
    python3 kimi-web-ws.py cancel <session_id>
    python3 kimi-web-ws.py plan-mode <session_id> --enable|--disable
    python3 kimi-web-ws.py stream <session_id>                   # interactive

Environment:
    KIMI_WEB_HOST (default: 127.0.0.1)
    KIMI_WEB_PORT (default: 5494)
    KIMI_WEB_TOKEN (optional)
"""

import argparse
import json
import os
import sys
import time
import uuid
from typing import Optional

import websocket

HOST = os.environ.get("KIMI_WEB_HOST", "127.0.0.1")
PORT = os.environ.get("KIMI_WEB_PORT", "5494")
TOKEN = os.environ.get("KIMI_WEB_TOKEN", "")


def build_ws_url(session_id: str) -> str:
    url = f"ws://{HOST}:{PORT}/api/sessions/{session_id}/stream"
    if TOKEN:
        url += f"?token={TOKEN}"
    return url


def is_valid_uuid(s: str) -> bool:
    try:
        uuid.UUID(s)
        return True
    except ValueError:
        return False


class WebSocketClient:
    def __init__(self, session_id: str, wait_idle: bool = False, timeout: float = 60.0):
        self.session_id = session_id
        self.url = build_ws_url(session_id)
        self.wait_idle = wait_idle
        self.timeout = timeout
        self.ws: Optional[websocket.WebSocketApp] = None
        self.history_complete = False
        self.connected = False
        self.start_time = 0.0
        self.prompt_id: Optional[str] = None
        self.state = "unknown"
        self._buffer = []
        self._expecting_response = False

    def on_open(self, ws: websocket.WebSocketApp) -> None:
        self.connected = True
        self.start_time = time.time()
        print(f"[CONNECTED] {self.url}", file=sys.stderr)
        print("[INFO] Waiting for history_complete...", file=sys.stderr)

    def on_message(self, ws: websocket.WebSocketApp, message: str) -> None:
        try:
            data = json.loads(message)
        except json.JSONDecodeError:
            print(f"[RAW] {message}", file=sys.stderr)
            return

        method = data.get("method")

        if method == "history_complete":
            self.history_complete = True
            print("[READY] Session ready for input.", file=sys.stderr)
            return

        if method == "session_status":
            params = data.get("params", {})
            self.state = params.get("state", "unknown")
            reason = params.get("reason", "")
            detail = params.get("detail")
            detail_str = f" ({detail})" if detail else ""
            print(f"[STATUS] {self.state} | reason={reason}{detail_str}", file=sys.stderr)
            return

        if method == "event":
            params = data.get("params", {})
            event_type = params.get("type", "")
            payload = params.get("payload", {})

            if event_type == "agent_text":
                text = payload.get("text", "")
                if text:
                    print(text, end="", flush=True)

            elif event_type == "agent_response":
                text = payload.get("text", "")
                if text:
                    print(text, end="", flush=True)

            elif event_type == "tool_call":
                name = payload.get("name", "")
                print(f"\n[TOOL CALL] {name}", file=sys.stderr)

            elif event_type == "tool_result":
                name = payload.get("name", "")
                success = payload.get("success", True)
                status = "OK" if success else "FAIL"
                print(f"[TOOL RESULT] {name} -> {status}", file=sys.stderr)

            elif event_type == "notice":
                text = payload.get("text", "")
                kind = payload.get("kind", "info")
                print(f"[NOTICE:{kind}] {text}", file=sys.stderr)

            else:
                preview = json.dumps(params, ensure_ascii=False)[:300]
                print(f"[EVENT:{event_type}] {preview}", file=sys.stderr)
            return

        if method == "request":
            req_id = data.get("id", "")
            params = data.get("params", {})
            req_type = params.get("type", "")
            print(f"\n[REQUEST] type={req_type} id={req_id}", file=sys.stderr)
            print(json.dumps(params, ensure_ascii=False, indent=2)[:800], file=sys.stderr)
            # Auto-approve simple approval requests if not interactive
            if req_type == "ApprovalRequest" and not sys.stdin.isatty():
                self.send_response(req_id, {"approved": True})
                print("[AUTO-APPROVE] Approved automatically (non-interactive)", file=sys.stderr)
            return

        if "error" in data:
            print(f"[ERROR] {json.dumps(data, ensure_ascii=False)}", file=sys.stderr)
            return

        if "result" in data:
            # Response to our message
            return

        # Unknown message
        preview = json.dumps(data, ensure_ascii=False)[:300]
        print(f"[MSG] {preview}", file=sys.stderr)

    def on_error(self, ws: websocket.WebSocketApp, error) -> None:
        print(f"[ERROR] {error}", file=sys.stderr)

    def on_close(self, ws: websocket.WebSocketApp, close_status_code, close_msg) -> None:
        self.connected = False
        print(f"\n[DISCONNECTED] code={close_status_code} msg={close_msg}", file=sys.stderr)

    def send_message(self, msg: dict) -> None:
        if self.ws and self.ws.sock and self.ws.sock.connected:
            self.ws.send(json.dumps(msg, ensure_ascii=False))
        else:
            raise ConnectionError("WebSocket not connected")

    def send_response(self, req_id: str, result: dict) -> None:
        self.send_message({"jsonrpc": "2.0", "id": req_id, "result": result})

    def send_prompt(self, text: str) -> None:
        self.prompt_id = str(uuid.uuid4())
        msg = {
            "jsonrpc": "2.0",
            "method": "prompt",
            "id": self.prompt_id,
            "params": {"user_input": text},
        }
        self.send_message(msg)
        print(f"[SENT] prompt id={self.prompt_id}", file=sys.stderr)

    def send_cancel(self) -> None:
        msg = {
            "jsonrpc": "2.0",
            "method": "cancel",
            "id": str(uuid.uuid4()),
        }
        self.send_message(msg)
        print("[SENT] cancel", file=sys.stderr)

    def send_plan_mode(self, enabled: bool) -> None:
        msg = {
            "jsonrpc": "2.0",
            "method": "set_plan_mode",
            "id": str(uuid.uuid4()),
            "params": {"enabled": enabled},
        }
        self.send_message(msg)
        print(f"[SENT] set_plan_mode enabled={enabled}", file=sys.stderr)

    def run(self, action: callable) -> None:
        self.ws = websocket.WebSocketApp(
            self.url,
            on_open=self.on_open,
            on_message=self.on_message,
            on_error=self.on_error,
            on_close=self.on_close,
        )

        # Schedule action after connection and history_complete
        def delayed_action():
            deadline = time.time() + 30.0
            while not self.history_complete and time.time() < deadline:
                time.sleep(0.1)
            if not self.history_complete:
                print("[WARN] history_complete not received, proceeding anyway", file=sys.stderr)
            try:
                action()
            except Exception as e:
                print(f"[ACTION ERROR] {e}", file=sys.stderr)

        import threading
        t = threading.Thread(target=delayed_action, daemon=True)
        t.start()

        # Run with timeout if specified
        if self.timeout > 0:
            self.ws.run_forever(ping_interval=30, ping_timeout=10)
        else:
            self.ws.run_forever(ping_interval=30, ping_timeout=10)


def cmd_prompt(session_id: str, text: str, wait: bool, timeout: float) -> None:
    if not is_valid_uuid(session_id):
        print(f"Invalid UUID: {session_id}", file=sys.stderr)
        sys.exit(1)

    client = WebSocketClient(session_id, wait_idle=wait, timeout=timeout)

    def action():
        client.send_prompt(text)
        if wait:
            print("[WAIT] Waiting for session to become idle...", file=sys.stderr)
            deadline = time.time() + timeout
            while time.time() < deadline:
                if client.state in ("idle", "stopped", "error"):
                    print(f"\n[DONE] State={client.state}", file=sys.stderr)
                    if client.ws:
                        client.ws.close()
                    break
                time.sleep(0.5)
            else:
                print("\n[TIMEOUT] Session did not become idle in time", file=sys.stderr)
                if client.ws:
                    client.ws.close()
        else:
            # Just wait fixed time then close
            time.sleep(timeout)
            if client.ws:
                client.ws.close()

    client.run(action)


def cmd_cancel(session_id: str) -> None:
    if not is_valid_uuid(session_id):
        print(f"Invalid UUID: {session_id}", file=sys.stderr)
        sys.exit(1)

    client = WebSocketClient(session_id, timeout=5.0)

    def action():
        client.send_cancel()
        time.sleep(2.0)
        if client.ws:
            client.ws.close()

    client.run(action)


def cmd_plan_mode(session_id: str, enabled: bool) -> None:
    if not is_valid_uuid(session_id):
        print(f"Invalid UUID: {session_id}", file=sys.stderr)
        sys.exit(1)

    client = WebSocketClient(session_id, timeout=5.0)

    def action():
        client.send_plan_mode(enabled)
        time.sleep(2.0)
        if client.ws:
            client.ws.close()

    client.run(action)


def cmd_stream(session_id: str) -> None:
    """Interactive streaming mode."""
    if not is_valid_uuid(session_id):
        print(f"Invalid UUID: {session_id}", file=sys.stderr)
        sys.exit(1)

    client = WebSocketClient(session_id, timeout=0)  # No auto-timeout

    def action():
        print("[INTERACTIVE] Type messages and press Enter. Empty line to exit.", file=sys.stderr)
        while client.connected:
            try:
                line = input()
            except EOFError:
                break
            if not line.strip():
                break
            client.send_prompt(line.strip())
        if client.ws:
            client.ws.close()

    client.run(action)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="WebSocket client for Kimi Code CLI Web Interface"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # prompt
    p_prompt = subparsers.add_parser("prompt", help="Send a prompt message")
    p_prompt.add_argument("session_id", help="Session UUID")
    p_prompt.add_argument("text", help="Message text")
    p_prompt.add_argument("--wait", action="store_true", help="Wait until session becomes idle")
    p_prompt.add_argument("--timeout", type=float, default=30.0, help="Max wait seconds (default: 30)")

    # cancel
    p_cancel = subparsers.add_parser("cancel", help="Cancel current prompt")
    p_cancel.add_argument("session_id", help="Session UUID")

    # plan-mode
    p_plan = subparsers.add_parser("plan-mode", help="Enable/disable plan mode")
    p_plan.add_argument("session_id", help="Session UUID")
    p_plan.add_argument("--enable", action="store_true", help="Enable plan mode")
    p_plan.add_argument("--disable", action="store_true", help="Disable plan mode")

    # stream
    p_stream = subparsers.add_parser("stream", help="Interactive streaming mode")
    p_stream.add_argument("session_id", help="Session UUID")

    args = parser.parse_args()

    if args.command == "prompt":
        cmd_prompt(args.session_id, args.text, args.wait, args.timeout)
    elif args.command == "cancel":
        cmd_cancel(args.session_id)
    elif args.command == "plan-mode":
        if args.enable:
            cmd_plan_mode(args.session_id, True)
        elif args.disable:
            cmd_plan_mode(args.session_id, False)
        else:
            print("Use --enable or --disable", file=sys.stderr)
            sys.exit(1)
    elif args.command == "stream":
        cmd_stream(args.session_id)


if __name__ == "__main__":
    main()
