# Kimi Web API Reference

Complete schema reference for Kimi Code CLI Web Interface REST API and WebSocket protocol.

## Base URLs

```
REST:    http://127.0.0.1:5494
WebSocket: ws://127.0.0.1:5494
```

---

## REST API Schema

### Sessions

#### `GET /api/sessions/`

List all sessions with optional pagination and search.

**Query Parameters:**
| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `limit` | integer | 100 | Max results (max 500) |
| `offset` | integer | 0 | Skip N results |
| `q` | string | - | Search query (title or work_dir) |
| `archived` | boolean | - | Filter: null=non-archived, true=archived |

**Response:** `Array<Session>`

```json
[
  {
    "session_id": "6726649d-1b5b-44a5-9b21-d12e5c9d971a",
    "title": "My Session",
    "work_dir": "/home/user/projects",
    "archived": false,
    "is_running": true,
    "status": {
      "session_id": "6726649d-1b5b-44a5-9b21-d12e5c9d971a",
      "state": "idle",
      "seq": 5,
      "worker_id": "abc-123",
      "reason": "start",
      "detail": null,
      "updated_at": "2026-05-15T18:00:00Z"
    },
    "created_at": "2026-05-15T10:00:00Z",
    "updated_at": "2026-05-15T18:00:00Z"
  }
]
```

---

#### `POST /api/sessions/`

Create a new session.

**Request Body:** `CreateSessionRequest`

```json
{
  "work_dir": "/home/user/projects/my-project",
  "create_dir": true
}
```

**Response:** `Session`

---

#### `GET /api/sessions/{session_id}`

Get session by ID.

**Path Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `session_id` | UUID | Session identifier |

**Response:** `Session | null`

---

#### `PATCH /api/sessions/{session_id}`

Update session metadata.

**Request Body:** `UpdateSessionRequest`

```json
{
  "title": "New Session Title",
  "archived": false
}
```

**Constraints:**
- `title`: 1-200 characters
- `archived`: boolean to archive/unarchive

**Response:** `Session`

---

#### `DELETE /api/sessions/{session_id}`

Delete a session permanently.

**Response:** `204 No Content`

---

#### `POST /api/sessions/{session_id}/fork`

Fork session at specific turn index.

**Request Body:** `ForkSessionRequest`

```json
{
  "turn_index": 5
}
```

**Response:** `Session` (new forked session)

---

#### `POST /api/sessions/{session_id}/generate-title`

AI-generate session title based on conversation history.

**Response:** `GenerateTitleResponse`

```json
{
  "title": "Generated Title"
}
```

---

#### `GET /api/sessions/{session_id}/git-diff`

Get git diff statistics for session's work directory.

**Response:** `GitDiffStats`

```json
{
  "files_changed": 3,
  "insertions": 42,
  "deletions": 10,
  "file_diffs": [
    {
      "path": "src/main.py",
      "change_type": "modified",
      "insertions": 20,
      "deletions": 5
    }
  ]
}
```

---

### Files

#### `POST /api/sessions/{session_id}/files`

Upload file to session.

**Content-Type:** `multipart/form-data`

**Form Fields:**
| Field | Type | Description |
|-------|------|-------------|
| `file` | binary | File content |

**Constraints:**
- Max file size: 100MB

**Response:** `FileUploadResponse`

```json
{
  "filename": "data.csv",
  "path": "uploads/data.csv",
  "size": 1024
}
```

---

#### `GET /api/sessions/{session_id}/files/{path}`

Get file or list directory from session work_dir.

**Path Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `path` | string | Relative path within work_dir |

**Response:**
- File: `FileResponse` (binary)
- Directory: `Array<FileInfo>`

```json
[
  {
    "name": "src",
    "type": "directory",
    "size": 0
  },
  {
    "name": "main.py",
    "type": "file",
    "size": 2048
  }
]
```

---

#### `GET /api/sessions/{session_id}/uploads/{path}`

Get uploaded file from session uploads directory.

**Response:** `FileResponse` (binary)

---

### Config

#### `GET /api/config/`

Get global kimi-cli config snapshot.

**Response:** `GlobalConfig`

```json
{
  "model": "kimi-k2",
  "thinking": "enabled",
  "api_key_configured": true,
  "work_dir": "/home/user/projects"
}
```

---

#### `PATCH /api/config/`

Update global default model/thinking.

**Request Body:** `UpdateGlobalConfigRequest`

```json
{
  "model": "kimi-k2",
  "thinking": "enabled"
}
```

**Response:** `UpdateGlobalConfigResponse`

---

#### `GET /api/config/toml`

Read kimi-cli config.toml content.

**Response:** `ConfigToml`

```json
{
  "content": "[core]\nmodel = \"kimi-k2\"\n"
}
```

---

#### `PUT /api/config/toml`

Update kimi-cli config.toml content.

**Request Body:** `UpdateConfigTomlRequest`

```json
{
  "content": "[core]\nmodel = \"kimi-k2\"\n"
}
```

**Response:** `UpdateConfigTomlResponse`

---

### Utility

#### `GET /api/work-dirs/`

List available work directories.

**Response:** `Array<string>`

---

#### `GET /api/work-dirs/startup`

Get the startup directory.

**Response:** `StartupDir`

```json
{
  "path": "/home/user"
}
```

---

#### `POST /api/open-in`

Open a path in local application.

**Request Body:** `OpenInRequest`

```json
{
  "path": "/home/user/projects",
  "application": "vscode"
}
```

---

#### `GET /healthz`

Health probe.

**Response:** `{"status": "ok"}`

---

## WebSocket Protocol Schema

### Connection

**URL:** `ws://127.0.0.1:5494/api/sessions/{session_id}/stream`

**Query Parameters:**
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `token` | string | Optional | Auth token if server requires it |

### Server → Client Messages

#### `history_complete`

Signals that history replay is finished and session is ready.

```json
{
  "jsonrpc": "2.0",
  "method": "history_complete",
  "id": "uuid-v4"
}
```

---

#### `session_status`

Session state update.

```json
{
  "jsonrpc": "2.0",
  "method": "session_status",
  "params": {
    "session_id": "6726649d-1b5b-44a5-9b21-d12e5c9d971a",
    "state": "idle",
    "seq": 1,
    "worker_id": "worker-uuid",
    "reason": "start",
    "detail": null,
    "updated_at": "2026-05-15T18:00:00Z"
  }
}
```

**States:**
- `stopped` — Worker not running
- `idle` — Worker ready, waiting for input
- `busy` — Processing a prompt
- `error` — Worker encountered an error
- `restarting` — Worker is restarting

---

#### `event`

Agent event (text, tool calls, notices).

```json
{
  "jsonrpc": "2.0",
  "method": "event",
  "params": {
    "type": "agent_text",
    "payload": {
      "text": "Hello! How can I help?"
    }
  }
}
```

**Event Types:**

| Type | Payload | Description |
|------|---------|-------------|
| `agent_text` | `{text: string}` | Streaming text fragment |
| `agent_response` | `{text: string}` | Complete response text |
| `tool_call` | `{name: string, arguments: object}` | Tool invocation |
| `tool_result` | `{name: string, success: bool, result: any}` | Tool result |
| `notice` | `{text: string, kind: string}` | System notice |

---

#### `request`

Agent request requiring user response.

```json
{
  "jsonrpc": "2.0",
  "method": "request",
  "id": "req-uuid",
  "params": {
    "type": "ApprovalRequest",
    "payload": {
      "tool_name": "WriteFile",
      "description": "Write to file.txt"
    }
  }
}
```

**Request Types:**
- `ApprovalRequest` — Approve/deny a tool action
- `QuestionRequest` — Answer a clarifying question

**Response format:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-uuid",
  "result": {
    "approved": true
  }
}
```

---

### Client → Server Messages

#### `initialize`

Initialize session capabilities.

```json
{
  "jsonrpc": "2.0",
  "method": "initialize",
  "id": "uuid-v4",
  "params": {
    "protocol_version": "1.0",
    "client": {
      "name": "kimi-web-client",
      "version": "1.0.0"
    },
    "capabilities": {
      "supports_question": true,
      "supports_plan_mode": true
    },
    "hooks": [],
    "external_tools": []
  }
}
```

---

#### `prompt`

Send a user prompt/message.

```json
{
  "jsonrpc": "2.0",
  "method": "prompt",
  "id": "uuid-v4",
  "params": {
    "user_input": "Your message here"
  }
}
```

**user_input** can be:
- `string` — Plain text message
- `Array<ContentPart>` — Rich content (text, images, documents)

ContentPart formats:
```json
{"type": "text", "text": "Hello"}
{"type": "image_url", "image_url": {"url": "data:image/png;base64,..."}}
```

---

#### `steer`

Send a steering instruction to active turn.

```json
{
  "jsonrpc": "2.0",
  "method": "steer",
  "id": "uuid-v4",
  "params": {
    "user_input": "Focus on the performance aspect"
  }
}
```

---

#### `set_plan_mode`

Enable or disable plan mode.

```json
{
  "jsonrpc": "2.0",
  "method": "set_plan_mode",
  "id": "uuid-v4",
  "params": {
    "enabled": true
  }
}
```

---

#### `cancel`

Cancel current in-flight prompt.

```json
{
  "jsonrpc": "2.0",
  "method": "cancel",
  "id": "uuid-v4"
}
```

---

#### `replay`

Request history replay.

```json
{
  "jsonrpc": "2.0",
  "method": "replay",
  "id": "uuid-v4"
}
```

---

## Error Codes

### HTTP Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 400 | Bad request |
| 403 | Forbidden (sensitive path, public access denied) |
| 404 | Not found |
| 422 | Validation error |

### WebSocket Close Codes

| Code | Meaning |
|------|---------|
| 4004 | Session not found |
| 4401 | Authentication required |
| 4403 | Access denied / Origin not allowed |

### JSON-RPC Error Codes

| Code | Meaning |
|------|---------|
| -32700 | Parse error |
| -32600 | Invalid request |
| -32601 | Method not found |
| -32602 | Invalid params |
| -32603 | Internal error |
| -32000 | Invalid state (session busy) |
| -32001 | LLM not set |
| -32002 | LLM not supported |
| -32003 | Chat provider error |
| -32004 | Authentication expired |

---

## Data Models

### Session

```json
{
  "session_id": "uuid",
  "title": "string | null",
  "work_dir": "string",
  "archived": "boolean",
  "is_running": "boolean",
  "status": "SessionStatus | null",
  "created_at": "ISO8601",
  "updated_at": "ISO8601"
}
```

### SessionStatus

```json
{
  "session_id": "uuid",
  "state": "stopped | idle | busy | error | restarting",
  "seq": "integer",
  "worker_id": "string | null",
  "reason": "string | null",
  "detail": "string | null",
  "updated_at": "ISO8601"
}
```

### FileInfo

```json
{
  "name": "string",
  "type": "file | directory",
  "size": "integer"
}
```

---

## Example Workflows

### Workflow 1: Create → Prompt → Fork

```bash
# 1. Create session
SESSION=$(./scripts/kimi-web.sh session create --work-dir ~/demo | jq -r '.session_id')

# 2. Send first prompt and wait
python3 scripts/kimi-web-ws.py prompt "$SESSION" "Create a Python script that prints hello" --wait --timeout 60

# 3. Fork at turn 2 (before the response)
FORKED=$(./scripts/kimi-web.sh session fork "$SESSION" --turn 2 | jq -r '.session_id')
echo "Forked to: $FORKED"
```

### Workflow 2: Upload and Analyze

```bash
SESSION="6726649d-1b5b-44a5-9b21-d12e5c9d971a"

# Upload multiple files
./scripts/kimi-web.sh file upload "$SESSION" ./report.pdf
./scripts/kimi-web.sh file upload "$SESSION" ./data.xlsx

# Prompt referencing files
python3 scripts/kimi-web-ws.py prompt "$SESSION" "Summarize report.pdf and analyze data.xlsx" --wait
```

### Workflow 3: Batch Archive Old Sessions

```bash
# List non-archived sessions older than N days and archive them
./scripts/kimi-web.sh session list | jq -r '.[] | select(.updated_at < "2026-05-01") | .session_id' | \
  while read sid; do
    ./scripts/kimi-web.sh session update "$sid" --archive
  done
```

### Workflow 4: Plan Mode Approval

```bash
SESSION="6726649d-1b5b-44a5-9b21-d12e5c9d971a"

# Enable plan mode
python3 scripts/kimi-web-ws.py plan-mode "$SESSION" --enable

# Send prompt that requires approval
python3 scripts/kimi-web-ws.py stream "$SESSION"
# (interactive mode allows approving/rejecting tool calls)
```

### Workflow 5: Config Change and Restart

```bash
# Update model
./scripts/kimi-web.sh config patch --model kimi-k2 --thinking enabled

# All running sessions will auto-restart with new config
```

---

## Implementation Notes

1. **Concurrency**: Only one prompt per session at a time. Sending `prompt` while `busy` returns JSON-RPC error `-32000`.
2. **History Replay**: Every WebSocket connection receives full history before `history_complete`.
3. **File Uploads**: Uploaded files are automatically referenced in subsequent prompts via `<document>`, `<image>`, or `<video>` tags.
4. **Worker Lifecycle**: Worker subprocess starts automatically on first `prompt` or explicit `start`. It can be restarted via config changes.
5. **Plan Mode**: When enabled, agent pauses before executing tool calls and sends `ApprovalRequest` via WebSocket.
6. **Sensitive Paths**: `/api/sessions/{id}/files/{path}` blocks access to `.ssh`, `.aws`, `.gnupg`, `.kube`, and files with extensions `.pem`, `.key`, `.p12`, `.pfx`, `.kdbx`, `.der`.

---

## Future Extensions (Planned)

### Webhook Relay Architecture

Since Kimi Code CLI Web Interface does not natively support webhooks, a relay layer can be built on top of the WebSocket stream:

```
Kimi CLI (:5494) ←──WebSocket──→ Relay Service →──HTTP POST──→ Your Endpoint
```

**Relay responsibilities:**
- Maintain persistent WebSocket connection to one or more sessions
- Filter and forward events to configured webhook URLs
- Implement retry with exponential backoff for failed deliveries
- Buffer events during endpoint downtime

**Target events for webhook delivery:**
| Event | Payload | Use Case |
|-------|---------|----------|
| `session.idle` | `{session_id, turn_index}` | CI/CD pipeline continuation |
| `session.error` | `{session_id, reason, detail}` | Alerting / monitoring |
| `approval.required` | `{request_id, tool_name, description}` | Human-in-the-loop notification |
| `turn.completed` | `{session_id, message_id}` | Logging / analytics |

**Status**: ⏳ Architecture defined, implementation pending.

### Callback Hooks

In-process callbacks for the WebSocket client:
- `on_idle(session_id)` — triggered when session reaches `idle` state
- `on_error(session_id, error)` — triggered on worker or prompt error
- `on_approval_required(request)` — triggered when agent requires human approval

**Status**: ⏳ API design drafted, implementation pending.
