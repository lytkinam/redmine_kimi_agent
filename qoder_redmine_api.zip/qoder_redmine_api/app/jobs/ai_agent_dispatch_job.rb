class AiAgentDispatchJob < ApplicationJob
  queue_as :default

  # Retry up to 2 more times on transient errors (network, timeout)
  retry_on RedmineAiAgent::AgentClient::AgentError, wait: :polynomially_longer, attempts: 3

  def perform(issue_id, ai_agent_id, triggered_by_user_id)
    issue   = Issue.find_by(id: issue_id)
    agent   = AiAgent.find_by(id: ai_agent_id)
    trigger = User.find_by(id: triggered_by_user_id)

    unless issue && agent && trigger
      Rails.logger.warn "[AiAgentDispatchJob] Missing record: issue=#{issue_id} agent=#{ai_agent_id} user=#{triggered_by_user_id}"
      return
    end

    # Create the dispatch record
    dispatch = AiAgentDispatch.create!(
      issue:        issue,
      ai_agent:     agent,
      triggered_by: triggered_by_user_id,
      status:       'running',
      dispatched_at: Time.current
    )

    # Post "task sent" journal note
    start_journal = post_journal(
      issue:   issue,
      user:    trigger,
      message: I18n.t('redmine_ai_agent.journal.dispatch_started',
                      agent_name: agent.name,
                      time:       Time.current.strftime('%Y-%m-%d %H:%M UTC'))
    )
    dispatch.update!(journal_id: start_journal&.id)

    # Call the agent, supporting a tool-call agentic loop
    client     = RedmineAiAgent::AgentClient.new(agent)
    result     = client.call(issue, triggered_by: trigger)
    agent_text = run_tool_loop(client, agent, issue, result)

    # Persist request/response payloads
    dispatch.update!(
      status:           'done',
      request_payload:  result[:request].to_json,
      response_payload: result[:raw_response].to_json,
      completed_at:     Time.current
    )

    # Post agent response as a journal note
    agent_text = agent_text.presence || '_Agent returned an empty response._'
    post_journal(
      issue:   issue,
      user:    trigger,
      message: I18n.t('redmine_ai_agent.journal.dispatch_done',
                      agent_name: agent.name,
                      response:   agent_text)
    )

    Rails.logger.info "[AiAgentDispatchJob] Done: dispatch=#{dispatch.id} issue=#{issue_id} agent=#{agent.name} (#{dispatch.duration}s)"

  rescue RedmineAiAgent::AgentClient::AgentError => e
    handle_error(dispatch, issue, trigger, agent, e.message)
    raise # re-raise so ActiveJob retry mechanism can kick in
  rescue StandardError => e
    handle_error(dispatch, issue, trigger, agent, "#{e.class}: #{e.message}")
    Rails.logger.error "[AiAgentDispatchJob] Unexpected error: #{e.class} #{e.message}\n#{e.backtrace.first(5).join("\n")}"
  end

  private

  def post_journal(issue:, user:, message:)
    journal = issue.init_journal(user, message)
    issue.save!
    journal
  rescue StandardError => e
    Rails.logger.error "[AiAgentDispatchJob] Failed to post journal: #{e.message}"
    nil
  end

  # Agentic loop: if the model returns tool_calls, execute them via RedmineApiSkill
  # and feed results back until it returns final text (max 10 turns).
  def run_tool_loop(client, agent, issue, result)
    base_url = Setting.plugin_redmine_ai_agent['redmine_api_base_url'].to_s
    api_key  = issue.assigned_to&.api_key.to_s
    skill    = RedmineAiAgent::RedmineApiSkill.new(base_url: base_url, api_key: api_key)

    messages = result[:request][:messages]&.dup || []
    raw      = result[:raw_response]

    10.times do
      choice      = raw.dig('choices', 0, 'message') || {}
      tool_calls  = choice['tool_calls']

      # No tool calls → agent has finished, return the text
      return result[:text] if tool_calls.blank?

      # Execute each tool call and collect results
      messages << { role: 'assistant', content: choice['content'], tool_calls: tool_calls }

      tool_calls.each do |tc|
        tool_result = skill.execute_tool_call(tc)
        messages << {
          role:         'tool',
          tool_call_id: tc['id'],
          content:      JSON.generate(tool_result)
        }
      end

      # Send updated message list back to the agent
      next_result = client.send(:post_to_agent, result[:request].merge(messages: messages))
      raw         = next_result
    end

    # Exhausted turns — return whatever text we have
    raw.dig('choices', 0, 'message', 'content').to_s
  rescue StandardError => e
    Rails.logger.error "[AiAgentDispatchJob] tool_loop error: #{e.message}"
    result[:text]
  end

  def handle_error(dispatch, issue, trigger, agent, error_message)
    dispatch&.update(
      status:       'error',
      response_payload: { error: error_message }.to_json,
      completed_at: Time.current
    )

    post_journal(
      issue:   issue,
      user:    trigger,
      message: I18n.t('redmine_ai_agent.journal.dispatch_error',
                      agent_name: agent.name,
                      error:      error_message)
    )
  end
end
