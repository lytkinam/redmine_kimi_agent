class AiAgentDispatch < ActiveRecord::Base
  STATUSES = %w[pending running done error].freeze

  belongs_to :issue
  belongs_to :ai_agent
  belongs_to :triggered_by_user, class_name: 'User', foreign_key: :triggered_by
  belongs_to :journal, optional: true

  validates :issue_id,     presence: true
  validates :ai_agent_id,  presence: true
  validates :triggered_by, presence: true
  validates :status,       inclusion: { in: STATUSES }

  scope :for_issue,  ->(issue)  { where(issue_id: issue.id).order(dispatched_at: :desc) }
  scope :pending,    -> { where(status: 'pending') }
  scope :running,    -> { where(status: 'running') }
  scope :completed,  -> { where(status: 'done') }
  scope :errored,    -> { where(status: 'error') }

  def pending?   = status == 'pending'
  def running?   = status == 'running'
  def done?      = status == 'done'
  def error?     = status == 'error'
  def finished?  = done? || error?

  def duration
    return nil unless dispatched_at && completed_at

    (completed_at - dispatched_at).round(1)
  end

  def request_data
    JSON.parse(request_payload) if request_payload.present?
  rescue JSON::ParserError
    nil
  end

  def response_data
    JSON.parse(response_payload) if response_payload.present?
  rescue JSON::ParserError
    nil
  end
end
