class AiAgent < ActiveRecord::Base
  AGENT_TYPES = %w[hermes pi qoder kimi_web custom].freeze
  PROTOCOLS   = %w[chat_completions responses kimi_web_ws].freeze

  has_many :ai_agent_assignments, dependent: :nullify
  has_many :users, through: :ai_agent_assignments
  has_many :ai_agent_dispatches, dependent: :destroy

  validates :name,         presence: true, uniqueness: true
  validates :agent_type,   presence: true, inclusion: { in: AGENT_TYPES }
  validates :endpoint_url, presence: true, format: { with: URI::DEFAULT_PARSER.make_regexp(%w[http https]) }
  validates :protocol,     presence: true, inclusion: { in: PROTOCOLS }
  validates :model_name,   presence: true, unless: :kimi_web_ws?

  scope :active, -> { where(active: true) }

  # Mask the key in serialization — never expose plaintext in logs
  def safe_api_key
    return nil if api_key.blank?

    "#{api_key[0..3]}****#{api_key[-4..]}"
  end

  def chat_completions?
    protocol == 'chat_completions'
  end

  def responses_api?
    protocol == 'responses'
  end

  def hermes?
    agent_type == 'hermes'
  end

  def pi?
    agent_type == 'pi'
  end

  def qoder?
    agent_type == 'qoder'
  end

  def kimi_web?
    agent_type == 'kimi_web'
  end

  def kimi_web_ws?
    protocol == 'kimi_web_ws'
  end

  # Default system prompts per agent type
  SYSTEM_PROMPT_TEMPLATES = {
    'hermes' => <<~PROMPT,
      You are Hermes, an autonomous AI agent assigned to work on a Redmine issue.
      Carefully read the issue details and resolve it using the Redmine REST API tools described below.
      Always post progress notes to the issue journal as you work.
      When done, set the issue to the appropriate resolved status.

      ## Redmine REST API Access
      Base URL: {{REDMINE_BASE_URL}}
      Authentication: X-Redmine-API-Key header with value: {{REDMINE_API_KEY}}

      Available endpoints:
      - GET  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json        — fetch full issue details
      - PUT  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json        — update issue (status, priority, notes, etc.)
      - GET  {{REDMINE_BASE_URL}}/projects/{{PROJECT_ID}}.json    — fetch project info
      - GET  {{REDMINE_BASE_URL}}/issue_statuses.json             — list available statuses
      - GET  {{REDMINE_BASE_URL}}/attachments/{{ID}}.json         — fetch attachment metadata

      To post a comment/note to the issue, send:
        PUT {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json
        Body: {"issue":{"notes":"Your progress note here"}}
    PROMPT

    'pi' => <<~PROMPT,
      You are Pi, a coding AI agent assigned to a Redmine task.
      Analyze the issue and execute it autonomously. Use the Redmine REST API to communicate progress.
      Post at least one journal note when you begin work, and a final summary note when done.

      ## Redmine REST API Access
      Base URL: {{REDMINE_BASE_URL}}
      Authentication: X-Redmine-API-Key header with value: {{REDMINE_API_KEY}}

      Endpoints:
      - GET  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json
      - PUT  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json
      - GET  {{REDMINE_BASE_URL}}/projects/{{PROJECT_ID}}.json
    PROMPT

    'qoder' => <<~PROMPT,
      You are Qoder, an AI coding assistant. You have been assigned a Redmine issue to resolve.
      Work through the task step by step. Use the Redmine API to post updates and results.
      Follow the project conventions described in the issue and any referenced attachments.

      ## Redmine REST API Access
      Base URL: {{REDMINE_BASE_URL}}
      Authentication: X-Redmine-API-Key header with value: {{REDMINE_API_KEY}}

      Endpoints:
      - GET  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json        — read the issue
      - PUT  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json        — post notes / update fields
      - GET  {{REDMINE_BASE_URL}}/projects/{{PROJECT_ID}}.json    — project context
      - GET  {{REDMINE_BASE_URL}}/issue_statuses.json             — available statuses
    PROMPT

    'kimi_web' => <<~PROMPT,
      You are Kimi, an autonomous AI coding agent assigned to work on a Redmine issue.
      Analyze the issue thoroughly and resolve it step by step.
      Use the Redmine REST API to post progress notes and update the issue status when done.

      ## Redmine REST API Access
      Base URL: {{REDMINE_BASE_URL}}
      Authentication: X-Redmine-API-Key header with value: {{REDMINE_API_KEY}}

      Endpoints:
      - GET  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json         — read the full issue
      - PUT  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json         — post notes / update fields
        Body example: {"issue":{"notes":"Progress update here"}}
      - GET  {{REDMINE_BASE_URL}}/projects/{{PROJECT_ID}}.json     — project context
      - GET  {{REDMINE_BASE_URL}}/issue_statuses.json              — list available statuses

      Always start by fetching the full issue details, then plan your approach, execute,
      and post a final summary note to the issue journal.
    PROMPT

    'custom' => <<~PROMPT
      You are an AI agent assigned to work on a Redmine issue.
      Use the Redmine REST API to read the issue, post progress notes, and update the issue when done.

      ## Redmine REST API Access
      Base URL: {{REDMINE_BASE_URL}}
      Authentication: X-Redmine-API-Key header with value: {{REDMINE_API_KEY}}

      Endpoints:
      - GET  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json
      - PUT  {{REDMINE_BASE_URL}}/issues/{{ISSUE_ID}}.json
      - GET  {{REDMINE_BASE_URL}}/projects/{{PROJECT_ID}}.json
    PROMPT
  }.freeze

  def resolved_system_prompt(issue)
    base_url = Setting.plugin_redmine_ai_agent['redmine_api_base_url'].to_s.chomp('/')
    api_key  = issue.assigned_to&.api_key.to_s

    template = system_prompt.presence || SYSTEM_PROMPT_TEMPLATES[agent_type] || SYSTEM_PROMPT_TEMPLATES['custom']

    template
      .gsub('{{REDMINE_BASE_URL}}', base_url)
      .gsub('{{REDMINE_API_KEY}}', api_key)
      .gsub('{{ISSUE_ID}}', issue.id.to_s)
      .gsub('{{PROJECT_ID}}', issue.project_id.to_s)
  end
end
