class AiAgentAssignment < ActiveRecord::Base
  belongs_to :user
  belongs_to :ai_agent

  validates :user_id,     presence: true, uniqueness: true
  validates :ai_agent_id, presence: true

  # Convenience: find assignment for a user (nil if none)
  def self.for_user(user)
    find_by(user: user)
  end

  # Returns the active agent for a user, or nil
  def self.agent_for(user)
    assignment = joins(:ai_agent)
                   .where(user: user)
                   .where(ai_agents: { active: true })
                   .first
    assignment&.ai_agent
  end

  def auto_dispatch?
    auto_dispatch
  end
end
