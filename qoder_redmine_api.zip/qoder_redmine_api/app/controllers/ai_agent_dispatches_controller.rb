class AiAgentDispatchesController < ApplicationController
  before_action :find_issue
  before_action :authorize_dispatch, only: [:create]

  def index
    @dispatches = AiAgentDispatch.for_issue(@issue).includes(:ai_agent, :triggered_by_user)
  end

  def show
    @dispatch = AiAgentDispatch.find(params[:id])
    render_404 unless @dispatch.issue_id == @issue.id
  end

  # POST /issues/:issue_id/ai_agent_dispatches
  # Manually trigger dispatch (or re-dispatch) from the issue page
  def create
    assignment = AiAgentAssignment.joins(:ai_agent)
                                  .where(user_id: @issue.assigned_to_id)
                                  .where(ai_agents: { active: true })
                                  .first

    unless assignment
      flash[:error] = l('redmine_ai_agent.errors.no_agent_for_assignee')
      return redirect_to issue_path(@issue)
    end

    AiAgentDispatchJob.perform_later(
      @issue.id,
      assignment.ai_agent_id,
      User.current.id
    )

    flash[:notice] = l('redmine_ai_agent.notices.dispatch_enqueued',
                       agent_name: assignment.ai_agent.name)
    redirect_to issue_path(@issue)
  end

  private

  def find_issue
    @issue = Issue.find(params[:issue_id])
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def authorize_dispatch
    render_403 unless User.current.allowed_to?(:dispatch_ai_agent, @issue.project)
  end

  def issue_path(issue)
    "/issues/#{issue.id}"
  end
end
