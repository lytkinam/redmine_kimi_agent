class AiAgentsController < ApplicationController
  before_action :require_admin
  before_action :find_agent, only: [:show, :edit, :update, :destroy, :test_connection]

  def index
    @agents = AiAgent.order(:name)
  end

  def show
  end

  def new
    @agent = AiAgent.new(
      agent_type: 'custom',
      protocol:   'chat_completions',
      active:     true,
      model_name: 'gpt-4o'
    )
  end

  def create
    @agent = AiAgent.new(agent_params)
    if @agent.save
      flash[:notice] = l(:notice_successful_create)
      redirect_to ai_agents_path
    else
      render :new
    end
  end

  def edit
  end

  def update
    if @agent.update(agent_params)
      flash[:notice] = l(:notice_successful_update)
      redirect_to ai_agents_path
    else
      render :edit
    end
  end

  def destroy
    @agent.destroy
    flash[:notice] = l(:notice_successful_delete)
    redirect_to ai_agents_path
  end

  # POST /ai_agents/:id/test_connection
  def test_connection
    # Kimi Web: just hit /healthz
    if @agent.kimi_web_ws?
      uri = URI.parse("#{@agent.endpoint_url.chomp('/')}/healthz")
      req = Net::HTTP::Get.new(uri)
      req['Authorization'] = "Bearer #{@agent.api_key}" if @agent.api_key.present?
      http = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl = uri.scheme == 'https'
      http.open_timeout = 10
      http.read_timeout = 10
      res = http.request(req)
      return render json: { ok: res.is_a?(Net::HTTPSuccess), status: res.code, body: res.body[0..200] }
    end

    # Standard OpenAI-compatible agents: minimal chat ping
    if @agent.chat_completions?
      payload = {
        model:    @agent.model_name,
        messages: [{ role: 'user', content: 'ping' }],
        max_tokens: 5
      }
      endpoint = "#{@agent.endpoint_url.chomp('/')}/v1/chat/completions"
    else
      payload = { model: @agent.model_name, input: 'ping' }
      endpoint = "#{@agent.endpoint_url.chomp('/')}/v1/responses"
    end

    uri = URI.parse(endpoint)
    req = Net::HTTP::Post.new(uri)
    req['Content-Type']  = 'application/json'
    req['Authorization'] = "Bearer #{@agent.api_key}" if @agent.api_key.present?
    req.body = payload.to_json

    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = uri.scheme == 'https'
    http.open_timeout = 10
    http.read_timeout = 15

    res = http.request(req)
    render json: { ok: res.is_a?(Net::HTTPSuccess), status: res.code, body: res.body[0..500] }
  rescue StandardError => e
    render json: { ok: false, error: e.message }
  end

  private

  def find_agent
    @agent = AiAgent.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def agent_params
    params.require(:ai_agent).permit(
      :name, :agent_type, :endpoint_url, :protocol,
      :api_key, :model_name, :system_prompt, :active,
      :kimi_web_session_id, :kimi_web_work_dir, :kimi_web_timeout
    )
  end
end
