class AiAgentAssignmentsController < ApplicationController
  before_action :require_admin

  def index
    @assignments = AiAgentAssignment.includes(:user, :ai_agent).order('users.login')
    @agents      = AiAgent.active.order(:name)
    @users       = User.active.order(:login)
  end

  def new
    @assignment = AiAgentAssignment.new
    @agents     = AiAgent.active.order(:name)
    @users      = User.active.where.not(id: AiAgentAssignment.select(:user_id)).order(:login)
  end

  def create
    @assignment = AiAgentAssignment.new(assignment_params)
    if @assignment.save
      flash[:notice] = l(:notice_successful_create)
      redirect_to ai_agent_assignments_path
    else
      @agents = AiAgent.active.order(:name)
      @users  = User.active.order(:login)
      render :new
    end
  end

  def edit
    @assignment = AiAgentAssignment.find(params[:id])
    @agents     = AiAgent.active.order(:name)
  end

  def update
    @assignment = AiAgentAssignment.find(params[:id])
    if @assignment.update(assignment_params)
      flash[:notice] = l(:notice_successful_update)
      redirect_to ai_agent_assignments_path
    else
      @agents = AiAgent.active.order(:name)
      render :edit
    end
  end

  def destroy
    AiAgentAssignment.find(params[:id]).destroy
    flash[:notice] = l(:notice_successful_delete)
    redirect_to ai_agent_assignments_path
  end

  private

  def assignment_params
    params.require(:ai_agent_assignment).permit(:user_id, :ai_agent_id, :auto_dispatch)
  end
end
