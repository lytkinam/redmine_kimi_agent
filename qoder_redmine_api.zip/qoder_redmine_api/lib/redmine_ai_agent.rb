require 'redmine_ai_agent/agent_client'
require 'redmine_ai_agent/kimi_web_client'
require 'redmine_ai_agent/hooks'
require 'redmine_ai_agent/redmine_api_skill'

module RedmineAiAgent
  # Re-export so callers don't need the full namespace
  AgentError = AgentClient::AgentError
end

# Register the hook listener with Redmine
RedmineAiAgent::Hooks
