module RedmineAiAgent
  class Hooks < Redmine::Hook::ViewListener
    # Triggered after an issue is updated (edit action saves successfully)
    def controller_issues_edit_after_save(context = {})
      return unless plugin_enabled?

      issue = context[:issue]
      return unless issue

      # Only fire if the assignee changed in this edit
      check_and_auto_dispatch(issue, triggered_by: context[:controller]&.current_user)
    end

    # Triggered after a new issue is created
    def controller_issues_new_after_save(context = {})
      return unless plugin_enabled?

      issue = context[:issue]
      return unless issue&.assigned_to_id.present?

      check_and_auto_dispatch(issue, triggered_by: context[:controller]&.current_user)
    end

    # -----------------------------------------------------------------------
    # View hooks — inject "Send to AI Agent" panel into the issue show page
    # -----------------------------------------------------------------------

    def view_issues_show_details_bottom(context = {})
      issue = context[:issue]
      return unless issue

      assignment = AiAgentAssignment.joins(:ai_agent)
                                    .where(user_id: issue.assigned_to_id)
                                    .where(ai_agents: { active: true })
                                    .first
      return unless assignment

      context[:controller].send(:render_to_string,
        partial: 'ai_agent_dispatches/dispatch_panel',
        locals:  {
          issue:       issue,
          agent:       assignment.ai_agent,
          assignment:  assignment,
          dispatches:  AiAgentDispatch.for_issue(issue).limit(10)
        }
      )
    end

    private

    def plugin_enabled?
      Setting.plugin_redmine_ai_agent['enabled'].to_s == 'true'
    end

    def check_and_auto_dispatch(issue, triggered_by:)
      assignee = issue.assigned_to
      return unless assignee.is_a?(User)

      assignment = AiAgentAssignment.joins(:ai_agent)
                                    .where(user_id: assignee.id)
                                    .where(ai_agents: { active: true })
                                    .first
      return unless assignment&.auto_dispatch?

      trigger_user = triggered_by || User.system
      AiAgentDispatchJob.perform_later(
        issue.id,
        assignment.ai_agent_id,
        trigger_user.id
      )
    end
  end
end
