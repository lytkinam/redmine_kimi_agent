require 'net/http'
require 'json'

module RedmineAiAgent
  # RedmineApiSkill provides standalone helper methods for executing
  # Redmine REST API calls on behalf of an AI agent.
  #
  # These are invoked server-side when an agent response contains
  # tool_calls (OpenAI function-calling format).  The job can call
  # execute_tool_call() in a loop until the agent stops returning calls.
  #
  # Example tool_call from agent response:
  #   {
  #     "id": "call_abc",
  #     "type": "function",
  #     "function": { "name": "redmine_update_issue",
  #                   "arguments": "{\"issue_id\": 42, \"notes\": \"Work in progress\"}" }
  #   }
  class RedmineApiSkill
    class RedmineApiError < StandardError
      attr_reader :status
      def initialize(msg, status: nil)
        super(msg)
        @status = status
      end
    end

    def initialize(base_url:, api_key:, timeout: 30)
      @base_url = base_url.to_s.chomp('/')
      @api_key  = api_key.to_s
      @timeout  = timeout.to_i
    end

    # Dispatch a single tool_call hash from an agent response.
    # Returns a JSON-serialisable result hash.
    def execute_tool_call(tool_call)
      fn_name = tool_call.dig('function', 'name').to_s
      args    = JSON.parse(tool_call.dig('function', 'arguments').to_s) rescue {}

      case fn_name
      when 'redmine_get_issue'
        get_issue(args['issue_id'])
      when 'redmine_update_issue'
        update_issue(
          args['issue_id'],
          notes:      args['notes'],
          status_id:  args['status_id'],
          done_ratio: args['done_ratio']
        )
      when 'redmine_list_statuses'
        list_statuses
      when 'redmine_get_project'
        get_project(args['project_id'])
      else
        { error: "Unknown tool: #{fn_name}" }
      end
    rescue RedmineApiError => e
      { error: e.message, status: e.status }
    rescue StandardError => e
      { error: "#{e.class}: #{e.message}" }
    end

    # -----------------------------------------------------------------------
    # Redmine REST calls
    # -----------------------------------------------------------------------

    def get_issue(issue_id)
      get("/issues/#{issue_id}.json?include=journals,attachments")
    end

    def update_issue(issue_id, notes: nil, status_id: nil, done_ratio: nil)
      body = {}
      body[:notes]      = notes      if notes
      body[:status_id]  = status_id  if status_id
      body[:done_ratio] = done_ratio unless done_ratio.nil?

      put("/issues/#{issue_id}.json", { issue: body })
    end

    def list_statuses
      get('/issue_statuses.json')
    end

    def get_project(project_id)
      get("/projects/#{project_id}.json?include=members")
    end

    private

    def get(path)
      uri     = URI.parse("#{@base_url}#{path}")
      request = Net::HTTP::Get.new(uri)
      request['X-Redmine-API-Key'] = @api_key
      request['Content-Type']      = 'application/json'
      perform(uri, request)
    end

    def put(path, body)
      uri     = URI.parse("#{@base_url}#{path}")
      request = Net::HTTP::Put.new(uri)
      request['X-Redmine-API-Key'] = @api_key
      request['Content-Type']      = 'application/json'
      request.body = JSON.generate(body)
      perform(uri, request)
    end

    def perform(uri, request)
      http              = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl      = uri.scheme == 'https'
      http.open_timeout = 10
      http.read_timeout = @timeout

      response = http.request(request)

      unless response.is_a?(Net::HTTPSuccess)
        raise RedmineApiError.new(
          "Redmine API #{request.method} #{uri.path} → HTTP #{response.code}",
          status: response.code.to_i
        )
      end

      response.body.present? ? JSON.parse(response.body) : { ok: true }
    rescue Net::TimeoutError => e
      raise RedmineApiError.new("Redmine API timeout: #{e.message}")
    rescue JSON::ParserError => e
      raise RedmineApiError.new("Redmine API returned invalid JSON: #{e.message}")
    end
  end
end
