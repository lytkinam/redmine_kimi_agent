require 'net/http'
require 'uri'
require 'json'

module RedmineAiAgent
  # Thin HTTP client that speaks both OpenAI Chat Completions and Responses API.
  # Returns a plain Ruby hash representing the agent's response.
  class AgentClient
    # Raised when the agent endpoint returns a non-2xx status or network error.
    class AgentError < StandardError
      attr_reader :status, :body

      def initialize(message, status: nil, body: nil)
        super(message)
        @status = status
        @body   = body
      end
    end

    DEFAULT_TIMEOUT = 120 # seconds

    def initialize(agent)
      @agent = agent
    end

    # Main entry point.
    # Returns { text: String, raw_response: Hash, request: Hash }
    def call(issue, triggered_by:)
      # Kimi Web uses its own WebSocket client — delegate entirely
      if @agent.kimi_web_ws?
        return KimiWebClient.new(@agent).call(issue)
      end

      payload = build_payload(issue)
      raw     = post_to_agent(payload)

      {
        text:         extract_text(raw),
        raw_response: raw,
        request:      payload
      }
    end

    private

    # -----------------------------------------------------------------------
    # Payload builders
    # -----------------------------------------------------------------------

    def build_payload(issue)
      if @agent.chat_completions?
        build_chat_completions_payload(issue)
      else
        build_responses_payload(issue)
      end
    end

    def build_chat_completions_payload(issue)
      {
        model:    @agent.model_name,
        messages: [
          { role: 'system', content: @agent.resolved_system_prompt(issue) },
          { role: 'user',   content: issue_context_message(issue) }
        ],
        # Tell the agent it may call back into Redmine — pass tools only for hermes/pi
        tools:       redmine_tools(issue),
        tool_choice: 'auto'
      }.tap { |h| h.delete(:tools) if h[:tools].empty? }
    end

    def build_responses_payload(issue)
      {
        model:        @agent.model_name,
        input:        issue_context_message(issue),
        instructions: @agent.resolved_system_prompt(issue)
      }
    end

    # -----------------------------------------------------------------------
    # Issue context message (user turn)
    # -----------------------------------------------------------------------

    def issue_context_message(issue)
      base_url = Setting.plugin_redmine_ai_agent['redmine_api_base_url'].to_s.chomp('/')

      lines = []
      lines << "# Issue ##{issue.id}: #{issue.subject}"
      lines << ""
      lines << "**Project:** #{issue.project.name}"
      lines << "**Status:** #{issue.status.name}"
      lines << "**Priority:** #{issue.priority.name}"
      lines << "**Assignee:** #{issue.assigned_to&.name}"
      lines << "**Author:** #{issue.author.name}"
      lines << "**Created:** #{issue.created_on&.strftime('%Y-%m-%d')}"
      lines << "**Updated:** #{issue.updated_on&.strftime('%Y-%m-%d')}"
      lines << "**URL:** #{base_url}/issues/#{issue.id}"
      lines << ""
      lines << "## Description"
      lines << (issue.description.presence || '_No description provided._')

      if issue.journals.any?
        lines << ""
        lines << "## Recent Journal Notes"
        issue.journals.includes(:user).order(:created_on).last(5).each do |j|
          next if j.notes.blank?

          lines << "**#{j.user.name} (#{j.created_on.strftime('%Y-%m-%d')}):** #{j.notes}"
        end
      end

      lines.join("\n")
    end

    # -----------------------------------------------------------------------
    # OpenAI-style function/tool definitions for Redmine REST API
    # These are included for agents that support tool_calls (Hermes, Pi).
    # -----------------------------------------------------------------------

    def redmine_tools(issue)
      # Kimi Web handles tool execution natively inside its own session loop
      return [] if @agent.kimi_web_ws?
      # Qoder uses its own skill system
      return [] if @agent.qoder?

      base_url = Setting.plugin_redmine_ai_agent['redmine_api_base_url'].to_s.chomp('/')

      [
        {
          type: 'function',
          function: {
            name:        'redmine_get_issue',
            description: 'Fetch full details of a Redmine issue including description, journals, and status.',
            parameters:  {
              type:       'object',
              properties: {
                issue_id: { type: 'integer', description: 'The issue ID to fetch' }
              },
              required: ['issue_id']
            }
          }
        },
        {
          type: 'function',
          function: {
            name:        'redmine_update_issue',
            description: 'Update a Redmine issue — post a journal note, change status, or update other fields.',
            parameters:  {
              type:       'object',
              properties: {
                issue_id: { type: 'integer', description: 'The issue ID to update' },
                notes:    { type: 'string',  description: 'Journal note to post (visible to all users)' },
                status_id: { type: 'integer', description: 'New status ID (use redmine_list_statuses to find IDs)' },
                done_ratio: { type: 'integer', description: 'Completion percentage 0-100' }
              },
              required: ['issue_id']
            }
          }
        },
        {
          type: 'function',
          function: {
            name:        'redmine_list_statuses',
            description: 'List all available issue statuses with their IDs.',
            parameters:  {
              type:       'object',
              properties: {},
              required:   []
            }
          }
        },
        {
          type: 'function',
          function: {
            name:        'redmine_get_project',
            description: 'Get project details and its members.',
            parameters:  {
              type:       'object',
              properties: {
                project_id: { type: 'string', description: 'Project ID or identifier slug' }
              },
              required: ['project_id']
            }
          }
        }
      ]
    end

    # -----------------------------------------------------------------------
    # HTTP transport
    # -----------------------------------------------------------------------

    def post_to_agent(payload)
      endpoint = resolve_endpoint
      uri      = URI.parse(endpoint)

      request = Net::HTTP::Post.new(uri)
      request['Content-Type'] = 'application/json'
      request['Authorization'] = "Bearer #{@agent.api_key}" if @agent.api_key.present?

      request.body = JSON.generate(payload)

      timeout = Setting.plugin_redmine_ai_agent['default_timeout'].to_i
      timeout = DEFAULT_TIMEOUT if timeout <= 0

      http = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl     = uri.scheme == 'https'
      http.read_timeout = timeout
      http.open_timeout = 15

      Rails.logger.info "[RedmineAiAgent] POST #{endpoint} (agent=#{@agent.name})"

      response = http.request(request)

      unless response.is_a?(Net::HTTPSuccess)
        raise AgentError.new(
          "Agent #{@agent.name} returned HTTP #{response.code}",
          status: response.code.to_i,
          body:   response.body
        )
      end

      JSON.parse(response.body)
    rescue Net::TimeoutError, Net::OpenTimeout => e
      raise AgentError.new("Timeout calling agent #{@agent.name}: #{e.message}")
    rescue JSON::ParserError => e
      raise AgentError.new("Invalid JSON from agent #{@agent.name}: #{e.message}")
    rescue URI::InvalidURIError => e
      raise AgentError.new("Invalid endpoint URL for agent #{@agent.name}: #{e.message}")
    end

    def resolve_endpoint
      base = @agent.endpoint_url.to_s.chomp('/')

      if @agent.chat_completions?
        "#{base}/v1/chat/completions"
      else
        "#{base}/v1/responses"
      end
    end

    # -----------------------------------------------------------------------
    # Response parsing
    # -----------------------------------------------------------------------

    def extract_text(raw)
      if @agent.chat_completions?
        # Standard OpenAI Chat Completions structure
        raw.dig('choices', 0, 'message', 'content').to_s
      else
        # OpenAI Responses API structure
        output = raw['output']
        if output.is_a?(Array)
          output.filter_map { |item| item.dig('content', 0, 'text') }.join("\n")
        else
          raw['output_text'].to_s
        end
      end
    end
  end
end
