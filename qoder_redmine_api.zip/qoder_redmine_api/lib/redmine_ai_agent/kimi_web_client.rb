require 'socket'
require 'openssl'
require 'uri'
require 'json'
require 'securerandom'
require 'net/http'

module RedmineAiAgent
  # KimiWebClient drives the Kimi Code CLI Web Interface via:
  #   1. REST API  — session create / health check    (Net::HTTP)
  #   2. WebSocket — JSON-RPC 2.0 message loop        (raw TCP + HTTP Upgrade)
  #
  # Protocol summary (from kimi-web SKILL.md):
  #   Connect → history replay → history_complete → initialize → prompt → wait idle → collect text
  #
  # The agent.endpoint_url should be the Kimi web UI base, e.g. http://127.0.0.1:5494
  # The agent.api_key is optional (used as ?token= query param if set).
  # The agent.kimi_web_session_id, if present, is reused; otherwise a new session is created.
  # The agent.kimi_web_work_dir is used when creating a new session.

  class KimiWebClient
    class KimiError < StandardError; end
    class KimiTimeoutError < KimiError; end
    class KimiSessionBusyError < KimiError; end

    WS_FRAME_OPCODE_TEXT  = 0x1
    WS_FRAME_OPCODE_CLOSE = 0x8
    WS_FRAME_OPCODE_PING  = 0x9
    WS_FRAME_OPCODE_PONG  = 0xA

    def initialize(agent)
      @agent   = agent
      @base    = agent.endpoint_url.to_s.chomp('/')
      @token   = agent.api_key.presence
      @timeout = (agent.kimi_web_timeout || 120).to_i
    end

    # Main entry. Returns { text: String, raw_response: Hash, request: Hash }
    def call(issue)
      session_id = ensure_session!
      prompt_text = build_prompt(issue)

      Rails.logger.info "[KimiWebClient] Using session #{session_id} for issue ##{issue.id}"

      result_text = websocket_prompt(session_id, prompt_text)

      {
        text:         result_text,
        raw_response: { session_id: session_id, agent_response: result_text },
        request:      { session_id: session_id, prompt: prompt_text }
      }
    rescue KimiError => e
      raise RedmineAiAgent::AgentClient::AgentError.new(
        "Kimi Web error: #{e.message}",
        status: nil,
        body:   e.message
      )
    end

    private

    # -------------------------------------------------------------------------
    # Session management (REST)
    # -------------------------------------------------------------------------

    def ensure_session!
      # Reuse a pinned session if configured and still alive
      if @agent.kimi_web_session_id.present?
        return @agent.kimi_web_session_id if session_alive?(@agent.kimi_web_session_id)

        Rails.logger.warn "[KimiWebClient] Pinned session #{@agent.kimi_web_session_id} is gone, creating new one"
      end

      create_session!
    end

    def session_alive?(session_id)
      uri = URI.parse("#{@base}/api/sessions/#{session_id}")
      res = http_get(uri)
      res.is_a?(Net::HTTPSuccess)
    rescue StandardError
      false
    end

    def create_session!
      uri  = URI.parse("#{@base}/api/sessions/")
      body = {}
      body[:work_dir]   = @agent.kimi_web_work_dir if @agent.kimi_web_work_dir.present?
      body[:create_dir] = true                      if @agent.kimi_web_work_dir.present?

      res  = http_post(uri, body)
      data = JSON.parse(res.body)
      sid  = data['session_id']

      raise KimiError, "Kimi session create failed: #{res.code} #{res.body[0..200]}" unless res.is_a?(Net::HTTPSuccess)
      raise KimiError, 'Kimi session create returned no session_id' unless sid.present?

      Rails.logger.info "[KimiWebClient] Created new session #{sid}"
      sid
    end

    # -------------------------------------------------------------------------
    # Prompt composition
    # -------------------------------------------------------------------------

    def build_prompt(issue)
      base_url = Setting.plugin_redmine_ai_agent['redmine_api_base_url'].to_s.chomp('/')
      api_key  = issue.assigned_to&.api_key.to_s

      lines = []
      lines << "# Redmine Issue ##{issue.id}: #{issue.subject}"
      lines << ""
      lines << "**Project:** #{issue.project.name}"
      lines << "**Status:** #{issue.status.name}"
      lines << "**Priority:** #{issue.priority.name}"
      lines << "**Assignee:** #{issue.assigned_to&.name}"
      lines << "**URL:** #{base_url}/issues/#{issue.id}"
      lines << ""
      lines << "## Description"
      lines << (issue.description.presence || '_No description._')

      if issue.journals.any?
        lines << ""
        lines << "## Recent Notes"
        issue.journals.includes(:user).order(:created_on).last(5).each do |j|
          next if j.notes.blank?

          lines << "**#{j.user.name}:** #{j.notes}"
        end
      end

      lines << ""
      lines << "---"
      lines << @agent.resolved_system_prompt(issue)
      lines.join("\n")
    end

    # -------------------------------------------------------------------------
    # WebSocket JSON-RPC 2.0 session
    # -------------------------------------------------------------------------

    def websocket_prompt(session_id, prompt_text)
      uri    = ws_uri(session_id)
      socket = open_socket(uri)

      begin
        do_handshake(socket, uri)
        collected_text = drive_session(socket, prompt_text)
      ensure
        close_socket(socket)
      end

      collected_text
    end

    def ws_uri(session_id)
      http_base = @base.sub(/\Ahttp/, 'ws')
      path      = "/api/sessions/#{session_id}/stream"
      path     += "?token=#{@token}" if @token.present?
      URI.parse("#{http_base}#{path}")
    end

    def open_socket(uri)
      if uri.scheme == 'wss'
        raw = TCPSocket.new(uri.host, uri.port || 443)
        ctx = OpenSSL::SSL::SSLContext.new
        ssl = OpenSSL::SSL::SSLSocket.new(raw, ctx)
        ssl.sync_close = true
        ssl.connect
        ssl
      else
        TCPSocket.new(uri.host, uri.port || 80)
      end
    end

    def close_socket(socket)
      socket&.close
    rescue StandardError
      nil
    end

    def do_handshake(socket, uri)
      nonce = Base64.strict_encode64(SecureRandom.bytes(16))
      host  = uri.host
      host  = "#{host}:#{uri.port}" if uri.port && ![80, 443].include?(uri.port)

      request_line = "GET #{uri.request_uri} HTTP/1.1\r\n"
      headers = {
        'Host'                  => host,
        'Upgrade'               => 'websocket',
        'Connection'            => 'Upgrade',
        'Sec-WebSocket-Key'     => nonce,
        'Sec-WebSocket-Version' => '13'
      }
      headers['Authorization'] = "Bearer #{@token}" if @token.present?

      socket.write(request_line + headers.map { |k, v| "#{k}: #{v}" }.join("\r\n") + "\r\n\r\n")

      # Read HTTP response headers
      response = ''
      loop do
        line = socket.gets("\r\n")
        break if line == "\r\n" || line.nil?

        response += line
      end

      raise KimiError, "WebSocket handshake failed: #{response.lines.first}" unless response.include?('101')
    end

    # Core message loop: initialize → wait history_complete → send prompt → wait idle
    def drive_session(socket, prompt_text)
      text_fragments = []
      history_done   = false
      initialized    = false
      final_text     = nil
      deadline       = Time.current + @timeout

      # Send initialize right away
      send_frame(socket, json_rpc('initialize', {
        protocol_version: '1.0',
        client:           { name: 'redmine-ai-agent', version: '1.0' },
        capabilities:     { supports_question: false, supports_plan_mode: false },
        hooks:            [],
        external_tools:   []
      }))

      loop do
        raise KimiTimeoutError, "Kimi did not respond within #{@timeout}s" if Time.current > deadline

        msg = read_frame(socket, timeout: [deadline - Time.current, 1].max.to_i)
        next if msg.nil? # timeout on read, loop again

        parsed = JSON.parse(msg) rescue next
        method = parsed['method']
        params = parsed['params'] || {}

        case method
        when 'history_complete'
          unless initialized
            send_frame(socket, json_rpc('prompt', { user_input: prompt_text }))
            initialized = true
          end

        when 'session_status'
          state = params['state']
          Rails.logger.debug "[KimiWebClient] session_status: #{state}"

          if state == 'idle' && initialized
            # Agent finished — break out
            final_text = text_fragments.join
            break
          elsif state == 'error'
            raise KimiError, "Kimi session entered error state: #{params['detail']}"
          end

        when 'event'
          case params['type']
          when 'agent_text'
            frag = params.dig('payload', 'text').to_s
            text_fragments << frag unless frag.empty?
          when 'agent_response'
            # Complete response — prefer this over fragments if both present
            full = params.dig('payload', 'text').to_s
            final_text = full unless full.empty?
          when 'notice'
            Rails.logger.info "[KimiWebClient] notice: #{params.dig('payload', 'text')}"
          end

        when 'request'
          # ApprovalRequest / QuestionRequest — auto-approve to keep the agent running
          handle_agent_request(socket, parsed)
        end

        # Close frame from server
        if parsed['method'].nil? && parsed.key?('error')
          raise KimiError, "Kimi JSON-RPC error: #{parsed['error']}"
        end
      end

      final_text || text_fragments.join
    end

    # Auto-approve any agent request (tool approval, questions) so the agent runs unattended
    def handle_agent_request(socket, request_msg)
      req_id   = request_msg['id']
      req_type = request_msg.dig('params', 'type')

      Rails.logger.info "[KimiWebClient] Auto-approving #{req_type} request #{req_id}"

      result = if req_type == 'ApprovalRequest'
                 { approved: true }
               else
                 # QuestionRequest — send an empty acknowledgement
                 { answer: 'Please proceed with the most reasonable option.' }
               end

      send_frame(socket, { 'jsonrpc' => '2.0', 'id' => req_id, 'result' => result })
    end

    # -------------------------------------------------------------------------
    # WebSocket frame encoding / decoding (RFC 6455 minimal subset)
    # -------------------------------------------------------------------------

    def send_frame(socket, data)
      payload = data.is_a?(String) ? data : JSON.generate(data)
      bytes   = payload.bytes

      frame  = [0x81].pack('C')  # FIN + text opcode
      len    = bytes.length

      if len < 126
        frame += [len | 0x80].pack('C')
      elsif len < 65_536
        frame += [126 | 0x80, len].pack('Cn')
      else
        frame += [127 | 0x80, len].pack('CQ>')
      end

      # Masking key (client must mask frames)
      mask   = 4.times.map { rand(256) }
      masked = bytes.each_with_index.map { |b, i| b ^ mask[i % 4] }
      frame += mask.pack('C4') + masked.pack('C*')

      socket.write(frame)
    rescue StandardError => e
      raise KimiError, "WebSocket write error: #{e.message}"
    end

    # Read one WebSocket frame. Returns text payload or nil on timeout.
    def read_frame(socket, timeout: 5)
      return nil unless IO.select([socket], nil, nil, timeout)

      # Read first 2 bytes
      header = read_bytes(socket, 2)
      return nil unless header

      b0, b1   = header.bytes
      _fin     = (b0 & 0x80) != 0
      opcode   = b0 & 0x0F
      masked   = (b1 & 0x80) != 0
      len      = b1 & 0x7F

      len = case len
            when 126 then read_bytes(socket, 2)&.unpack1('n')
            when 127 then read_bytes(socket, 8)&.unpack1('Q>')
            else len
            end

      return nil unless len

      mask_bytes = masked ? read_bytes(socket, 4)&.bytes : nil
      payload    = read_bytes(socket, len)
      return nil unless payload

      if opcode == WS_FRAME_OPCODE_CLOSE
        raise KimiError, 'Server closed WebSocket connection'
      end

      if opcode == WS_FRAME_OPCODE_PING
        send_frame(socket, "\x0A") # pong
        return nil
      end

      return nil unless opcode == WS_FRAME_OPCODE_TEXT

      if masked && mask_bytes
        payload.bytes.each_with_index.map { |b, i| b ^ mask_bytes[i % 4] }.pack('C*').force_encoding('UTF-8')
      else
        payload.force_encoding('UTF-8')
      end
    rescue IOError, Errno::ECONNRESET => e
      raise KimiError, "WebSocket read error: #{e.message}"
    end

    def read_bytes(socket, n)
      buf = ''
      while buf.bytesize < n
        chunk = socket.read(n - buf.bytesize)
        return nil if chunk.nil? || chunk.empty?

        buf += chunk
      end
      buf
    end

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def json_rpc(method, params = {})
      { 'jsonrpc' => '2.0', 'method' => method, 'id' => SecureRandom.uuid, 'params' => params }
    end

    def http_get(uri)
      http = build_http(uri)
      req  = Net::HTTP::Get.new(uri)
      req['Content-Type'] = 'application/json'
      req['Authorization'] = "Bearer #{@token}" if @token.present?
      http.request(req)
    end

    def http_post(uri, body)
      http = build_http(uri)
      req  = Net::HTTP::Post.new(uri)
      req['Content-Type'] = 'application/json'
      req['Authorization'] = "Bearer #{@token}" if @token.present?
      req.body = JSON.generate(body)
      http.request(req)
    end

    def build_http(uri)
      http              = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl      = uri.scheme == 'https'
      http.open_timeout = 10
      http.read_timeout = 30
      http
    end
  end
end
