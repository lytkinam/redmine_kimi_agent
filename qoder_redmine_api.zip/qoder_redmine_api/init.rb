require 'redmine_ai_agent'

Redmine::Plugin.register :redmine_ai_agent do
  name        'Redmine AI Agent'
  author      'qoder_redmine_api'
  description 'Assign AI agents (Hermes, Pi, Qoder, custom OpenAI-compatible) to Redmine users. ' \
              'When an issue is assigned the agent autonomously processes it via the Redmine REST API.'
  version     '0.1.0'
  url         'https://github.com/your-org/redmine_ai_agent'
  requires_redmine version_or_higher: '6.0'

  settings default: {
    'enabled'              => true,
    'redmine_api_base_url' => '',   # e.g. https://redmine.example.com
    'default_timeout'      => 120
  }, partial: 'settings/ai_agent_settings'

  # Admin sidebar entry
  menu :admin_menu, :ai_agents,
       { controller: 'ai_agents', action: 'index' },
       caption: 'AI Agents',
       html:    { class: 'icon icon-robot' }

  # Permission — project-level
  project_module :ai_agent do
    permission :dispatch_ai_agent, ai_agent_dispatches: [:create, :index, :show]
    permission :manage_ai_agents,  ai_agents: [:index, :show, :new, :create, :edit, :update, :destroy],
                                   ai_agent_assignments: [:index, :show, :new, :create, :edit, :update, :destroy]
  end
end
