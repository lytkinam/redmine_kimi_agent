RedmineApp::Application.routes.draw do
  # Admin: agent CRUD with test_connection action
  resources :ai_agents do
    member do
      post :test_connection
    end
  end

  # Admin: user ↔ agent assignment CRUD
  resources :ai_agent_assignments

  # Per-issue dispatch: create (manual trigger) + show (detail view)
  resources :issues do
    resources :ai_agent_dispatches, only: [:create, :index, :show]
  end
end
